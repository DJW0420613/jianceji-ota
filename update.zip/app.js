/* ===================================================================
 * 简策集  Build ancient text and bazi
 * 八字排盘 / 万年历 / 古籍阅读 / 数理分析
 * 农历与节气数据来自 calendar.js（jjonline，1900–2100）
 * =================================================================== */

const STEMS = ['甲','乙','丙','丁','戊','己','庚','辛','壬','癸'];
const BRANCHES = ['子','丑','寅','卯','辰','巳','午','未','申','酉','戌','亥'];
const GAN_WX = {甲:'wood',乙:'wood',丙:'fire',丁:'fire',戊:'earth',己:'earth',庚:'metal',辛:'metal',壬:'water',癸:'water'};
const ZHI_WX = {子:'water',丑:'earth',寅:'wood',卯:'wood',辰:'earth',巳:'fire',午:'fire',未:'earth',申:'metal',酉:'metal',戌:'earth',亥:'water'};
const GAN_NUM = {甲:1,乙:2,丙:3,丁:4,戊:5,己:6,庚:7,辛:8,壬:9,癸:10};
const ZHI_NUM = {子:1,丑:2,寅:3,卯:4,辰:5,巳:6,午:7,未:8,申:9,酉:10,戌:11,亥:12};
const WX_NAME = {wood:'木',fire:'火',earth:'土',metal:'金',water:'水'};
const GZ_60 = Array.from({length:60}, (_,k)=> STEMS[k%10]+BRANCHES[k%12]);
const gzIndex = gz => GZ_60.indexOf(gz);

/* ---------- 四柱扩展信息：十二长生 / 空亡 / 神煞 ---------- */
const CS_NAMES = ['长生','沐浴','冠带','临官','帝旺','衰','病','死','墓','绝','胎','养'];
const GAN_CS = {
  '甲':['亥','子','丑','寅','卯','辰','巳','午','未','申','酉','戌'],
  '乙':['午','巳','辰','卯','寅','丑','子','亥','戌','酉','申','未'],
  '丙':['寅','卯','辰','巳','午','未','申','酉','戌','亥','子','丑'],
  '丁':['酉','申','未','午','巳','辰','卯','寅','丑','子','亥','戌'],
  '戊':['寅','卯','辰','巳','午','未','申','酉','戌','亥','子','丑'],
  '己':['酉','申','未','午','巳','辰','卯','寅','丑','子','亥','戌'],
  '庚':['巳','午','未','申','酉','戌','亥','子','丑','寅','卯','辰'],
  '辛':['子','亥','戌','酉','申','未','午','巳','辰','卯','寅','丑'],
  '壬':['申','酉','戌','亥','子','丑','寅','卯','辰','巳','午','未'],
  '癸':['卯','寅','丑','子','亥','戌','酉','申','未','午','巳','辰']
};
function changshengOf(dayGan, zhi){
  const arr = GAN_CS[dayGan]; if(!arr) return '';
  const i = arr.indexOf(zhi); return i < 0 ? '' : CS_NAMES[i];
}
function kongwangBranches(dayGan, dayZhi){
  const gi = STEMS.indexOf(dayGan), zi = BRANCHES.indexOf(dayZhi);
  if(gi < 0 || zi < 0) return [];
  const head = ((zi - gi) % 12 + 12) % 12;
  return [BRANCHES[(head + 10) % 12], BRANCHES[(head + 11) % 12]];
}
function sanheOf(zhi){
  if(zhi==='申'||zhi==='子'||zhi==='辰') return '水';
  if(zhi==='寅'||zhi==='午'||zhi==='戌') return '火';
  if(zhi==='亥'||zhi==='卯'||zhi==='未') return '木';
  if(zhi==='巳'||zhi==='酉'||zhi==='丑') return '金';
  return '';
}
const SH_MAP = {
  '水':{ma:'寅',tao:'酉',hua:'辰',jiang:'子'},
  '火':{ma:'申',tao:'卯',hua:'戌',jiang:'午'},
  '木':{ma:'巳',tao:'子',hua:'未',jiang:'卯'},
  '金':{ma:'亥',tao:'午',hua:'丑',jiang:'酉'}
};
const TIANYI = {
  '甲':['丑','未'],'戊':['丑','未'],'庚':['寅','午'],
  '乙':['子','申'],'己':['子','申'],
  '丙':['亥','酉'],'丁':['亥','酉'],
  '壬':['卯','巳'],'癸':['卯','巳'],'辛':['寅','午']
};
const YUEDE = {'火':'丙','水':'壬','木':'甲','金':'庚'};
const TIANDE = {
  '寅':{t:'干',v:'丁'},'卯':{t:'支',v:'申'},'辰':{t:'干',v:'壬'},'巳':{t:'干',v:'辛'},
  '午':{t:'支',v:'亥'},'未':{t:'干',v:'癸'},'申':{t:'支',v:'寅'},'酉':{t:'支',v:'辰'},
  '戌':{t:'干',v:'丙'},'亥':{t:'支',v:'卯'},'子':{t:'支',v:'午'},'丑':{t:'干',v:'庚'}
};
function guChenGuaShu(dayZhi){
  if(dayZhi==='寅'||dayZhi==='卯'||dayZhi==='辰') return ['巳','丑'];
  if(dayZhi==='巳'||dayZhi==='午'||dayZhi==='未') return ['申','辰'];
  if(dayZhi==='申'||dayZhi==='酉'||dayZhi==='戌') return ['亥','未'];
  if(dayZhi==='亥'||dayZhi==='子'||dayZhi==='丑') return ['寅','戌'];
  return ['',''];
}
function shenshaOf(zhi, gan, dayGan, dayZhi, monthZhi){
  const list = [];
  if((TIANYI[dayGan]||[]).includes(zhi)) list.push('天乙');
  const sh = sanheOf(dayZhi);
  if(sh){
    const m = SH_MAP[sh];
    if(zhi===m.ma) list.push('驿马');
    if(zhi===m.tao) list.push('桃花');
    if(zhi===m.hua) list.push('华盖');
    const jiangIdx = BRANCHES.indexOf(m.jiang);
    if(zhi===BRANCHES[(jiangIdx + 6) % 12]) list.push('灾煞');
    if(zhi===BRANCHES[(jiangIdx + 1) % 12]) list.push('官符');
  }
  const yd = YUEDE[sanheOf(monthZhi)];
  if(yd && gan === yd) list.push('月德');
  const td = TIANDE[monthZhi];
  if(td){ if(td.t==='支' && td.v===zhi) list.push('天德'); else if(td.t==='干' && td.v===gan) list.push('天德'); }
  const gc = guChenGuaShu(dayZhi);
  if(zhi===gc[0]) list.push('孤辰');
  if(zhi===gc[1]) list.push('寡宿');
  return list;
}
const LUNAR_MONTHS = ['正月','二月','三月','四月','五月','六月','七月','八月','九月','十月','十一月','腊月'];

/* ---------- 干支阴阳（阴/阳支，与小程序 bazi.js 同源） ---------- */
const YANG_ZHI = ['子','寅','辰','午','申','戌'];   // 阳支
const YIN_ZHI  = ['丑','卯','巳','未','酉','亥'];   // 阴支

// 农历日的中文显示：8 → 初八，20 → 二十，30 → 三十
function lunarDayLabel(n){
  const cn = ['零','一','二','三','四','五','六','七','八','九','十'];
  if (n <= 10) return '初' + cn[n];
  if (n < 20)  return '十' + cn[n - 10];
  if (n === 20) return '二十';
  if (n < 30)  return '廿' + cn[n - 20];
  return '三十';
}
/* ---------- 81 数理（姓名学） ---------- */
/* [序号, 五行, 吉凶, 含义]  吉凶: 吉/凶/半 */
const LIUSHIYI = [
 [1,'wood','吉','太极之数，万物开泰，大吉之象'],
 [2,'wood','凶','混沌未开，进退失据，艰难困苦'],
 [3,'fire','吉','进取如意，立业兴家，名利双收'],
 [4,'fire','凶','身遭凶变，破败辛苦，凡事难成'],
 [5,'earth','吉','福禄长寿，阴阳和合，安稳余庆'],
 [6,'earth','吉','安稳余庆，六亲和睦，丰厚圆满'],
 [7,'metal','吉','刚毅果断，独立权威，大吉之数'],
 [8,'metal','吉','意志坚刚，勤勉不懈，成功可期'],
 [9,'water','凶','兴尽凶始，虽得成功，后运多难'],
 [10,'water','凶','万事终局，空虚寂寞，悲惨之数'],
 [11,'wood','吉','稳健吉顺，挽回家运，大吉之数'],
 [12,'wood','凶','薄弱无力，志望难达，欠缺勇气'],
 [13,'fire','吉','智略超群，才艺兼备，富有权威'],
 [14,'fire','凶','忍得苦难，然而枉费，破家之象'],
 [15,'earth','吉','福寿圆满，涵养雅量，德高望重'],
 [16,'earth','吉','厚重载德，安富尊荣，财官双美'],
 [17,'metal','吉','刚柔兼修，突破万难，必获成功'],
 [18,'metal','吉','铁镜重磨，权威显达，有志竟成'],
 [19,'water','凶','多难挫折，灾害交加，万事受阻'],
 [20,'water','凶','非业破运，灾祸频至，短命之数'],
 [21,'wood','吉','明月中天，独立权威，首领之运'],
 [22,'wood','凶','秋草逢霜，怀才不遇，困难重重'],
 [23,'fire','吉','旭日东升，壮丽可嘉，功名荣达'],
 [24,'fire','吉','金钱丰惠，白手成家，财源广进'],
 [25,'earth','吉','英俊刚毅，资性英敏，成就可期'],
 [26,'earth','凶','变怪奇异，英雄遭难，波澜重叠'],
 [27,'metal','凶','欲望无止，多受诽谤，苦难缠身'],
 [28,'metal','凶','遭难废疾，家亲缘薄，逆境之数'],
 [29,'water','吉','智谋兼备，如龙得云，成就大业'],
 [30,'water','凶','浮沉不定，吉凶难分，晚景凄凉'],
 [31,'wood','吉','春日花开，智勇得志，功名可成'],
 [32,'wood','吉','侥幸贵人，天赐吉运，才略出众'],
 [33,'fire','吉','旭日升天，鸾凤相会，权威鼎盛'],
 [34,'fire','凶','破家亡身，灾难不绝，大凶之数'],
 [35,'earth','吉','温和平静，优雅发展，安稳余庆'],
 [36,'earth','凶','波澜重叠，风浪不息，侠气成仁'],
 [37,'metal','吉','权威显达，吉人天相，万事亨通'],
 [38,'metal','凶','意志薄弱，一生不得志，难望成功'],
 [39,'water','吉','富贵荣华，德泽四方，大业可成'],
 [40,'water','凶','退安守分，多事之非，晚景自苦'],
 [41,'wood','吉','德高望重，专心进取，可奏大功'],
 [42,'wood','凶','寒蝉在柳，十艺九不成，缺乏毅力'],
 [43,'fire','凶','散财破产，外祥内苦，前途暗淡'],
 [44,'fire','凶','烦闷逆境，破家亡身，灾祸惨淡'],
 [45,'earth','吉','顺风扬帆，富贵繁荣，可望成功'],
 [46,'earth','凶','罗网系身，离祖破家，一生多难'],
 [47,'metal','吉','点铁成金，开花结果，可获大功'],
 [48,'metal','吉','古松立鹤，德智兼备，可望成功'],
 [49,'water','凶','转变迁移，吉凶难定，患难淹留'],
 [50,'water','凶','小舟入海，吉凶参半，须防倾覆'],
 [51,'wood','半','盛衰交加，先盛后衰，须防反复'],
 [52,'wood','吉','卓识达眼，先见之明，功成名就'],
 [53,'fire','凶','曲卷推车，忧愁困苦，进退维谷'],
 [54,'fire','凶','石上栽花，难得长久，外荣内苦'],
 [55,'earth','凶','善恶兼得，半吉半凶，难定祸福'],
 [56,'earth','凶','浪里行舟，历尽艰辛，才成大业'],
 [57,'metal','吉','日照青松，寒雪逢春，可望有成'],
 [58,'metal','半','晚行遇月，沉浮不定，乏耐心者凶'],
 [59,'water','凶','寒蝉悲风，时运不济，徒劳无功'],
 [60,'water','凶','无谋无略，进退失据，暗淡无光'],
 [61,'wood','吉','牡丹独秀，名利双收，繁华之象'],
 [62,'wood','凶','衰败贫苦，一生拮据，难望安定'],
 [63,'fire','吉','富贵荣达，家运隆昌，天长地久'],
 [64,'fire','凶','骨肉分离，孤独悲愁，晚景凄凉'],
 [65,'earth','吉','巨流归海，富贵长寿，宏图大展'],
 [66,'earth','凶','进退维谷，艰难窘迫，晚景多难'],
 [67,'metal','吉','财通四海，天长地久，家门隆昌'],
 [68,'metal','吉','顺风吹帆，兴业立家，如意安康'],
 [69,'water','凶','非业非力，灾祸频来，难望安泰'],
 [70,'water','凶','残菊逢霜，虚弱短命，一生多难'],
 [71,'wood','半','石上金花，得失参半，乏耐心者凶'],
 [72,'wood','半','劳苦进取，中年可成，晚景安稳'],
 [73,'fire','凶','无勇无谋，处处受阻，难望成功'],
 [74,'fire','凶','残花经霜，沉沦逆境，一生多难'],
 [75,'earth','吉','退守得安，先苦后甘，晚景荣华'],
 [76,'earth','凶','离散败亡，骨肉分离，一生多难'],
 [77,'metal','半','半吉半凶，得失相兼，须防后患'],
 [78,'metal','凶','晚景凄凉，浮沉不定，难望安泰'],
 [79,'water','凶','云头望月，虚名虚利，一生难成'],
 [80,'water','凶','凶星入度，一生困穷，大凶之数'],
 [81,'wood','吉','万物回春，大富大贵，还本归元']
];
function liuShu(n){
  let x = n;
  if (x > 81) x = x - 80;            // 超过81减80取用
  if (x < 1) x = 1;
  const row = LIUSHIYI[x-1];
  return { num:x, wx:row[1], jx:row[2], desc:row[3] };
}

/* ---------- 笔画字典（康熙字典 63696 字，来自 strokes-data.js） ---------- */
const STROKE = typeof STROKE_DATA !== 'undefined' ? STROKE_DATA : {};

/* ---------- 古籍数据 ---------- */
// cat: 四部分类（经 / 子）；school: 学派；core: 核心思想标签
// 把一本典籍的简介/名言/核心/精选节选拼成可读纯文本，用于应用内阅读（离线）回退
function buildExcerptText(b){
  const L = [];
  L.push('【' + (b.name||'') + '】');
  if (b.meta) L.push(b.meta);
  L.push('');
  if (b.desc) L.push(b.desc);
  if (b.quote) { L.push(''); L.push('· 名言 ·'); L.push('' + b.quote + ''); }
  if (b.core && b.core.length) { L.push(''); L.push('· 核心思想 ·'); L.push(b.core.join('、')); }
  if (b.excerpts && b.excerpts.length) {
    L.push('');
    L.push('· 精选节选（共 ' + b.excerpts.length + ' 段）·');
    b.excerpts.forEach(e=>{
      L.push('');
      L.push('▍ ' + (e.title||''));
      if (e.source) L.push(e.source);
      if (e.translation) L.push('【译】' + e.translation);
    });
  }
  L.push('');
  L.push('—— 以上为 App 内置精选内容（离线可读）。完整原文请见详情卡下方查看全本（网页）。');
  return L.join('\n');
}

const BOOKS = [
  // ===== 经部（儒家经典）=====
  {name:'周易', cat:'经', school:'易学', meta:'周 · 姬昌（文王）等', desc:'群经之首，论述阴阳变化与六十四卦，是儒家与道家共同的思想源头。含《经》上下与《十翼》，以卦象推演天道人事。', quote:'天行健，君子以自强不息。', core:['阴阳','变易','三才','卦象'], url:'https://so.gushiwen.cn/guwen/book_466738A5E3EF.aspx', excerpts:[
    {title:'乾卦第一', source:'乾：元亨利贞。\n《象》曰：天行健，君子以自强不息。', translation:'乾卦象征天：创始、通达、适宜、正固。天道运行刚健不息，君子应效法天道自强不息。'},
    {title:'坤卦第二', source:'坤：元亨，利牝马之贞。君子有攸往，先迷后得主，利。\n《象》曰：地势坤，君子以厚德载物。', translation:'坤卦象征地：创始、通达，像母马一样柔顺守正。大地宽厚和顺，君子应效法大地以厚德包容万物。'}
  ]},
  {name:'尚书', cat:'经', school:'史书', meta:'上古至周 · 多方编订', desc:'上古历史文献汇编，记帝王诰命与政事，为五经之一。', quote:'满招损，谦受益。', core:['典谟训诰','政事','德治'], url:'https://so.gushiwen.cn/guwen/book_1617A0B158B6.aspx', excerpts:[
    {title:'洪范·九畴', source:'洪范九畴，彝伦攸叙。\n一曰水，二曰火，三曰木，四曰金，五曰土。', translation:'洪范九类大法，是常理的秩序。第一是水，第二是火，第三是木，第四是金，第五是土。'},
    {title:'五子之歌', source:'民惟邦本，本固邦宁。', translation:'人民是国家的根本，根本牢固，国家才会安宁。'}
  ]},
  {name:'诗经', cat:'经', school:'诗文', meta:'西周至春秋 · 佚名汇编', desc:'我国最早的诗歌总集，风雅颂三百零五篇，反映周代社会生活。', quote:'关关雎鸠，在河之洲。窈窕淑女，君子好逑。', core:['风雅颂','赋比兴','兴观群怨'], url:'https://so.gushiwen.cn/guwen/book_11.aspx', excerpts:[
    {title:'国风·周南·关雎', source:'关关雎鸠，在河之洲。窈窕淑女，君子好逑。\n参差荇菜，左右流之。窈窕淑女，寤寐求之。', translation:'关关鸣叫的雎鸠鸟，在河中小洲上。文静美丽的好姑娘，是君子理想的配偶。长短不齐的荇菜，左右摘取。文静美丽的好姑娘，日夜思念追求她。'},
    {title:'小雅·采薇', source:'昔我往矣，杨柳依依。今我来思，雨雪霏霏。\n行道迟迟，载渴载饥。我心伤悲，莫知我哀！', translation:'回想当初出征时，杨柳依依随风飘。如今归来路途中，大雪纷纷满天飞。道路泥泞走得慢，又渴又饥真劳累。我的心中充满伤悲，没有人知道我的哀痛！'}
  ]},
  {name:'周礼', cat:'经', school:'礼学', meta:'战国 · 托名周公', desc:'记载周代官制与礼法，分天地春夏秋冬六官，为三礼之首。', quote:'以祀礼教敬，以阳礼教让，以昏礼教亲。', core:['六官','礼制','官制'], excerpts:[
    {title:'天官·冢宰', source:'惟王建国，辨方正位，体国经野，设官分职，以为民极。', translation:'王者建立国家，辨明方位，规划都城与郊野，设置官职、分派职掌，作为百姓的准则。'},
    {title:'六官', source:'天官冢宰、地官司徒、春官宗伯、夏官司马、秋官司寇、冬官司空，各有职掌。', translation:'六官分掌：天官掌政务、地官掌教化、春官掌礼仪、夏官掌军事、秋官掌刑狱、冬官掌百工，各有所司。'}
  ]},
  {name:'礼记', cat:'经', school:'礼学', meta:'西汉 · 戴圣编', desc:'秦汉以前礼制与儒家礼学思想的汇编，含《大学》《中庸》。', quote:'玉不琢，不成器；人不学，不知道。', core:['礼教','修身','精义'], excerpts:[
    {title:'礼运·大同', source:'大道之行也，天下为公。选贤与能，讲信修睦。', translation:'大道施行的时候，天下是公共的。选拔贤能，讲求诚信、和睦相处。'},
    {title:'学记', source:'玉不琢，不成器；人不学，不知道。', translation:'玉石不雕琢，不能成为器物；人不学习，就不明白道理。'}
  ]},
  {name:'春秋左传', cat:'经', school:'史书', meta:'春秋 · 左丘明', desc:'以《春秋》为纲的编年史，详记各国政治军事外交，文辞精炼。', quote:'多行不义，必自毙。', core:['编年','战争','辞令'], excerpts:[
    {title:'烛之武退秦师', source:'焉用亡郑以陪邻？邻之厚，君之薄也。', translation:'何必灭掉郑国来增厚邻国？邻国强大了，就是您的削弱。'},
    {title:'曹刿论战', source:'夫战，勇气也。一鼓作气，再而衰，三而竭。', translation:'作战，靠的是勇气。第一次击鼓士气振奋，第二次衰减，第三次耗尽。'}
  ]},
  {name:'论语', cat:'经', school:'儒家', meta:'春秋 · 孔子弟子及再传弟子', desc:'记录孔子及其弟子言行的语录体著作，儒家思想核心。', quote:'学而时习之，不亦说乎？有朋自远方来，不亦乐乎？', core:['仁','礼','克己','中庸'], url:'https://so.gushiwen.cn/guwen/book_33.aspx', excerpts:[
    {title:'学而篇第一', source:'子曰："学而时习之，不亦说乎？有朋自远方来，不亦乐乎？人不知而不愠，不亦君子乎？"\n曾子曰："吾日三省吾身：为人谋而不忠乎？与朋友交而不信乎？传不习乎？"', translation:'孔子说："学习并时常温习，不是很快乐吗？有朋友从远方来，不是很高兴吗？别人不了解我而我不生气，不是君子吗？"\n曾子说："我每天多次反省自己：替人办事是否尽心？与朋友交往是否守信？老师传授的知识是否复习了？"'},
    {title:'为政篇第二', source:'子曰："温故而知新，可以为师矣。"\n子曰："学而不思则罔，思而不学则殆。"', translation:'孔子说："温习旧知识而能从中悟出新见解，就可以做老师了。"\n孔子说："只学习不思考就会迷茫，只思考不学习就会陷入困境。"'}
  ]},
  {name:'孟子', cat:'经', school:'儒家', meta:'战国 · 孟轲', desc:'发扬孔子仁学，主张性善与仁政，气势磅礴。', quote:'富贵不能淫，贫贱不能移，威武不能屈。此之谓大丈夫。', core:['性善','仁政','养气'], url:'https://so.gushiwen.cn/guwen/book_34.aspx', excerpts:[
    {title:'告子上·鱼我所欲也', source:'鱼，我所欲也；熊掌，亦我所欲也。二者不可得兼，舍鱼而取熊掌者也。生，亦我所欲也；义，亦我所欲也。二者不可得兼，舍生而取义者也。', translation:'鱼是我想要的，熊掌也是我想要的。如果不能同时得到，我就舍弃鱼而选取熊掌。生命是我想要的，道义也是我想要的。如果不能同时得到，我就舍弃生命而选取道义。'},
    {title:'生于忧患死于安乐', source:'故天将降大任于是人也，必先苦其心志，劳其筋骨，饿其体肤，空乏其身，行拂乱其所为，所以动心忍性，曾益其所不能。', translation:'所以上天将要把重大责任降临给这个人时，一定先使他内心痛苦、筋骨劳累、身体饥饿、穷困匮乏，使他做事总不顺利，用这些来激励他的心志、坚韧他的性格，增加他不具备的才能。'}
  ]},
  {name:'大学', cat:'经', school:'儒家', meta:'战国 · 曾参', desc:'三纲八目，讲明修身齐家治国平天下之序，为四书之一。', quote:'大学之道，在明明德，在亲民，在止于至善。', core:['三纲','八目','修身'], excerpts:[
    {title:'三纲领', source:'大学之道，在明明德，在亲民，在止于至善。', translation:'大学的宗旨，在于彰明光明德性，在于亲近爱抚百姓，在于达到至善的境界。'},
    {title:'八条目', source:'物格而后知至，知至而后意诚，意诚而后心正，心正而后身修，身修而后家齐，家齐而后国治，国治而后天下平。', translation:'推究事理而后知识完备，知识完备而后意念真诚，诚意而后心思端正，心正而后修养自身，修身而后家庭整齐，家齐而后国家太平，国治而后天下太平。'}
  ]},
  {name:'中庸', cat:'经', school:'儒家', meta:'战国 · 子思', desc:'阐发中庸之道，不偏不倚、执两用中，儒家心法。', quote:'喜怒哀乐之未发，谓之中；发而皆中节，谓之和。', core:['中和','诚明','执两用中'], excerpts:[
    {title:'天命', source:'天命之谓性，率性之谓道，修道之谓教。', translation:'天所赋予的叫做性，依循本性而行叫做道，修养大道叫做教。'},
    {title:'中和', source:'喜怒哀乐之未发，谓之中；发而皆中节，谓之和。', translation:'喜怒哀乐未发作时，叫做中；发作出来都合于节度，叫做和。'}
  ]},
  {name:'孝经', cat:'经', school:'儒家', meta:'春秋 · 曾参（传）', desc:'论孝道为德之本，自天子至庶人各有孝之标准，影响深远。', quote:'夫孝，德之本也，教之所由生也。', core:['孝道','根本','教化'], excerpts:[
    {title:'开宗明义', source:'夫孝，德之本也，教之所由生也。', translation:'孝，是德行的根本，教化由此而产生。'},
    {title:'纪孝行', source:'孝子之事亲也，居则致其敬，养则致其乐，病则致其忧，丧则致其哀，祭则致其严。', translation:'孝子侍奉双亲，日常起居要恭敬，奉养要使父母欢乐，患病要忧心，治丧要哀痛，祭祀要庄严。'}
  ]},

  // ===== 史部（历史地理）=====
  {name:'史记', cat:'史', school:'正史', meta:'西汉 · 司马迁', desc:'我国第一部纪传体通史，上起黄帝下至汉武帝，含本纪世家列传书表。', quote:'人固有一死，或重于泰山，或轻于鸿毛。', core:['纪传体','通史','究天人之际'], url:'https://so.gushiwen.cn/guwen/book_3.aspx', excerpts:[
    {title:'太史公自序', source:'究天人之际，通古今之变，成一家之言。\n人固有一死，或重于泰山，或轻于鸿毛，用之所趋异也。', translation:'探究天道与人事之间的关系，通晓古今历史变化的规律，形成自己独特的学说。人总有一死，有的人死得比泰山还重，有的人死得比鸿毛还轻，这是因为他们的追求不同。'}
  ]},
  {name:'资治通鉴', cat:'史', school:'编年', meta:'北宋 · 司马光', desc:'编年体通史巨著，上起周威烈王下至五代，专论历代治乱兴衰。', quote:'兼听则明，偏信则暗。', core:['编年','治乱','资治'], excerpts:[
    {title:'通鉴·鉴于往事', source:'鉴前世之兴衰，考当今之得失。', translation:'借鉴前代的兴盛衰亡，考察当今的成败得失。'},
    {title:'臣光曰·智伯', source:'兼听则明，偏信则暗。', translation:'广泛听取意见就能明辨是非，偏信一方就会昏暗不明。'}
  ]},
  {name:'三国志', cat:'史', school:'正史', meta:'西晋 · 陈寿', desc:'纪传体断代史，记魏蜀吴三国鼎立史事，文笔简洁。', quote:'勿以恶小而为之，勿以善小而不为。', core:['三国','纪传','鼎立'], excerpts:[
    {title:'先主传', source:'勿以恶小而为之，勿以善小而不为。', translation:'不要因为坏事小就去做，不要因为好事小就不去做。'},
    {title:'诸葛亮传', source:'鞠躬尽瘁，死而后已。', translation:'恭敬勤勉，竭尽心力，直到死去才停止。'}
  ]},
  {name:'战国策', cat:'史', school:'史书', meta:'西汉 · 刘向编', desc:'记战国纵横家策谋言论，文辞犀利，长于论辩。', quote:'前事之不忘，后事之师。', core:['纵横','策谋','论辩'], excerpts:[
    {title:'赵策·触龙说赵太后', source:'父母之爱子，则为之计深远。', translation:'父母爱护子女，就要为他们作长远的打算。'},
    {title:'秦策·苏秦', source:'前事之不忘，后事之师。', translation:'不忘过去的事情，可以作为以后行事的借鉴。'}
  ]},
  {name:'汉书', cat:'史', school:'正史', meta:'东汉 · 班固', desc:'我国第一部纪传体断代史，记西汉一朝典章制度与人物事迹。', quote:'明者防祸于未萌，智者图患于将来。', core:['断代','制度','典雅'], excerpts:[
    {title:'食货志', source:'明者防祸于未萌，智者图患于将来。', translation:'明智的人在祸患未萌发时就加以防范，聪慧的人在祸患发生前就图谋应对。'},
    {title:'司马迁传', source:'究天人之际，通古今之变。', translation:'探究天道与人事的关系，通晓古今变化的规律。'}
  ]},

  // ===== 子部（诸子百家）=====
  {name:'道德经', cat:'子', school:'道家', meta:'春秋 · 老子', desc:'道家根本经典，五千言阐发道法自然、无为而治的哲理。', quote:'道可道，非常道；名可名，非常名。', core:['道法自然','无为','上善若水'], bookFile:'books/daodejing.txt', bookKey:'daodejing', url:'https://so.gushiwen.cn/guwen/book_1.aspx', excerpts:[
    {title:'第一章', source:'道可道，非常道；名可名，非常名。无名天地之始，有名万物之母。故常无欲，以观其妙；常有欲，以观其徼。此两者同出而异名，同谓之玄，玄之又玄，众妙之门。', translation:'可以用语言表达的"道"，就不是永恒的道；可以用名称定义的"名"，就不是永恒的名。无是天地的本始，有是万物的根源。常从"无"中体察道的奥妙，常从"有"中体察道的端倪。'},
    {title:'第八章', source:'上善若水。水善利万物而不争，处众人之所恶，故几于道。居善地，心善渊，与善仁，言善信，政善治，事善能，动善时。夫唯不争，故无尤。', translation:'最高的善就像水一样。水善于滋润万物而不与万物相争，停留在众人都不喜欢的地方，所以最接近于"道"。'},
    {title:'第二十五章', source:'人法地，地法天，天法道，道法自然。', translation:'人效法地，地效法天，天效法道，道效法自然。'}
  ]},
  {name:'庄子', cat:'子', school:'道家', meta:'战国 · 庄周', desc:'道家经典，以寓言阐发逍遥齐物之旨，文笔汪洋恣肆。', quote:'天地与我并生，而万物与我为一。', core:['逍遥','齐物','养生','寓言'], url:'https://so.gushiwen.cn/guwen/book_12.aspx', excerpts:[
    {title:'逍遥游', source:'北冥有鱼，其名为鲲。鲲之大，不知其几千里也。化而为鸟，其名为鹏。鹏之背，不知其几千里也。怒而飞，其翼若垂天之云。', translation:'北海有一条鱼，它的名字叫鲲。鲲的巨大，不知道有几千里。变化成为鸟，它的名字叫鹏。鹏的脊背，不知道有几千里。当它奋起而飞时，展开的双翅就像天边的云彩。'},
    {title:'齐物论', source:'天地与我并生，而万物与我为一。', translation:'天地与我一同存在，万物与我合为一体。'}
  ]},
  {name:'列子', cat:'子', school:'道家', meta:'战国 · 列御寇', desc:'道家著作，多寓言传说，以冲虚自然为宗旨。', quote:'圣人以心导耳目，小人以耳目导心。', core:['冲虚','寓言','自然'], excerpts:[
    {title:'汤问·愚公移山', source:'虽我之死，有子存焉；子又生孙，孙又生子；子子孙孙，无穷匮也。', translation:'即使我死了，还有儿子在；儿子又生孙子，孙子又生儿子；子子孙孙，是没有穷尽的。'},
    {title:'黄帝·梦', source:'昼想夜梦，神形所遇。', translation:'白天所思，夜里所梦，是精神与形体相交感的结果。'}
  ]},
  {name:'孙子兵法', cat:'子', school:'兵家', meta:'春秋 · 孙武', desc:'世界最早的军事谋略经典，十三篇论胜负之道。', quote:'知己知彼，百战不殆。', core:['知己知彼','奇正','虚实'], url:'https://so.gushiwen.cn/guwen/book_15.aspx', excerpts:[
    {title:'始计篇第一', source:'兵者，国之大事，死生之地，存亡之道，不可不察也。\n故经之以五事，校之以计而索其情：一曰道，二曰天，三曰地，四曰将，五曰法。', translation:'战争是国家大事，关乎军民生死和国家存亡，不可不认真考察。要从五个方面分析比较：一是道义，二是天时，三是地利，四是将领，五是法制。'},
    {title:'谋攻篇第三', source:'知彼知己者，百战不殆；不知彼而知己，一胜一负；不知彼不知己，每战必殆。', translation:'了解敌人又了解自己，百战都不会失败；不了解敌人而了解自己，胜败各半；既不了解敌人也不了解自己，每次都会失败。'}
  ]},
  {name:'韩非子', cat:'子', school:'法家', meta:'战国 · 韩非', desc:'法家集大成之作，主张法势术相结合以治国。', quote:'刑过不避大臣，赏善不遗匹夫。', core:['法治','势术','赏罚'], url:'https://so.gushiwen.cn/guwen/book_23.aspx', excerpts:[
    {title:'五蠹', source:'世异则事异，事异则备变。是以圣人不期修古，不法常可，论世之事，因为之备。', translation:'时代不同了，事情就会变化；事情变化了，措施就要相应改变。所以圣人不期望遵循古道，不效法成规，而是研究当代的情况，据此制定相应的措施。'}
  ]},
  {name:'墨子', cat:'子', school:'墨家', meta:'战国 · 墨翟', desc:'墨家经典，主张兼爱非攻尚贤尚同节用。', quote:'兼相爱，交相利。', core:['兼爱','非攻','尚贤'], excerpts:[
    {title:'兼爱', source:'兼相爱，交相利。\n视人之国若视其国，视人之家若视其家，视人之身若视其身。', translation:'彼此相爱，互相得利。看待别人的国家如同自己的国家，别人的家族如同自己的家族，别人如同自己。'},
    {title:'非攻', source:'今攻者，农夫不得耕，妇人不得织，以守为事。', translation:'如今发动攻战，农夫不能耕种，妇女不能纺织，都去从事守备作战。'}
  ]},
  {name:'荀子', cat:'子', school:'儒家', meta:'战国 · 荀况', desc:'儒家后世大儒，主性恶、隆礼重法，为法家思想源头。', quote:'不积跬步，无以至千里；不积小流，无以成江海。', core:['性恶','隆礼','劝学'], url:'https://so.gushiwen.cn/guwen/book_54.aspx', excerpts:[
    {title:'劝学篇', source:'青，取之于蓝，而青于蓝；冰，水为之，而寒于水。\n学不可以已。\n不积跬步，无以至千里；不积小流，无以成江海。', translation:'靛青是从蓝草中提取的，却比蓝草更青；冰是由水凝结成的，却比水更寒冷。学习不可以停止。不半步半步地积累，就无法到达千里之外；不汇集细小的水流，就无法形成江海。'}
  ]},
  {name:'鬼谷子', cat:'子', school:'纵横家', meta:'战国 · 鬼谷子', desc:'纵横家经典，论捭阖术、揣摩权变之道。', quote:'捭之者，开也，言也，阳也；阖之者，闭也，默也，阴也。', core:['捭阖','揣摩','权变'], excerpts:[
    {title:'捭阖', source:'捭之者，开也，言也，阳也；阖之者，闭也，默也，阴也。', translation:'捭，是敞开、言说、显扬（阳）；阖，是闭合、沉默、隐敛（阴）。'},
    {title:'揣篇', source:'度其情，量其能，揣其力，然后就其情。', translation:'揣度对方的实情，衡量其能力，估量其势力，然后顺其情势而为。'}
  ]},
  {name:'黄帝内经', cat:'子', school:'医家', meta:'战国至汉 · 托名黄帝', desc:'中医理论奠基之作，论阴阳五行、藏象经络与养生。', quote:'上工治未病，不治已病。', core:['阴阳五行','藏象','治未病'], excerpts:[
    {title:'素问·上古天真论', source:'上古之人，其知道者，法于阴阳，和于术数，食饮有节，起居有常，不妄作劳，故能形与神俱，而尽终其天年。', translation:'上古懂得养生之道的人，效法阴阳，调和术数，饮食有节制，起居有规律，不妄加操劳，所以形体与精神协调，能享尽天年。'},
    {title:'素问·四气调神', source:'上工治未病，不治已病。', translation:'高明的医生在疾病未发时便加以防治，而不是等病已成才去治疗。'}
  ]},
  {name:'管子', cat:'子', school:'法家', meta:'战国 · 管仲（托名）', desc:'融汇道法儒的治世之作，论经济军事与治国方略。', quote:'仓廪实则知礼节，衣食足则知荣辱。', core:['富国','轻重','牧民'], excerpts:[
    {title:'牧民', source:'仓廪实则知礼节，衣食足则知荣辱。', translation:'粮仓充实，人民才懂得礼节；衣食丰足，人民才晓得荣辱。'},
    {title:'权修', source:'一年之计，莫如树谷；十年之计，莫如树木；终身之计，莫如树人。', translation:'一年的打算，不如种谷；十年的打算，不如栽树；一生的打算，不如培育人才。'}
  ]},

  // ===== 术数部（命理 · 相术）=====
  {name:'滴天髓', cat:'术', school:'命理', meta:'宋 · 京图 撰，明 · 刘基 注', desc:'命理学经典，以歌诀体阐发五行生克、日主衰旺与用神喜忌，任铁樵注本影响最巨。', quote:'欲识三元万法宗，先观帝载与神功。', core:['日主','用神','衰旺','五行'], bookKey:'dts', excerpts:[
    {title:'通神论·天道', source:'欲识三元万法宗，先观帝载与神功。\n坤元合德机缄通，五气偏全定吉凶。', translation:'要识破天地人三才万法的根本，先要观察天地的造化与功用。大地之德与造化相通，五行之气偏全不同，便定下命运的吉凶。'},
    {title:'通神论·衰旺', source:'能知衰旺之真机，其于三命之奥，思过半矣。', translation:'若能懂得日主衰旺的真正机窍，那么对八字命理的深奥道理，就已经领悟一大半了。'}
  ]},
  {name:'渊海子平', cat:'术', school:'命理', meta:'宋 · 徐子平 撰，徐大升 编', desc:'八字命理的奠基之作，确立以日干为主、十神六亲与格局推算的体系。', quote:'用之官星不可伤，不用官星尽可欺。', core:['日主','十神','格局','六亲'], bookKey:'yhzp', excerpts:[
    {title:'论日为主', source:'予尝考其理，原其本，乃以日为主，年为本，月为提纲，时为辅佐。', translation:'我考察命理的义理、推究其本源，是以出生日的天干为主，年柱为本根，月柱为提纲，时柱为辅佐。'},
    {title:'碧渊赋', source:'官星带刃无克战，职居极品；财星得局遇长生，富比陶朱。', translation:'官星得羊刃相辅而无人来克战，必居极品高位；财星成局又遇长生之地，富可敌国（如陶朱公）。'}
  ]},
  {name:'三命通会', cat:'术', school:'命理', meta:'明 · 万民英 撰', desc:'汇辑历代命理学说之大成，十二卷博采众家，为命理集大成之作。', quote:'看命先观日主，次察财官，又看气势，然后定休咎。', core:['日主','财官','纳音','气势'], bookKey:'smt', excerpts:[
    {title:'看命口诀', source:'看命先观日主，次察财官，又看气势，然后定休咎。', translation:'推断命运先观察日主强弱，其次考察财星官星，再看整盘五行气势，然后才能判定吉凶。'},
    {title:'论纳音', source:'纳音者，天地之气交，五行之音声也。', translation:'纳音，是天地阴阳之气相交合，化为五行的声音与气韵。'}
  ]},
  {name:'子平真诠', cat:'术', school:'命理', meta:'清 · 沈孝瞻 撰', desc:'格局派命理经典，专论月令取用、格局成败与相神喜忌。', quote:'八字用神，专求月令。', core:['用神','格局','月令','相神'], bookKey:'ziping', excerpts:[
    {title:'论用神', source:'八字用神，专求月令。以日干配月令地支，而生克不同，格局于是分焉。', translation:'八字取用神，专门向月令（出生月地支）寻求。以日干配合月令地支，因生克关系不同，格局便由此区分。'},
    {title:'论相神', source:'月令既分，格局既定，则宜相喜相忌，以定吉凶。', translation:'月令取出用神、格局既已确定，便要看相神（辅助用神者）的喜忌，来判定吉凶。'}
  ]},
  {name:'穷通宝鉴', cat:'术', school:'命理', meta:'清 · 余春台 编', desc:'以十天干配十二月之调候用神为核心，重寒暖燥湿与四时宜忌，实务性极强。', quote:'甲木参天，脱胎要火。', core:['十天干','调候','用神','寒暖'], bookKey:'qiong', excerpts:[
    {title:'论甲木', source:'甲木参天，脱胎要火。春不容金，秋不容土。\n火炽乘龙，水宕骑虎。地润天和，植立千古。', translation:'甲木如参天大树，初生需火来脱胎（泄秀）。春木怕金克，秋木怕土耗。火旺宜坐辰（龙）库，水旺宜骑寅（虎）根。地润天和，方能长久挺立。'},
    {title:'论丙火', source:'丙火猛烈，欺霜侮雪。能煅庚金，逢辛反怯。\n土众成慈，水猖显节。虎马犬乡，甲来成灭。', translation:'丙火猛烈，能欺霜侮雪。能锻庚金，遇辛金反显怯懦。土多则火成慈祥，水狂则火显节操。入寅午戌火局，再逢甲木反致熄灭。'},
    {title:'论庚金', source:'庚金带煞，刚健为最。得水而清，得火而锐。\n土润则生，土干则脆。能赢甲兄，输于乙妹。', translation:'庚金带煞气，最为刚健。得水则清秀，得火则锐利。湿土能生，燥土反脆。能胜过甲木（兄），却输给乙木（妹，乙庚合）。'}
  ]},
  {name:'麻衣相法', cat:'术', school:'相术', meta:'五代 · 麻衣道者 传', desc:'传统相术经典，论面貌五官、气色骨相与心性祸福之应。', quote:'有心无相，相随心生；有相无心，相随心灭。', core:['五官','气色','骨相','心相'], bookKey:'sxqb', excerpts:[
    {title:'相心', source:'有心无相，相随心生；有相无心，相随心灭。', translation:'有善良心性而无好相貌，相貌会随心性而变好；有好的相貌而无善心，相貌也会随心性败坏而消失。'},
    {title:'五岳三停', source:'相面之法，先观五岳，次察三停。\n五岳朝拱，富贵双全；三停平等，一生安稳。', translation:'看相面，先看五岳（额、鼻、左右颧、下巴）是否丰隆朝拱，再看三停（上中下三部分）是否均匀。五岳朝拱主富贵双全，三停平匀主一生安稳。'}
  ]},

  // ===== 集部（文学总集）=====
  {name:'楚辞', cat:'集', school:'辞赋', meta:'战国 · 屈原等', desc:'我国浪漫主义文学源头，以屈原《离骚》为代表，香草美人托物言志。', quote:'路漫漫其修远兮，吾将上下而求索。', core:['骚体','香草美人','浪漫'], url:'https://so.gushiwen.cn/guwen/book_10.aspx', excerpts:[
    {title:'离骚', source:'长太息以掩涕兮，哀民生之多艰。\n路漫漫其修远兮，吾将上下而求索。', translation:'我长叹一声掩面流泪，哀叹人民的生活如此艰难。前方的道路漫长而遥远，我将上天下地去追寻真理。'},
    {title:'九章·橘颂', source:'后皇嘉树，橘徕服兮。受命不迁，生南国兮。\n深固难徙，更壹志兮。', translation:'天地间美好的橘树，生来就适应这片土地。禀受天命不可迁移，生长在南方。根深蒂固难以迁徙，更显专一的意志。'}
  ]},
  {name:'文心雕龙', cat:'集', school:'文论', meta:'南朝梁 · 刘勰', desc:'我国第一部系统的文学理论专著，论述文章体式与创作原理。', quote:'操千曲而后晓声，观千剑而后识器。', core:['文道','体式','风骨'], excerpts:[
    {title:'神思', source:'形在江海之上，心存魏阙之下。', translation:'形体虽在江海之上，心神却系念于魏阙之下的荣利。'},
    {title:'知音', source:'操千曲而后晓声，观千剑而后识器。', translation:'弹奏过千百支曲子而后才懂得音乐，观察过千百口剑而后才识别兵器。'}
  ]},
  {name:'唐诗三百首', cat:'集', school:'诗歌', meta:'清 · 蘅塘退士编', desc:'最通行的唐诗选本，选七十七家诗三百一十余首。', quote:'海上生明月，天涯共此时。', core:['唐诗','格律','各体兼备'], excerpts:[
    {title:'静夜思（李白）', source:'床前明月光，疑是地上霜。\n举头望明月，低头思故乡。', translation:'床前洒满明亮的月光，恍疑是地上的白霜。抬头望着天上的明月，低头思念远方的故乡。'},
    {title:'登鹳雀楼（王之涣）', source:'白日依山尽，黄河入海流。\n欲穷千里目，更上一层楼。', translation:'夕阳依傍山峦渐渐沉落，黄河奔涌流向大海。想要望尽千里风光，就要再登上更高一层楼。'}
  ]},
  {name:'左传选读', cat:'集', school:'散文', meta:'清 · 吴楚材编', desc:'《古文观止》中精选春秋左传名篇，叙事精炼、辞令优美。', quote:'一鼓作气，再而衰，三而竭。', core:['叙事','辞令','战事'], excerpts:[
    {title:'郑伯克段于鄢', source:'多行不义，必自毙。', translation:'多做不合道义的事，必定会自己垮台。'},
    {title:'曹刿论战', source:'一鼓作气，再而衰，三而竭。', translation:'第一次击鼓士气振奋，第二次衰减，第三次耗尽。'}
  ]},
];
// 部类配色与四部分类标签
const BOOK_CAT = {
  '经': { label:'经部', color:'#9c2b2b' },
  '史': { label:'史部', color:'#3f7368' },
  '子': { label:'子部', color:'#7a5c2e' },
  '集': { label:'集部', color:'#4a6fa5' },
  '术': { label:'术数', color:'#6b4a8a' }
};
// 收藏状态（持久化于 localStorage）
const BOOK_STATUS = {
  reading:   { label:'在读', color:'#b0742f' },
  read:      { label:'已读', color:'#3f7368' },
  collected: { label:'藏书', color:'#9c2b2b' }
};
function loadBookStatus(){
  try { return JSON.parse(localStorage.getItem('claw_book_status_v1') || '{}'); }
  catch (e) { return {}; }
}
function saveBookStatus(map){
  try { localStorage.setItem('claw_book_status_v1', JSON.stringify(map)); } catch (e) {}
}
let booksFilter = 'all';
let booksQuery = '';
let booksSelected = null;

/* ===================================================================
 * 八字排盘
 * =================================================================== */
function hourBranch(h){ if (h === 23) return 0; return Math.floor((h + 1) / 2); }
const DAY_STEM_ZI = {甲:0,己:0,乙:2,庚:2,丙:4,辛:4,丁:6,壬:6,戊:8,癸:8};
const YANG_GAN = new Set(['甲','丙','戊','庚','壬']);

/* ---------- 地支藏干（本气）与十神 ---------- */
const HIDDEN = {
  '子':['癸'], '丑':['己','辛','癸'], '寅':['甲','丙','戊'], '卯':['乙'],
  '辰':['戊','乙','癸'], '巳':['丙','庚','戊'], '午':['丁','己'], '未':['己','丁','乙'],
  '申':['庚','壬','戊'], '酉':['辛'], '戌':['戊','辛','丁'], '亥':['壬','甲']
};
const HIDDEN_W = {0:0.6, 1:0.3, 2:0.1}; // 地支藏干权重：本气 / 中气 / 余气
const WX_SHENG = {wood:'fire',fire:'earth',earth:'metal',metal:'water',water:'wood'}; // A生B
const WX_KE = {wood:'earth',earth:'water',water:'fire',fire:'metal',metal:'wood'};     // A克B
function wuXingProducing(t){ for (const k in WX_SHENG) if (WX_SHENG[k]===t) return k; } // 生t者
function wuXingControlling(t){ for (const k in WX_KE) if (WX_KE[k]===t) return k; }      // 克t者
function isYangGan(g){ return YANG_GAN.has(g); }

// 十神：以日干 dm（五行 dmWx）看他干/地支本气 other（五行 otherWx）
function shiShen(dm, dmWx, other, otherWx){
  if (otherWx === dmWx) return isYangGan(dm)===isYangGan(other) ? '比肩' : '劫财';
  if (WX_SHENG[dmWx] === otherWx) return isYangGan(dm)===isYangGan(other) ? '食神' : '伤官';
  if (WX_SHENG[otherWx] === dmWx) return isYangGan(dm)===isYangGan(other) ? '偏印' : '正印';
  if (WX_KE[dmWx] === otherWx) return isYangGan(dm)===isYangGan(other) ? '偏财' : '正财';
  if (WX_KE[otherWx] === dmWx) return isYangGan(dm)===isYangGan(other) ? '七杀' : '正官';
  return '';
}
function pillarTG(dm, dmWx, gz){
  return {
    gan: shiShen(dm, dmWx, gz[0], GAN_WX[gz[0]]),
    zhi: shiShen(dm, dmWx, HIDDEN[gz[1]][0], GAN_WX[HIDDEN[gz[1]][0]])
  };
}
// ===== 《旺衰论》百分制打分（教学对齐版）=====
const GAN_JF = 36; // 天干基分
const ZHI_CANG = {
  '子':[['癸',100]],
  '丑':[['己',60],['癸',30],['辛',10]],
  '寅':[['甲',60],['丙',30],['戊',10]],
  '卯':[['乙',100]],
  '辰':[['戊',60],['乙',30],['癸',10]],
  '巳':[['丙',60],['庚',30],['戊',10]],
  '午':[['丁',70],['己',30]],
  '未':[['己',60],['丁',30],['乙',10]],
  '申':[['庚',60],['壬',30],['戊',10]],
  '酉':[['辛',100]],
  '戌':[['戊',60],['辛',30],['丁',10]],
  '亥':[['壬',70],['甲',30]]
};
// 60 组单柱组合：g=天干系数(本柱组合后乘此)，z=地支本气系数(本柱组合后乘此)
// 去枚举化（2026-07-24）：本柱干支关系不再查经验表 GANZHI_COMBO，改用五行生克传导统一推导 comboFactor()。
// 关系由 WX_SHENG/WX_KE 推出，非查表，消除「盖头/截脚/干生支/支生干/比和」逐对枚举的无力感。
// 其余（全局天干生克、中余气受天干生克、通根距离、比和加成）保留，均为原理性计算。
function comboFactor(g, z){
  const gWx = GAN_WX[g];
  const zb = ZHI_CANG[z][0];
  const zbWx = GAN_WX[zb[0]];
  let fg = 1.0, fz = 1.0;
  if (gWx === zbWx){                  // 比和：干支同气，互助
    fg = 1.15; fz = 1.15;
  } else if (WX_SHENG[gWx] === zbWx){  // 天干生地支：天干泄略减，地支得生略增
    fg = 0.92; fz = 1.08;
  } else if (WX_KE[gWx] === zbWx){     // 天干克地支（盖头）：天干劳而无功略减，地支受克减
    fg = 0.95; fz = 0.8;
  } else if (WX_SHENG[zbWx] === gWx){  // 地支生天干：天干得生增，地支泄减
    fg = 1.12; fz = 0.92;
  } else if (WX_KE[zbWx] === gWx){     // 地支克天干（截脚）：天干被克减，地支略增
    fg = 0.78; fz = 1.08;
  }
  return {g: fg, z: fz};
}
// （原 60 组 GANZHI_COMBO 经验枚举表已废弃删除；本柱干支关系统一由上方 comboFactor() 五行生克传导推导）
// 天干 g 受其它天干 o 生克影响的乘子：以「十神关系」统一推导（取代原 8 个孤立经验魔法数），阴阳仅作微调；
// 关系方向——印生我→增益、官杀克我→受制大减、我克财→耗减、我生食伤→泄减、比和同气→不动（保持原数值映射）。
function ganRelFactor(gWx, oWx, same){
  if (gWx === oWx) return 1.0;                           // 同五行他干：原逻辑不额外加成
  if (WX_SHENG[oWx] === gWx) return same ? 1.20 : 1.30; // 印（他干生我）→ 增益（异性有情生力更充）
  if (WX_SHENG[gWx] === oWx) return same ? 0.80 : 0.70; // 食伤（我生他）→ 泄减（同性无情泄尽更减）
  if (WX_KE[oWx] === gWx) return same ? 0.50 : 0.70;    // 官杀（他干克我）→ 受制大减
  if (WX_KE[gWx] === oWx) return same ? 0.70 : 0.85;    // 财（我克他）→ 耗减
  return 1.0;
}
const ZHI_ORDER10 = ['子','丑','寅','卯','辰','巳','午','未','申','酉','戌','亥'];
function _tongGenF(dist){ return dist===0?1 : dist===1?0.9 : dist===2?0.75 : 0.6; }
function _ganKeZang(ganWx, zangWx){
  if (WX_KE[ganWx] === zangWx) return 0.6;   // 天干克该藏干
  if (WX_SHENG[ganWx] === zangWx) return 1.3; // 天干生该藏干
  return 1.0;
}
// 核心：按《旺衰论》计算金木水火土各元素百分分
function wuXingScores(P){
  const order = ['year','month','day','hour'];
  const dmWx = GAN_WX[P.day[0]];
  const dayZhi = P.day[1];
  const dayIdx = ZHI_ORDER10.indexOf(dayZhi);
  const score = {wood:0,fire:0,earth:0,metal:0,water:0};
  // 一、天干分数（本柱组合 → 天干生克 → 比和加成）
  order.forEach(p=>{
    const g = P[p][0], z = P[p][1];
    const gWx = GAN_WX[g];
    const combo = comboFactor(g, z);
    let gs = GAN_JF * combo.g;
    order.forEach(q=>{
      if (q === p) return;
      const og = P[q][0], oWx = GAN_WX[og];
      const same = (YANG_GAN.has(g) === YANG_GAN.has(og));
      gs *= ganRelFactor(gWx, oWx, same);   // 天干间生克：十神关系推导（取代原 8 个经验魔法数）
    });
    const zb = ZHI_CANG[z][0];
    if (GAN_WX[zb[0]] === gWx) gs += zb[1] * 0.5; // 干支比和：天干加地支本气同五行50%
    score[gWx] += gs;
  });
  // 二、地支通根分数（本气受组合系数，中余气受天干生克，整体按距离衰减；日主五行根不减）
  order.forEach(p=>{
    const g = P[p][0], z = P[p][1];
    const combo = comboFactor(g, z);
    const zhIdx = ZHI_ORDER10.indexOf(z);
    const dist = zhIdx < 0 || dayIdx < 0 ? 0 : Math.min(Math.abs(zhIdx - dayIdx), 12 - Math.abs(zhIdx - dayIdx));
    const distF = _tongGenF(dist);
    ZHI_CANG[z].forEach((pair, i)=>{
      const cg = pair[0], cs = pair[1], cWx = GAN_WX[cg];
      let s = cs;
      if (i === 0) s *= combo.z;              // 组合系数只作用于本气
      if (i > 0){ order.forEach(q2=>{ s *= _ganKeZang(GAN_WX[P[q2][0]], cWx); }); } // 中余气受四天干生克
      if (cWx !== dmWx) s *= distF;          // 非日主五行：按距离衰减
      else if (dist >= 2) s *= distF;        // 日主五行通根：仅与坐下(日支)相邻(dist<=1)不减力，远隔(年支等)仍按距离衰减
      score[cWx] += s;
    });
  });
  return score;
}
// （旧 sanDeOrd / strengthLevel 平权三得序数函数已废弃删除：新引擎以 AD_strengthPower 的 net2 净实力 + NET_* 阈值为准，三得仅作保底闸参考输入，不再单独成函数）
// 日主净实力 net2 → 强弱档位（与 NET_* 阈值一致）
// 七级体系：强极(专旺) · 太强 · 偏强 · 中和 · 偏弱 · 太弱 · 弱极(从格)。
// 「旺」统一作「强」——旺不等于强（得时失地失助只旺不强），标签以「强」反映真实力量。
// 强极/弱极不入正格（由 pattern 单独标：专旺=强极、从格=弱极），此处只出正格五级。
function AD_strengthLevelNet(net2){
  if (net2 > NET_TAIWANG) return {key:'taiqiang', label:'太强'};
  if (net2 > NET_PIANQIANG) return {key:'pianqiang', label:'偏强'};
  if (net2 > NET_PING) return {key:'zhonghe', label:'中和'};
  if (net2 > NET_TAIRUO) return {key:'pianruo', label:'偏弱'};
  return {key:'tairuo', label:'太弱'};
}
// ── 三元量化打分（用户「生态分析法」定案 2026-07-25）：月令40 + 党羽35 + 时支25 ──
// 移植自用户提供的 suanfa.txt（Python 版，逐例比对一致后启用）。
// 混合引擎分工：特殊格局（专旺/从格/化气/两神/暗冲/暗合）仍由 AD_resolveXiJi 原逻辑优先识别；
// 普通盘档位与身强/身弱取喜忌由本打分决定。5级体系：专旺 · 身强 · 中和 · 身弱 · 从格。
// 423例实测：混合引擎粗化 78.0%（基线 aa5b991 为 71.9%）。
const SY_WX = {'甲':'木','乙':'木','丙':'火','丁':'火','戊':'土','己':'土','庚':'金','辛':'金','壬':'水','癸':'水'};
const SY_CANG = {
  '子':{ben:'癸'}, '丑':{ben:'己',zhong:'癸',yu:'辛'}, '寅':{ben:'甲',zhong:'丙',yu:'戊'},
  '卯':{ben:'乙'}, '辰':{ben:'戊',zhong:'乙',yu:'癸'}, '巳':{ben:'丙',zhong:'戊',yu:'庚'},
  '午':{ben:'丁',zhong:'己'}, '未':{ben:'己',zhong:'丁',yu:'乙'}, '申':{ben:'庚',zhong:'壬',yu:'戊'},
  '酉':{ben:'辛'}, '戌':{ben:'戊',zhong:'辛',yu:'丁'}, '亥':{ben:'壬',zhong:'甲'}
};
const SY_SANHE = [['亥子丑','水'],['寅午戌','火'],['巳酉丑','金'],['申子辰','水']];
const SY_SHENG5 = {'木':'火','火':'土','土':'金','金':'水','水':'木'};
function SY_isYinBi(gan, riZhu){
  const g = SY_WX[gan], r = SY_WX[riZhu];
  if (!g || !r) return false;
  return g === r || SY_SHENG5[g] === r;
}
function SY_sanhe(zhiList){
  for (let i = 0; i < SY_SANHE.length; i++){
    const parts = SY_SANHE[i][0].split('');
    let match = 0;
    parts.forEach(p => { if (zhiList.indexOf(p) >= 0) match++; });
    if (match >= 3) return SY_SANHE[i][1];
  }
  return null;
}
function AD_sanyuanBase(P, dayStem){
  const riZhu = dayStem, riWx = SY_WX[riZhu];
  const zhis = [P.year[1], P.month[1], P.day[1], P.hour[1]].filter(Boolean);
  const gans = [P.year[0], P.month[0], P.day[0], P.hour[0]].filter(Boolean);
  const mz = P.month[1], mg = P.month[0], hz = P.hour[1];
  // 月令根基（40）
  let month = 5;
  if (mz && SY_CANG[mz] && SY_isYinBi(SY_CANG[mz].ben, riZhu)) month = 40;
  const heHua = SY_sanhe(zhis);
  if (heHua && heHua !== riWx) month = Math.floor(month / 2);
  if ((riZhu==='壬'&&mg==='丁')||(riZhu==='丁'&&mg==='壬')) month -= 8;
  if ((riZhu==='戊'&&mg==='癸')||(riZhu==='癸'&&mg==='戊')) month -= 6;
  month = Math.max(0, Math.min(40, month));
  // 党羽势力（35）
  let party = 0;
  gans.forEach(g => { if (SY_isYinBi(g, riZhu)) party += 15; });
  zhis.forEach(z => {
    const c = SY_CANG[z]; if (!c) return;
    if (SY_isYinBi(c.ben, riZhu)) party += 10;
    if (c.zhong && SY_isYinBi(c.zhong, riZhu)) party += 5;
    if (c.yu && SY_isYinBi(c.yu, riZhu)) party += 5;
  });
  if (heHua === riWx) party += 10;
  party = Math.max(0, Math.min(35, party));
  // 时支归属（25）
  let hour = 0;
  if (hz && SY_CANG[hz]){
    if (SY_isYinBi(SY_CANG[hz].ben, riZhu)) hour = 25;
    else if (SY_CANG[hz].yu && SY_isYinBi(SY_CANG[hz].yu, riZhu)) hour = 10;
  }
  if (heHua === riWx) hour += 5;
  hour = Math.min(25, hour);
  return { month, party, hour, total: month + party + hour, heHua };
}
// 三元分 → 普通盘三级（专旺/从格等由 pattern 单独标，共成5级）：≥72 身强 / 71 中和 / <71 身弱（423例校准阈值）
const SY_STRONG = 72, SY_MID = 71;
function AD_strengthLevelSY(total){
  if (total >= SY_STRONG) return { key:'pianqiang', label:'身强' };
  if (total >= SY_MID) return { key:'zhonghe', label:'中和' };
  return { key:'pianruo', label:'身弱' };
}
// 三得保底闸：net2 算完后、特殊格局已排除（专旺/从/化气/两神/暗冲暗合由 pattern 单独标），
// 对「正格」做结构化保底/封顶，纠正「得令+有根+比劫印 仍被判偏弱」「微根+他神弱 却落太弱」两类失真。
// 返回 { floor: 最低档key | null, ceil: 最高档key | null }。仅约束正格五级（不影响特殊格局）。
function AD_strengthFloor(P, dayStem, dmWx, pw){
  const monthBenWx = GAN_WX[HIDDEN[P.month[1]][0]];
  const ling = (monthBenWx === dmWx) || (WX_SHENG[monthBenWx] === dmWx); // 得令（月令本气为日主同类或印）
  const gans = [P.year[0], P.month[0], P.day[0], P.hour[0]];
  let biYinGan = 0;
  gans.forEach(g=>{ const s = shiShen(dayStem, dmWx, g, GAN_WX[g]);
    if (s === '比肩' || s === '劫财' || s === '正印' || s === '偏印') biYinGan++; });
  const enemyS = (pw.keeR || 0) + 0.6 * (pw.ganKe || 0); // 他神克耗力
  let floor = null, ceil = null;
  // 保底偏强：得令 且（有本气根 或 天干比劫印≥2）→ 至少偏强，不落偏弱/太弱
  // 但须 net2 不太负才保（防「得令+有根却克耗极重、net2 已深度为负」被硬抬成偏强，造成过判强）
  if (ling && (pw.dmR0 >= 1.0 || biYinGan >= 2) && pw.net2 > -2.0) floor = 'pianqiang';
  // 封顶偏弱：有根（微根亦可）且他神克耗不大 → 不落太弱（防「微根+他神弱」误判太弱）
  if (pw.rooted && enemyS < 2.5 && floor === null) ceil = 'pianruo';
  if (pw.sdk || pw.piao) floor = null;   // 生多为克/印旺漂身已识别：不保底偏强（已对日主根/印打折），须置于保底计算之后
  return { floor, ceil };
}
// 将保底/封顶施加到 net2 七级档位上
function AD_applyFloor(lv, floor, ceil){
  // 保底：只向上抬（得令+有根/比劫印 → 至少偏强），不压强盘
  if (floor){
    const ord = { taiqiang:6, pianqiang:5, zhonghe:4, pianruo:3, tairuo:2 };
    if ((ord[lv.key] || 0) < ord[floor]) return { key: floor, label: (floor==='pianqiang'?'偏强':(floor==='qiang'?'强':'偏强')) };
  }
  // 封顶：仅当原判已是「太弱」时，把「微根+他神弱」提至偏弱（防误落太弱），绝不向下压强盘
  if (ceil && lv.key === 'tairuo') return { key: ceil, label: (ceil==='pianruo'?'偏弱':'太弱') };
  return lv;
}
// （旧 STRONG_ORD / CONG_ORD / ZHUANWANG_ORD 三得序数阈值已废弃删除：专旺/从格判定已统一改用 NET_ZHUAN / NET_CONG / NET_DM_REAL_ROOT_WEAK 净实力阈值，不再依赖平权三得序数）
// 强弱总闸：以「日主净实力 net2（根重加权 + 印旺漂身）」替代粗糙二元三得序数。阈值经 39 例真实命盘校准对齐用户手感。
const NET_ZHUAN = 2.2;         // 专旺（克星门未破时）
const NET_TAIWANG = 1.2;       // 太强（正格最高档；再上为强极·专旺）
const NET_PIANQIANG = 0.6;     // 偏强（≥ 即身旺侧，取克泄耗为喜）
const NET_PING = -0.4;         // 中和
const NET_TAIRUO = -3.5;       // 偏弱
const NET_CONG = -5.5;         // 从格（净实力极负且日主无根）
const NET_DM_REAL_ROOT_WEAK = 0.5; // 日主真根力阈值（< 即无本气依托）
const NET_KE_BREAK = 0.4;      // 克星根破专旺门阈值
const CONG_DISPLAY = { cong_cai:'从财格', cong_sha:'从杀格', cong_er:'从儿格', cong_shi:'从势格' }; // 从格细分显示名

// 特殊格局（专旺 / 从格 / 化气 / 两神成象 / 暗冲 / 暗合）识别 + 主喜忌取值。必须在 sanDeOrd（三得旺衰）之后、所有断语之前调用，
// 否则大运 / 流年 / 财运 / 事业 / 婚姻的吉凶会整体算反（P0-1）。

// 某五行在命局（天干+地支本中余气，加权）是否有根有力
function AD_hasRoot(wx, P){
  let w = 0;
  [P.year[0],P.month[0],P.day[0],P.hour[0]].forEach(g=>{ if (GAN_WX[g]===wx) w += 1.0; });
  [P.year[1],P.month[1],P.day[1],P.hour[1]].forEach(z=>{
    (HIDDEN[z]||[]).forEach((g,i)=>{ if (GAN_WX[g]===wx) w += [0.6,0.3,0.1][i]||0; });
  });
  return w >= 0.6;
}

// 日主之正官天干：克日主五行中、与日主异性者为正官（阳日主→阴克星，阴日主→阳克星）
function zhengGuanGan(dayGan){
  const guanWx = wuXingControlling(GAN_WX[dayGan]);
  const yangGan = {wood:'甲',fire:'丙',earth:'戊',metal:'庚',water:'壬'}[guanWx];
  const yinGan = {wood:'乙',fire:'丁',earth:'己',metal:'辛',water:'癸'}[guanWx];
  const isYang = (dayGan==='甲'||dayGan==='丙'||dayGan==='戊'||dayGan==='庚'||dayGan==='壬');
  return isYang ? yinGan : yangGan;
}

// 二级特殊格局：化气 / 两神成象 / 暗冲 / 暗合（罕见，命中即定）
function AD_resolveSpecial(P, dayGan, dmWx, score, wx){
  const gans = [P.year[0],P.month[0],P.day[0],P.hour[0]];
  const HE_HUA = {'甲己':'earth','乙庚':'metal','丙辛':'water','丁壬':'wood','戊癸':'fire'};
  const heCheck = [[gans[1],gans[2]],[gans[2],gans[3]]]; // 仅取紧贴日主的五合对：月-日（最得月令之气）、日-时；剔除年-日（离日主远、不受月令牵制，成化气概率极低，易误判）
  let hua = null, huaPair = null;
  for (const pair of heCheck){
    const k1 = pair[0]+pair[1], k2 = pair[1]+pair[0];
    if (HE_HUA[k1]){ hua = HE_HUA[k1]; huaPair = [pair[0],pair[1]]; break; }
    if (HE_HUA[k2]){ hua = HE_HUA[k2]; huaPair = [pair[1],pair[0]]; break; }
  }
  if (hua){
    const monthBen = HIDDEN[P.month[1]][0];
    const maxWx = Object.keys(wx).reduce((a,b)=> wx[a]>=wx[b]?a:b);
    const dominant = (GAN_WX[monthBen]===hua) || (maxWx===hua);
    const keHua = wuXingControlling(hua);
    // 合化之干本身即参与化气，不计为“克化神”（如甲己化土，甲为木却不可作克土论）
    const hasKe = gans.some(g=> GAN_WX[g]===keHua && !(huaPair && huaPair.includes(g)));
    if (dominant && !hasKe) return { special:'huaqi', subType:'化气格（'+WX_NAME[hua]+'化气）', xi:[hua], ji:[wuXingProducing(hua), dmWx] };
  }
  // 暗冲/暗合官格（须定日、三同字冲合出虚神官、原局无正官）——优先级高于两神成象
  const zhis = [P.year[1],P.month[1],P.day[1],P.hour[1]];
  const dayKey = dayGan + P.day[1];            // 暗冲/暗合官格须「定日」（日柱干支）
  const guanWx2 = wuXingControlling(dmWx);
  // 原局「无正官」：天干无正官十神、且四地支本气无日主正官 → 否则明见正官破格（如庚子日透丁）
  const hasMingGuan = gans.some(g => shiShen(dayGan, dmWx, g, GAN_WX[g]) === '正官')
    || zhis.some(z => GAN_WX[HIDDEN[z] && HIDDEN[z][0]] === guanWx2);
  // 暗冲官格（飞天禄马）：六日之一 + 三同字冲出暗官（庚/壬子兼申子辰、辛亥/癸亥兼亥卯未三合暗冲）+ 原局无正官
  const AN_CHONG_DAY = {
    '丙午': { chong:'午', guanWx:'water', out:'子' },
    '丁巳': { chong:'巳', guanWx:'water', out:'亥' },
    '庚子': { chong:'子', guanWx:'fire',  out:'午', sanhe:'申子辰', opp:'寅午戌' },
    '壬子': { chong:'子', guanWx:'earth', out:'午', sanhe:'申子辰', opp:'寅午戌' },
    '辛亥': { chong:'亥', guanWx:'fire',  out:'巳', sanhe:'亥卯未', opp:'巳酉丑' },
    '癸亥': { chong:'亥', guanWx:'earth', out:'巳', sanhe:'亥卯未', opp:'巳酉丑' },
  };
  if (!hasMingGuan && AN_CHONG_DAY[dayKey]){
    const cfg = AN_CHONG_DAY[dayKey];
    const cnt = zhis.filter(z => z === cfg.chong).length;
    const sanhe = cfg.sanhe && zhis.includes(cfg.chong)
      && (cfg.chong==='子' ? (zhis.includes('申')&&zhis.includes('辰')) : (zhis.includes('卯')&&zhis.includes('未')));
    if (cnt >= 3 || sanhe){
      const guanGan = zhengGuanGan(dayGan);
      const lvl = HIDDEN[cfg.out].indexOf(guanGan);
      // 暗冲官格门槛：冲出字本气须为日主正官方入；冲出财/它神（如壬子日三子冲午，午本气丁为财非官）不入暗冲官格
      if (lvl === 0){
        const lvlName = '本气';
        const SANHE_WX = {'申子辰':'水','寅午戌':'火','亥卯未':'木','巳酉丑':'金'};
        const reason = sanhe
          ? `地支${cfg.sanhe}${SANHE_WX[cfg.sanhe]}局暗冲${cfg.opp}${SANHE_WX[cfg.opp]}局（以${cfg.out}本气之${guanGan}${WX_NAME[cfg.guanWx]}为${dayGan}${WX_NAME[dmWx]}正官），局无明官，入暗冲官格；忌${guanGan}及${cfg.out}填实——虚神本为喜用，大运流年行此即为填实破格。`
          : `${cnt}个${cfg.chong}字冲出${cfg.out}字，${cfg.out}本气为${guanGan}${WX_NAME[cfg.guanWx]}（为${dayGan}${WX_NAME[dmWx]}正官），局无明官，入暗冲官格；忌${guanGan}及${cfg.out}填实——虚神本为喜用，大运流年行此即为填实破格。`;
        return { special:'anChong', subType:'暗冲官格（'+cfg.chong+'暗冲'+cfg.out+'，以'+WX_NAME[cfg.guanWx]+'为暗官）',
                 xi:[cfg.guanWx], ji:[], reason, dayKey, kind:'anChong', guanGan, out:cfg.out, chong:cfg.chong };
      }
    }
  }
  // 暗合官格：四日之一 + 三同字合出暗官 + 原局无正官
  const AN_HE_DAY = {
    '甲辰': { he:'辰', guanWx:'metal', out:'酉' },
    '戊戌': { he:'戌', guanWx:'wood',  out:'卯' },
    '癸卯': { he:'卯', guanWx:'earth', out:'戌' },
    '癸酉': { he:'酉', guanWx:'earth', out:'辰' },
  };
  if (!hasMingGuan && AN_HE_DAY[dayKey]){
    const cfg = AN_HE_DAY[dayKey];
    const cnt = zhis.filter(z => z === cfg.he).length;
    if (cnt >= 3){
      const guanGan = zhengGuanGan(dayGan);
      const lvl = HIDDEN[cfg.out].indexOf(guanGan);
      const lvlName = ['本气','中气','余气'][lvl] || '所藏';
      const reason = `${cnt}个${cfg.he}字暗合${cfg.out}字，${cfg.out}的${lvlName}为${guanGan}${WX_NAME[cfg.guanWx]}（为${dayGan}${WX_NAME[dmWx]}正官），局无明官，入暗合官格；忌${guanGan}及${cfg.out}填实——虚神本为喜用，大运流年行此即为填实破格。`;
      return { special:'anHe', subType:'暗合官格（'+cfg.he+'暗合'+cfg.out+'，以'+WX_NAME[cfg.guanWx]+'为暗官）',
               xi:[cfg.guanWx], ji:[], reason, dayKey, kind:'anHe', guanGan, out:cfg.out, he:cfg.he };
    }
  }
  // 两神成象（两元素主导且相生克关联）：暗冲/暗合未命中才考虑
  const present = Object.keys(wx).filter(w=>wx[w] >= 1);
  if (present.length === 2){
    const a = present[0], b = present[1];
    const related = (WX_SHENG[a]===b||WX_SHENG[b]===a||WX_KE[a]===b||WX_KE[b]===a);
    const maxWx = Object.keys(wx).reduce((x,y)=> wx[x]>=wx[y]?x:y);
    if (related && present.includes(maxWx)) return { special:'liangShen', subType:'两神成象（'+WX_NAME[a]+WX_NAME[b]+'）', xi:present.slice(), ji:[wuXingControlling(a),wuXingControlling(b)].filter(w=>!present.includes(w)) };
  }
  return null;
}

// ===== 强弱总闸：日主净实力 net2（根重加权 + 印旺漂身） =====
// 取代二元 sanDeOrd：地支根为主、天干印比按有无根打折；印旺漂身（生多为克）归弱；克星根破专旺。
function AD_strengthPower(P, dayStem, dmWx){
  const yin = wuXingProducing(dmWx), shang = WX_SHENG[dmWx], cai = WX_KE[dmWx], guan = wuXingControlling(dmWx);
  const zhis = [P.year[1], P.month[1], P.day[1], P.hour[1]];
  const gans = [P.year[0], P.month[0], P.day[0], P.hour[0]];
  // ── 合减力：参与天干五合 / 地支六合的克耗他神，其克耗力羁绊打折（HE_WEAKEN）──
  const heGans = new Set();
  for (let i=0;i<gans.length;i++) for (let j=i+1;j<gans.length;j++){
    const k1 = gans[i]+gans[j], k2 = gans[j]+gans[i];
    if (GAN_WUHE[k1] || GAN_WUHE[k2]){ heGans.add(gans[i]); heGans.add(gans[j]); }
  }
  const heZhis = new Set();
  for (let i=0;i<zhis.length;i++) for (let j=i+1;j<zhis.length;j++){
    if (ZHI_LIUHE[zhis[i]+zhis[j]] || ZHI_LIUHE[zhis[j]+zhis[i]]){ heZhis.add(zhis[i]); heZhis.add(zhis[j]); }
  }
  let dmR = 0, dmR0 = 0, yinR = 0, keeR = 0, shangR = 0, biR0 = 0;
  // 坐下根受伤：日支被任意三会/三合化为他行 → 坐下根(印/比劫)被会合夺气，帮身微（专旺门须严）
  let dayRootHurt = false;
  const _SANJI = [
    ['亥','子','丑','water'],['寅','卯','辰','wood'],['巳','午','未','fire'],['申','酉','戌','earth'],
    ['申','子','辰','water'],['亥','卯','未','wood'],['寅','午','戌','fire'],['巳','酉','丑','earth']
  ];
  for (const t of _SANJI){
    if (zhis.includes(t[0]) && zhis.includes(t[1]) && zhis.includes(t[2]) && zhis.includes(P.day[1]) && t[3] !== dmWx) dayRootHurt = true;
  }
  zhis.forEach(z=>{ (HIDDEN[z]||[]).forEach((g, j)=>{ const w = GAN_WX[g], wgt = [1.0, 0.5, 0.2][j];
    // 克耗他神若处于六合中，羁绊减力（只减克耗分量，不影响日主根/印）
    const ww = (heZhis.has(z) && (w === guan || w === cai || w === shang)) ? wgt * HE_WEAKEN : wgt;
    if (w === dmWx){ let rw = ww; if (z === P.day[1] && dayRootHurt) rw *= 0.2; dmR += rw; if (j === 0){ dmR0 += rw; biR0 += rw; } }
    else if (w === yin) yinR += ww;
    else if (w === shang) shangR += ww;
    if (w === guan || w === cai || w === shang) keeR += ww;
  }); });
  const rooted = dmR >= 0.5;
  let ganBi = 0, ganYin = 0;
  gans.forEach(g=>{ const s = shiShen(dayStem, dmWx, g, GAN_WX[g]);
    if (s === '比肩' || s === '劫财') ganBi++;
    else if (s === '正印' || s === '偏印') ganYin++;
  });
  const yinMul = dayRootHurt ? 0.2 : (rooted ? 0.5 : 0.1);
  const ganBonus = rooted ? (ganBi*0.6 + ganYin*yinMul) : (ganBi*0.15 + ganYin*yinMul);
  // 天干克耗：逐干计权，参与五合者羁绊减力（仅减克耗，不影响日主/印）
  let ganKe = 0;
  gans.forEach(g=>{ const s = shiShen(dayStem, dmWx, g, GAN_WX[g]);
    let w = 0;
    if (s === '正官' || s === '七杀') w = 0.5;
    else if (s === '正财' || s === '偏财') w = 0.4;
    else if (s === '食神' || s === '伤官') w = 0.5;
    if (w > 0 && heGans.has(g)) w *= HE_WEAKEN;
    ganKe += w;
  });
  const sx = wuXingScores(P);
  const sxYin = sx[yin];
  const maxSx = Math.max(sx.wood, sx.fire, sx.earth, sx.metal, sx.water);
  const yinIsMax = sxYin >= 0.9 * maxSx;
  const noBiRoot = biR0 <= 0;   // 无地支本气=日主五行（无禄/比劫禄依托）
  // 印旺漂身（生多为克）：印为全局最旺元素、远超日主根、且日主无本气依托 → 身弱不受生
  const piao = (sxYin > 1.5) && (sxYin > 1.3 * dmR) && yinIsMax && noBiRoot;
  // 生多为克（中度档）：印为全局主导、远超日主、且他神生印加旺，即便日主有本气根亦被厚印埋没（土多金埋之类）
  const shengYinWx = wuXingProducing(yin);  // 生印星(印=yin)的五行：火生土之类；方向须为「生 yin 者」
  const otherShengYin = gans.some(g => GAN_WX[g] === shengYinWx && g !== P.day[0]);
  const yinGanCount = gans.filter(g => { const s = shiShen(dayStem, dmWx, g, GAN_WX[g]); return s === '正印' || s === '偏印'; }).length;
  // 印占字数（天干直接计 + 地支主气藏干计）：量纲安全，用于厚印埋身判定
  const yinChars = [P.year[0],P.month[0],P.day[0],P.hour[0]].filter(g=>GAN_WX[g]===yin).length
                + [P.year[1],P.month[1],P.day[1],P.hour[1]].filter(z=>GAN_WX[(HIDDEN[z]||[])[0]]===yin).length;
  // 生多为克（厚印埋身）：印为全局最旺、远超日主、他神生印加旺；无本气依托或印干≥2 触发
  // 说明：sxYin 来自 wuXingScores（200+ 量级），致 sxYin>1.5/1.6*dmR/2.2*dmR 阈值恒真，
  //   实际退化为 yinIsMax ∧ otherShengYin ∧ (noBiRoot ∨ 印干≥2) —— 此为 aa5b991 实测基线（精确40.7%/粗化71.9%）
  const sdk = (sxYin > 1.5) && yinIsMax && (sxYin > 1.6 * dmR) && otherShengYin
              && (noBiRoot || yinGanCount >= 2 || sxYin > 2.2 * dmR);
  let dmEff = dmR, yinEff;
  if (sdk) { dmEff = dmR * 0.45; yinEff = 0; }
  else if (piao) { dmEff = dmR * 0.3; yinEff = 0; }
  else if (rooted) yinEff = dayRootHurt ? yinR * 0.3 : yinR;
  else yinEff = yinR * 0.4;
  // 印旺生身但食伤旺泄 → 平衡打折（仅当不漂、不生多为克、有依托）：印制食伤护身，食伤亦盗泄日主
  if (!sdk && !piao && rooted && yinR > 1.5 && shangR > 1.2) yinEff *= 0.6;
  const ganBonus2 = (sdk || piao) ? 0 : ganBonus;
  const net2 = dmEff + yinEff + ganBonus2 - (keeR + 0.6 * ganKe);
  // 克星门（合化感知）：克星透干必破专旺；地支克星本/中/余气根若被日主三合/三会化掉则不破
  const hasKeGan = gans.some(g => GAN_WX[g] === guan);
  const transformed = new Set();
  const she = AD_SANHE[dmWx]; if (she && she.every(z => zhis.includes(z))) she.forEach(z => transformed.add(z));
  const shui = AD_SANHUI[dmWx]; if (shui && shui.every(z => zhis.includes(z))) shui.forEach(z => transformed.add(z));
  const isEarth = dmWx === 'earth';
  let kw = 0;
  zhis.forEach(z=>{ if (transformed.has(z)) return;
    if (isEarth && ['辰','戌','丑','未'].includes(z)) return;
    (HIDDEN[z]||[]).forEach((g, i)=>{ if (GAN_WX[g] === guan) kw += [1.0, 0.5, 0.2][i] || 0; });
  });
  const keBreak = hasKeGan || kw > NET_KE_BREAK;
  return { net2, dmR, dmR0, yinR, shangR, biR0, rooted, piao, keBreak, yinEff, ganBonus2, keeR, ganKe, dayRootHurt, sdk, otherShengYin, yinGanCount, yinChars, yinIsMax, dmEff };
}
// 两神成象通关之神（木+火→土，火+土→金，…）：取居中五行搭桥为用
function liangShenXi(a, b){
  for (const z of ['wood','fire','earth','metal','water']){
    if (WX_SHENG[a] === z && WX_SHENG[z] === b) return z;
    if (WX_SHENG[b] === z && WX_SHENG[z] === a) return z;
  }
  return null;
}
// 两神成象检测（改进：其余三行无地支本气、天干不现第三行、且两行相生/克关联）
function AD_liangShenDetect(P, wx){
  const zhis = [P.year[1], P.month[1], P.day[1], P.hour[1]];
  const gans = [P.year[0], P.month[0], P.day[0], P.hour[0]];
  const ent = Object.entries(wx).sort((a, b)=> b[1] - a[1]);
  const related = (a, b) => WX_SHENG[a] === b || WX_SHENG[b] === a || WX_KE[a] === b || WX_KE[b] === a;
  const benWx = new Set(zhis.map(z => GAN_WX[HIDDEN[z][0]]));
  const othersHaveBen = ent.slice(2).some(([w]) => benWx.has(w));
  const ganWxs = new Set(gans.map(g => GAN_WX[g]));
  const ganOutside = [...ganWxs].some(w => w !== ent[0][0] && w !== ent[1][0]);
  const liangOk = ent[0][1] >= 2.5 && ent[1][1] >= 2.5 && !othersHaveBen && !ganOutside && related(ent[0][0], ent[1][0]);
  return liangOk ? { a: ent[0][0], b: ent[1][0] } : null;
}
function AD_congOk(P, dmWx, wx){
  const gans = [P.year[0], P.month[0], P.day[0], P.hour[0]];
  const zhis = [P.year[1], P.month[1], P.day[1], P.hour[1]];
  const maxWx = Object.keys(wx).reduce((a, b) => wx[a] >= wx[b] ? a : b);
  if (GAN_WX[HIDDEN[P.month[1]][0]] === maxWx) return true;
  if (gans.some(g => GAN_WX[g] === maxWx)) return true;
  const cnt = zhis.filter(z => (HIDDEN[z] && HIDDEN[z][0] && GAN_WX[HIDDEN[z][0]] === maxWx)).length;
  if (cnt >= 2) return true;
  if (AD_SANHE[maxWx] && AD_SANHE[maxWx].some(z => zhis.includes(z))) return true;
  if (AD_SANHUI[maxWx] && AD_SANHUI[maxWx].some(z => zhis.includes(z))) return true;
  return false;
}
function AD_fromSub(P, dayStem, dmWx, wx){
  const cai = WX_KE[dmWx], guan = wuXingControlling(dmWx), shang = WX_SHENG[dmWx];
  const maxWx = Object.keys(wx).reduce((a, b) => wx[a] >= wx[b] ? a : b);
  if (maxWx === cai) return 'cong_cai';
  if (maxWx === guan) return 'cong_sha';
  if (maxWx === shang) return 'cong_er';
  return 'cong_shi';
}
// 从格"中和净实力"：把被旺神中和掉的无效生扶（财坏印、官杀克比劫）从 net2 中剔除，
// 得 net2cong。生扶既已失效，日主净实力更负 → 真从；无效生扶仍在则 net2cong 不变 → 弱而不从。
// 生我(印)/同我(比劫)为全局最旺时不可论从（漂身/身弱非从），直接返回原 net2（不会从）。
function AD_congNet2(P, dmWx, pw, wx){
  const cai = WX_KE[dmWx], guan = wuXingControlling(dmWx), yin = wuXingProducing(dmWx);
  const maxWx = Object.keys(wx).reduce((a, b) => wx[a] >= wx[b] ? a : b);
  if (maxWx === yin || maxWx === dmWx) return pw.net2;   // 不能从生我/同我
  let yinPart = pw.yinEff, biPart = pw.ganBonus2;
  const gans = [P.year[0], P.month[0], P.day[0], P.hour[0]];
  const ganCai = gans.some(g => GAN_WX[g] === cai);
  const ganGuan = gans.some(g => GAN_WX[g] === guan);
  if (ganCai || (maxWx === cai && wx[cai] > wx[yin] * 1.2)) yinPart = 0;   // 财坏印（财透干或财旺于印）
  if (ganGuan || maxWx === guan) biPart = 0;                               // 官杀克比劫
  return pw.net2 - (pw.yinEff - yinPart) - (pw.ganBonus2 - biPart);
}

function AD_resolveXiJi(P, dayStem, dmWx, net2, wx){
  const yin = wuXingProducing(dmWx), shang = WX_SHENG[dmWx], cai = WX_KE[dmWx], guan = wuXingControlling(dmWx);
  const pw = AD_strengthPower(P, dayStem, dmWx);
  const net2v = pw.net2;
  let pattern = 'normal', congType = '';
  const gans = [P.year[0], P.month[0], P.day[0], P.hour[0]];
  const zhis = [P.year[1], P.month[1], P.day[1], P.hour[1]];
  // 二级特殊格局先算（化气/暗冲/暗合/两神宽松检测），专旺最高优先
  const sp = AD_resolveSpecial(P, dayStem, dmWx, net2v, wx);
  let liangRes = null;
  // 特殊格局优先级：化气 > 暗冲/暗合官格 > 专旺 > 两神 > 从格
  // 暗冲/暗合官格须定日、三同字冲合出虚神官、原局无正官，优先级高于专旺（避免旺局误判专旺）
  if (sp && sp.special === 'huaqi' && pw.dmR0 <= 0){
    // 化气格：仅当日主有本气禄根（真依托）才破化；泄神不破化（引擎 AD_resolveSpecial 本只破于克化神天干）
    pattern = 'huaqi'; congType = sp.subType;
  } else if (sp && (sp.special === 'anChong' || sp.special === 'anHe')){
    pattern = sp.special; congType = sp.subType;
  } else if (!pw.keBreak && net2v > NET_ZHUAN){
    pattern = 'zhuanwang';
  } else {
    liangRes = AD_liangShenDetect(P, wx);
    if (liangRes){
      pattern = 'liangShen';
      congType = '两神成象（' + WX_NAME[liangRes.a] + WX_NAME[liangRes.b] + '）';
    } else if (pw.dmR < NET_DM_REAL_ROOT_WEAK && AD_congNet2(P, dmWx, pw, wx) < NET_CONG && AD_congOk(P, dmWx, wx)){
      pattern = 'cong';
      congType = AD_fromSub(P, dayStem, dmWx, wx);
    }
  }
  let xi, ji;
  if (pattern === 'zhuanwang'){
    xi = [dmWx, yin];            // 专旺：喜比劫、印绶，顺其旺势
    ji = [cai, guan, shang];     // 忌财、官杀、食伤（克泄耗激怒旺神）
  } else if (pattern === 'cong'){
    if (congType === 'cong_cai') xi = [cai];
    else if (congType === 'cong_sha') xi = [guan];
    else if (congType === 'cong_er') xi = [shang];
    else xi = [cai, guan, shang]; // 从势：喜所从之旺神
    ji = [yin, dmWx];            // 忌印、比劫（扶身则假从破格）
  } else if (pattern === 'liangShen'){
    const a = liangRes.a, b = liangRes.b;
    xi = [liangShenXi(a, b)].filter(Boolean);   // 两神成象：以通关之神为用
    ji = [wuXingControlling(a), wuXingControlling(b)].filter(w => w !== a && w !== b);
  } else if (pattern === 'huaqi' || pattern === 'anChong' || pattern === 'anHe'){
    xi = sp ? sp.xi : [dmWx];
    ji = sp ? sp.ji : [wuXingControlling(dmWx)];
  } else {
    // 普通盘身旺/身弱由三元打分定（混合引擎 2026-07-25）：≥72 身强取克泄耗，否则（中和/身弱）取印比生扶
    const strong = AD_sanyuanBase(P, dayStem).total >= SY_STRONG;
    if (strong){
      // 身旺取用：克泄耗为喜（优先取有根，三行皆无根则回退全量；官食伤皆有时去食伤免伤官见官）
      const rooted = [cai,guan,shang].filter(w=>AD_hasRoot(w, P));
      if (rooted.length === 0){ xi = [cai, guan, shang]; }
      else {
        const xiSet = new Set();
        if (rooted.includes(guan)) xiSet.add(guan);
        if (rooted.includes(shang)) xiSet.add(shang);
        if (rooted.includes(cai)) xiSet.add(cai);
        if (xiSet.has(guan) && xiSet.has(shang)) xiSet.delete(shang);
        xi = Array.from(xiSet);
      }
      ji = [yin, dmWx];
    } else {
      xi = [yin, dmWx]; ji = [cai, guan, shang];
    }
  }
  const anHit = sp && (sp.special === 'anChong' || sp.special === 'anHe');
  return { pattern, congType, xi, ji, xiNames: xi.map(w=>WX_NAME[w]), jiNames: ji.map(w=>WX_NAME[w]),
    anReason: anHit ? sp.reason : '', anDayKey: anHit ? sp.dayKey : '', anKind: anHit ? sp.kind : '' };
}
// P1-1：将调候/通关/病药整合进主喜忌（仅 normal 格局；专旺/从 成格喜忌不可被覆盖）
function AD_comprehensiveXiJi(resolved, wx, monthZhi){
  if (resolved.pattern !== 'normal') return { xi: resolved.xi, ji: resolved.ji, tiaoWx: '', added: [] };
  const xiSet = new Set(resolved.xi), jiSet = new Set(resolved.ji), added = [];
  // 调候：寒局需火、燥局需水，调候为急，即便扶抑原本为忌亦转喜
  let tiaoWx = '';
  if (['亥','子','丑'].includes(monthZhi)) tiaoWx = 'fire';
  else if (['巳','午','未'].includes(monthZhi)) tiaoWx = 'water';
  if (tiaoWx){
    if (jiSet.has(tiaoWx)) jiSet.delete(tiaoWx);
    if (!xiSet.has(tiaoWx)){ xiSet.add(tiaoWx); added.push(tiaoWx); }
  }
  // 通关：两五行交战，以居中五行搭桥
  const strong2 = Object.keys(wx).filter(w=>wx[w]>=3);
  if (strong2.length>=2){
    const pair = [strong2[0], strong2[1]];
    const bridge = {'wood|fire':'earth','fire|earth':'metal','earth|metal':'water','metal|water':'wood','water|wood':'fire','wood|metal':'fire','fire|water':'wood','earth|water':'metal','metal|wood':'water','water|earth':'wood'}[pair.sort().join('|')];
    if (bridge){ if (jiSet.has(bridge)) jiSet.delete(bridge); if (!xiSet.has(bridge)){ xiSet.add(bridge); added.push(bridge); } }
  }
  // 病药：最旺五行为病，克之者为药
  const maxWx = Object.keys(wx).reduce((a,b)=> wx[a]>=wx[b]?a:b);
  const ke5 = {wood:'metal',fire:'water',earth:'wood',metal:'fire',water:'earth'};
  const yao = ke5[maxWx];
  if (yao){ if (jiSet.has(yao)) jiSet.delete(yao); if (!xiSet.has(yao)){ xiSet.add(yao); added.push(yao); } }
  return { xi: Array.from(xiSet), ji: Array.from(jiSet), tiaoWx, added };
}
const DM_TRAIT = {
  '甲':'甲木日主，上进积极，个性耿直，心地仁慈，有天生领导气象，然有时应变欠敏。',
  '乙':'乙木日主，感觉细腻，有审美力，外表谦虚而内心占有欲强，善随机应变，适应环境能力佳。',
  '丙':'丙火日主，活泼豪放，急躁不拘小节，乐于服务，心地光明，然有时缺乏耐性与坚毅。',
  '丁':'丁火日主，温和敏锐，思想细腻，重牺牲富同情，为人守礼而多疑，心机智深。',
  '戊':'戊土日主，沉稳厚重，重名誉信实无欺，憨厚而略显呆板，生活较为平实。',
  '己':'己土日主，细心多疑，常具双重性格，多才多艺能伸能缩，重视内涵，做事精明而多变化。',
  '庚':'庚金日主，干练强硬，粗犷豪爽具侠义心，个性好胜，爱出风头。',
  '辛':'辛金日主，温润秀气，重感情而性不坚，爱面子有虚荣，有气质而欠魄力。',
  '壬':'壬水日主，乐观外向热情，善把握时机，允文允武，虽聪明却纵欲任性。',
  '癸':'癸水日主，平静和缓，柔情善感好幻想，重情调讲原则，不尚实际，遇逆境不馁而有坚忍。'
};
const TEN_GOD_TRAIT_FULL = {
  '正官': { xing:'正直保守，重责任与纪律', you:'端庄稳重，秉公尚义，重信用负责任，安于本分而有人群威望，严于律己宽以待人', que:'偏于保守优柔，临事易犹豫而坐失良机' },
  '七杀': { xing:'刚烈偏激，叛逆好胜', you:'有志气进取心，坚决果断，嫉恶如仇，勇于突破开创，有威严领导力', que:'性刚易偏激，少知心友，好胜猜忌易树敌，冲动而粗鲁' },
  '正财': { xing:'节俭憨直，谨慎守本分', you:'独善其身，安分耐劳，珍惜家庭，守信用而有满足感', que:'过重则刻薄吝啬，魄力不足虎头蛇尾，刻板不知变通' },
  '偏财': { xing:'圆滑干练，慷慨豪迈而急躁', you:'善抓机遇营财，速战速决，乐观有手腕，外缘佳多意外之得', que:'慷慨易疏理财，女人缘多扰家，意外开销偏大' },
  '正印': { xing:'温文慈祥，重名誉爱面子', you:'方正亲切，宽容仁慈，重内涵学问，易得名誉近宗教', que:'依赖心重，思想天真不切实际，爱面子而打肿脸充胖子' },
  '偏印': { xing:'忧郁疑虑，孤僻重幻想', you:'领悟奇特，感觉敏锐善观察，喜创造学艺，老练喜怒不形于色', que:'三心二意无事空忙，内向多疑钻牛角尖，偏印过多与亲缘薄' },
  '食神': { xing:'含蓄保守，温柔多情而聪明', you:'聪明精细，温和通情达理，清高儒雅，爱好文艺，有口福善烹调', que:'理想易脱现实，体力不足易疲劳，喜幻想不喜拘束，内觉空虚' },
  '伤官': { xing:'任性乐观，活跃骄傲而富创造', you:'多才多艺或清逸，领悟强理想高，倔强有战斗精神，易成特殊领域之英', que:'博而不精易败，恃才傲物目中无人，好管闲事弄巧成拙' },
  '比肩': { xing:'自主冷静，自尊心与自我意识强', you:'意志坚定，自尊心强明分寸，自信乐观进取，重情义', que:'以自我为中心，少体谅人，易争执，待人严厉不甚得缘' },
  '劫财': { xing:'执拗嫉妒，不认输野心大而浮华', you:'个性突出惹人注目，口才立论精辟，反应灵敏，易得朋友', que:'浮而不实，嫉妒双重性格，不善理财，易因友而损家' }
};
function dominantTenGod(tg){
  const all = [tg.year.gan,tg.year.zhi,tg.month.gan,tg.month.zhi,tg.day.zhi,tg.hour.gan,tg.hour.zhi];
  const cnt = {};
  all.forEach(s=>{ if (s && s!=='比肩' && s!=='劫财') cnt[s]=(cnt[s]||0)+1; });
  let best=null, n=0;
  for (const k in cnt) if (cnt[k]>n){ n=cnt[k]; best=k; }
  return best;
}
// 大运批断 V2：依据《岁月分析》方法论——「外因（大运）作用于内因（命局）」，
// 分析大运干支与命局四柱的生克冲合刑害 / 三合三会，判断干支喜忌、引动何宫，
// 从而针对【该命局】给出批断（而非罗列十神标签）。返回 {text, gong}
// 大运→命局「作用路线」判定（《干支作用论》）：大运(第二层次)能否真正触及用神/忌神
// 忌神运若无路线伤用神，则实质平顺（鞭长莫及）；喜用运若无路线助用神，亦实质平顺（爱莫能助）。
function dayunRoute(P, dayStem, dmWx, d, xi, ji){
  const gw = d.gz[0], zw = d.gz[1];
  const gwWx = GAN_WX[gw];
  const zwBen = HIDDEN[zw][0], zwWx = GAN_WX[zwBen];
  const xiSet = new Set(xi), jiSet = new Set(ji);
  const rt = { xiHelp:false, xiHarm:false, jiRestrained:false, jiBoosted:false, reachXi:false, reachJi:false };
  const pillars = [['年',P.year],['月',P.month],['日',P.day],['时',P.hour]];
  // 一、天干层：大运干(高层次)直击命局天干
  pillars.forEach(([role,p])=>{
    const tw = GAN_WX[p[0]];
    if (xiSet.has(tw)){
      if (gwWx===wuXingProducing(tw)) rt.xiHelp = true;        // 大运干生用神天干
      else if (gwWx===WX_KE[tw]) rt.xiHarm = true;             // 大运干克用神天干
    }
    if (jiSet.has(tw)){
      if (gwWx===WX_KE[tw]) rt.jiRestrained = true;            // 大运干克忌神天干 → 制忌
      else if (gwWx===wuXingProducing(tw)) rt.jiBoosted = true;// 大运干生忌神天干 → 助忌
    }
  });
  // 二、地支流层：大运支须与命局地支有刑冲合害/三合三会方实质作用
  pillars.forEach(([role,p])=>{
    const r = AD_relateTwo(zw, p[1]);
    if (!r) return;
    const benWx = GAN_WX[HIDDEN[p[1]][0]];
    const zangWx = [...new Set((HIDDEN[p[1]]||[]).map(g=>GAN_WX[g]))];
    const isXiZ = zangWx.some(w=>xiSet.has(w));
    const isJiZ = zangWx.some(w=>jiSet.has(w));
    const he = /合|会/.test(r);
    if (zwWx===WX_KE[benWx]){           // 大运支克/冲命局地支本气
      if (isXiZ) rt.xiHarm = true;
      if (isJiZ) rt.jiRestrained = true;
    } else if (zwWx===wuXingProducing(benWx)){ // 大运支生命局地支本气
      if (isXiZ) rt.xiHelp = true;
      if (isJiZ) rt.jiBoosted = true;
    }
    if (he){                           // 合会聚气：引动该支五行
      if (isXiZ) rt.xiHelp = true;
      if (isJiZ) rt.jiBoosted = true;
    }
  });
  // 三、大运支被命局本气反克（下克上力弱，仅当大运支本身为忌/喜时计其减力）
  pillars.forEach(([role,p])=>{
    const benWx = GAN_WX[HIDDEN[p[1]][0]];
    if (benWx===WX_KE[zwWx]){
      if (jiSet.has(zwWx)) rt.jiRestrained = true; // 大运忌神被制 → 利日主
      if (xiSet.has(zwWx)) rt.xiHarm = true;       // 大运用神被制 → 减利
    }
  });
  rt.reachXi = rt.xiHelp || rt.jiRestrained;  // 用神得助 或 忌神被制 → 真喜
  rt.reachJi = rt.xiHarm || rt.jiBoosted;      // 用神受伤 或 忌神得助 → 真忌
  return rt;
}
// 十神取象字典（《十神组合》《岁月分析》综合）：中性的「寓意区间」，吉凶由喜忌定
const SS_XIANG = {
  '比肩': { people:'同辈、朋友、兄弟姐妹', happy:'得同辈朋友之助、合作顺遂', bad:'同辈争竞、朋友分财、自我耗散' },
  '劫财': { people:'朋友、同事、合伙者', happy:'行动力旺、开拓进取有成', bad:'破财、被夺、口舌争讼' },
  '食神': { people:'子女、下属、晚辈', happy:'表达顺畅、才艺发挥、投资有得、子女乖巧', bad:'泄身过度、思虑多、子女或下属生烦' },
  '伤官': { people:'才华、情感、晚辈', happy:'才艺显露、名气渐起', bad:'口舌是非、情感波动、犯官、女命克夫' },
  '正财': { people:'妻子、父亲、正业之财', happy:'财运稳定、妻贤、正业进财', bad:'破正财、妻病或感情波动、父亲欠安' },
  '偏财': { people:'父亲、外财、偏业', happy:'偏财易得、外缘佳、投资获利', bad:'偏财耗散、因财生事、父亲不安' },
  '正官': { people:'职位、名誉、丈夫（女命）', happy:'职位升迁、名誉清贵、正缘安定', bad:'官非口舌、职位动摇、压力缠身' },
  '七杀': { people:'压力、小人、病灾、武职', happy:'权威立、魄力显、化压力为动力', bad:'官司压力、病灾、小人暗算' },
  '正印': { people:'母亲、长辈、文书、学业', happy:'得长辈护持、学业文书顺、住房安稳', bad:'印重身疲、依赖懒散、长辈烦忧' },
  '偏印': { people:'长辈（偏）、冷门技艺、偏业', happy:'偏业有得、技艺精进', bad:'思虑孤僻、冷门受困、枭神夺食之扰' }
};
const SS_ROLE = {'年':'祖上','月':'父母、师长、事业平台','日':'夫妻与自身','时':'子女、晚辈'};
// 天干五合（救应判定用）：乙庚合/甲己合/丙辛合/丁壬合/戊癸合
const GAN_WUHE = {'甲己':1,'乙庚':1,'丙辛':1,'丁壬':1,'戊癸':1};
// 地支六合（暗合/羁绊减力用）：子丑合土、寅亥合木、卯戌合火、辰酉合金、巳申合水、午未合火
const ZHI_LIUHE = {'子丑':1,'丑子':1,'寅亥':1,'亥寅':1,'卯戌':1,'戌卯':1,'辰酉':1,'酉辰':1,'巳申':1,'申巳':1,'午未':1,'未午':1};
// 合绊减力系数：参与天干五合/地支六合的克耗他神，其克耗力羁绊打折（不计入合化的化神增强，仅作羁绊减力）
const HE_WEAKEN = 0.4;
// 大运/流年（高层次）作用于命局，分析「哪个字受伤/得生」+ 十神取象（原则A：受伤者定应事，来者定起因；原则B：伤喜用才凶、伤忌神反吉）
function hurtTargets(srcGz, P, xi, ji, dayStem, dmWx){
  const srcGan = srcGz[0], srcZhi = srcGz[1];
  const srcGanWx = GAN_WX[srcGan], srcZhiBen = HIDDEN[srcZhi][0], srcZhiWx = GAN_WX[srcZhiBen];
  const xiSet = new Set(xi), jiSet = new Set(ji);
  const pillars = [['年',P.year],['月',P.month],['日',P.day],['时',P.hour]];
  const allZhis = pillars.map(([r,p])=>p[1]).concat(srcZhi);
  const out = [];
  // 天干层：高层次干克/生四柱天干（君/臣 管 民）
  pillars.forEach(([role,p])=>{
    const tGan = p[0], tWx = GAN_WX[tGan];
    const act = _ganAct(srcGanWx, tWx);
    if(act==='克' || act==='生'){
      const tSS = shiShen(dayStem,dmWx,tGan,tWx);
      const sSS = shiShen(dayStem,dmWx,srcGan,srcGanWx);
      out.push({ role, kind:'干', char:tGan, wx:tWx, ss:tSS, srcSS:sSS,
        isXi:xiSet.has(tWx), isJi:jiSet.has(tWx), act: act==='克'?'伤':'生', rel: act });
    }
  });
  // 地支流层：须刑冲合害/三合三会才实质作用
  pillars.forEach(([role,p])=>{
    const tZhi = p[1], tBen = HIDDEN[tZhi][0], tWx = GAN_WX[tBen];
    const rel = _zhiRel(srcZhi, tZhi, allZhis);
    if(!rel) return;
    const sBen = HIDDEN[srcZhi][0], sWx = GAN_WX[sBen];
    const tSS = shiShen(dayStem,dmWx,tBen,tWx);
    const sSS = shiShen(dayStem,dmWx,sBen,sWx);
    const hurt = /冲|刑|害|破/.test(rel);
    out.push({ role, kind:'支', char:tBen, wx:tWx, ss:tSS, srcSS:sSS,
      isXi:xiSet.has(tWx), isJi:jiSet.has(tWx), act: hurt?'伤':'生', rel });
  });
  return out;
}
function effSent(e, srcLabel){
  const who = e.kind==='干' ? (e.role+'干'+e.char) : (e.role+'支本气'+e.char);
  const sx = (SS_XIANG[e.srcSS] && SS_XIANG[e.srcSS].people) || (e.srcSS||'外因');
  if(e.act==='伤'){
    if(e.isXi) return `命局${who}（日主之${e.ss}，属喜用）被${srcLabel}所${e.rel}，${e.ss}受伤，多应${SS_XIANG[e.ss].bad}；起因在${e.srcSS}（${sx}）之克伐。`;
    if(e.isJi) return `命局${who}（日主之${e.ss}，属忌神）被${srcLabel}所${e.rel}，${e.ss}受制得去，反为利多，多应${SS_XIANG[e.ss].happy}。`;
    return `命局${who}（日主之${e.ss}）被${srcLabel}所${e.rel}，${e.ss}受扰，应事多关${SS_XIANG[e.ss].people}。`;
  } else {
    if(e.isXi) return `命局${who}（日主之${e.ss}，属喜用）得${srcLabel}${e.rel}而生，${e.ss}得力，多应${SS_XIANG[e.ss].happy}。`;
    if(e.isJi) return `命局${who}（日主之${e.ss}，属忌神）得${srcLabel}${e.rel}而壮，${e.ss}势增，多应${SS_XIANG[e.ss].bad}。`;
    return `命局${who}（日主之${e.ss}）与${srcLabel}${e.rel}，气机和合，应事多关${SS_XIANG[e.ss].people}。`;
  }
}
/* ===== 宫位生命周期 · 阶段化「策」洞察 =====
 * 阿文 07-21 定调：四柱每个字主 8 岁（年柱 1-16 / 月柱 17-32 / 日柱 33-48 / 时柱 49-64），
 * 干支互克须落到具体年龄段 + 十神取象，才能产出有「策」感的结论，而非泛泛「财星为水」。
 * 复用引擎已有：_ganAct / _zhiRel / shiShen / HIDDEN / GAN_WX / WX_KE / SS_XIANG。 */
const AD_PALACE = {
  year:  { gan:[1,8],   zhi:[9,16]   },
  month: { gan:[17,24], zhi:[25,32]  },
  day:   { gan:[33,40], zhi:[41,48]  },
  hour:  { gan:[49,56], zhi:[57,64]  }
};
const AD_SS_HINT = {
  '正印':'印主文墨、学业与长辈荫护', '偏印':'偏印主冷门技艺、偏业与孤学',
  '正财':'财主正业之利、妻缘与务实', '偏财':'偏财主外财、父缘与机遇',
  '正官':'官主职位、名誉与规矩',     '七杀':'杀主压力、魄力与小人病灾',
  '食神':'食神主才艺、表达与子女',   '伤官':'伤官主才华、情感与叛逆',
  '比肩':'比肩主同辈、合作与自我',   '劫财':'劫财主朋辈争竞、破耗'
};
const AD_TENSE_CE = {
  '财克印':'财星坏印，幼年及求学阶段易因重利轻文、外务分心而学业根基不稳；宜自幼立规矩、养专注，莫早逐财利。',
  '财克偏印':'偏财损偏印，偏业之学易受功利牵扰；宜择一专攻、忌三心二意。',
  '官克身':'官杀克身，青年立业期压力大、易遇职位规矩之束；宜守分、积实力，忌硬碰。',
  '杀克身':'七杀攻身，该阶段压力陡增、小人病灾需防；宜以韧化压、远是非。',
  '比劫克财':'比劫夺财，该阶段财易外泄、朋辈分利；宜独立经营、忌合伙草率。',
  '劫财克财':'劫财夺正财，妻缘与正财易受朋辈争竞所损；婚恋财事宜明算账。',
  '食伤克官':'食伤制官，求知期易恃才傲上、犯官非口舌；宜敛锋、尊规矩。',
  '伤官克官':'伤官见官，口舌是非、职位波动明显；女命尤防感情波折，宜柔守。',
  '印克食伤':'印绶夺食，才华表达受抑、思虑多而行动缓；宜破依赖、敢于尝试。',
  '枭神夺食':'偏印夺食，才艺子女之途易受孤学所困；宜开放交流、忌闭门。'
};
function AD_stageFlavor(lo, hi){
  if (hi <= 16) return '幼年启蒙期';
  if (hi <= 32) return '幼学至青年立业前';
  if (hi <= 48) return '青年至中年发展期';
  if (lo <= 48) return '中年发展至晚年过渡';
  return '晚年收成期';
}
// 十神互克归一（兼容正/偏）：财→印、官杀→比劫、食伤→官杀、印→食伤、比劫→财
function _tenseNorm(aSS, bSS){
  if (/财/.test(aSS) && /印/.test(bSS)) return '财克印';
  if (/财/.test(aSS) && /偏印/.test(bSS)) return '财克偏印';
  if (/[官杀]/.test(aSS) && /[比劫]/.test(bSS)) return '官克身';
  if (/[食伤]/.test(aSS) && /[官杀]/.test(bSS)) return '食伤克官';
  if (/印/.test(aSS) && /[食伤]/.test(bSS)) return '印克食伤';
  if (/[比劫]/.test(aSS) && /财/.test(bSS)) return '比劫克财';
  return aSS+'克'+bSS;
}
function AD_lifeStageInsights(P, dayStem, dmWx, xi, ji){
  const xiSet = new Set(xi), jiSet = new Set(ji);
  const keys = ['year','month','day','hour'];
  const pairs = [];
  for (let i=0;i<4;i++) for (let j=i+1;j<4;j++) pairs.push([keys[i],keys[j]]);
  const items = [];
  let ord = 0;
  // 天干层：i 干对 j 干 的克/生（方向确定 actor/tgt）
  pairs.forEach(([ak,bk])=>{
    const aG=P[ak][0], bG=P[bk][0];
    const rel = _ganAct(GAN_WX[aG], GAN_WX[bG]);
    if (rel==='克' || rel==='生')      items.push(_buildLS(ak,bk,'干',aG,bG, rel==='克', ord++, P, xiSet, jiSet));
    else if (rel==='被克'||rel==='被生') items.push(_buildLS(bk,ak,'干',bG,aG, rel==='被克', ord++, P, xiSet, jiSet));
  });
  // 地支层：i 支与 j 支 的刑冲合害破
  const allZhis = keys.map(k=>P[k][1]);
  pairs.forEach(([ak,bk])=>{
    const aZ=P[ak][1], bZ=P[bk][1];
    const rel = _zhiRel(aZ, bZ, allZhis);
    if (!rel) return;
    const aBen=HIDDEN[aZ][0], bBen=HIDDEN[bZ][0];
    const hurt = /冲|刑|害|破/.test(rel);
    items.push(_buildLS(ak,bk,'支',aBen,bBen,hurt,ord++, P, xiSet, jiSet, rel));
  });
  // 显著度排序：克(干)>冲>刑>害破>合>生；同档按出现序
  const sev = it => ({'克':3,'冲':3,'刑':2,'害':1,'破':1,'合':0,'生':-1})[it.act] ?? 0;
  items.sort((a,b)=> (sev(b)-sev(a)) || a.ord-b.ord);
  // 去重（同两柱组合只留最显著一条；同类互克「策」只出现一次，避免重复）
  const seen = new Set(); const seenTense = new Set(); const out = [];
  items.forEach(it=>{
    const k=[it.actor,it.tgt,it.kind, it.act==='合'?'h':'x'].sort().join('-');
    if(seen.has(k)) return; seen.add(k);
    if(it.act==='克' && it.tense && seenTense.has(it.tense)) return;
    if(it.tense) seenTense.add(it.tense);
    out.push(it);
  });
  return out.slice(0,4).map(it=> ({ ageText: it.ageText, title: it.title, text: it.text }));
}
// 把阶段化「策」按主题映射到四张维度卡（性格/财运/事业/姻缘），供卡片顶部引导语使用
function AD_dimOf(text){
  const w = {
    char:    [['印',2],['比劫',1],['文',1],['学',1],['心性',1],['性格',1],['表达',1],['技艺',1],['自我',1],['仁',1]],
    wealth:  [['财',2],['求财',1],['破财',1],['进财',1],['利',1],['积蓄',1],['经营',1],['比劫',1]],
    career:  [['官',2],['事业',1],['权责',1],['职位',1],['学业',1],['平台',1],['技艺',1],['口舌',1]],
    marriage:[['妻',2],['夫',2],['婚姻',2],['配偶',2],['姻缘',2],['日支',1]]
  };
  let best=null, bestScore=0;
  for (const dim in w){
    let sc=0;
    for (const [kw,wt] of w[dim]) if (text.indexOf(kw)>=0) sc+=wt;
    if (sc>bestScore){ bestScore=sc; best=dim; }
  }
  return bestScore>0 ? best : null;
}
function AD_lsFor(items, dim){
  for (const it of (items||[])){ if (AD_dimOf(it.text)===dim) return it; }
  return null;
}
function AD_lsHtml(items, dim){
  const it = AD_lsFor(items, dim);
  if (!it) return '';
  return `<p class="ls-lead"><span class="ls-tag">策</span>${it.text}</p>`;
}
function _buildLS(actor, tgt, kind, aChar, bChar, actIsTension, ord, P, xiSet, jiSet, rel){
  const aWx=GAN_WX[aChar], bWx=GAN_WX[bChar];
  const dm = P.day[0], dmW = GAN_WX[dm];
  const aSS = shiShen(dm, dmW, aChar, aWx);
  const bSS = shiShen(dm, dmW, bChar, bWx);
  const aAge=AD_PALACE[actor], bAge=AD_PALACE[tgt];
  const lo=Math.min(aAge.gan[0], bAge.gan[0]), hi=Math.max(aAge.zhi[1], bAge.zhi[1]);
  const ageText = lo+'–'+hi+' 岁';
  const flv = AD_stageFlavor(lo,hi);
  const aH = AD_SS_HINT[aSS]||('日主之'+aSS), bH = AD_SS_HINT[bSS]||('日主之'+bSS);
  const aWhere = kind==='干' ? (actor+'干'+aChar) : (actor+'支本气'+aChar);
  const bWhere = kind==='干' ? (tgt+'干'+bChar) : (tgt+'支本气'+bChar);
  const bIsXi = xiSet.has(bWx), bIsJi = jiSet.has(bWx);
  let tail='';
  if (bIsXi) tail='（所伤'+bSS+'为喜用，影响更实，尤当留意）';
  else if (bIsJi) tail='（所制'+bSS+'为忌神，反有去病之利）';
  let text='';
  const exactTense = aSS+'克'+bSS;
  const nKey = actIsTension ? _tenseNorm(aSS, bSS) : '';
  if (actIsTension){
    const custom = AD_TENSE_CE[nKey] || AD_TENSE_CE[exactTense];
    if (custom){
      text = `${aWhere}（日主之${aSS}）克 ${bWhere}（日主之${bSS}），于 ${ageText}（${flv}）构成「${nKey}」之象：${custom}${tail}`;
    } else {
      const sx = (SS_XIANG[aSS]&&SS_XIANG[aSS].people)||aSS;
      text = `${aWhere}（日主之${aSS}）克 ${bWhere}（日主之${bSS}），于 ${ageText}（${flv}）：${bH}受扰，多应 ${(SS_XIANG[bSS]&&SS_XIANG[bSS].bad)||'相关人事波动'}；成因在${aSS}（${sx}）之克伐。${tail}`;
    }
  } else if (rel && /合/.test(rel)){
    text = `${actor}支${aChar}与${tgt}支${bChar} ${rel}，于 ${ageText}（${flv}）气机和合，${bH}得${aSS}之谐，多主 ${(SS_XIANG[bSS]&&SS_XIANG[bSS].happy)||'相关人事和顺'}；亦须防牵绊迟滞。`;
  } else {
    text = `${aWhere}（日主之${aSS}）生 ${bWhere}（日主之${bSS}），于 ${ageText}（${flv}）${bH}得力，多应 ${(SS_XIANG[bSS]&&SS_XIANG[bSS].happy)||'相关人事顺遂'}。`;
  }
  const actSym = actIsTension ? '克' : (rel&&/合/.test(rel)?'合':'生');
  const title = `${aWhere} ${actSym} ${bWhere}（${exactTense||(aSS+(rel&&/合/.test(rel)?'合':'生')+bSS)}）`;
  return { actor, tgt, kind, act: actIsTension?'克':(rel&&/合/.test(rel)?'合':'生'), ord, ageText, title, text, tense: nKey };
}
// 半合：两字同属某一三合局（不论第三字是否在地支），用于「冲被阻隔」判定
function AD_heBan(a, b){
  for (const k in AD_SANHE){ const arr = AD_SANHE[k]; if (arr.includes(a) && arr.includes(b) && a !== b) return '半合'+WX_NAME[WX_KEY[k]]; }
  return '';
}
// 综合合关系（六合/三合/三会/半合），供冲合阻隔判定
function AD_heRel(a, b, allZhis){
  const r = _zhiRel(a, b, allZhis);
  if (r && r.indexOf('合') >= 0) return r;
  const bh = AD_heBan(a, b);
  if (bh) return bh;
  return '';
}
// 日主强弱·推理叙述：其余七字按生克路线与日主论生克，输出类似
// 「日元丁火虽在月建不得令，但时支巳火本气通根…通根相连不减力…」的推理句
// 日主强弱·推理叙述（范式：得令 → 地支根/印 → 天干帮扶与全局克泄耗 → 综合结论+用神忌神）
// 自然叙述、含十神名、不带括号（去括号去冗余铁律 07-24）
function AD_strengthNarrative(P, dayStem, dmWx, b){
  const dmGan = P.day[0], dmName = WX_NAME[dmWx];
  const PIL = [['年',P.year],['月',P.month],['日',P.day],['时',P.hour]];
  const allZhis = PIL.map(x=>x[1][1]);

  // 特殊格局（专旺/从格/化气…）走范式风格短句
  if (b.pattern && b.pattern !== 'normal'){
    const map = {
      zhuanwang: `日元${dmGan}${dmName}成专旺格，印比林立、全局一气，日主极旺，宜顺其势，以泄以耗为用，忌克抑。`,
      cong: `日元${dmGan}${dmName}无根无助、弃命相从，所从旺神得地则成，忌印比扶身破格。`,
      huaqi: `日元${dmGan}${dmName}化气成形，气局一变，当从化神之势而论。`,
      liangShen: `日元${dmGan}${dmName}两神成象，二气清纯，宜顺其性。`,
      anChong: `日元${dmGan}${dmName}，${b.anReason}`,
      anHe: `日元${dmGan}${dmName}，${b.anReason}`
    };
    return map[b.pattern] || `日元${dmGan}${dmName}入特殊格局，宜以格局之法别论。`;
  }

  // ① 得令
  const monthZhi = P.month[1], mb = HIDDEN[monthZhi][0], mbWx = GAN_WX[mb];
  const ling = (mbWx === dmWx) || (WX_SHENG[mbWx] === dmWx);
  const lingSS = shiShen(dayStem, dmWx, mb, mbWx);
  let seg1;
  if (ling){
    const lingDesc = (mbWx === dmWx)
      ? `月令为${dmName}本气禄地`
      : `月令${mb}${WX_NAME[mbWx]}为日主之${lingSS}、生气相资`;
    seg1 = `${dmGan}${dmName}生于${monthZhi}月得令，${lingDesc}，根基初始有力`;
  } else {
    let state;
    // 五行旺相休囚死（以月令为参照）：当令者旺、令生者相、生令者休、克令者囚、令克者死
    if (WX_KE[mbWx] === dmWx) state = '令克者死';
    else if (WX_SHENG[dmWx] === mbWx) state = '生令者休';
    else if (WX_KE[dmWx] === mbWx) state = '克令者囚';
    else state = '失时';
    seg1 = `${dmGan}${dmName}生于${monthZhi}月不得令，${state}，根基初始不足`;
  }

  // ② 地支根 / 印星 + 冲合受损
  const dZhi = P.day[1];
  const rootToks = [], rootZhis = [];
  const sitRoots = [];
  HIDDEN[dZhi].forEach((g,i)=>{ if (GAN_WX[g]===dmWx) sitRoots.push({i,g}); });
  if (sitRoots.length) sitRoots.forEach(r=>{ rootToks.push(`日支${dZhi}坐${r.g}${r.i===0?'本气强根':(r.i===1?'中气之根':'余气微根')}`); rootZhis.push(dZhi); });
  PIL.forEach(([pos, gz])=>{
    if (pos === '日') return;
    const z = gz[1];
    const rh = [];
    HIDDEN[z].forEach((g,i)=>{ if (GAN_WX[g]===dmWx) rh.push({i,g}); });
    if (rh.length){
      rh.forEach(r=>{ rootToks.push(`${pos}支${z}为${dmName}${r.i===0?'本气强根':(r.i===1?'中气之根':'余气微根')}`); rootZhis.push(z); });
    } else {
      const yh = [];
      HIDDEN[z].forEach(g=>{ if (WX_SHENG[GAN_WX[g]]===dmWx) yh.push(g); });
      if (yh.length) rootToks.push(`${pos}支${z}藏${[...new Set(yh)].join('')}${WX_NAME[GAN_WX[yh[0]]]}，为印星生${dmName}，然无实质${dmName}根支援`);
    }
  });
  let seg2 = rootToks.length ? `地支${rootToks.join('，')}` : `地支无${dmName}之根，日主漂浮无依`;
  for (let i=0;i<PIL.length;i++) for (let j=i+1;j<PIL.length;j++){
    const za = PIL[i][1][1], zb = PIL[j][1][1];
    if (!AD_CHONG.some(pr=>(pr[0]===za&&pr[1]===zb)||(pr[0]===zb&&pr[1]===za))) continue;
    if (!rootZhis.includes(za) && !rootZhis.includes(zb)) continue;
    let blocked = null;
    for (let k=Math.min(i,j)+1; k<Math.max(i,j); k++){ const zc = PIL[k][1][1]; const rel = AD_heRel(zc, za, allZhis) || AD_heRel(zc, zb, allZhis); if (rel){ blocked = {pos:PIL[k][0], zhi:zc, rel}; break; } }
    const pair = `${PIL[i][0]}支${za}与${PIL[j][0]}支${zb}`;
    if (blocked) seg2 += `；${pair}本相冲，然${blocked.pos}支${blocked.zhi}与其中一支${blocked.rel}阻隔，冲不成立，根基得全`;
    else seg2 += `；惜${pair}相冲，${dmName}根受损`;
  }

  // ③ 天干帮扶 + 全局克泄耗（天干+地支藏干）统计
  const HE_HUA = {'甲己':'earth','乙庚':'metal','丙辛':'water','丁壬':'wood','戊癸':'fire'};
  const hePairs = [];
  for (let i=0;i<PIL.length;i++) for (let j=i+1;j<PIL.length;j++){
    const ga = PIL[i][1][0], gb = PIL[j][1][0], k1 = ga+gb, k2 = gb+ga;
    if (GAN_WUHE[k1] || GAN_WUHE[k2]) hePairs.push({i, j, ga, gb, key:k1, hua: HE_HUA[k1]||HE_HUA[k2]});
  }
  const heIdx = new Set(); hePairs.forEach(h=>{ heIdx.add(h.i); heIdx.add(h.j); });
  const tg = [];
  PIL.forEach(([pos, gz], idx)=>{
    if (pos === '日') return;
    const g = gz[0], gw = GAN_WX[g], ss = shiShen(dayStem, dmWx, g, gw);
    let role = gw===dmWx ? '比劫' : WX_SHENG[gw]===dmWx ? '印' : WX_KE[gw]===dmWx ? '官杀' : WX_SHENG[dmWx]===gw ? '食伤' : '财';
    tg.push({idx, pos, g, ss, role, gw});
  });
  const sheng = tg.filter(x=>(x.role==='印'||x.role==='比劫') && !heIdx.has(x.idx));
  const kkx = {ke:new Set(), xie:new Set(), hao:new Set()};
  tg.filter(x=>!heIdx.has(x.idx)).forEach(x=>{
    if (x.role==='官杀') kkx.ke.add(x.gw);
    else if (x.role==='食伤') kkx.xie.add(x.gw);
    else if (x.role==='财') kkx.hao.add(x.gw);
  });
  PIL.forEach(([pos, gz])=>{
    HIDDEN[gz[1]].forEach(g=>{
      const gw = GAN_WX[g];
      if (WX_KE[gw]===dmWx) kkx.ke.add(gw);
      else if (WX_SHENG[dmWx]===gw) kkx.xie.add(gw);
      else if (WX_KE[dmWx]===gw) kkx.hao.add(gw);
    });
  });
  const kkxToks = [];
  kkx.hao.forEach(w=>kkxToks.push(`${WX_NAME[w]}耗${dmName}`));
  kkx.ke.forEach(w=>kkxToks.push(`${WX_NAME[w]}克${dmName}`));
  kkx.xie.forEach(w=>kkxToks.push(`${WX_NAME[w]}泄${dmName}`));
  let seg3 = '';
  if (sheng.length) seg3 += `天干${sheng.map(x=>`${x.pos}干${x.g}${x.ss}`).join('、')}透出帮扶日主，得势有助`;
  if (kkxToks.length) seg3 += (seg3?'；局内':'局内') + kkxToks.join('、') + '并存';
  else if (seg3) seg3 += '；局内克泄耗全无，日主愈得其势';

  // ④ 综合结论 + 用神忌神
  const levelWord = {太强:'身强',偏强:'偏旺',偏弱:'偏弱',太弱:'身弱'}[b.level] || b.level; // 新5级(身强/中和/身弱)直接透传，旧七级词兼容映射
  const xi = (b.xiNames && b.xiNames.length) ? b.xiNames.join('、') : '生扶';
  const ji = (b.jiNames && b.jiNames.length) ? b.jiNames.join('、') : '克泄';
  const seg4 = `综合较量，日主${dmGan}${dmName}${levelWord}，取${xi}为用，忌${ji}`;

  return [seg1, seg2, seg3, seg4].join('。') + '。';
}

// 简策：每盘三条可执行决策建议（用神定调 / 人生阶段策 / 当前大运策），古传承书面语
function AD_policyBrief(P, dayStem, dmWx, b){
  const dmGan = dayStem, dmName = WX_NAME[dmWx];
  const xi = b.xiNames || [], ji = b.jiNames || [];
  const WX_DIR = { '木':'东方', '火':'南方', '土':'中央', '金':'西方', '水':'北方' };
  const xiDir = xi.map(w=>WX_DIR[w]).filter(Boolean).join('、');
  const items = [];
  // ① 用神定调（依强弱）
  let s1;
  if (b.pattern && b.pattern !== 'normal'){
    s1 = `日元${dmGan}${dmName}入${b.congType||b.pattern}，宜顺其势而为，弃命相从则成，忌逆格扶身破局。`;
  } else {
    if (b.strong){
      s1 = `日主身强，宜泄宜耗；喜${xi.join('、')||'生扶'}为用，利${xiDir||'生扶'}之地，忌${ji.join('、')||'无'}耗身。`;
    } else if (b.level === '中和'){
      s1 = `日主中和，不偏不倚；以${xi.join('、')||'生扶'}为用，利${xiDir||'生扶'}之地，随运取用，忌${ji.join('、')||'无'}过盛。`;
    } else {
      s1 = `日主身弱，宜生宜补；喜${xi.join('、')||'生扶'}为助，利${xiDir||'生扶'}之地，忌${ji.join('、')||'无'}克泄。`;
    }
  }
  items.push({ tag:'用神', text:s1 });
  // ② 人生阶段策（取最显著一条）
  const s2 = (b.lifeStage && b.lifeStage.length) ? b.lifeStage[0].text : '中年官印相资，事业可期，宜早立根基、厚积薄发。';
  items.push({ tag:'阶段', text:s2 });
  // ③ 当前大运策
  const fl = b.fortuneLines || [];
  const idx = Math.min(b.activeDayunIdx || 0, fl.length - 1);
  const cur = fl[idx];
  let s3;
  if (cur){
    const flat = cur.flat || '';
    s3 = `现行大运${b.forward?'顺行':'逆行'}，${cur.age}岁起运，${flat || '宜审时度势、动静以时'}。`;
  } else {
    s3 = '幼年未起运，宜养正蓄德，静待时运之来。';
  }
  items.push({ tag:'时运', text:s3 });
  return items;
}
function dayunPiDuanV2(P, dayStem, dmWx, d, isXi, isJi, xi, ji, xiNames, jiNames, keyRootZhi, rt, tag){
  const gw = d.gz[0], zw = d.gz[1];
  const gwWx = GAN_WX[gw], zwBen = HIDDEN[zw][0], zwWx = GAN_WX[zwBen];
  const gwSS = shiShen(dayStem, dmWx, gw, gwWx);
  const zwSS = shiShen(dayStem, dmWx, zwBen, zwWx);
  const xiSet = new Set(xi), jiSet = new Set(ji);
  const comps = [gwWx, zwWx, ...(HIDDEN[zw].slice(1)).map(g=>GAN_WX[g])];
  const xiHit = [...new Set(comps.filter(w=>xiSet.has(w)))].map(w=>WX_NAME[w]);
  const jiHit = [...new Set(comps.filter(w=>jiSet.has(w)))].map(w=>WX_NAME[w]);
  // 大运作用于命局：哪个字受伤/得生（十神取象）
  const eff = hurtTargets(d.gz, P, xi, ji, dayStem, dmWx);
  const hurtXi = eff.filter(e=>e.act==='伤'&&e.isXi);
  const hurtJi = eff.filter(e=>e.act==='伤'&&e.isJi);
  const helpXi = eff.filter(e=>e.act==='生'&&e.isXi);
  const helpJi = eff.filter(e=>e.act==='生'&&e.isJi);
  const gong = [...new Set(eff.map(e=>e.role))];
  let flat = null;
  let s = `大运${gw}${zw}：`;
  s += `天干${gw}为日主之${gwSS}`;
  if (zwSS) s += `、地支${zw}本气${zwBen}为日主之${zwSS}`;
  s += '。';
  if (xiHit.length || jiHit.length){
    const ct = [];
    if (xiHit.length) ct.push(`含喜用（${xiHit.join('、')}）`);
    if (jiHit.length) ct.push(`犯忌（${jiHit.join('、')}）`);
    s += ct.join('、') + '；';
  }
  // 取象批断（按显著度：伤喜用 > 伤忌神(吉) > 生喜用 > 生忌神）
  const order = [...hurtXi, ...hurtJi, ...helpXi, ...helpJi];
  order.slice(0,2).forEach(e=>{ s += effSent(e, `大运${gw}${zw}`); });
  // 基调 + 应事结论（依路线判定真喜/真忌：忌神无路→平顺无虞；喜用无路→平顺安稳）
  let concl = '';
  if (isJi){
    if (gong.includes('日')) concl = '宜守不宜攻，防夫妻、健康与根基之波动，凡事留余地。';
    else if (gong.length) concl = `引动${gong.map(r=>SS_ROLE[r]).join('、')}相关人事，宜谨慎低调、以稳为安。`;
    else if (rt && !rt.reachJi){ concl = '此运虽干支偏忌、然无路线伤用神，伤不到用神，平顺无虞，照常处事即可。'; flat = 'ji'; }
    else concl = '忌神当令而路线直伤用神，宜守成、防人际与健康之耗，静待时机。';
  } else if (isXi){
    if (gong.includes('日')) concl = '用神得地、夫妻与自身多蒙其利，宜把握机遇、积极进取。';
    else if (gong.length) concl = `引动${gong.map(r=>SS_ROLE[r]).join('、')}相关人事，多现利好，可顺势而为。`;
    else if (rt && !rt.reachXi){ concl = '此运虽逢喜用、然无路线助用神，用神不得其力，平顺安稳，宜按部就班、顺势积累。'; flat = 'xi'; }
    else concl = '用神得力且路线通畅，宜积极进取、把握机遇，谋事易成。';
  } else {
    const rootChong = !!(keyRootZhi && AD_CHONG.some(pr=> pr.includes(zw) && pr.includes(keyRootZhi)));
    if (rootChong) concl = '日主根基逢冲，此运防变动较多，宜稳守。';
    else if (gong.length) concl = `此运平顺为主，然引动${gong.map(r=>SS_ROLE[r]).join('、')}（${gong.map(r=>SS_ROLE[r]).join('、')}相关之事），宜顺势打理、夯实基础。`;
    else concl = `此运干支平和、内外静稳，宜按部就班、顺势积累，不必强求突变。`;
  }
  s += concl;
  return { text: s, gong, flat };
}

// 大运「十维度分领域」批语（草稿版，内容待用户定调）
// 驱动数据全部来自 App 真引擎：每步大运整体喜忌(isXi/isJi) + 大运干支十神(对日主) + 宫位(gong) + 日主根冲 + 驿马
// 不用 yuncheng.txt 原算法（其起运随机、吉凶只看印比，已弃）；此版遵循 07-19「身强忌印比 / 强弱×喜忌辩证」铁律
const SWD_REL = {
  career:['正官','七杀','正印','偏印'],
  wealth:['正财','偏财'],
  emotion:['正财','偏财','正官','七杀'],
  helper:['正印','偏印'],
  family:['正印','偏印','食神','伤官'],
  study:['正印','偏印','食神','伤官'],
  social:['比肩','劫财','食神','伤官']
};
const SWD_LAB = {career:'事业',wealth:'财运',emotion:'感情',helper:'贵人',family:'家庭',study:'学业',social:'社交',health:'健康',travel:'出行',aura:'气场'};
const SWD_YIMA = new Set(['寅','申','巳','亥']);
const SWD_CHONG = [['子','午'],['丑','未'],['寅','申'],['卯','酉'],['辰','戌'],['巳','亥']];
function _swdLevel(base, xiSig, jiSig, isJi, gongLen){
  if (xiSig >= 0.6 && xiSig > jiSig + 0.2) return '吉';
  if (jiSig >= 0.6 && jiSig > xiSig + 0.2 && (isJi || gongLen > 0)) return '凶';
  return base;
}
function dayunShiWeiDu(P, dayStem, dmWx, d, isXi, isJi, xi, ji, keyRootZhi, gong){
  const gw = d.gz[0], zw = d.gz[1];
  const xiSet = new Set(xi), jiSet = new Set(ji);
  // 大运干支十神（对日主），带权重：干1.0 / 支本气0.6 / 中气0.3 / 余气0.1
  const comps = [{ w:1.0, ss:shiShen(dayStem,dmWx,gw,GAN_WX[gw]), wx:GAN_WX[gw] }];
  (HIDDEN[zw]||[]).slice(0,3).forEach((g,i)=>{ if(g) comps.push({ w:[0.6,0.3,0.1][i], ss:shiShen(dayStem,dmWx,g,GAN_WX[g]), wx:GAN_WX[g] }); });
  const base = isXi ? '吉' : (isJi ? '凶' : '平');
  const gongLen = (gong||[]).length;
  const calc = relArr => {
    let xiSig = 0, jiSig = 0; const ssHit = [];
    comps.forEach(c=>{ if(relArr.indexOf(c.ss)>=0){ ssHit.push(c.ss); if(xiSet.has(c.wx)) xiSig+=c.w; if(jiSet.has(c.wx)) jiSig+=c.w; } });
    return { xiSig, jiSig, ssHit };
  };
  const fields = {};
  Object.keys(SWD_REL).forEach(k=>{
    const r = calc(SWD_REL[k]);
    fields[k] = { level:_swdLevel(base, r.xiSig, r.jiSig, isJi, gongLen), ssHit:r.ssHit };
  });
  // 健康：日主受扰（宫位引动日柱且忌运）或根基逢冲 → 凶
  let hl = base;
  if (gong && gong.indexOf('日')>=0 && isJi) hl = '凶';
  else if (keyRootZhi && SWD_CHONG.some(pr=>pr.indexOf(zw)>=0 && pr.indexOf(keyRootZhi)>=0)) hl = '凶';
  fields.health = { level: hl };
  // 出行：驿马星动（支为寅申巳亥）宜远行；凶运遇驿马稍缓
  let tv = base;
  if (SWD_YIMA.has(zw)) tv = (base==='凶') ? '平' : '吉';
  fields.travel = { level: tv };
  // 气场：整体基调
  fields.aura = { level: base };
  // 文案（书面语、去括号、无 emoji；草稿，待用户定调）
  const hitStr = ssHit => ssHit.length ? ('大运逢' + [...new Set(ssHit)].join('、')) : '喜用得地';
  Object.keys(fields).forEach(k=>{
    const f = fields[k], lab = SWD_LAB[k], lv = f.level;
    let text;
    if (k==='health'){
      if (lv==='凶') text = '大运引动日主根基或自身，健康须防，宜调摄静养、定期检身。';
      else if (lv==='吉') text = '日主得地，精力充畅，惟仍须规律作息、勿过劳。';
      else text = '健康平顺，宜守常养身、张弛有度。';
    } else if (k==='travel'){
      if (SWD_YIMA.has(zw)) text = '驿马星动，利远行、搬迁与拓展外地，宜把握变动之机。';
      else if (lv==='凶') text = '此运不宜远行，宜居家静守、按程而动。';
      else text = '出行平顺，宜近不宜远、循序渐进。';
    } else if (k==='aura'){
      if (lv==='吉') text = '气场充畅，自信果断，宜主动进取、把握机缘。';
      else if (lv==='凶') text = '气场偏弱，宜静养内守、减少无谓耗散。';
      else text = '中正平和，稳扎稳打、按部就班。';
    } else {
      if (lv==='吉') text = hitStr(f.ssHit) + '，' + lab + '多蒙其利，宜顺势进取、把握机缘。';
      else if (lv==='凶'){
        const h = f.ssHit.length ? ('大运' + [...new Set(f.ssHit)].join('、') + '犯忌') : '忌神当值';
        text = h + '，' + lab + '防耗损波折，宜守成静养、凡事留余地。';
      } else text = lab + '平顺为主，按部就班、稳扎稳打即可。';
    }
    f.text = text; delete f.ssHit;
  });
  return fields;
}

// 一生命运总势（叙事性总断）：格局定性 + 大运喜忌分段趋势 + 定论；各步大运明细退为其下列表
function yunchengZongshi(b){
  const fl = (b.fortuneLines || []);
  if (!fl.length) return '';
  // —— 格局定性（取格局精断「总评」句，已含日主强弱与体用） ——
  const geJuJing = (b.advanced && b.advanced.geJuJing) || [];
  const zp = geJuJing.find(s => s.indexOf('总评') >= 0);
  let dingxing = zp ? zp.replace(/^总评：/, '') : ('日主' + b.level);
  // —— 五行偏颇 / 缺陷（美中不足之由：仅喜用缺失/偏弱方为缺陷；缺忌神反减其患，不写入） ——
  const wx = b.wx || {};
  const xiSet = new Set(b.xiNames || []);
  const jiSet = new Set(b.jiNames || []);
  const miss = Object.keys(wx).filter(w => wx[w] === 0).map(w => WX_NAME[w]);
  const weakWx = Object.keys(wx).filter(w => wx[w] === 1).map(w => WX_NAME[w]);
  let pianpo = '';
  const missXi = miss.filter(x => xiSet.has(x));     // 缺喜用 → 真缺陷
  const weakXi = weakWx.filter(x => xiSet.has(x));   // 喜用偏弱 → 缺陷
  if (missXi.length) pianpo = '局中缺' + missXi.join('、') + '（喜用），是为美中不足，须借运补';
  else if (weakXi.length) pianpo = '五行以' + weakXi.join('、') + '偏弱，喜用不充，须借运补';
  let head = dingxing;
  if (pianpo) head += pianpo + '。';
  // —— 大运喜忌分段（早年/中年/晚年，依大运起始岁） ——
  const segOf = a => (a < 33 ? 'early' : (a < 49 ? 'mid' : 'late'));
  const SEG = { early:{name:'早年',lines:[]}, mid:{name:'中年',lines:[]}, late:{name:'晚年',lines:[]} };
  fl.forEach(l => SEG[segOf(l.age)].lines.push(l));
  const segClause = (seg) => {
    const ls = seg.lines; if (!ls.length) return '';
    const ageR = `约${ls[0].age}至${ls[ls.length-1].age+9}岁`;
    const xiL = ls.filter(l => l.isXi), jiL = ls.filter(l => l.isJi);
    let tone;
    if (xiL.length > jiL.length) tone = '以用神得地之运为多，进益可期';
    else if (jiL.length > xiL.length) tone = '以忌神主导之运为多，宜守防耗';
    else if (xiL.length || jiL.length) tone = '喜忌交杂、平运相间';
    else tone = '平顺为主、起伏不大';
    let note = '';
    if (xiL.length){ const best = xiL.slice().sort((x,y)=>x.age-y.age)[0]; note = `，尤以${best.age}岁起${best.gz}运最利`; }
    else if (jiL.length){ const w = jiL.slice().sort((x,y)=>y.age-x.age)[0]; note = `，尤以${w.age}岁起${w.gz}运须慎`; }
    return `${seg.name}（${ageR}）${tone}${note}`;
  };
  const segs = ['early','mid','late'].map(k => segClause(SEG[k])).filter(Boolean);
  const body = segs.length ? ('大运走势：' + segs.join('；') + '。') : '';
  // —— 定论（一生进益之阶与须防之关） ——
  const best = fl.filter(l => l.isXi).sort((x,y)=>x.age-y.age)[0];
  const worst = fl.filter(l => l.isJi).sort((x,y)=>y.age-x.age)[0];
  let concl;
  if (best && worst) concl = `一生以${best.age}岁起${best.gz}用神运为进益之阶，而${worst.age}岁起${worst.gz}忌神运为须防之关，宜把握运程节奏、顺势而为`;
  else if (best) concl = `一生运程多走喜地，进益可期，惟仍须防流年引动之波动`;
  else if (worst) concl = `一生运程多入忌乡，宜守成为安，静待流年之机`;
  else concl = `一生运程平顺为主，宜按部就班、顺势积累`;
  return `<p class="yc-zongshi"><b>一生命运总势：</b>${head}${body}${concl}。</p>`;
}
// 流年 干支（以立春为界的年柱，与 calendar 库 1900–2100 内结果一致，且不受库的数据范围限制）
function yearGanZhi(yr){
  const g = ((yr - 4) % 10 + 10) % 10;
  const z = ((yr - 4) % 12 + 12) % 12;
  return STEMS[g] + BRANCHES[z];
}
// 当前（或指定年份）流年批注（《岁月分析》：君·臣·民三层）
// 岁支主吉凶、岁干主事象，配宫位引动与十神组合成立，定当年之象。
function liuNianPiDuan(P, dayStem, dmWx, gz, xiNames, jiNames, xi, ji, year, interact, keyRootZhi, curDayunGz){
  const gw = gz[0], zw = gz[1];
  const gwWx = GAN_WX[gw], zwBen = HIDDEN[zw][0], zwWx = GAN_WX[zwBen];
  const gwSS = shiShen(dayStem, dmWx, gw, gwWx);
  const zwSS = shiShen(dayStem, dmWx, zwBen, zwWx);
  const curYear = year || new Date().getFullYear();
  const xiSet = new Set(xi), jiSet = new Set(ji);
  const comps = [gwWx, zwWx, ...(HIDDEN[zw].slice(1)).map(g=>GAN_WX[g])];
  const jiHit = [...new Set(comps.filter(w=>jiSet.has(w)))].map(w=>WX_NAME[w]);
  // 一、先定大运×命局之「病」（臣→民，先看大运）
  const dyEff = curDayunGz ? hurtTargets(curDayunGz, P, xi, ji, dayStem, dmWx) : [];
  const bing = dyEff.filter(e=>e.act==='伤'&&e.isXi);   // 忌神大运伤喜用 = 病
  const dyJiRestr = dyEff.filter(e=>e.act==='伤'&&e.isJi); // 大运制忌 = 药
  // 二、流年（君）介入，作用于大运与命局
  const lnEff = hurtTargets(gz, P, xi, ji, dayStem, dmWx);
  const lnHurtXi = lnEff.filter(e=>e.act==='伤'&&e.isXi);  // 流年伤喜用
  const lnHelpJi = lnEff.filter(e=>e.act==='生'&&e.isJi);  // 流年助忌
  const lnHelpXi = lnEff.filter(e=>e.act==='生'&&e.isXi);  // 流年助喜
  // 救应：大运忌神(病存在) 被流年合住（天干五合 / 地支六合）→ 凶转平
  let saved = false, saveKind = '';
  if (bing.length && curDayunGz){
    const dG = curDayunGz[0], dZ = curDayunGz[1];
    if (GAN_WUHE[dG+gw]||GAN_WUHE[gw+dG]){ saved = true; saveKind = '天干'+dG+gw+'合'; }
    else if (AD_LIUHE.some(p=>(p[0]===dZ&&p[1]===zw)||(p[0]===zw&&p[1]===dZ))){ saved = true; saveKind = '地支'+dZ+zw+'合'; }
  }
  // 忌神叠加：大运病(伤喜用)存在 且 流年犯忌 → 必应灾；须确有受伤目标（流年伤喜用 / 冲日主根 / 或延续大运之病）才判灾
  let zai = false, zaiTgt = null;
  if (bing.length && jiHit.length){
    const rootChong = !!(keyRootZhi && AD_CHONG.some(pr=> pr.includes(zw) && pr.includes(keyRootZhi)));
    zai = true;
    zaiTgt = lnHurtXi[0] || (rootChong ? 'root' : bing[0]);
  }
  let s = `流年${gz}（${curYear}年）：`;
  // 岁支主吉凶（岁为君，支为吉凶所主）
  const zwXi = xiSet.has(zwWx), zwJi = jiSet.has(zwWx);
  if (zwXi && !zwJi) s += `岁支${zw}（${WX_NAME[zwWx]}）系喜用，此年根基向吉、多逢助力；`;
  else if (zwJi && !zwXi) s += `岁支${zw}（${WX_NAME[zwWx]}）犯忌神，此年根基动荡、宜防耗损；`;
  else if (zwXi && zwJi) s += `岁支${zw}（${WX_NAME[zwWx]}）喜忌交杂，吉凶参半；`;
  else s += `岁支${zw}（${WX_NAME[zwWx]}）平和，岁支无大起落；`;
  // 岁干主事象（十神之象）
  s += `岁干${gw}为日主之${gwSS}，事象多应${((SS_XIANG[gwSS]&&SS_XIANG[gwSS].people)||gwSS)}；`;
  // 三、先大运定病 → 流年裁决（救应 / 忌神叠加 / 直接作用）
  if (saved){
    s += `流年${gw}${zw}与当运${curDayunGz}相合（${saveKind}），君合住臣，忌神被羁绊，原局用神得解，本运之病转平，此年反得安稳`;
    if (lnHelpXi.length) s += '，且喜用得流年生助，更利';
    s += '。';
  } else if (zai){
    if (zaiTgt === 'root') s += '大运忌神未解、流年再犯忌神且冲日主根基，忌神叠加必应灾：日主根基受冲，防根基动摇、意外伤病。';
    else if (zaiTgt) s += '大运忌神未解、流年再犯忌神，忌神叠加必应灾：' + effSent(zaiTgt, zaiTgt===bing[0]?'当运':'岁运', '伤');
    else s += '大运忌神、流年再犯，忌神叠加，此年防耗损、波折不顺。';
  } else if (lnHurtXi.length){
    s += lnHurtXi.slice(0,2).map(e=>effSent(e, '流年'+gz, '伤')).join('');
  } else if (lnHelpXi.length){
    s += lnHelpXi.slice(0,2).map(e=>effSent(e, '流年'+gz, '生')).join('');
  } else if (bing.length){
    const bingNote = bing[0] ? ('原局'+bing[0].ss+'受伤之累') : '原局之累';
    s += '大运忌神伤用神之病仍在，流年未来解救亦未加害，宜守成、防' + bingNote + '。';
  } else if (lnHelpJi.length){
    s += lnHelpJi.slice(0,2).map(e=>effSent(e, '流年'+gz, '生')).join('');
  } else if (dyJiRestr.length){
    s += '大运制忌得力，此年无额外扰动，平顺安稳。';
  } else {
    s += '岁运平和、无突出刑冲，平顺为主，按部就班即可。';
  }
  // 宫位引动（岁支冲合何宫，定人/事范围）
  const gongSet = new Set([...bing, ...lnEff].map(e=>e.role));
  if (gongSet.size) s += '事象落于' + [...gongSet].map(r=>SS_ROLE[r]+'宫').join('、') + '。';
  // 四、十神组合在岁运下是否成立（《十神组合》）
  const tgJi = ss => [P.year[0],P.month[0],P.day[0],P.hour[0]].some(g=>{ const t=shiShen(dayStem,dmWx,g,GAN_WX[g]); return t===ss && jiSet.has(GAN_WX[g]); });
  let combo = '';
  if (gwSS==='食神' && tgJi('偏印')) combo = '岁君食神透出、命局枭神（偏印）为忌透干，「枭神夺食」成立，防病灾、破财、工作波动。';
  else if (gwSS==='正官' && tgJi('伤官')) combo = '岁君正官透出、命局伤官为忌透干，「伤官见官」成立，防官非、口舌、职位动摇。';
  else if ((gwSS==='正财'||gwSS==='偏财') && tgJi('劫财')) combo = '岁君财星透出、命局劫财为忌透干，「比劫夺财」成立，防破财、因友损财。';
  if (combo) s += '\n' + combo;
  return s;
}
// 真平太阳时差（近似，单位：分钟）
/* ---------- 阿拉伯数字转中文数字（0-99，用于骨重等） ---------- */
function cnNum(n){
  n = +n;
  if (isNaN(n)) return '';
  if (n === 0) return '零';
  const d = ['零','一','二','三','四','五','六','七','八','九','十'];
  if (n <= 10) return d[n];
  if (n < 20) return '十' + d[n - 10];
  const t = Math.floor(n / 10), o = n % 10;
  return d[t] + '十' + (o ? d[o] : '');
}

/* ---------- 袁天罡称骨（骨重，单位：钱；1两=10钱） ---------- */
const CHENGU_YEAR = {
  '甲子':12,'乙丑':9,'丙寅':6,'丁卯':7,'戊辰':12,'己巳':5,'庚午':7,'辛未':5,'壬申':7,'癸酉':8,
  '甲戌':15,'乙亥':9,'丙子':7,'丁丑':8,'戊寅':8,'己卯':9,'庚辰':12,'辛巳':6,'壬午':8,'癸未':7,
  '甲申':5,'乙酉':15,'丙戌':6,'丁亥':16,'戊子':15,'己丑':7,'庚寅':9,'辛卯':12,'壬辰':10,'癸巳':7,
  '甲午':15,'乙未':6,'丙申':5,'丁酉':14,'戊戌':14,'己亥':9,'庚子':7,'辛丑':8,'壬寅':9,'癸卯':12,
  '甲辰':18,'乙巳':7,'丙午':13,'丁未':5,'戊申':14,'己酉':15,'庚戌':9,'辛亥':17,'壬子':7,'癸丑':7,
  '甲寅':12,'乙卯':19,'丙辰':8,'丁巳':6,'戊午':10,'己未':6,'庚申':8,'辛酉':16,'壬戌':10,'癸亥':6
};
// 正月..腊月（农历月序 1-12）
const CHENGU_MONTH = [6,7,18,9,5,16,9,15,18,8,9,5];
// 初一..三十（农历日序 1-30）
const CHENGU_DAY = [5,10,8,15,16,15,8,16,8,16,9,17,8,17,10,8,9,18,5,15,10,9,8,9,15,18,7,8,16,6];
// 子丑寅卯辰巳午未申酉戌亥（时辰序 0-11）
const CHENGU_HOUR = [16,6,7,10,9,16,10,8,8,9,6,6];
const CHENGU_POEM = {
  21:'一生衣禄总无周，作事遭成又一休；祖业家财难靠托，奔波劳碌度春秋。',
  22:'身寒骨冷苦伶仃，此命推来行乞人；劳劳碌碌无度日，终年打拱过平生。',
  23:'此命推来骨格轻，求谋作事事难成；妻儿兄弟应难许，别处他乡度一生。',
  24:'此命推来福禄无，门庭困苦总难荣；六亲骨肉皆无靠，流到他乡作老翁。',
  25:'此命推来祖业微，门庭营度似稀奇；六亲骨肉如冰炭，一世勤劳自把持。',
  26:'平生衣禄苦中求，独自营谋事不休；离祖出门宜早计，晚来衣禄庶无忧。',
  27:'一生作事少商量，难靠祖宗作主张；独马单枪空做去，早年晚岁总无长。',
  28:'一生行事似飘蓬，祖宗根基不易成；骨肉亲缘空效力，早岁晚景似梦中。',
  29:'初年运限未曾亨，纵有功名不久长；富贵不能济贫苦，看看超过看如何。',
  30:'劳劳碌碌苦中求，东走西奔何日休；若问求财须有志，祖业难招可自由。',
  31:'忙忙碌碌苦中求，何日云开见日头；难得祖基家可立，中年衣食渐无忧。',
  32:'初年运蹇事难谋，渐有财源如水流；到得中年衣食旺，那时名利一齐收。',
  33:'早年做事事难成，百计徒劳枉费心；半世自如流水去，后来运到得黄金。',
  34:'此命福气果如何，僧道衣粮赖此身；门派修行亦安泰，富贵荣华比石崇。',
  35:'生平福量不周全，祖业根基觉少传；营事生涯宜守旧，时来衣食胜从前。',
  36:'不须劳碌过平生，独自成家福不轻；早有福星常照命，任君行去百般成。',
  37:'此命般般事不成，弟兄少力自孤行；虽然祖业须微有，来得明时去不明。',
  38:'一生骨肉最清高，早入黉门姓氏标；待到年将三十六，蓝衣脱去换红袍。',
  39:'此命终身运不通，劳劳作事尽皆空；苦心竭力成家计，到得那时在梦中。',
  40:'平生衣禄是绵长，件件心中自主张；前面风霜多受过，后来必定享安康。',
  41:'此命推来事不同，为人能干异凡庸；中年还有逍遥福，不比前时运未通。',
  42:'得宽怀处且宽怀，何用双眉皱不开；若使中年命运济，那时名利一齐来。',
  43:'为人心性最聪明，作事轩昂近贵人；衣禄一生天注定，不须劳碌是丰亨。',
  44:'万事由天莫苦求，须知福禄赖心修；当年财帛难如意，晚景欣然便不忧。',
  45:'名利推求竟若何，前番辛苦后奔波；命中难养男和女，骨肉扶持也不多。',
  46:'东西南北尽皆通，出姓移居更觉隆；衣禄无穷无数定，中年晚景一般同。',
  47:'此命推来喜气新，文昌文曲降凡尘；早年渐入黄门客，晚景荣华乐太平。',
  48:'初年运道未曾通，几许蹉跎命亦穷；兄弟六亲难可靠，一生事业晚来隆。',
  49:'此命推来福不轻，自成自立显门庭；从来富贵人钦敬，使婢差奴过一生。',
  50:'为利为名终日劳，中年福禄也多遭；老来自有喜讯至，得意荣华显六亲。',
  51:'一世荣华事事通，不须劳碌自亨通；兄弟叔侄皆如意，家业成时福禄宏。',
  52:'一世享通事事能，不须劳苦自然荣；宗族有光欣喜甚，家产丰盈自称心。',
  53:'此命推来福泽宏，兴家立业在其中；一生衣禄安排定，却是人间一富翁。',
  54:'此命推来厚且清，诗书满腹看功成；丰衣足食多安稳，正是人间有福人。',
  55:'走马扬鞭争利名，少年作事费筹论；一朝福禄源源至，富贵荣华显六亲。',
  56:'此命推来礼义通，一生福禄用无穷；甜酸苦辣皆尝过，滚滚财源稳且丰。',
  57:'福禄盈盈万事全，一生荣耀显双亲；名扬威震人争羡，此世逍遥宛似仙。',
  58:'平生衣食自然来，名利双全富贵偕；金玉满堂人口旺，荣华得意外人财。',
  59:'细推此命福非轻，富贵荣华孰与争；定主才高过人辈，文章振发显英名。',
  60:'一朝金榜快题名，显祖荣宗大其成；衣禄定然原裕足，田园财帛更丰盈。',
  61:'不作朝中金榜客，定为世上大英豪；聪明天赋经书熟，名显高科自是荣。',
  62:'此命生来福不穷，读书必定显亲宗；紫衣金带为卿相，富贵荣华孰与同。',
  63:'命主为官福禄长，得来富贵实非常；名题雁塔传金榜，大显门庭姓氏香。',
  64:'此命威权不可当，兵权柄印在北方；琵琶弹尽胡笳调，千里关山作远疆。',
  65:'此命推来福不轻，聪明出众达天庭；经书熟读文章显，定是朝廷作宰臣。',
  66:'此命生来福自宏，田园家业最高隆；平生衣禄盈丰足，一世荣华万事通。',
  67:'此命生来福自隆，平生家业亦兴隆；一生衣禄丰盈足，一世荣华万事通。',
  68:'富贵由天莫苦求，万金家计不须谋；十年饱暖多安稳，晚景逍遥更自由。',
  69:'君是人间福禄星，一生富贵众人钦；总然衣禄常丰足，也是门前有贵人。',
  70:'此命推来福不轻，不须愁虑苦劳心；一生天定衣禄盛，富贵荣华极品人。',
  71:'此命生成大不同，公侯卿相在其中；一生自有逍遥福，富贵荣华极品隆。',
  72:'此命推来天下奇，十世修来一品贵；天上紫微来照命，纵横富贵不须疑。'
};
function chengu(yearGZ, lMonth, lDay, brIdx){
  const y = CHENGU_YEAR[yearGZ] || 0;
  const m = CHENGU_MONTH[(lMonth - 1 + 12) % 12] || 0;
  const d = CHENGU_DAY[Math.min(Math.max(lDay, 1), 30) - 1] || 0;
  const h = CHENGU_HOUR[brIdx] || 0;
  const total = y + m + d + h;
  const liang = Math.floor(total / 10), qian = total % 10;
  const poem = CHENGU_POEM[total] || '此命骨重难得细批，然天命在人谋，积善修德、勤俭持身，自能转机安康。';
  return { year:y, month:m, day:d, hour:h, total, liang, qian, text:`${liang>0?liang+'两':''}${qian}钱`, poem };
}
// 统计某五行在四柱（天干 + 地支本气）出现次数
function countWxInBazi(wx, P){
  let n = 0;
  for (const k of ['year','month','day','hour']){
    if (GAN_WX[P[k][0]] === wx) n++;
    if (GAN_WX[HIDDEN[P[k][1]][0]] === wx) n++;
  }
  return n;
}
// 财运总趋势：以财星（日主所克）为纲，结合喜忌、食伤（生财之源）、十神主导
function wealthAnalysis(dayMaster, dmWx, caiWx, caiIsXi, xiNames, jiNames, P, strong, mid, dom, pattern){
  const caiN = countWxInBazi(caiWx, P);
  const shangWx = WX_SHENG[dmWx];
  const shangN = countWxInBazi(shangWx, P);
  const caiName = WX_NAME[caiWx];
  let s = `日主${dayMaster}（${WX_NAME[dmWx]}），财星为${caiName}（日主所克之五行）。`;
  s += caiIsXi
    ? '财星恰为喜用，主财源通畅、求财省力，理财与经营易见成效。'
    : '财星属忌神，求财较费心力，宜稳健务实，忌冒进与投机。';
  s += `命局财星（${caiName}）现 ${caiN} 处，食伤（生财之源）现 ${shangN} 处；`;
  if (caiN >= 2 && caiIsXi) s += '财星有力且得用，财运根基厚实，利于经商、投资或凭专业获利；';
  else if (caiN >= 2) s += '财星虽显却非喜用，多为过手之财，宜守成积累、量入为出；';
  else if (caiN === 1) s += '财星有根气，财运平稳，须待运年引动方显；';
  else s += '财星偏弱，宜靠技艺、职务与长期积累生财，不宜奢望横财。';
  if (shangN >= 1 && caiIsXi) s += '食伤生财，多凭才华、创意或技艺得财，亦利口碑与副业。';
  if (dom === '正财') s += '命局正财较显，主踏实工资与经营之财，量入为出渐能聚财。';
  else if (dom === '偏财') s += '命局偏财较显，多有意外之财与交际机遇，宜灵活把握。';
  let zsW;
  if (pattern === 'zhuanwang') zsW = '专旺成格，旺极宜顺，行喜用（比劫、印绶）之运则财源畅旺';
  else if (pattern === 'cong') zsW = '从格弃命相从，所从旺神（'+xiNames.join('、')+'）得地则财气自来，忌印比扶身破格';
  else if (mid) zsW = '命局中和，日主不偏，财星宜忌不显，随大运流年引动而取用，行运得力则财源渐进';
  else zsW = strong ? '身强足以担财，财来能守' : '身弱财旺须防为财所累，宜待身旺之运或合伙分担';
  s = s.replace(/；$/, '。');               // 第一段（总势前）文末若为分号，改为句号
  s += `<br>总势：${zsW}。`;
  return s;
}
// 工作事业：以官杀（事业权责）为凭、印星（学业靠山）为荫，结合喜忌与十神主导
function careerAnalysis(dayMaster, dmWx, guanWx, yinWx, guanIsXi, xiNames, jiNames, P, strong, mid, dom, pattern){
  const guanN = countWxInBazi(guanWx, P);
  const yinN = countWxInBazi(yinWx, P);
  const guanName = WX_NAME[guanWx];
  let s = `事业官运以官杀（${guanName}）为凭，印星（${WX_NAME[yinWx]}）为荫。`;
  s += guanIsXi
    ? '官杀为喜用，主有职务权责之缘，宜在体制、管理或专业岗位发展；'
    : '官杀非喜用，事业宜以技术实务立足，少涉权争；';
  s += `命局官杀现 ${guanN} 处，印星现 ${yinN} 处；`;
  if (guanN >= 2 && guanIsXi) s += '官杀得用，进取易得提拔，宜力争上游；';
  else if (yinN >= 2) s += '印星有力，多得长辈、学历、证书之助，宜钻研专业、厚积薄发；';
  else if (guanN >= 1) s += '官星有根，循序渐进可成，宜稳中求进；';
  else s += '官星偏弱，事业宜靠一技之长与持续积累，未必以职位论英雄。';
  if (dom === '正官') s += '正官格局，守规矩、责任心强，宜公职或大型企业；';
  else if (dom === '七杀') s += '七杀显达，魄力决断、敢闯敢拼，宜开拓型岗位；';
  else if (dom === '正印' || dom === '偏印') s += '印星较显，善学善思，宜文教、研究、技术类工作；';
  let zsC;
  if (pattern === 'zhuanwang') zsC = '专旺成格，旺极宜顺，行喜用（比劫、印绶）之运则事业宏开';
  else if (pattern === 'cong') zsC = '从格弃命相从，所从旺神（'+xiNames.join('、')+'）得地则权责自来，忌印比扶身破格';
  else if (mid) zsC = '命局中和，日主不偏，宜随大运流年而取用，行运得力则权责渐进、事业平顺';
  else zsC = strong ? '身强可任事，宜主动承担、拓展局面' : '身弱宜择稳健平台，发挥专长、借力成事';
  s += `工作事业总以${zsC}为宜。`;
  return s;
}

function equationOfTime(y, m, d){
  const doy = Math.floor((Date.UTC(y, m-1, d) - Date.UTC(y, 0, 0)) / 86400000);
  const B = 2*Math.PI*(doy-1)/365.25;
  return -7.659*Math.sin(B) + 9.863*Math.sin(2*B + 3.5932);
}
function fmtHM(h, mi){ return String(h).padStart(2,'0') + ':' + String(mi).padStart(2,'0'); }

/* ===================================================================
 * 八字排盘（含强弱 / 喜用神 / 十神 / 批断）
 * opts: { calType:'solar'|'lunar', trueSolar:bool, longitude:number, ziType:'modern'|'traditional' }
 * =================================================================== */
// 性格心性（重写）：以日主天性为基，按十神旺度、月令本气、贴近日干定主导，
// 并据日主强弱与十神喜忌彰显优缺（运用原则3）。合冲顺逆透露个性色彩。
const DI_ZHI_HE = {'子':'丑','丑':'子','寅':'亥','亥':'寅','卯':'戌','戌':'卯','辰':'酉','酉':'辰','巳':'申','申':'巳','午':'未','未':'午'};
function countHeChong(P){
  let he = 0, chong = 0;
  const gs = [P.year[0], P.month[0], P.day[0], P.hour[0]];
  for (let i = 0; i < gs.length; i++) for (let j = i + 1; j < gs.length; j++){
    const k1 = gs[i] + gs[j], k2 = gs[j] + gs[i];
    if (GAN_WUHE[k1] || GAN_WUHE[k2]) he++;
  }
  const zs = [P.year[1], P.month[1], P.day[1], P.hour[1]];
  for (let i = 0; i < zs.length; i++) for (let j = i + 1; j < zs.length; j++){
    const a = zs[i], b = zs[j];
    if (AD_CHONG.some(pr => (pr[0] === a && pr[1] === b) || (pr[0] === b && pr[1] === a))) chong++;
    else if (DI_ZHI_HE[a] === b) he++;
  }
  return { he, chong };
}
function AD_personalityV2(P, dayStem, dmWx, xi, ji, pattern, congType){
  const xiSet = new Set(xi), jiSet = new Set(ji);
  // 十神影响聚合：位置权重（月令本气×1.6、贴身×1.3、远×1.0）× 透干/藏干基数
  const pillars = [
    ['年干', P.year[0], 'far'], ['年支', P.year[1], 'far'],
    ['月干', P.month[0], 'tie'], ['月支', P.month[1], 'yue'],
    ['日支', P.day[1], 'tie'],
    ['时干', P.hour[0], 'tie'], ['时支', P.hour[1], 'tie']
  ];
  const occ = [];
  pillars.forEach(function(it){
    const pos = it[0], gz = it[1], kind = it[2];
    if (kind === 'tie' || kind === 'far'){
      const g = gz, wx = GAN_WX[g], ss = shiShen(dayStem, dmWx, g, wx);
      occ.push({ ss, wx, base: 1.0, posMult: kind === 'tie' ? 1.3 : 1.0, yueBen: false, tie: kind === 'tie' });
    } else { // 地支：本气/中气/余气
      const z = gz, cang = HIDDEN[z] || [];
      cang.forEach(function(g, i){
        const wx = GAN_WX[g], ss = shiShen(dayStem, dmWx, g, wx);
        const base = i === 0 ? 0.7 : (i === 1 ? 0.4 : 0.2);
        let posMult = 1.0;
        if (kind === 'yue' && i === 0) posMult = 1.6;
        else if (kind === 'tie') posMult = 1.3;
        occ.push({ ss, wx, base, posMult, yueBen: (kind === 'yue' && i === 0), tie: (kind === 'tie' || (kind === 'yue' && i === 0)) });
      });
    }
  });
  const agg = {};
  occ.forEach(function(o){
    if (!o.ss) return;
    if (!agg[o.ss]) agg[o.ss] = { total: 0, youW: 0, queW: 0, yueBen: false, tie: false, wx: o.wx };
    const m = o.base * o.posMult;
    const isXi = xiSet.has(o.wx), isJi = jiSet.has(o.wx);
    agg[o.ss].total += m;
    if (isXi){ agg[o.ss].youW += m * 1.5; agg[o.ss].queW += m * 0.6; }
    else if (isJi){ agg[o.ss].youW += m * 0.6; agg[o.ss].queW += m * 1.5; }
    else { agg[o.ss].youW += m; agg[o.ss].queW += m; }
    if (o.yueBen) agg[o.ss].yueBen = true;
    if (o.tie) agg[o.ss].tie = true;
  });
  // 运用原则3·旺度强者为主导
  const gods = Object.keys(agg).filter(function(g){ return agg[g].total >= 0.7; })
                        .sort(function(a, b){ return agg[b].total - agg[a].total; });
  const parts = [];
  parts.push(DM_TRAIT[dayStem] || '');
  if (gods.length){
    const segs = gods.slice(0, 3).map(function(g, i){
      const a = agg[g], t = TEN_GOD_TRAIT_FULL[g]; if (!t) return '';
      const isXi = xiSet.has(a.wx), isJi = jiSet.has(a.wx);
      const lead = i === 0
        ? ('命局以' + g + (a.yueBen ? '坐月令本气' : (a.tie ? '贴身而旺' : '透现于局')) + '为主导')
        : (g + (a.yueBen ? '坐月令本气亦显' : (a.tie ? '贴身亦显' : '亦显')));
      let body;
      if (isXi) body = '为喜用，优长得以发挥：' + t.you;
      else if (isJi) body = '为忌神，偏失易于显露：' + t.que;
      else body = t.xing + '，' + t.you;
      return lead + '，' + body + '。';
    });
    parts.push(segs.join(''));
  }
  // 运用原则3·干支合冲会合透露个性色彩：合多者性顺，冲多者性逆
  const hc = countHeChong(P);
  if (hc.he > hc.chong && hc.he >= 2) parts.push('八字合多，性情和顺，待人圆融。');
  else if (hc.chong > hc.he && hc.chong >= 2) parts.push('八字冲多，性情刚烈易变，处事多波折。');
  else if (hc.he >= 1 && hc.chong >= 1) parts.push('合冲并见，外顺内逆，宜动静有常。');
  // 特殊格局（十神主导之极端，与运用原则一致）
  if (pattern === 'zhuanwang') parts.push('全局印比林立成专旺，日主极旺，性格专一果决、敢作敢当。');
  else if (pattern === 'cong') parts.push('日主弃命相从，识时务而善变通，性格随环境借力而成。');
  else if (pattern === 'huaqi') parts.push('化气成格，气质脱俗，易有奇遇。');
  else if (pattern === 'liangShen') parts.push('两神成象，性情纯粹专一、爱憎分明。');
  else if (pattern === 'anChong' || pattern === 'anHe') parts.push('暗冲暗合格，外似平顺而内藏变动之机。');
  return parts.filter(Boolean).join('');
}

// E：伤病灾提示（全面嵌入《伤病灾》六大维度：过弱/过旺/冲克/合化/寒暖燥湿/伤官）
function AD_healthRisk(P, wx, dmWx, dayGan, score, level){
  const WX = ['wood','fire','earth','metal','water'];
  const wxOrgan = {
    wood:'肝胆、筋骨、四肢', fire:'心脑、血脉、眼目', earth:'脾胃、皮肤、肌肉',
    metal:'肺、呼吸道、大肠', water:'肾、膀胱、泌尿、生殖'
  };
  // 柱位定位：天干/地支所在柱 → 人体区域
  const colArea = {
    year:'头面颈（年柱·少年）', month:'胸肺心脑胆上肢（月柱·青年）',
    day:'腹胃泌尿生殖（日柱·中年自身）', hour:'下肢腰膝腿脚（时柱·晚年）'
  };
  const cols = ['year','month','day','hour'];
  const ganOf = c => P[c][0], zhiOf = c => P[c][1];
  // 各五行：出现柱位（天干/地支）、计数、是否有根
  const info = {};
  WX.forEach(w=>{
    const ganCols=[], zhiCols=[];
    cols.forEach(c=>{
      if (GAN_WX[ganOf(c)]===w) ganCols.push(c);
      if (ZHI_WX[zhiOf(c)]===w) zhiCols.push(c);
    });
    info[w] = { cnt: wx[w], ganCols, zhiCols, has: wx[w]>0, root: cols.some(c=> ZHI_WX[zhiOf(c)]===w) };
  });
  const loc = w => {
    const g = info[w].ganCols[0], z = info[w].zhiCols[0];
    const c = g || z; if(!c) return '';
    if (g && z) return '（'+colArea[c]+'）';
    if (g) return '（'+colArea[c]+'·天干）';
    return '（'+colArea[c]+'·地支）';
  };
  const items = [];
  const seen = new Set();
  const add = (w, txt, conf) => { const k=w+'|'+txt.slice(0,10); if(seen.has(k)) return; seen.add(k); items.push({t:txt,c:conf}); };

  // —— 维度一：过弱之五行（现/不现）——
  WX.forEach(w=>{
    const n = info[w].cnt;
    if (n>=2) return;
    if (n===0){
      add(w, WX_NAME[w]+'在命局不现（过弱而无者，怕出现）：一般无病，逢大运流年引出该五行方显'+wxOrgan[w]+'隐患，宜留意。', 1);
    } else {
      let s = WX_NAME[w]+'过弱而在命局出现'+loc(w)+'：'+wxOrgan[w]+'先天偏弱、易病且早发，宜早养护。';
      if (!info[w].root) s += '（该五行无根虚浮，主虚脱无力之象）';
      add(w, s, 3);
    }
  });

  // —— 维度二：过旺之五行（憋 / 有克 / 反克 / 生多为克 / 盗泄太过）——
  WX.forEach(w=>{
    const n = info[w].cnt;
    if (n<4) return;
    const keChu = wx[WX_KE[w]] > 0;        // 能克到的（被w克者）在局
    const shengChu = wx[WX_SHENG[w]] > 0;   // w有泄处（w生的五行在局）
    const ctrl = wuXingControlling(w);       // 克w者
    const isZhuan = level && (level.indexOf('专旺')>=0 || level.indexOf('从')>=0);
    if (!keChu && !shengChu && !isZhuan){
      add(w, WX_NAME[w]+'过旺且无克无泄（不成专旺）：'+wxOrgan[w]+'易因壅滞憋出病伤。', 2);
    }
    if (keChu){
      const bk = WX_KE[w];
      add(w, WX_NAME[w]+'过旺且有克处，所克之'+WX_NAME[bk]+'（'+wxOrgan[bk]+'）易受克伤，防交战皮肉之伤。', 2);
    }
    if (info[ctrl].cnt<=1){ // 反克
      const fan = {metal:'木强金缺',water:'火多水干',wood:'土多木折',fire:'金多火熄',earth:'水多土荡'}[ctrl];
      add(ctrl, '反克：'+WX_NAME[w]+'强而'+WX_NAME[ctrl]+'弱（'+fan+'），'+WX_NAME[ctrl]+'（'+wxOrgan[ctrl]+'）反受损伤。', 2);
    }
    if (info[WX_SHENG[w]].cnt<=1){ // 生多为克
      const sm = {metal:'土多金埋',water:'金多水浊',wood:'水多木漂',fire:'木多火塞',earth:'火多土焦'}[WX_SHENG[w]];
      add(WX_SHENG[w], '生多为克：'+WX_NAME[w]+'多而'+WX_NAME[WX_SHENG[w]]+'弱（'+sm+'），'+WX_NAME[WX_SHENG[w]]+'（'+wxOrgan[WX_SHENG[w]]+'）不受生而伤。', 2);
    }
  });
  // 盗泄太过（被生方旺、生方弱 → 生方受伤；成语以被生方为键）
  WX.forEach(w=>{
    const sheng = WX_SHENG[w]; // 被生方（接受w所生）
    if (info[w].cnt<=1 && info[sheng].cnt>=4){
      const dao = {fire:'火多木焚',wood:'木多水缩',earth:'土多火晦',metal:'金多土虚',water:'水多金沉'}[sheng];
      add(w, '盗泄太过：'+WX_NAME[sheng]+'旺而'+WX_NAME[w]+'弱（'+dao+'），'+WX_NAME[w]+'（'+wxOrgan[w]+'）被盗泄受损。', 2);
    }
  });

  // —— 维度三：被冲克之五行（必然伤病）——
  const gans = cols.map(c=>({g:ganOf(c), c}));
  for (let i=0;i<gans.length;i++) for (let j=0;j<gans.length;j++){
    if (i===j) continue;
    if (WX_KE[GAN_WX[gans[i].g]]===GAN_WX[gans[j].g]){
      const w = GAN_WX[gans[j].g];
      add(w, WX_NAME[w]+'被天干克制（'+gans[j].c+'柱·天干）'+loc(w)+'：'+wxOrgan[w]+'必然易有伤病灾。', 4);
    }
  }
  const zhis = cols.map(c=>({z:zhiOf(c), c}));
  for (let i=0;i<zhis.length;i++) for (let j=0;j<zhis.length;j++){
    if (i===j) continue;
    if (CHONG[zhis[i].z]===zhis[j].z){
      const w = ZHI_WX[zhis[i].z];
      add(w, WX_NAME[w]+'地支相冲（'+zhis[i].c+'·'+zhis[i].z+'冲'+zhis[j].z+'）'+loc(w)+'：'+wxOrgan[w]+'必然易有伤病灾。', 4);
      const w2 = ZHI_WX[zhis[j].z];
      add(w2, WX_NAME[w2]+'地支相冲（'+zhis[j].c+'·'+zhis[j].z+'冲'+zhis[i].z+'）'+loc(w2)+'：'+wxOrgan[w2]+'必然易有伤病灾。', 4);
    }
  }

  // —— 维度四：被合化之五行（受伤变性质）——
  for (let i=0;i<gans.length;i++) for (let j=i+1;j<gans.length;j++){
    const k1=gans[i].g+gans[j].g, k2=gans[j].g+gans[i].g;
    if (GAN_WUHE[k1]||GAN_WUHE[k2]){
      [gans[i],gans[j]].forEach(o=>{
        const w=GAN_WX[o.g];
        add(w, WX_NAME[w]+'参与天干五合（'+o.c+'柱）改变性质，'+wxOrgan[w]+'易有隐患（合化受伤）。', 2);
      });
    }
  }
  for (const k in AD_SANHE){
    const arr=AD_SANHE[k];
    if (arr.every(z=> zhis.some(o=>o.z===z))){
      arr.forEach(z=>{
        const w=ZHI_WX[z];
        if (w!==k) add(w, '地支三合'+WX_NAME[k]+'局，'+WX_NAME[w]+'被合化改变性质（'+wxOrgan[w]+'）易有隐患。', 2);
      });
    }
  }

  // —— 维度五：寒暖燥湿 ——
  const mz = P.month[1];
  if (['亥','子','丑'].includes(mz)){
    if (wx['water']>=3 && wx['fire']<=1)
      items.push({t:'局中过寒（冬生水旺火弱）：易寒湿、气血凝滞，皮肤易痒疹皮炎，腰腿怕冷。',c:2});
    else
      items.push({t:'局中偏寒（冬生），注意寒痹、气血凝滞、肾阳不足。',c:1});
  } else if (['巳','午','未'].includes(mz)){
    if (wx['fire']>=3 && wx['water']<=1)
      items.push({t:'局中过燥（夏生火旺水弱）：易热性病、心火亢、津液耗、皮肤燥热。',c:2});
    else
      items.push({t:'局中偏燥（夏生），注意心火亢、津液耗、皮肤燥热。',c:1});
  }

  // —— 维度六：伤官揭示（日弱伤官旺为忌）——
  const shangWx = WX_SHENG[dmWx];
  if (score < 1.4 && wx[shangWx] >= 2){
    const guanCols = gans.filter(o=>{ const s=shiShen(dayGan, dmWx, o.g, GAN_WX[o.g]); return s==='正官'||s==='七杀'; }).map(o=>o.c);
    const shangCols = gans.filter(o=>{ const s=shiShen(dayGan, dmWx, o.g, GAN_WX[o.g]); return s==='食神'||s==='伤官'; }).map(o=>o.c);
    if (guanCols.length && shangCols.length){
      items.push({t:'日弱伤官旺为忌，伤官克官星（'+colArea[guanCols[0]]+'）：该区域易有伤病灾。',c:2});
    } else if (shangCols.length){
      items.push({t:'日弱伤官旺为忌，官星不显/克不到，伤官所在（'+colArea[shangCols[0]]+'）易有伤病灾。',c:2});
    }
  }

  if (score < 1.0) items.push({t:'日主偏弱，整体元气不足，易疲劳、抗病力弱，宜静养培元。',c:1});
  if (!items.length) items.push({t:'五行分布较匀，无明显脏腑偏颇，平素调和即可。',c:0});
  items.sort((a,b)=> b.c - a.c);
  const top = items.slice(0,9);
  return '<div class="adv-list">'+top.map(x=>'<div class="adv-item">'+x.t+'</div>').join('')+'</div>';
}

// F：灾祸提示（官司牢狱 / 伤残病灾 / 一般性破财；不做负债专项）
function AD_disaster(P, dayGan, dmWx, xi, ji, wx, sc, spouseWx, palaceWx, keyRootZhi){
  const guanWx = wuXingControlling(dmWx);
  const guanIsXi = xi.includes(guanWx);
  const guanShaGan = [P.year[0],P.month[0],P.hour[0]].filter(g=> {
    const s = shiShen(dayGan, dmWx, g, GAN_WX[g]);
    return s==='正官'||s==='七杀';
  });
  let law;
  if (guanShaGan.length === 0){
    const shangGan = [P.year[0],P.month[0],P.hour[0]].filter(g=> {
      const s = shiShen(dayGan, dmWx, g, GAN_WX[g]);
      return s==='食神'||s==='伤官';
    });
    law = shangGan.length ? '局中无官星，伤官透出为忌之象，须防口舌官非、因言惹讼。' : '局中官星不显，官非之象较轻，然仍宜守法避争。';
  } else {
    law = guanIsXi ? '官星为喜用，仕途名望可期；唯岁运冲克官星时防官非阻滞。' : '官星为忌而近日干有力，须防官司牢狱、官非缠身，宜守法低调。';
  }
  const maxWx = Object.keys(wx).reduce((a,b)=> wx[a]>=wx[b]?a:b);
  const maxIsJi = ji.includes(maxWx);
  const hurtMap = {wood:'肝胆手脚',fire:'心脑血',earth:'皮肤脑血栓',metal:'肺呼吸筋骨',water:'肾尿血'};
  const hurt = maxIsJi ? ('最旺五行「'+WX_NAME[maxWx]+'」为忌，须防对应脏腑伤损与意外血光（'+(hurtMap[maxWx]||'')+'）。') : '五行虽有偏颇，伤残病灾之象不显，平素注意安全即可。';
  const poCai = '财星/比劫应凶之岁运，注意一般性破财、投资谨慎，不宜担保借贷（非负债专项）。';
  return '<div class="adv-list">'
    + '<div class="adv-item"><b>官司牢狱：</b>'+law+'</div>'
    + '<div class="adv-item"><b>伤残病灾：</b>'+hurt+'</div>'
    + '<div class="adv-item"><b>破财：</b>'+poCai+'</div>'
    + '</div>';
}

function computeBazi(y, m, d, h, mi, gender, opts){
  opts = opts || {};
  const calType = opts.calType === 'lunar' ? 'lunar' : 'solar';
  const trueSolar = !!opts.trueSolar;
  const longitude = (typeof opts.longitude === 'number' && !isNaN(opts.longitude)) ? opts.longitude : 116.4;
  const ziType = opts.ziType === 'traditional' ? 'traditional' : 'modern';

  const notes = [];
  let sy, sm, sd;
  if (calType === 'lunar'){
    const cv = calendar.lunar2solar(y, m, d, opts.isLeap === true);
    if (!cv || cv === -1) return { error: '农历日期超出范围或不存在（支持 1900–2100）' };
    sy = cv.cYear; sm = cv.cMonth; sd = cv.cDay;
    notes.push(`农历输入：${cv.gzYear}年 ${cv.IMonthCn}${cv.IDayCn}`);
  } else {
    sy = y; sm = m; sd = d;
  }

  let sh = h, smi = mi;
  if (trueSolar){
    const eot = equationOfTime(sy, sm, sd);
    const corr = 4*(longitude - 120) + eot;     // 每度 4 分钟
    let total = sh*60 + smi + corr;
    total = ((total % 1440) + 1440) % 1440;
    sh = Math.floor(total/60); smi = Math.round(total % 60);
    notes.push(`真太阳时校正：${fmtHM(h,mi)} → ${fmtHM(sh,smi)}（经度 ${longitude}°E）`);
  }

  // 早晚子时：夜子时（23–24）归次日之子时；早子时（0–1）归当日
  let dayShift = 0, useH = sh;
  if (ziType === 'traditional' && sh === 23){ dayShift = 1; useH = 0; notes.push('夜子时：23–24 时归次日之子时'); }
  else if (ziType === 'traditional' && sh === 0){ notes.push('早子时：0–1 时归当日之子时'); }

  const obj = calendar.solar2lunar(sy, sm, sd + dayShift);
  if (!obj || obj === -1) return { error: '日期超出范围（支持 1900–2100）' };
  const yearGZ = obj.gzYear, monthGZ = obj.gzMonth, dayGZ = obj.gzDay;
  const dayStem = dayGZ[0];
  const br = hourBranch(useH);
  const hrStem = (DAY_STEM_ZI[dayStem] + br) % 10;
  const hourGZ = STEMS[hrStem] + BRANCHES[br];

  // 五行统计（四柱八字共 8 个字 + 地支本气已用于强弱，这里仅展示天干地支表层）
  const wx = {wood:0,fire:0,earth:0,metal:0,water:0};
  [yearGZ,monthGZ,dayGZ,hourGZ].forEach(gz=>{
    wx[GAN_WX[gz[0]]]++; wx[ZHI_WX[gz[1]]]++;
  });

  // 大运
  const yearGan = yearGZ[0];
  const isYang = YANG_GAN.has(yearGan);
  const forward = (gender === 'male' && isYang) || (gender === 'female' && !isYang);
  const monthIdx = gzIndex(monthGZ);

  const terms = [
    [1,1,1],[3,2,2],[5,3,3],[7,4,4],[9,5,5],[11,6,6],
    [13,7,7],[15,8,8],[17,9,9],[19,10,10],[21,11,11],[23,12,0]
  ]; // [n, month(1-12), 月支idx]
  const birth = new Date(sy, sm-1, sd + dayShift, useH, smi);
  const termDates = [];
  for (const yy of [sy-1, sy, sy+1]){
    for (const [n, mo, bIdx] of terms){
      const dayT = calendar.getTerm(yy, n);
      termDates.push({ date: new Date(yy, mo-1, dayT, 0, 0), branch: bIdx });
    }
  }
  let target = null;
  if (forward){
    const later = termDates.filter(t => t.date > birth).sort((a,b)=>a.date-b.date);
    target = later[0];
  } else {
    const earlier = termDates.filter(t => t.date < birth).sort((a,b)=>b.date-a.date);
    target = earlier[0];
  }
  let qiYun = {years:0, months:0};
  let dayun = [];
  if (target){
    const diffDays = Math.abs((target.date - birth) / 86400000);
    const years = diffDays / 3;
    qiYun = { years: Math.floor(years), months: Math.round((years - Math.floor(years)) * 12) };
    for (let i=0; i<8; i++){
      const idx = ((monthIdx + (forward ? 1 : -1) * (i+1)) % 60 + 60) % 60;
      const gz = GZ_60[idx];
      dayun.push({ age: qiYun.years + i*10, gz, wx: GAN_WX[gz[0]] });
    }
  }

  // 强弱 / 喜用神 / 十神 / 批断
  const dmWx = GAN_WX[dayStem];
  const P = {year:yearGZ, month:monthGZ, day:dayGZ, hour:hourGZ};
  // D：日主唯一根（地支本气为日主五行且全局仅一处）→ 命局关键一字，岁运冲之防灾
  const dmRoots = [P.year[1],P.month[1],P.day[1],P.hour[1]].filter(z=> HIDDEN[z] && HIDDEN[z][0] && GAN_WX[HIDDEN[z][0]]===dmWx);
  const keyRootZhi = dmRoots.length === 1 ? dmRoots[0] : '';
  const tg = {
    year: pillarTG(dayStem, dmWx, yearGZ),
    month: pillarTG(dayStem, dmWx, monthGZ),
    day: pillarTG(dayStem, dmWx, dayGZ),
    hour: pillarTG(dayStem, dmWx, hourGZ)
  };
  // 当前大运 / 流年
  const curYear = new Date().getFullYear();
  const curAge = curYear - sy;
  const activeDayun = dayun.filter(l => l.age <= curAge);
  const curDayunGz = activeDayun.length ? activeDayun[activeDayun.length - 1].gz : monthGZ;
  const liuNianGz = calendar.solar2lunar(curYear, 6, 1).gzYear;
  const curDayunTG = pillarTG(dayStem, dmWx, curDayunGz);
  const liuNianTG = pillarTG(dayStem, dmWx, liuNianGz);
  const pw = AD_strengthPower(P, dayStem, dmWx);
  const net2 = pw.net2;
  const score = Math.round(net2*10)/10;   // 日主净实力（显示字段；标签改「净实力」）
  const syBase = AD_sanyuanBase(P, dayStem);
  const strong = syBase.total >= SY_STRONG; const mid = (!strong && syBase.total >= SY_MID); // 三元打分定身旺侧（混合引擎）
  const resolved = AD_resolveXiJi(P, dayStem, dmWx, net2, wx);
  const pattern = resolved.pattern, congType = resolved.congType;
  let strengthLabel, level;
  if (pattern === 'zhuanwang') { strengthLabel = '强极'; level = '专旺'; }
  else if (pattern === 'cong') { strengthLabel = '弱极'; level = '从格'; }
  else if (pattern === 'huaqi') { strengthLabel = '化气格'; level = '化气'; }
  else if (pattern === 'liangShen') { strengthLabel = '两神成象格'; level = '两神'; }
  else if (pattern === 'anChong') { strengthLabel = congType || '暗冲格'; level = '暗冲'; }
  else if (pattern === 'anHe') { strengthLabel = congType || '暗合格'; level = '暗合'; }
  else {
    // 普通盘档位改由三元打分定（混合引擎 2026-07-25，5级：专旺·身强·中和·身弱·从格）
    const lv = AD_strengthLevelSY(AD_sanyuanBase(P, dayStem).total);
    strengthLabel = '日主' + lv.label;
    level = lv.label;
  }

  const yin = wuXingProducing(dmWx), shang = WX_SHENG[dmWx], cai = WX_KE[dmWx], guan = wuXingControlling(dmWx);
  let _xi = resolved.xi, _ji = resolved.ji;
  if (resolved.pattern === 'normal'){
    const comp = AD_comprehensiveXiJi(resolved, wx, P.month[1]);
    _xi = comp.xi; _ji = comp.ji;
  }
  const xi = _xi, ji = _ji;
  const xiNames = xi.map(w=>WX_NAME[w]), jiNames = ji.map(w=>WX_NAME[w]);

  const fortuneLines = dayun.map(d=>{
    const gw = GAN_WX[d.gz[0]], zw = ZHI_WX[d.gz[1]];
    // 加权评分：天干1.0 / 地支本气0.6 / 中气0.3 / 余气0.1，喜忌各计其分，比较定吉凶
    const cang = HIDDEN[d.gz[1]] || [];
    const comps = [gw, zw, ...cang.map(g=>GAN_WX[g])].slice(0, 4);
    const wght = [1.0, 0.6, 0.3, 0.1];
    let xiScore = 0, jiScore = 0; const xiComps = [], jiComps = [];
    comps.forEach((wxk, idx)=>{
      if (xi.includes(wxk)){ xiScore += wght[idx]; xiComps.push(WX_NAME[wxk]); }
      else if (ji.includes(wxk)){ jiScore += wght[idx]; jiComps.push(WX_NAME[wxk]); }
    });
    // 路线判定（《干支作用论》）：忌神若有路线伤用神则为忌神运，无路线则实质平顺；喜用同理
    const rt = dayunRoute(P, dayStem, dmWx, d, xi, ji);
    let tag = '平运', isXi = false, isJi = false;
    if (xiScore > jiScore + 0.4 && rt.reachXi){ tag = (xiScore >= 1.3 ? '用神运·大吉' : '用神运·吉'); isXi = true; }
    else if (jiScore > xiScore + 0.4 && rt.reachJi){ tag = (jiScore >= 1.3 ? '忌神运·凶' : '忌神运·慎'); isJi = true; }
    const startYear = sy + d.age;
    const liuNian = [];
    for (let k = 0; k < 10; k++){
      const yr = startYear + k;
      const gz = yearGanZhi(yr);
      liuNian.push({ gz, year: yr, age: d.age + k, desc: liuNianPiDuan(P, dayStem, dmWx, gz, xiNames, jiNames, xi, ji, yr, '', keyRootZhi, curDayunGz) });
    }
    const _pd = dayunPiDuanV2(P, dayStem, dmWx, d, isXi, isJi, xi, ji, xiNames, jiNames, keyRootZhi, rt, tag);
    return { age:d.age, gz:d.gz, tag, isXi, isJi, flat:_pd.flat, liuNian, desc: _pd.text, gong: _pd.gong, shiweidu: dayunShiWeiDu(P, dayStem, dmWx, d, isXi, isJi, xi, ji, keyRootZhi, _pd.gong) };
  });
  const dom = dominantTenGod(tg);
  const yueLing = monthGZ[1];
  const yueWx = ZHI_WX[yueLing];
  const tiaoNote = (function(){ if(['亥','子','丑'].includes(yueLing)) return '生于寒冬，局中盼火暖局，性含内秀而待时而发'; if(['巳','午','未'].includes(yueLing)) return '生于炎夏，局中需水润泽，性显外华而贵涵蓄'; return ''; })();
  const personality = AD_personalityV2(P, dayStem, dmWx, xi, ji, pattern, congType);


  // 婚姻（增强 G）：星宫 + 远近 + 空墓 + 生克 + 刑冲合害
  const spouseWx = gender === 'male' ? cai : guan;
  const spouseName = gender === 'male' ? '财星（妻星）' : '官杀（夫星）';
  let sc = 0; const spouseZhis = []; const spousePillars = [];
  [['年',yearGZ],['月',monthGZ],['日',dayGZ],['时',hourGZ]].forEach(([role,gz])=>{
    if (GAN_WX[gz[0]]===spouseWx){ sc++; spousePillars.push(role); }
    (HIDDEN[gz[1]]||[]).forEach(g=>{ if (GAN_WX[g]===spouseWx){ sc++; spouseZhis.push(gz[1]); spousePillars.push(role); } });
  });
  const palaceZhi = dayGZ[1];
  const palaceWx = ZHI_WX[palaceZhi];
  const palaceXi = xi.includes(palaceWx);
  // 入墓 / 空亡
  const MU = {wood:'未',fire:'戌',metal:'丑',water:'辰',earth:'辰'};
  const inMu = spouseZhis.includes(MU[spouseWx]);
  const kw = kongwangBranches(dayStem, palaceZhi);
  const inKong = spouseZhis.some(z=> kw.includes(z));
  // 生克：男比劫克财 / 女食伤克官
  let biCnt = 0, shiCnt = 0;
  [yearGZ,monthGZ,dayGZ,hourGZ].forEach(gz=>{
    const s1 = shiShen(dayStem,dmWx,gz[0],GAN_WX[gz[0]]);
    if (s1==='比肩'||s1==='劫财') biCnt++;
    if (s1==='食神'||s1==='伤官') shiCnt++;
    (HIDDEN[gz[1]]||[]).forEach(g=>{ const s2 = shiShen(dayStem,dmWx,g,GAN_WX[g]); if (s2==='比肩'||s2==='劫财') biCnt++; if (s2==='食神'||s2==='伤官') shiCnt++; });
  });
  // 夫妻宫刑冲合害
  const palaceRels = [['年支',P.year[1]],['月支',P.month[1]],['时支',P.hour[1]]].map(([n,z])=> AD_relateTwo(palaceZhi, z)).filter(Boolean);
  const palaceChong = palaceRels.some(r=> r.indexOf('冲')>=0);
  const palaceHe = palaceRels.some(r=> r.indexOf('合')>=0);
  let marriage = `日支（夫妻宫）为${palaceZhi}属${WX_NAME[palaceWx]}${palaceXi?'，为喜用，主夫妻和顺、互相助益':''}。${spouseName}在四柱见 ${sc} 处，${sc>=2?'星明有力，'+(gender==='male'?'妻缘':'夫缘')+'深厚':sc===1?'星有根气，尚可有依':(gender==='male'?'妻星偏弱，宜晚婚或用心经营':'夫星偏弱，宜晚婚或多加经营')}。`;
  if (spousePillars.includes('日') || spousePillars.includes('时')) marriage += '配偶星贴近日主（日/时柱），对命主影响直接而深。';
  else if (spousePillars.includes('年')) marriage += '配偶星居年柱较远，配偶多为外地或迟遇之象。';
  if (gender==='male' && biCnt>=2) marriage += '比劫林立克财，妻星受制，婚姻易不稳、宜晚婚且多经营。';
  else if (gender==='female' && shiCnt>=2) marriage += '食伤过旺克官，夫星受伤，婚姻易有波折、宜择柔合之配。';
  if (inMu) marriage += '配偶星入墓库，缘薄或配偶多病灾、早别之象。';
  else if (inKong) marriage += '配偶星逢空亡，夫妻缘浅、聚少离多或迟婚。';
  if (palaceChong) marriage += '夫妻宫逢冲，婚恋多变动、易有二婚或外缘之象。';
  else if (palaceHe) marriage += '夫妻宫逢合，异性缘旺，亦主外缘牵绊、宜专情守一。';
  marriage += '<br>婚姻宜结合全局与大运流年详参。';

  // 袁天罡称骨（P2-3：改用农历年干支，春节为界，修正立春—春节间出生者骨重偏差）
  const lunarYearGZ = (obj && typeof obj.lYear === 'number') ? yearGanZhi(obj.lYear) : yearGZ;
  const cg = chengu(lunarYearGZ, obj.lMonth, obj.lDay, hourBranch(useH));
  // 财运总趋势 / 工作事业
  const caiWx = WX_KE[dmWx];
  const careerWx = wuXingControlling(dmWx);
  const wealth = wealthAnalysis(dayStem, dmWx, caiWx, xi.includes(caiWx), xiNames, jiNames, P, strong, mid, dom, pattern);
  const career = careerAnalysis(dayStem, dmWx, careerWx, wuXingProducing(dmWx), xi.includes(careerWx), xiNames, jiNames, P, strong, mid, dom, pattern);

  return {
    year:yearGZ, month:monthGZ, day:dayGZ, hour:hourGZ,
    disclaimer: '以上命理分析仅供传统文化娱乐参考，不作为任何人生决策依据。',
    dayMaster:dayStem, dayMasterWx:dmWx,
    wx, dayun, qiYun, forward,
    lunarText: obj.IMonthCn + obj.IDayCn,
    solarText: `${sy}年${sm}月${sd+dayShift}日`,
    calType, trueSolar, longitude, ziType, notes,
    tenGods: Object.assign({}, tg, { dayun: curDayunTG, liuNian: liuNianTG }),
    curDayunGz, liuNianGz, liuNianYear: curYear, startedDayun: activeDayun.length > 0,
    strengthLabel, level, strong, score: Math.round(score*10)/10,
    pattern, congType,
    anReason: resolved.anReason, anDayKey: resolved.anDayKey, anKind: resolved.anKind,
    xiNames, jiNames,
    personality,
    fortuneLines,
    liuNianDesc: liuNianPiDuan(P, dayStem, dmWx, liuNianGz, xiNames, jiNames, xi, ji, undefined, '', keyRootZhi, curDayunGz), // 第一段不再拼地支关系（下方 adv-list 已展开，避免重复）
    activeDayunIdx: (()=>{ const ca = new Date().getFullYear() - sy; let ai = 0; dayun.forEach((d,i)=>{ if (d.age <= ca) ai = i; }); return ai; })(),
    marriage,
    healthRisk: AD_healthRisk(P, wx, dmWx, dayStem, score, level),
    disaster: AD_disaster(P, dayStem, dmWx, xi, ji, wx, sc, spouseWx, palaceWx, keyRootZhi),
    chengu: cg, wealth, career,
    lifeStage: AD_lifeStageInsights(P, dayStem, dmWx, xi, ji),
    advanced: AD_computeAdvanced(P, dayStem, dmWx, xi, ji, monthGZ[1], dayGZ[1], yearGZ[1], curDayunGz, liuNianGz, strong, score, wx, pattern, congType, mid, resolved.anDayKey)
  };
}

/* ===================================================================
 * 进阶批断模块（AD_ 前缀，自包含，避免与引擎已有符号冲突）
 * 包含：纳音 / 神煞补全 / 地支刑冲合害破 / 调候用神 /
 *       格局精断（透干·三合三会·专旺从化） / 十神组合 /
 *       用神分层（扶抑·调候·通关·病药） / 六亲 / 流年交互
 * 依赖（两引擎均有同名）：GZ_60, BRANCHES, STEMS, GAN_WX, ZHI_WX,
 *   WX_NAME, WX_SHENG, WX_KE, HIDDEN, wuXingProducing, wuXingControlling,
 *   shiShen, pillarTG, sanheOf
 * =================================================================== */

/* ---------- 纳音五行（六十甲子） ---------- */
const AD_NAYIN_NAMES = ['海中金','炉中火','大林木','路旁土','剑锋金','山头火','涧下水','城头土','白镴金','杨柳木','泉中水','屋上土','霹雳火','松柏木','长流水','沙中金','山下火','平地木','壁上土','金箔金','覆灯火','天河水','大驿土','钗钏金','桑柘木','大溪水','沙中土','天上火','石榴木','大海水'];
const AD_NAYIN = {};
GZ_60.forEach((gz,i)=>{ AD_NAYIN[gz] = AD_NAYIN_NAMES[Math.floor(i/2)]; });
function AD_sanheOf(zhi){
  if(zhi==='申'||zhi==='子'||zhi==='辰') return '水';
  if(zhi==='寅'||zhi==='午'||zhi==='戌') return '火';
  if(zhi==='亥'||zhi==='卯'||zhi==='未') return '木';
  if(zhi==='巳'||zhi==='酉'||zhi==='丑') return '金';
  return '';
}

/* ---------- 神煞（全量，自包含常量 AD_ 前缀） ---------- */
const AD_TIANYI = {'甲':['丑','未'],'戊':['丑','未'],'庚':['寅','午'],'乙':['子','申'],'己':['子','申'],'丙':['亥','酉'],'丁':['亥','酉'],'壬':['卯','巳'],'癸':['卯','巳'],'辛':['寅','午']};
const AD_SH_MAP = {'水':{ma:'寅',tao:'酉',hua:'辰',jiang:'子'},'火':{ma:'申',tao:'卯',hua:'戌',jiang:'午'},'木':{ma:'巳',tao:'子',hua:'未',jiang:'卯'},'金':{ma:'亥',tao:'午',hua:'丑',jiang:'酉'}};
const AD_YUEDE = {'火':'丙','水':'壬','木':'甲','金':'庚'};
const AD_TIANDE = {'寅':{t:'干',v:'丁'},'卯':{t:'支',v:'申'},'辰':{t:'干',v:'壬'},'巳':{t:'干',v:'辛'},'午':{t:'支',v:'亥'},'未':{t:'干',v:'癸'},'申':{t:'支',v:'寅'},'酉':{t:'支',v:'辰'},'戌':{t:'干',v:'丙'},'亥':{t:'支',v:'卯'},'子':{t:'支',v:'午'},'丑':{t:'干',v:'庚'}};
function AD_guChenGuaShu(dayZhi){
  if(['寅','卯','辰'].includes(dayZhi)) return ['巳','丑'];
  if(['巳','午','未'].includes(dayZhi)) return ['申','辰'];
  if(['申','酉','戌'].includes(dayZhi)) return ['亥','未'];
  if(['亥','子','丑'].includes(dayZhi)) return ['寅','戌'];
  return ['',''];
}
const AD_WENCHANG = {'甲':'巳','乙':'午','丙':'申','丁':'酉','戊':'申','己':'酉','庚':'亥','辛':'子','壬':'寅','癸':'卯'};
const AD_YANGREN  = {'甲':'卯','乙':'辰','丙':'午','戊':'午','丁':'未','己':'未','庚':'酉','辛':'戌','壬':'子','癸':'丑'};
const AD_LUSHEN   = {'甲':'寅','乙':'卯','丙':'巳','戊':'巳','丁':'午','己':'午','庚':'申','辛':'酉','壬':'亥','癸':'子'};
const AD_WANG_SHEN = {'水':'申','木':'亥','火':'寅','金':'巳'}; // 三合局长生=亡神
const AD_JIE_SHEN  = {'水':'巳','木':'寅','火':'亥','金':'申'}; // 三合局绝=劫煞
const AD_JIANG_XING = {'水':'子','木':'卯','火':'午','金':'酉'}; // 三合局帝旺=将星
const AD_HONGLUAN = {'子':'卯','丑':'寅','寅':'丑','卯':'子','辰':'亥','巳':'戌','午':'酉','未':'申','申':'未','酉':'午','戌':'巳','亥':'辰'};
function AD_shenshaFull(zhi, gan, dayGan, dayZhi, monthZhi, yearZhi){
  const list = [];
  // 每个神煞记录其「所临之字」(anchor)：多数临地支 zhi；月德/天德(干)临天干 gan。
  const push = (name, anchorChar) => { list.push({n:name, a:anchorChar}); };
  if((AD_TIANYI[dayGan]||[]).includes(zhi)) push('天乙贵人', zhi);
  // P1-4：桃花/驿马/华盖/将星/亡神/劫煞/灾煞/官符 以日支、年支并参，分别标注（日）/（年）
  const pushBy = (baseZhi, tag) => {
    const sh = AD_sanheOf(baseZhi);
    if(!sh) return;
    const m = AD_SH_MAP[sh];
    if(zhi===m.ma) push('驿马('+tag+')', zhi);
    if(zhi===m.tao) push('桃花('+tag+')', zhi);
    if(zhi===m.hua) push('华盖('+tag+')', zhi);
    const ji = BRANCHES.indexOf(m.jiang);
    if(zhi===BRANCHES[(ji+6)%12]) push('灾煞('+tag+')', zhi);
    if(zhi===BRANCHES[(ji+1)%12]) push('官符('+tag+')', zhi);
    if(zhi===AD_WANG_SHEN[sh]) push('亡神('+tag+')', zhi);
    if(zhi===AD_JIE_SHEN[sh]) push('劫煞('+tag+')', zhi);
    if(zhi===AD_JIANG_XING[sh]) push('将星('+tag+')', zhi);
  };
  pushBy(dayZhi, '日');
  if (yearZhi && yearZhi !== dayZhi) pushBy(yearZhi, '年');
  const yd = AD_YUEDE[AD_sanheOf(monthZhi)];
  if(yd && gan===yd) push('月德', gan);
  const td = AD_TIANDE[monthZhi];
  if(td){ if(td.t==='支' && td.v===zhi) push('天德', zhi); else if(td.t==='干' && td.v===gan) push('天德', gan); }
  const gc = AD_guChenGuaShu(dayZhi);
  if(zhi===gc[0]) push('孤辰', zhi);
  if(zhi===gc[1]) push('寡宿', zhi);
  if(zhi===AD_WENCHANG[dayGan]) push('文昌', zhi);
  if(zhi===AD_YANGREN[dayGan]) push(isYangGan(dayGan)?'羊刃':'阴刃', zhi); // P2-5：阴干羊刃标注为阴刃
  if(zhi===AD_LUSHEN[dayGan]) push('禄神', zhi);
  if(zhi===AD_HONGLUAN[yearZhi]) push('红鸾', zhi);
  const hlIdx = BRANCHES.indexOf(AD_HONGLUAN[yearZhi]);
  if(hlIdx>=0 && zhi===BRANCHES[(hlIdx+6)%12]) push('天喜', zhi);
  return list;
}
// 神煞所临之字（天干/地支）对日干的喜忌：据其五行是否喜用/忌神判定。
// 返回 'xi'(喜字/吉字) | 'ji'(忌字/凶字) | 'mid'(闲字)。
function AD_shaFav(char, xiWxArr, jiWxArr){
  const isStem = Object.prototype.hasOwnProperty.call(GAN_WX, char);
  const wx = isStem ? GAN_WX[char] : (ZHI_WX[char] || '');
  if (xiWxArr.indexOf(wx) >= 0) return 'xi';
  if (jiWxArr.indexOf(wx) >= 0) return 'ji';
  return 'mid';
}

/* ---------- 地支刑冲合害破 ---------- */
const AD_CHONG = [['子','午'],['丑','未'],['寅','申'],['卯','酉'],['辰','戌'],['巳','亥']];
const AD_LIUHE = [['子','丑'],['寅','亥'],['卯','戌'],['辰','酉'],['巳','申'],['午','未']];
const AD_SANHE = {'水':['申','子','辰'],'火':['寅','午','戌'],'木':['亥','卯','未'],'金':['巳','酉','丑']};
const AD_SANHUI = {'木':['寅','卯','辰'],'火':['巳','午','未'],'金':['申','酉','戌'],'水':['亥','子','丑']};
const AD_XING = [['寅','巳','申'],['丑','戌','未'],['子','卯'],['辰'],['午'],['酉'],['亥']];
const AD_HAI = [['子','未'],['丑','午'],['寅','巳'],['卯','辰'],['申','亥'],['酉','戌']];
const AD_PO = [['子','酉'],['丑','辰'],['寅','亥'],['卯','午'],['巳','申'],['未','戌']];
function AD_relateTwo(a, b){
  if(a===b) return '';
  for(const p of AD_CHONG) if((p[0]===a&&p[1]===b)||(p[0]===b&&p[1]===a)) return '相冲';
  for(const p of AD_LIUHE) if((p[0]===a&&p[1]===b)||(p[0]===b&&p[1]===a)) return '六合';
  for(const k in AD_SANHE){ const arr=AD_SANHE[k]; if(arr.includes(a)&&arr.includes(b)&&a!==b) return '三合'+k; }
  for(const k in AD_SANHUI){ const arr=AD_SANHUI[k]; if(arr.includes(a)&&arr.includes(b)&&a!==b) return '三会'+k; }
  for(const g of AD_XING){ if(g.length>1 && g.includes(a) && g.includes(b)) return '相刑'; if(g.length===1 && g[0]===a && g[0]===b) return '自刑'; }
  for(const p of AD_HAI) if((p[0]===a&&p[1]===b)||(p[0]===b&&p[1]===a)) return '相害';
  for(const p of AD_PO) if((p[0]===a&&p[1]===b)||(p[0]===b&&p[1]===a)) return '相破';
  return '';
}
function AD_relateAll(zhis){
  const out = [];
  const seen = new Set();
  for(let i=0;i<zhis.length;i++){
    for(let j=i+1;j<zhis.length;j++){
      const a=zhis[i], b=zhis[j];
      if(a===b){ const key='同'+a; if(!seen.has(key)){ seen.add(key); out.push({text:'地支'+a+'伏吟，事象叠加', type:'伏吟'}); } continue; }
      const r = AD_relateTwo(a,b);
      if(r){ const key=[a,b,r].sort().join(''); if(!seen.has(key)){ seen.add(key); out.push({text:''+a+'与'+b+''+r, type:r}); } }
    }
  }
  return out;
}

/* ---------- 干支作用路线（《干支作用论》教学落地）----------
 * 四层确定性模型：①本柱干支直接作用、异柱不作用 ②天干紧贴才生克、年干⇄时干断路
 * ③地支须刑冲合害或三合三会才实质作用，否则仅气势之虚 ④藏干本气60/中气30/余气10，
 *   受本气克/泄/耗的余气为「假藏干」（受伤无用，除非命局同类五行旺相）。*/
function _ganAct(aWx, bWx){ // a 对 b 的五行作用向
  if(aWx===bWx) return '同气帮扶';
  if(WX_SHENG[aWx]===bWx) return '生';
  if(WX_KE[aWx]===bWx) return '克';
  if(WX_SHENG[bWx]===aWx) return '被生';
  if(WX_KE[bWx]===aWx) return '被克';
  return '无';
}
// 判藏干真假：仅判最弱「余气」（本气/中气默认真根）；返回带真假标注的藏干列表
function AD_cangReal(zhi){
  const arr = ZHI_CANG[zhi]; const roles=['本气','中气','余气'];
  const list = arr.map((it,i)=>({gan:it[0],wx:GAN_WX[it[0]],score:it[1],role:roles[i]||'余气',real:true,note:'真根'}));
  if(list.length<=1){ list[0].note='专气独藏，真根'; return list; }
  const ben=list[0], yu=list[list.length-1]; // 本气 / 余气
  if(WX_KE[ben.wx]===yu.wx){ yu.real=false; yu.note='受本气'+WX_NAME[ben.wx]+'所克，假藏干（受伤无用）'; }
  else if(WX_SHENG[yu.wx]===ben.wx){ yu.real=false; yu.note='生本气'+WX_NAME[ben.wx]+'而被盗泄，假藏干（受伤）'; }
  else if(WX_KE[yu.wx]===ben.wx){ yu.real=false; yu.note='克本气'+WX_NAME[ben.wx]+'反自耗，假藏干（受伤）'; }
  else if(WX_SHENG[ben.wx]===yu.wx){ yu.note='受本气'+WX_NAME[ben.wx]+'所生，真根得力'; }
  else { yu.note='与本气同气，真根'; }
  if(list.length===3){ const mid=list[1]; const act=_ganAct(ben.wx, mid.wx);
    mid.note = act==='生'?('受本气'+WX_NAME[ben.wx]+'生，真根'):act==='克'?('受本气'+WX_NAME[ben.wx]+'牵制但力可存，仍作根'):'真根';
  }
  return list;
}
// 路线专用地支关系：刑冲合害破六合按两字判；三合/三会须三字俱全（隔位方能作用）
function _zhiRel(a, b, allZhis){
  if(a===b) return '';
  for(const p of AD_CHONG) if((p[0]===a&&p[1]===b)||(p[0]===b&&p[1]===a)) return '相冲';
  for(const p of AD_LIUHE) if((p[0]===a&&p[1]===b)||(p[0]===b&&p[1]===a)) return '六合';
  for(const g of AD_XING){ if(g.length>1 && g.includes(a) && g.includes(b)) return '相刑'; }
  for(const p of AD_HAI) if((p[0]===a&&p[1]===b)||(p[0]===b&&p[1]===a)) return '相害';
  for(const p of AD_PO) if((p[0]===a&&p[1]===b)||(p[0]===b&&p[1]===a)) return '相破';
  for(const k in AD_SANHE){ const arr=AD_SANHE[k]; if(arr.includes(a)&&arr.includes(b)&&arr.every(z=>allZhis.includes(z))) return '三合'+k+'局'; }
  for(const k in AD_SANHUI){ const arr=AD_SANHUI[k]; if(arr.includes(a)&&arr.includes(b)&&arr.every(z=>allZhis.includes(z))) return '三会'+k+'局'; }
  return '';
}


/* ---------- 格局精断 ---------- */
function AD_geJuJing(P, dayGan, dmWx, monthZhi, monthBenQi, geJuName, score, strong, pattern, mid){
  const gans = [P.year[0],P.month[0],P.day[0],P.hour[0]];
  const zhis = [P.year[1],P.month[1],P.day[1],P.hour[1]];
  const out = [];
  if(geJuName){
    // 月令本气十神格（八格：财官印食杀伤枭；比劫当令为禄刃，不入正格）
    const ZHENG_GE = ['正财','偏财','正官','七杀','正印','偏印','食神','伤官'];
    const SHAN = ['正官','正财','偏财','正印','食神']; // 善神（顺用、宜扶）
    if(ZHENG_GE.includes(geJuName)){
      const tgSSall = gans.map(g => shiShen(dayGan, dmWx, g, GAN_WX[g]));
      let pos;
      if(tgSSall[1]===geJuName) pos='月干透出，为真格、力量最纯';
      else if(tgSSall[0]===geJuName) pos='年干透出，力量次之';
      else if(tgSSall[3]===geJuName) pos='时干透出，力量又次';
      else pos='伏于地支未透天干，为暗格，待大运流年引动方显';
      const nature = SHAN.includes(geJuName) ? '善神格（宜顺用、扶护）' : '恶神格（宜逆用、制化）';
      out.push('月令'+geJuName+'格：'+pos+'；'+nature+'。');
    }
  }
  // 三合/三会局：点明该局五行对日主之关系（生扶/克伐/比助/财/食伤）
  // 注意 AD_SANHE/AD_SANHUI 的 key 是中文五行（木火金水），须经 WX_KEY 映射到英文 key
  const juRel = (k)=>{
    const wk = WX_KEY[k];
    if(WX_SHENG[wk]===dmWx) return '生扶日主（印旺之基）';
    if(WX_KE[wk]===dmWx) return '克伐日主（官杀攻身之基）';
    if(wk===dmWx) return '比助日主（比劫汇聚）';
    if(WX_SHENG[dmWx]===wk) return '泄秀日主（食伤之基）';
    if(WX_KE[dmWx]===wk) return '为日主之财（富局之基）';
    return '与日主相峙';
  };
  for(const k in AD_SANHE){ const arr=AD_SANHE[k]; if(arr.every(z=>zhis.includes(z))) out.push('地支三合'+WX_NAME[WX_KEY[k]]+'局（'+arr.join('')+'），五行气势汇聚成势，于日主为'+juRel(k)+'。'); }
  for(const k in AD_SANHUI){ const arr=AD_SANHUI[k]; if(arr.every(z=>zhis.includes(z))) out.push('地支三会'+WX_NAME[WX_KEY[k]]+'局（'+arr.join('')+'），方局成势、性情专一，于日主为'+juRel(k)+'。'); }
  // 专旺格：日主+比劫+印极旺且无官杀
  const tgSS = gans.map(g => shiShen(dayGan, dmWx, g, GAN_WX[g]));
  const bx = tgSS.filter(s=>s==='比肩'||s==='劫财').length;
  const yin = tgSS.filter(s=>s==='正印'||s==='偏印').length;
  const guan = tgSS.filter(s=>s==='正官'||s==='七杀').length;
  // 专旺（放宽·印比旺致专旺）：印比占八字（天干十神+地支本气共8字）≥6、克泄耗≤2、无官杀透干，不得令亦成（电脑公式化：以八字数占比替人脑"根受伤无用"软判）
  const yinK = wuXingProducing(dmWx), shangK = WX_SHENG[dmWx], caiK = WX_KE[dmWx], guanK = wuXingControlling(dmWx);
  const _ybGanK = gans.map(g=>shiShen(dayGan,dmWx,g,GAN_WX[g])).filter(s=>s==='比肩'||s==='劫财'||s==='正印'||s==='偏印').length;
  const _kxGanK = gans.map(g=>shiShen(dayGan,dmWx,g,GAN_WX[g])).filter(s=>s==='正财'||s==='偏财'||s==='正官'||s==='七杀'||s==='食神'||s==='伤官').length;
  const _ybZhiK = zhis.some(z=>{ const w=GAN_WX[HIDDEN[z]&&HIDDEN[z][0]]; return w===dmWx||w===yinK; }).length;
  const _kxZhiK = zhis.some(z=>{ const w=GAN_WX[HIDDEN[z]&&HIDDEN[z][0]]; return w===caiK||w===guanK||w===shangK; }).length;
  const zhuanByYinBiK = (_ybGanK+_ybZhiK) >= 6 && (_kxGanK+_kxZhiK) <= 2 && guan === 0;
  if(pattern === 'zhuanwang'){ // 专旺：与 AD_resolveXiJi 决策保持一致（克星门未破 + 净实力超阈值）
    const zw = {'wood':'曲直','fire':'炎上','earth':'稼穑','metal':'从革','water':'润下'}[dmWx];
    const FANG={wood:['寅','卯','辰'],fire:['巳','午','未'],earth:['辰','戌','丑','未'],metal:['申','酉','戌'],water:['亥','子','丑']};
    const fz=FANG[dmWx]; const cheng = dmWx==='earth' ? fz.filter(z=>zhis.includes(z)).length>=3 : fz.every(z=>zhis.includes(z));
    out.push('专旺格（'+zw+'格）：日主极旺，比劫印绶林立而无官杀克泄，宜顺其旺势，喜行比劫印运，忌财官。'+(cheng?'地支复成'+zw+'方局，旺气归一、格局清纯。':''));
  }
  // 从格：日主极弱、日主外（年/月/时）无印比、且地支（本/中/余气）亦无印比之根。
  // 须排除日干自身（日干恒为比肩）否则条件永不成立；P0-2 后中余气参与，须查地支根方能定真从。
  const otherSS = [P.year[0],P.month[0],P.hour[0]].map(g => shiShen(dayGan, dmWx, g, GAN_WX[g]));
  const obx = otherSS.filter(s=>s==='比肩'||s==='劫财').length;
  const oyin = otherSS.filter(s=>s==='正印'||s==='偏印').length;
  let oRoot = false;
  [P.year[1],P.month[1],P.day[1],P.hour[1]].forEach(z=>{ (HIDDEN[z]||[]).forEach(g=>{ const s=shiShen(dayGan,dmWx,g,GAN_WX[g]); if(s==='正印'||s==='偏印'||s==='比肩'||s==='劫财') oRoot=true; }); });
  if(pattern === 'cong'){ // 从格：与 AD_resolveXiJi 决策保持一致（净实力极负且日主无根）
    let fromWhat = '从势';
    if(otherSS.includes('正财')||otherSS.includes('偏财')) fromWhat = '从财';
    else if(otherSS.includes('正官')||otherSS.includes('七杀')) fromWhat = '从杀';
    else if(otherSS.includes('食神')||otherSS.includes('伤官')) fromWhat = '从儿';
    out.push('从格（'+fromWhat+'格）：日主孤立无援，极弱弃命相从，喜行所从旺神（'+fromWhat.replace('从','')+'）之运，忌印比扶身破格。本App以真从为判——若局中印比微根未净，则归偏弱论，不从。');
  }
  if(out.length===0) out.push('命局平正，无特殊成格；以日主强弱为体，扶抑取用——具体病因对症详见「用神取用」一节。');
  else {
    let zp;
    if (pattern === 'zhuanwang') zp = '极旺成格，宜顺其旺势、行比劫印运则发，忌财官克泄';
    else if (pattern === 'cong') zp = '弃命相从，宜行所从旺神之运，忌印比扶身破格';
    else if (pattern === 'anChong') zp = '暗冲官格，以虚神官星为用，喜冲出之官、忌岁运填实破格';
    else if (pattern === 'anHe') zp = '暗合官格，以虚神官星为用，喜合出之官、忌岁运填实破格';
    else if (pattern === 'huaqi' || pattern === 'liangShen') zp = '特殊成格，宜顺其格势而为';
    else zp = (strong ? '偏旺，顺其势、用克泄耗则成' : '偏弱，得生扶比劫则发');
    out.push('总评：日主' + zp + (geJuName && ['正财','偏财','正官','七杀','正印','偏印','食神','伤官'].includes(geJuName) ? '，以'+geJuName+'格为体' : '') + '。');
  }
  return out;
}

/* ---------- 十神组合（灾祸符号体系：组合为符号，成立与否视喜忌·透干·岁运引发） ---------- */
function AD_combos(P, dayGan, dmWx, jiWxArr, xiWxArr, monthZhi){
  const gans=[P.year[0],P.month[0],P.day[0],P.hour[0]];
  const zhis=[P.year[1],P.month[1],P.day[1],P.hour[1]];
  // 天干 / 藏干 各自的十神·五行·是否忌神 / 是否喜神
  const tg = gans.map(g=>({g, ss:shiShen(dayGan,dmWx,g,GAN_WX[g]), wx:GAN_WX[g], ji:jiWxArr.indexOf(GAN_WX[g])>=0}));
  const zang=[];
  zhis.forEach(z=>(HIDDEN[z]||[]).forEach(g=>zang.push({g, ss:shiShen(dayGan,dmWx,g,GAN_WX[g]), wx:GAN_WX[g], ji:jiWxArr.indexOf(GAN_WX[g])>=0})));
  const all=[...tg,...zang];
  const hasTg = ss => tg.some(t=>t.ss===ss);              // 透干出现
  const hasAny = ss => all.some(t=>t.ss===ss);            // 命局出现（含藏干）
  const tgJi = ss => tg.some(t=>t.ss===ss && t.ji);       // 透干且为忌
  const anyJi = ss => all.some(t=>t.ss===ss && t.ji);     // 出现且为忌（含藏干）
  const anyXi = ss => all.some(t=>t.ss===ss && xiWxArr.indexOf(t.wx)>=0); // 出现且为喜
  const out=[];
  // typ 随“凶神为忌透干 / 吉神为喜用”动态：忌→凶(bad)，非忌→中(mid)，喜用→吉(good)
  const push=(name, typ, typCls, symbol, cond)=> out.push({name, typ, typCls, symbol, cond});
  const latent = sym => '（潜伏）' + sym.replace(/之符号$/, '') + '，非忌则多不显';

  // 一、常见十神组合与灾祸符号
  // 1 枭神夺食（偏印见食神）
  if(hasAny('偏印') && hasAny('食神')){
    const ji = tgJi('偏印');
    push('枭神夺食', ji?'凶':'中', ji?'bad':'mid',
      ji ? '病灾、破财、休学、失业、降职之符号' : latent('病灾、破财、休学、失业、降职之符号'),
      ji ? '命局枭神（偏印）为忌透干无制化，岁运见食神则“夺食”成立，符号即现；灾祸大小视枭神为忌之程度。'
         : '枭神虽现而非忌（或为喜用、有制化），夺力有限；若枭神为用，流年见食伤仍主工作、家庭之良性波动，非凶。');
  }
  // 2 伤官见官
  if(hasAny('伤官') && hasAny('正官')){
    const ji = tgJi('伤官');
    push('伤官见官', ji?'凶':'中', ji?'bad':'mid',
      ji ? '官灾、降职、失业、破财、克夫之符号' : latent('官灾、降职、失业、破财、克夫之符号'),
      ji ? '伤官为忌透干旺而无制化，岁运见正官则“伤官制官”成立，不论官星吉凶，符号皆现。'
         : '伤官非忌或官星非忌时，多主工作、事业、家庭之动荡不安与口舌是非，事小而鲜有大伤。');
  }
  // 3 比劫夺财
  {
    const biAny = hasAny('比肩')||hasAny('劫财');
    const caiAny = hasAny('正财')||hasAny('偏财');
    if(biAny && caiAny){
      const jieJi = tg.some(t=>(t.ss==='劫财') && t.ji);
      const biJi  = tg.some(t=>(t.ss==='比肩') && t.ji);
      const ji = jieJi||biJi;
      push('比劫夺财', ji?'凶':'中', ji?'bad':'mid',
        ji ? '破财、病灾、婚灾、乃至官非之符号' : latent('破财、病灾、婚灾、乃至官非之符号'),
        ji ? '比劫为忌透干（'+(jieJi?'劫财透干尤甚':'比肩透干')+'），见岁运透财则“夺财”成立，符号显现。'
           : '比劫虽现而非忌（或为用神），夺财之象不显，仅主钱财进出频繁、花费偏大。');
    }
  }
  // 4 七杀制身（特殊位置条件：当令 / 紧贴日主 / 明显感应）
  {
    const shaAny = all.filter(t=>t.ss==='七杀');
    if(shaAny.length){
      const monthBen = HIDDEN[monthZhi] ? HIDDEN[monthZhi][0] : '';
      const monthSha = monthBen && shiShen(dayGan,dmWx,monthBen,GAN_WX[monthBen])==='七杀';
      const near = tg.some(t=>(t.ss==='七杀') && (t.g===P.month[0]||t.g===P.hour[0]))
                || (HIDDEN[P.day[1]]||[]).some(g=>shiShen(dayGan,dmWx,g,GAN_WX[g])==='七杀');
      const shaJi = shaAny.some(t=>t.ji);
      if(shaJi && (monthSha||near)){
        push('七杀制身','凶','bad','伤病灾、官非牢狱之符号',
          (monthSha?'七杀当令（月令本气）':near?'七杀紧贴日主（月干·时干·日支）':'七杀明显感应日主')
          +'，且为忌无制化，直接威胁日主；岁运再见财生杀或杀透，则制身到位、符号即现。');
      } else {
        push('七杀制身','中','mid','（潜在）攻身之忧',
          '命局见七杀，'+(shaJi?'且为忌，':'')+(monthSha||near?'位置已逼日主':'但位置较远未紧贴')
          +'；若有印化或食制（制化得宜），则七杀化为权柄，反成威严担当。');
      }
    }
  }
  // 二、凶神组合符号（凶神=伤官·七杀·劫财·枭神，两两组合狼狈为奸、互不制约）
  const pairDef=[
    ['伤官','七杀','官非、伤病、凶死之符号'],
    ['伤官','劫财','打架斗殴、官非口舌之符号'],
    ['偏印','伤官','破财、病灾、失业之符号'],
    ['七杀','劫财','打斗、伤残、病灾、官灾之符号'],
    ['七杀','偏印','病灾、降职、失业之符号'],
    ['偏印','劫财','官非口舌、破财之符号']
  ];
  pairDef.forEach(([a,b,sym])=>{
    if(hasAny(a) && hasAny(b)){
      const ji = tgJi(a)||tgJi(b);
      push(a+'见'+b, ji?'凶':'中', ji?'bad':'mid',
        ji ? sym : latent(sym),
        ji ? '两凶神（'+a+'·'+b+'）为忌透干，互不制约而共攻日主，岁运引发则符号显现；程度视其忌之深浅。'
           : a+'·'+b+'虽同现而非忌（或为用），凶性不彰，多主性格活跃、敢为，未必成灾。');
    }
  });
  // 三、吉象组合（正格搭配，条件：为喜用方显其利）
  if(hasAny('食神') && hasAny('七杀')){
    const xi = anyXi('食神')||anyXi('七杀');
    push('食神制杀', xi?'吉':'中', xi?'good':'mid', '以技立身、武职或专业技艺易成之象',
      xi ? '食神（或七杀）为喜用，食神驾御七杀、化煞为权，主凭专长建功、武职或技艺有成。'
         : '食神驾御七杀、化煞为权；若食杀皆为喜用，主凭专长建功。');
  }
  if((hasAny('正财')||hasAny('偏财')) && hasAny('正官')){
    const xi = anyXi('正官')||anyXi('正财')||anyXi('偏财');
    push('财官相生', xi?'吉':'中', xi?'good':'mid', '利仕途与实业、富贵可期之象',
      xi ? '财星或正官为喜用，财能生官，主务实进取、名实相副、利仕途实业。'
         : '财能生官；若财官为喜用，主务实进取、名实相副。');
  }
  if(hasAny('正官') && hasAny('正印')){
    const xi = anyXi('正官')||anyXi('正印');
    push('官印相生', xi?'吉':'中', xi?'good':'mid', '清贵、文途顺畅之象',
      xi ? '官星或正印为喜用，官来生印、印来护官，主得贵人、文职顺遂。'
         : '官来生印、印来护官；若官印为喜用，主得贵人、文职顺遂。');
  }
  if(hasAny('伤官') && hasAny('正印')){
    const xi = anyXi('正印');
    push('伤官佩印', xi?'吉':'中', xi?'good':'mid', '才华得显而不招祸之象',
      xi ? '正印为喜用，伤官之锐得印绶收敛，文采飞扬而少是非。'
         : '伤官之锐得印绶收敛；若印为喜用，则文采飞扬而少是非。');
  }
  if((hasAny('正财')||hasAny('偏财')) && (hasAny('正印')||hasAny('偏印'))){
    const ji = anyJi('正财')||anyJi('偏财');
    push('财星坏印', ji?'凶':'中', ji?'bad':'mid',
      ji ? '重实务而轻书香、因财损名之符号' : '（潜伏）财印相战，印旺则能制',
      ji ? '财星为忌而克印，主因财妨学、因利损名；印旺有根则能制。'
         : '财来克印；若财旺印弱为忌，主因财妨学、因利损名，印旺则能制。');
  }
  return out;
}

/* ---------- 用神分层 ---------- */
function AD_yongShen(dmWx, strong, xiWxArr, jiWxArr, tiaoWx, wx, pattern, congType, mid, anDayKey){
  const out = [];
  const xiNames = xiWxArr.map(w=>WX_NAME[w]).join('、');
  // 暗冲/暗合官格用神：按日柱定喜忌（虚神为用，岁运引动则发，填实/冲破则破）
  const AN_YONGSHEN = {
    anChong: {
      '丙午': { xi:'喜申来合起子官', ji:'忌行癸子年运' },
      '丁巳': { xi:'喜寅及卯来合起壬官', ji:'忌行壬亥年运' },
      '庚子': { xi:'喜寅来合起午官', ji:'忌行丁午年运' },
      '壬子': { xi:'喜寅来合起午中己官', ji:'忌行巳午未年运' },
      '辛亥': { xi:'喜申酉合起巳官', ji:'忌行丙巳年运' },
      '癸亥': { xi:'喜酉合起巳中戊官', ji:'忌行戊己戌年运' },
    },
    anHe: {
      '甲辰': { xi:'喜辰来助合', ji:'最忌酉填实，次忌戌冲辰' },
      '戊戌': { xi:'喜戌来助合', ji:'最忌卯填实，次忌辰冲戌' },
      '癸卯': { xi:'喜卯来助合', ji:'最忌戌填实，次忌酉冲卯' },
      '癸酉': { xi:'喜酉来助合', ji:'最忌辰填实，次忌卯冲酉' },
    }
  };
  if (pattern === 'zhuanwang'){
    out.push('专旺用神：日主极旺成格，宜顺其旺势，以'+xiNames+'（比劫、印绶）为用——喜行比劫印运，忌财官克泄，犯之则激怒旺神而多挫。');
  } else if (pattern === 'cong'){
    const congLabel = {cong_cai:'从财',cong_sha:'从杀',cong_er:'从儿',cong_shi:'从势'}[congType] || '从势';
    out.push('从格用神：日主弃命相从（'+congLabel+'格），以'+xiNames+'为用——喜行所从旺神之运，忌印比扶身，一逢生扶则假从破格而凶。');
  } else if (pattern === 'huaqi'){
    out.push('化气用神：日主化气为'+xiNames+'，宜顺化气之势，以化神为用——喜行化神旺相之运，忌克破化神（'+jiWxArr.map(w=>WX_NAME[w]).join('、')+'）。');
  } else if (pattern === 'liangShen'){
    out.push('两神成象用神：全局仅两行成象，宜顺其势，以'+xiNames+'为用——喜行两神生旺之运，忌混杂第三行破象。');
  } else if (pattern === 'anChong' || pattern === 'anHe'){
    const kind = pattern === 'anChong' ? 'anChong' : 'anHe';
    const rule = AN_YONGSHEN[kind] && AN_YONGSHEN[kind][anDayKey];
    if (rule){
      out.push('暗'+(pattern==='anChong'?'冲':'合')+'官格用神：'+rule.xi+'；'+rule.ji+'。（暗官为虚神，岁运引动则发，填实/冲破则破格。）');
    } else {
      out.push('暗冲/暗合用神：局藏暗动之机，以'+xiNames+'为用——宜待时而动、借暗合暗冲之力，忌明冲破局。');
    }
  } else if(strong){
    out.push('扶抑用神：日主偏旺，宜克泄耗，以'+xiNames+'为用——宜行克泄耗之运，从事需施展、表达、流动之业；忌生扶比劫之运，防恃旺生骄、刚极易折。');
  } else if(mid){
    out.push('扶抑用神：日主中和，不偏不倚，喜忌宽泛，以'+xiNames+'为用——宜随大运流年而取用，行运得力则成，不执一端。');
  } else {
    out.push('扶抑用神：日主偏弱，宜生扶比劫，以'+xiNames+'为用——宜行生扶之运，得长辈、同伴之力；忌克泄耗之运，防身弱不胜其任。');
  }
  if(tiaoWx) out.push('调候用神：' + (tiaoWx==='fire' ? '寒局需火（丙丁）暖之，寒谷回春则精神发越。' : '燥局需水（壬癸）润之，水火既济则秀气流行。'));
  if (pattern === 'normal'){
    // 通关：两五行相战
    const strong2 = Object.keys(wx).filter(w=>wx[w]>=3);
    if(strong2.length>=2){
      const pair = [strong2[0], strong2[1]];
      const bridge = {'wood|fire':'earth','fire|earth':'metal','earth|metal':'water','metal|water':'wood','water|wood':'fire',
                      'wood|metal':'fire','fire|water':'wood','earth|water':'metal','metal|wood':'water','water|earth':'wood'}[pair.sort().join('|')];
      if(bridge) out.push('通关用神：'+WX_NAME[pair[0]]+'与'+WX_NAME[pair[1]]+'交战不和，宜用'+WX_NAME[bridge]+'居中通关——宜居间调和、中介斡旋之位，化敌为友。');
    }
    // 病药：最强旺五行为病，克之者为药
    const maxWx = Object.keys(wx).reduce((a,b)=> wx[a]>=wx[b]?a:b);
    const ke5 = {wood:'metal',fire:'water',earth:'wood',metal:'fire',water:'earth'};
    out.push('病药用神：'+WX_NAME[maxWx]+'过旺为病，以'+WX_NAME[ke5[maxWx]]+'制之为药——宜行制病之运、从事制化之业，治病即建功。');
  }
  return out;
}

/* ---------- 十神分组计数（天干全权 + 藏干半权） ---------- */
function AD_shiShenGroups(P, dayGan, dmWx){
  const gans=[P.year[0],P.month[0],P.day[0],P.hour[0]];
  const zhis=[P.year[1],P.month[1],P.day[1],P.hour[1]];
  const cnt={yin:0,bi:0,shi:0,cai:0,guan:0};
  const add=(g,w)=>{ const s=shiShen(dayGan,dmWx,g,GAN_WX[g]);
    if(s==='正印'||s==='偏印') cnt.yin+=w;
    else if(s==='比肩'||s==='劫财') cnt.bi+=w;
    else if(s==='食神'||s==='伤官') cnt.shi+=w;
    else if(s==='正财'||s==='偏财') cnt.cai+=w;
    else if(s==='正官'||s==='七杀') cnt.guan+=w;
  };
  gans.forEach(g=>add(g,1));
  zhis.forEach(z=>(HIDDEN[z]||[]).forEach(g=>add(g,0.5)));
  return cnt;
}


/* ---------- 六亲定位 ---------- */
function AD_liuQin(P, dayGan, dmWx){
  const gans = [P.year[0],P.month[0],P.day[0],P.hour[0]];
  const zhis = [P.year[1],P.month[1],P.day[1],P.hour[1]];
  let yin=0, bi=0, shi=0, cai=0;
  gans.forEach(g=>{ const s=shiShen(dayGan,dmWx,g,GAN_WX[g]); if(s==='正印'||s==='偏印')yin++; else if(s==='比肩'||s==='劫财')bi++; else if(s==='食神'||s==='伤官')shi++; else if(s==='正财'||s==='偏财')cai++; });
  zhis.forEach(z=>{ (HIDDEN[z]||[]).forEach(g=>{ const s=shiShen(dayGan,dmWx,g,GAN_WX[g]); if(s==='正印'||s==='偏印')yin++; else if(s==='比肩'||s==='劫财')bi++; else if(s==='食神'||s==='伤官')shi++; else if(s==='正财'||s==='偏财')cai++; }); });
  // H：直观标志 / 位正 / 本气克藏干
  const parentNote = [];
  const yearGanS = shiShen(dayGan, dmWx, P.year[0], GAN_WX[P.year[0]]);
  if (yearGanS==='比肩' || yearGanS==='劫财') parentNote.push('年干见比劫，不利父亲（比劫夺财），父缘偏弱或父亲劳碌。');
  const yinGans = gans.filter(g=>{ const s=shiShen(dayGan,dmWx,g,GAN_WX[g]); return s==='正印'||s==='偏印'; });
  if (yinGans.length>=2) parentNote.push('印星双透，或多母之象（继母、养母缘分）。');
  // 本气克藏干中的印（母）/食伤（子女）→ 该六亲伤损
  const benKeNotes = [];
  [['年',P.year],['月',P.month],['日',P.day],['时',P.hour]].forEach(([role,p])=>{
    const benWx = HIDDEN[p[1]] && HIDDEN[p[1]][0] ? GAN_WX[HIDDEN[p[1]][0]] : '';
    (HIDDEN[p[1]]||[]).slice(1).forEach(g=>{
      const s = shiShen(dayGan, dmWx, g, GAN_WX[g]);
      const gWx = GAN_WX[g];
      if (benWx && WX_KE[benWx]===gWx && (s==='正印'||s==='偏印'||s==='食神'||s==='伤官')){
        benKeNotes.push(role+'柱本气克藏干'+(s==='正印'||s==='偏印'?'印星（母）':'食伤（子女）')+'，该六亲有伤损之象。');
      }
    });
  });
  const childNote = [];
  const shiZhiS = (HIDDEN[P.hour[1]]||[]).map(g=>shiShen(dayGan,dmWx,g,GAN_WX[g]));
  if (shiZhiS.includes('伤官')) childNote.push('时柱见伤官，子女宫有克泄，子女教养宜用心，或子女缘有波折。');
  // 配偶星守夫妻宫（位正）：日支本气为 财/官（配偶星）
  const palaceBenWx = HIDDEN[P.day[1]] && HIDDEN[P.day[1]][0] ? GAN_WX[HIDDEN[P.day[1]][0]] : '';
  const spouseInPalace = (palaceBenWx === WX_KE[dmWx] || palaceBenWx === wuXingControlling(dmWx));
  const r = {};
  r.父母 = '印星（父母）见 '+yin+' 处：'+(yin>=2?'双亲荫护深厚，得长辈力。':yin===1?'有长辈依靠。':'印星偏弱，宜自立、主动孝养双亲。') + (parentNote.length?(' '+parentNote.join('')):'') + (benKeNotes.some(n=>n.indexOf('母')>=0)?(' '+benKeNotes.filter(n=>n.indexOf('母')>=0).join('')):'');
  r.兄弟 = '比劫（兄弟）见 '+bi+' 处：'+(bi>=2?'手足情深、朋辈助力多。':bi===1?'兄弟各立。':'比劫弱，独立性强、少依朋辈。');
  r.子女 = '食伤（子女）见 '+shi+' 处：'+(shi>=2?'子女缘厚、易得子女力。':shi===1?'有子女缘。':'食伤弱，子女宜晚、或用心教养。') + (childNote.length?(' '+childNote.join('')):'') + (benKeNotes.some(n=>n.indexOf('子女')>=0)?(' '+benKeNotes.filter(n=>n.indexOf('子女')>=0).join('')):'');
  r.夫妻 = '财官（夫妻）见 '+cai+' 处：'+(cai>=2?'配偶星明，夫妻缘分深厚。':cai===1?'配偶有根气。':'配偶星偏弱，宜晚婚、多经营。') + (spouseInPalace?'配偶星守夫妻宫（位正），夫妻情笃、配偶得力。':'');
  return r;
}

/* ---------- 流年 × 大运 × 命局 三方交互 ---------- */
function AD_liuNianInteract(P, liuNianGz, curDayunGz){
  const lnZ = liuNianGz[1];
  const targets = [
    ['年支',P.year[1]],['月支',P.month[1]],['日支',P.day[1]],['时支',P.hour[1]]
  ];
  if(curDayunGz) targets.push(['大运支',curDayunGz[1]]);
  const out = [];
  targets.forEach(([name,z])=>{
    const r = AD_relateTwo(lnZ, z);
    if(r) out.push({text:'流年'+lnZ+'与'+name+''+z+''+r+'。', info:AD_relExplain(r)+'（'+AD_LN_PILLAR[name]+'）'});
  });
  return out;
}

/* ---------- 解释字典（纳音 / 神煞 / 地支关系 / 流年宫位） ---------- */
const AD_NAYIN_DESC = {
  '海中金':'潜藏未露之金，性沉静，宜深造蓄力、厚积薄发。',
  '炉中火':'锻造炼器之火，性急进，宜磨砺成材，忌散漫无恒。',
  '大林木':'参天成林之木，性仁厚，宜扎根固本，忌飘摇无根。',
  '路旁土':'承载万物之土，性宽厚，宜稳守务实，忌轻浮易动。',
  '剑锋金':'刚锐锋利之金，性果决，宜施展锋芒，忌妄动招损。',
  '山头火':'高处照远之火，性明朗，宜声名外显，忌虚浮无实。',
  '涧下水':'幽静清澈之水，性柔润，宜涵养智慧，忌污浊混杂。',
  '城头土':'护卫城垣之土，性稳重，宜守成庇护，忌动摇根基。',
  '白蜡金':'饰用柔金，性灵巧，宜精巧营为、修饰仪表。',
  '杨柳木':'随风柔木，性柔韧，宜顺势而为，忌刚折易断。',
  '泉中水':'源泉活水，性清灵，宜生养不息，忌枯竭无源。',
  '屋上土':'覆庇之家土，性安顿，宜安居乐业，忌漂泊无依。',
  '霹雳火':'震雷烈火，性骤变，宜把握时机一击，忌轻躁妄动。',
  '松柏木':'耐寒长青之木，性坚贞，宜操守不改，忌随波逐流。',
  '长流水':'奔流不息之水，性通达，宜顺势远行，忌停滞淤塞。',
  '沙中金':'埋沙藏金，性内秀，宜淘炼方显，忌埋没无闻。',
  '山下火':'霞映山火，性温和，宜文采外溢，忌刻意炫耀。',
  '平地木':'广泽之木，性敦厚，宜普惠包容，忌偏私狭隘。',
  '壁上土':'装饰之土，性粉饰，宜修饰门面，忌虚饰无实。',
  '金箔金':'贴金薄饰，性华美，宜点缀生辉，忌浮夸无根。',
  '覆灯火':'夜照之灯，性幽明，宜指引暗途，忌昏昧无光。',
  '天河水':'天降甘霖，性润泽，宜普施恩惠，忌泛滥无归。',
  '大驿土':'通途之土，性通达，宜交际往来、四方得力。',
  '钗钏金':'首饰之金，性华贵，宜妆点受赏、为人赏识。',
  '桑柘木':'养蚕之木，性柔润，宜养育手艺，忌折损无成。',
  '大溪水':'溪壑奔涌，性活泼，宜奔放进取，忌泛滥无制。',
  '沙中土':'积沙成洲，性聚散，宜积聚渐成，忌涣散无收。',
  '天上火':'太阳之火，性光明，宜普照显达，忌亢旱无润。',
  '石榴木':'多子之木，性繁盛，宜开花结果、人丁兴旺。',
  '大海水':'浩瀚之水，性包容，宜胸襟开阔，忌泛滥无制。'
};
const AD_NAYIN_GONG = {'年柱':'祖上根基·少年运','月柱':'父母门庭·青年运','日柱':'自身夫妻·中年运','时柱':'子女晚景·老运'};
const AD_SHENSHA_DESC = {
  '天乙贵人':{typ:'吉',typCls:'good',desc:'命中至贵，遇难呈祥，得人扶助。'},
  '驿马':{typ:'中',typCls:'mid',desc:'主奔走变动、远行迁徙，宜动中求成。'},
  '桃花':{typ:'中',typCls:'mid',desc:'主情缘人缘，亦主风流，过旺则易惹纠纷。'},
  '华盖':{typ:'中',typCls:'mid',desc:'主聪颖孤高、艺术宗教缘，性喜独处。'},
  '灾煞':{typ:'凶',typCls:'bad',desc:'主意外灾殃，宜谨慎防灾。'},
  '官符':{typ:'凶',typCls:'bad',desc:'主口舌官非、争讼，宜守法避争。'},
  '月德':{typ:'吉',typCls:'good',desc:'月中德神，化凶为吉，性仁厚。'},
  '天德':{typ:'吉',typCls:'good',desc:'至高福德，解厄消灾，大吉之神。'},
  '孤辰':{typ:'凶',typCls:'bad',desc:'主孤寡离群，六亲缘薄。'},
  '寡宿':{typ:'凶',typCls:'bad',desc:'主孤寂少伴，女命尤验。'},
  '文昌':{typ:'吉',typCls:'good',desc:'主文采学识、功名显达，利考试。'},
  '羊刃':{typ:'凶',typCls:'bad',desc:'刚烈刑伤之神，主血光争斗，制化为权。'},
  '阴刃':{typ:'凶',typCls:'bad',desc:'阴干羊刃，性烈而隐，主血光暗伤，宜制化。'},
  '禄神':{typ:'吉',typCls:'good',desc:'主爵禄安稳、衣食丰足。'},
  '亡神':{typ:'凶',typCls:'bad',desc:'主心神不宁、暗耗，宜静守。'},
  '劫煞':{typ:'凶',typCls:'bad',desc:'主劫夺损耗、突发变故。'},
  '将星':{typ:'吉',typCls:'good',desc:'主权威统领、武职或管理之才。'},
  '红鸾':{typ:'吉',typCls:'good',desc:'主姻缘喜庆、婚恋机缘。'},
  '天喜':{typ:'吉',typCls:'good',desc:'主喜事临门、添丁纳福。'}
};
function AD_relExplain(type){
  if(type.indexOf('三合')===0){ const el=type.slice(2); return '三合'+el+'局，三气相投而生助，主贵人扶持、助力汇聚，成事有凭。'; }
  if(type.indexOf('三会')===0){ const el=type.slice(2); return '三会'+el+'方局，气势专一而盛，主志同道合、阵营分明、力量凝聚。'; }
  const MAP = {
    '相冲':'冲者动也，主变动、迁居、远行、冲突。喜用受冲则损，忌神受冲则散——吉凶在动静之间。',
    '六合':'合者和也，主人缘和合、合作顺遂、姻缘暗动；亦主牵绊依恋，事宜借力而成。',
    '相刑':'刑者伤也，主口舌、刑伤、官非、内心纠结，宜忍让调和。',
    '自刑':'自刑，主自我纠结、内耗钻牛角，宜放宽心境。',
    '相害':'害者损也，主暗中小人、背后妨害、亲情有隙，宜明察防微。',
    '相破':'破者耗也，主破财破损、情谊断裂、暗中消耗，宜保守。',
    '伏吟':'伏吟，主事象重复、迟滞、旧事重提，宜守成不宜冒进。'
  };
  return MAP[type] || '';
}
const AD_LN_PILLAR = {'年支':'太岁/祖基·自身根基','月支':'父母兄弟宫','日支':'夫妻宫/自身配偶','时支':'子女宫/晚辈','大运支':'当前大运'};

/* ---------- 汇总入口 ---------- */
function AD_computeAdvanced(P, dayGan, dmWx, xiWxArr, jiWxArr, monthZhi, dayZhi, yearZhi, curDayunGz, liuNianGz, strong, score, wx, pattern, congType, mid, anDayKey){
  const pillars = [
    {role:'年柱', gz:P.year}, {role:'月柱', gz:P.month}, {role:'日柱', gz:P.day}, {role:'时柱', gz:P.hour}
  ];
  // 按神煞名归集其「所临之字」（同一神煞可能临不同字，如天乙贵人可同时临丑、未）
  const byName = {};
  pillars.forEach(p=>{
    const gz=p.gz, gan=gz[0], zhi=gz[1];
    AD_shenshaFull(zhi, gan, dayGan, dayZhi, monthZhi, yearZhi).forEach(it=>{
      (byName[it.n] = byName[it.n] || []).push(it.a);
    });
  });
  const zhis = [P.year[1],P.month[1],P.day[1],P.hour[1]];
  const monthBenQi = HIDDEN[monthZhi] ? HIDDEN[monthZhi][0] : '';
  const geJuName = monthBenQi ? shiShen(dayGan, dmWx, monthBenQi, GAN_WX[monthBenQi]) : '';
  const tiaoWx = (function(){ const cold=['亥','子','丑']; const hot=['巳','午','未']; if(cold.includes(monthZhi))return 'fire'; if(hot.includes(monthZhi))return 'water'; return ''; })();
  const liuQinObj = AD_liuQin(P, dayGan, dmWx);
  const relRaw = AD_relateAll(zhis);
  const lnDetail = AD_liuNianInteract(P, liuNianGz, curDayunGz);
  return {

    nayinItems: [
      {role:'年柱', name:AD_NAYIN[P.year], gong:AD_NAYIN_GONG['年柱'], desc:AD_NAYIN_DESC[AD_NAYIN[P.year]]},
      {role:'月柱', name:AD_NAYIN[P.month], gong:AD_NAYIN_GONG['月柱'], desc:AD_NAYIN_DESC[AD_NAYIN[P.month]]},
      {role:'日柱', name:AD_NAYIN[P.day], gong:AD_NAYIN_GONG['日柱'], desc:AD_NAYIN_DESC[AD_NAYIN[P.day]]},
      {role:'时柱', name:AD_NAYIN[P.hour], gong:AD_NAYIN_GONG['时柱'], desc:AD_NAYIN_DESC[AD_NAYIN[P.hour]]}
    ],

    shenShaAll: Object.keys(byName),
    // 神煞终极吉凶：本性(吉/中/凶) × 所临之字喜忌。
    // 吉神煞临忌字→降级「中」(吉力微弱)；临喜字→喜上加喜(仍吉)。
    // 凶神煞临喜字→降级「中」(凶力微弱)；临忌字→仍凶。
    // 中神煞及闲字(非喜非忌)保持本性不动。
    shenShaDesc: Object.keys(byName).map(name=>{
      const anchors = byName[name];
      const base = name.replace(/\([年月日]\)$/,'');
      const meta = AD_SHENSHA_DESC[base] || {typ:'中',typCls:'mid',desc:''};
      const distinct = anchors.filter((v,i,a)=>a.indexOf(v)===i);
      return distinct.map(ach=>{
        const fav = AD_shaFav(ach, xiWxArr, jiWxArr);
        let typ = meta.typ, typCls = meta.typCls, note = '';
        if (typ==='吉'){
          if (fav==='ji'){ typ='中'; typCls='mid'; note='（临'+ach+'为忌神，吉力微弱）'; }
          else if (fav==='xi'){ note='（临'+ach+'为喜用，喜上加喜）'; }
        } else if (typ==='凶'){
          if (fav==='xi'){ typ='中'; typCls='mid'; note='（临'+ach+'为喜用，凶力微弱）'; }
          else if (fav==='ji'){ note='（临'+ach+'为忌神，凶力显）'; }
        }
        const dispName = distinct.length>1 ? (name+'（'+ach+'）') : name;
        return { name: dispName, typ: typ, typCls: typCls, desc: meta.desc + note };
      });
    }).reduce((a,b)=>a.concat(b), []),

    relItems: relRaw.map(x=>({text:x.text, info:AD_relExplain(x.type)})),
    geJuJing: AD_geJuJing(P, dayGan, dmWx, monthZhi, monthBenQi, geJuName, score, strong, pattern, mid),
    combos: AD_combos(P, dayGan, dmWx, jiWxArr, xiWxArr, monthZhi),
    yongShen: AD_yongShen(dmWx, strong, xiWxArr, jiWxArr, tiaoWx, wx, pattern, congType, mid, anDayKey),
    liuQin: liuQinObj,
    liuQinList: [liuQinObj.父母, liuQinObj.兄弟, liuQinObj.子女, liuQinObj.夫妻],

    liuNianDetail: lnDetail
  };
}

function wxTag(wx){ return `<span class="wx-${wx}">${WX_NAME[wx]}</span>`; }

// 十二时辰下拉：value=时辰序 0-11（子…亥），标签含时间段，便于直观选择
const SHICHEN_RANGES = ['23–1','1–3','3–5','5–7','7–9','9–11','11–13','13–15','15–17','17–19','19–21','21–23'];
function fillShichenSelect(sel, defIdx){
  if (!sel) return;
  sel.innerHTML = '';
  for (let i=0;i<12;i++){
    const o=document.createElement('option');
    o.value=i; o.textContent = BRANCHES[i]+'时 '+SHICHEN_RANGES[i]+'点';
    sel.appendChild(o);
  }
  if (defIdx!=null && defIdx>=0 && defIdx<12) sel.value = defIdx;
}
// 从 date input 的 value（YYYY-MM-DD）拆出 年/月/日
function parseDateInput(id){
  const el = document.getElementById(id);
  if (!el || !el.value) return null;
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(el.value);
  if (!m) return null;
  const y = +m[1], mo = +m[2], d = +m[3];
  if (y < 100 || mo < 1 || mo > 12 || d < 1 || d > 31) return null;
  return { y, m: mo, d };
}
function formatDateInput(y, m, d){
  const p = n => String(n).padStart(2,'0');
  return `${y}-${p(m)}-${p(d)}`;
}
// 时辰序 → 代表时:分（保证 computeBazi 内 hourBranch 反推回同一时辰）
function shichenToHM(sc){ return [ (sc===0 ? 0 : sc*2) % 24, 0 ]; }

function initBaziForm(){
  fillShichenSelect(document.getElementById('bazi-shichen'), 6);   // 默认午时
  fillShichenSelect(document.getElementById('lunar-shichen'), 6);
  updateShichenDisp('bazi-shichen');
  updateShichenDisp('lunar-shichen');

  const caltypeRow = document.getElementById('bazi-caltype-row');
  const solarRow = document.getElementById('bazi-daterow');
  const lunarRow = document.getElementById('bazi-lunar-row');
  const solarShi = document.getElementById('bazi-shichen');
  const lunarShi = document.getElementById('lunar-shichen');
  const solarDate = document.getElementById('solar-date');
  const lunarDate = document.getElementById('lunar-date');
  // 默认出生时间由 Birth 单一数据源初始化（2026-07-02 午时），并同步隐藏镜像与显示标签
  Birth._syncDOM();
  caltypeRow.querySelectorAll('.seg[data-caltype]').forEach(btn=>{
    btn.onclick = ()=>{
      caltypeRow.querySelectorAll('.seg[data-caltype]').forEach(x=>x.classList.remove('on'));
      btn.classList.add('on');
      const rt = document.getElementById('reverse-toggle');
      if (rt){ rt.classList.remove('rev-on'); rt.setAttribute('aria-expanded','false'); }
      const rmodal = document.getElementById('reverse-modal');
      if (rmodal) rmodal.hidden = true;
      if (btn.dataset.caltype === 'lunar'){
        solarRow.hidden = true; lunarRow.hidden = false;
      } else {
        solarRow.hidden = false; lunarRow.hidden = true;
      }
      document.getElementById('bazi-card').classList.add('show');
      const calType = btn.dataset.caltype;
      // 切历法同时直接弹出日期滚轮（用户预期：点“新历/农历”即出日期输入卡）；
      // Birth 单一数据源自动同步双历镜像与命盘（无需手动互写）
      Birth.set({ calType });
      dwOpen({ calType });
    };
  });
  // 出生信息各输入变化 → 同步下方日期标签
  ['solar-date','bazi-shichen','lunar-date','lunar-shichen','lunar-leap'].forEach(id=>{
    const el = document.getElementById(id); if (el) el.addEventListener('change', updateBaziDateLabel);
  });
  document.querySelectorAll('input[name=gender]').forEach(r=> r.addEventListener('change', ()=>{ updateBaziDateLabel(); applyMainToSheet(); saveGender(document.querySelector('input[name=gender]:checked')?.value); }));
  const tsEl = document.getElementById('bazi-truesolar'); if (tsEl) tsEl.addEventListener('change', applyMainToSheet);
  const ziEl = document.getElementById('bazi-zi'); if (ziEl) ziEl.addEventListener('change', applyMainToSheet);
  // 年月日滚动选择器：显示按钮 → 打开滚轮
  const solarDisp = document.getElementById('solar-date-disp');
  const lunarDisp = document.getElementById('lunar-date-disp');
  if (solarDisp) solarDisp.addEventListener('click', ()=>dwOpen({ calType:'solar' }));
  if (lunarDisp) lunarDisp.addEventListener('click', ()=>dwOpen({ calType:'lunar' }));
  const solarShiDisp = document.getElementById('bazi-shichen-disp');
  const lunarShiDisp = document.getElementById('lunar-shichen-disp');
  const curCal = ()=>{ const on = document.querySelector('#bazi-caltype-row .seg.on'); return on ? on.dataset.caltype : 'solar'; };
  if (solarShiDisp) solarShiDisp.addEventListener('click', ()=>dwOpen({ calType:curCal() }));
  if (lunarShiDisp) lunarShiDisp.addEventListener('click', ()=>dwOpen({ calType:curCal() }));
  refreshDateDisps();
  // 历史记录：绑定「历史记录」切片展开/收起 + 清空
  const histBtn = document.getElementById('history-toggle');
  if (histBtn) histBtn.onclick = ()=> toggleHistory();
  const histClear = document.getElementById('history-clear');
  if (histClear) histClear.onclick = async ()=>{
    if (await showAppConfirm('确定清空全部排盘记录？')){ clearHistory(); renderHistoryList(); }
  };
  initAppConfirm();
}

/* ===================== 排盘历史记录 =====================
   每次成功排盘后写入 localStorage（clawBaziHistory_v1），同四柱+性别去重，最多 30 条。
   八字页「历史记录」切片点击展开列表，点某项回填并重排。 */
const HISTORY_KEY = 'clawBaziHistory_v1';
const HISTORY_MAX = 30;
function loadHistory(){
  try { const a = JSON.parse(localStorage.getItem(HISTORY_KEY) || '[]'); return Array.isArray(a) ? a : []; }
  catch(e){ return []; }
}
function saveHistory(arr){
  try { localStorage.setItem(HISTORY_KEY, JSON.stringify(arr.slice(0, HISTORY_MAX))); } catch(e){}
}
function pushHistory(item){
  const arr = loadHistory();
  const key = item.pillars + '|' + item.gender;
  const idx = arr.findIndex(h => (h.pillars + '|' + h.gender) === key);
  if (idx >= 0){ arr[idx] = Object.assign({}, arr[idx], item); }   // 同盘更新时间戳，不新增
  else { arr.unshift(item); }
  if (arr.length > HISTORY_MAX) arr.length = HISTORY_MAX;
  saveHistory(arr);
}
function clearHistory(){ saveHistory([]); }

/* 仅在用户显式确认排盘（滚轮确认 / 反推选中 / 历史项回填）后写入历史；
   自动渲染（切历法、Birth.subscribe、默认排一卦）不应记录。 */
let _baziRecordHistory = false;
/* applyHistory 程序化回填时不让 Birth.subscribe 的自动渲染抢跑（避免用旧历法段渲染/误 alert）；
   界面态就绪后由 applyHistory 显式 renderBazi 一次。 */
let _suppressBirthRender = false;

/* 通用确认弹层（替代原生 confirm） */
let _appConfirmResolve = null;
function showAppConfirm(msg){
  return new Promise((resolve)=>{
    _appConfirmResolve = resolve;
    const overlay = document.getElementById('app-confirm-overlay');
    const msgEl = document.getElementById('app-confirm-msg');
    if (msgEl) msgEl.textContent = msg;
    if (overlay) overlay.hidden = false;
  });
}
function hideAppConfirm(result){
  const overlay = document.getElementById('app-confirm-overlay');
  if (overlay) overlay.hidden = true;
  if (_appConfirmResolve){ _appConfirmResolve(result); _appConfirmResolve = null; }
}
function initAppConfirm(){
  const cancel = document.getElementById('app-confirm-cancel');
  const ok = document.getElementById('app-confirm-ok');
  if (cancel) cancel.onclick = ()=> hideAppConfirm(false);
  if (ok) ok.onclick = ()=> hideAppConfirm(true);
}

function renderHistoryList(){
  const list = document.getElementById('history-list');
  const empty = document.getElementById('history-empty');
  if (!list) return;
  const arr = loadHistory();
  list.innerHTML = '';
  if (!arr.length){ if (empty) empty.hidden = false; return; }
  if (empty) empty.hidden = true;
  arr.forEach((h)=>{
    const el = document.createElement('div');
    el.className = 'hist-item';
    const genderLabel = (h.gender === 'female') ? '坤造' : '乾造';
    const calLabel = (h.calType === 'lunar') ? '农历' : '新历';
    el.innerHTML = `<div class="hist-pillars">${h.pillars}</div>` +
      `<div class="hist-meta">${genderLabel} · ${calLabel} ${h.solarLabel || ''}</div>`;
    el.onclick = ()=> applyHistory(h);
    list.appendChild(el);
  });
}
function toggleHistory(){
  const panel = document.getElementById('history-panel');
  const btn = document.getElementById('history-toggle');
  if (!panel) return;
  const show = panel.hidden;
  panel.hidden = !show;
  if (btn){ btn.classList.toggle('on', show); btn.setAttribute('aria-expanded', String(show)); }
  if (show) renderHistoryList();
}
function applyHistory(h){
  if (!h) return;
  // 兼容旧 schema：优先 h.solar，其次 h.date（数组），再退 h.y/h.m/h.d；都没有则尝试从 pillars 取不出公历，报错提示
  let solar = (Array.isArray(h.solar) && h.solar.length >= 3) ? h.solar
            : (Array.isArray(h.date) && h.date.length >= 3) ? h.date
            : (typeof h.y === 'number' && typeof h.m === 'number' && typeof h.d === 'number') ? [h.y, h.m, h.d]
            : null;
  if (!solar || !solar[0] || !solar[1] || !solar[2]){
    console.error('历史记录缺少有效公历日期，无法回填', h);
    if (typeof alert === 'function') alert('该历史记录数据不完整，无法重新排盘');
    return;
  }
  const y = +solar[0], m = +solar[1], d = +solar[2];
  if (isNaN(y) || isNaN(m) || isNaN(d) || y < 100 || m < 1 || m > 12 || d < 1 || d > 31){
    console.error('历史记录日期非法', h);
    if (typeof alert === 'function') alert('该历史记录日期非法，无法重新排盘');
    return;
  }
  try {
    // 1) 先把界面态设好（性别 / 历法段切新历 / 日期行显示），确保后续渲染用正确上下文
    const gR = document.querySelector('input[name="gender"][value="' + (h.gender === 'female' ? 'female' : 'male') + '"]');
    if (gR) gR.checked = true;
    const row = document.getElementById('bazi-caltype-row');
    if (row){
      row.querySelectorAll('.seg[data-caltype]').forEach(x=>x.classList.remove('on'));
      const solarSeg = row.querySelector('.seg[data-caltype="solar"]');
      if (solarSeg) solarSeg.classList.add('on');
    }
    const solarRow = document.getElementById('bazi-daterow');
    const lunarRow = document.getElementById('bazi-lunar-row');
    if (solarRow) solarRow.hidden = false;
    if (lunarRow) lunarRow.hidden = true;
    // 2) 抑制订阅者自动渲染，等界面态就绪后一次性渲染（避免用旧历法段渲染 / 农历分支误 alert）
    _suppressBirthRender = true;
    if (typeof Birth !== 'undefined' && Birth){
      _baziRecordHistory = true;
      Birth.set({ calType:'solar', y, m, d, leap:false, shichen: (h.shichen || 0) });
    }
  } catch(e){
    _suppressBirthRender = false;
    console.error('applyHistory 回填失败', e);
    if (typeof alert === 'function') alert('回填出生时间失败：' + (e && e.message ? e.message : e));
    return;
  } finally {
    _suppressBirthRender = false;
  }
  // 3) 关闭面板
  const panel = document.getElementById('history-panel');
  if (panel) panel.hidden = true;
  const btn = document.getElementById('history-toggle');
  if (btn){ btn.classList.remove('on'); btn.setAttribute('aria-expanded','false'); }
  // 4) 界面态已就绪 → 用新历上下文一次性渲染
  if (typeof renderBazi === 'function') renderBazi();
}

/* ============ 统一出生时间数据源 Birth（单一真相） ============
   八字 / 起名 / 数理 三页共用同一份出生时间。任意一页确认滚轮后写回 Birth，
   自动同步隐藏 DOM 镜像（#solar-date / #lunar-date / #lunar-leap / #bazi-shichen / #lunar-shichen）
   并通知所有订阅者刷新，彻底取代 DP_lastPicked / window.nameBirthSel 等散落状态。 */
const Birth = {
  _v: { calType:'solar', y:2026, m:7, d:2, leap:false, shichen:6 },
  _subs: [],
  _init(){
    try {
      const s = localStorage.getItem('clawBirth');
      if (s){ const o = JSON.parse(s); if (o && o.y >= 1900) Object.assign(this._v, o); }
    } catch(e){}
  },
  get(){ return Object.assign({}, this._v); },
  // 取农历表示：_v 内 y/m/d 恒为公历真值（dwConfirm 无论 solar/lunar 模式都存公历，
  // leap 为农历闰月标记），故农历表示始终由 solar→lunar 换算得到，
  // 绝不可直接用 _v.y/m/d 当农历值（否则在“数理/起名用公历输完后切八字农历”会算错 → “农历日期不存在”）
  lunar(){
    const cv = window.calendar.solar2lunar(this._v.y, this._v.m, this._v.d);
    if (!cv || cv === -1) return null;
    return { ly:cv.lYear, lm:cv.lMonth, ld:cv.lDay, leap:cv.isLeap };
  },
  set(partial){
    Object.assign(this._v, partial);
    try { localStorage.setItem('clawBirth', JSON.stringify(this._v)); } catch(e){}
    this._syncDOM();
    this._notify();
  },
  _syncDOM(){
    const v = this._v;
    const solarEl = document.getElementById('solar-date');
    const lunarEl = document.getElementById('lunar-date');
    const lunarLeap = document.getElementById('lunar-leap');
    const baziShi = document.getElementById('bazi-shichen');
    const lunarShi = document.getElementById('lunar-shichen');
    if (solarEl) solarEl.value = formatDateInput(v.y, v.m, v.d);
    const lv = this.lunar();
    if (lunarEl && lv) lunarEl.value = formatDateInput(lv.ly, lv.lm, lv.ld);
    if (lunarLeap) lunarLeap.checked = (v.calType === 'lunar') ? !!v.leap : false;
    if (baziShi) baziShi.value = String(v.shichen);
    if (lunarShi) lunarShi.value = String(v.shichen);
    if (typeof updateDateDisp === 'function'){ updateDateDisp('solar'); updateDateDisp('lunar'); }
    if (typeof updateShichenDisp === 'function'){ updateShichenDisp('bazi-shichen'); updateShichenDisp('lunar-shichen'); }
  },
  _notify(){ this._subs.forEach(fn=>{ try { fn(this.get()); } catch(e){ console.error(e); } }); },
  subscribe(fn){ this._subs.push(fn); }
};
Birth._init();

/* ============ 统一日期/时辰滚轮 DateWheel（年·月·日·时辰，跨页共用） ============ */
const DW = {
  mask:null, sheet:null, title:null, leapWrap:null, leapChk:null,
  inner:{year:null, month:null, day:null, hour:null},
  colEl:{year:null, month:null, day:null, hour:null},
  values:{year:[], month:[], day:[], hour:[]},
  ITEM_H:46, VISIBLE:5,
  sel:{y:2026, m:7, d:2, leap:false, shichen:6},
  calType:'solar',
  onConfirm:null,
  ready:false, _t:{}
};

function dwEnsureInit(){
  if (DW.ready) return;
  DW.mask = document.getElementById('date-picker-mask');
  DW.sheet = document.getElementById('date-picker-sheet');
  DW.title = document.getElementById('dp-title');
  DW.leapWrap = document.getElementById('dp-leap-wrap');
  DW.leapChk = document.getElementById('dp-leap');
  DW.inner.year = document.getElementById('dp-year-inner');
  DW.inner.month = document.getElementById('dp-month-inner');
  DW.inner.day = document.getElementById('dp-day-inner');
  DW.inner.hour = document.getElementById('dp-hour-inner');
  ['year','month','day','hour'].forEach(u=>{
    DW.colEl[u] = DW.inner[u].parentElement;
    DW.colEl[u].addEventListener('scroll', ()=>dwOnScroll(u), {passive:true});
  });
  document.getElementById('dp-cancel').onclick = dwClose;
  document.getElementById('dp-confirm').onclick = dwConfirm;
  DW.leapChk.addEventListener('change', ()=>{ DW.sel.leap = DW.leapChk.checked; dwRebuildDay(); dwApplySel(); });
  DW.mask.addEventListener('click', e=>{ if (e.target===DW.mask) dwClose(); });
  // 弹层内的出生信息控件（男/女/真太阳时/早夜子时/经度）↔ 主页面 双向同步
  DW.sheet.querySelectorAll('input[name="dp-gender"]').forEach(r=> r.addEventListener('change', applySheetToMain));
  const dpTs = document.getElementById('dp-truesolar'); if (dpTs) dpTs.addEventListener('change', applySheetToMain);
  const dpZi = document.getElementById('dp-zi'); if (dpZi) dpZi.addEventListener('change', applySheetToMain);
  // 出生地下拉框的打开逻辑改由 initLngPicker 内就近定位打开（见 initLngPicker），此处不再委托给八字页控件
  DW.ready = true;
}

// 打开统一滚轮：calType 决定年/月/日按公历还是农历显示；时辰列始终显示
function dwOpen(opts){
  dwEnsureInit();
  opts = opts || {};
  DW.calType = (opts.calType === 'lunar') ? 'lunar' : 'solar';
  DW.onConfirm = opts.onConfirm || null;
  const v = Birth.get();
  if (DW.calType === 'lunar'){
    const lv = Birth.lunar();
    if (lv){ DW.sel.y = lv.ly; DW.sel.m = lv.lm; DW.sel.d = lv.ld; DW.sel.leap = lv.leap; }
    else { DW.calType = 'solar'; }
  }
  if (DW.calType === 'solar'){
    DW.sel.y = v.y; DW.sel.m = v.m; DW.sel.d = v.d; DW.sel.leap = false;
  }
  DW.sel.shichen = v.shichen;
  DW.title.textContent = (DW.calType==='lunar' ? '农历出生时间' : '公历出生时间') + '（年 · 月 · 日 · 时辰）';
  DW.leapWrap.hidden = (DW.calType !== 'lunar');
  DW.values.year = [];
  for (let y=1900; y<=2100; y++) DW.values.year.push(y);
  dwRender('year', val=>`${val}年`);
  DW.values.month = [];
  for (let m=1; m<=12; m++) DW.values.month.push(m);
  dwRender('month', val=>(DW.calType==='lunar' ? (LUNAR_MONTHS[val-1] || (val+'月')) : (val+'月')));
  if (DW.calType==='lunar'){
    const lm = window.calendar.leapMonth(DW.sel.y);
    const hasLeap = (lm === DW.sel.m);
    DW.leapChk.disabled = !hasLeap;
    DW.leapChk.checked = hasLeap ? DW.sel.leap : false;
    DW.sel.leap = DW.leapChk.checked;
  }
  DW.values.hour = [];
  for (let i=0; i<12; i++) DW.values.hour.push(i);
  dwRender('hour', val=>`${BRANCHES[val]}时${SHICHEN_RANGES[val]}点`);
  dwRebuildDay();
  dwApplySel();
  DW.mask.hidden = false;
  document.body.classList.add('dp-locked');
  applyMainToSheet();          // 打开时把主页面性别/选项/经度同步进弹层
  requestAnimationFrame(()=>{ dwApplySel(); positionSheetNearInput(); });
}

function dwRender(unit, fmt){
  const vals = DW.values[unit];
  let html = '';
  vals.forEach(v=>{ html += `<div class="dp-item">${fmt(v)}</div>`; });
  DW.inner[unit].innerHTML = html;
}

function dwRebuildDay(){
  const calType = DW.calType;
  let max;
  if (calType==='lunar'){
    max = DW.sel.leap ? window.calendar.leapDays(DW.sel.y) : window.calendar.monthDays(DW.sel.y, DW.sel.m);
    if (!(max > 0)) max = 30;
  } else {
    max = new Date(DW.sel.y, DW.sel.m, 0).getDate();
  }
  DW.values.day = [];
  for (let d=1; d<=max; d++) DW.values.day.push(d);
  dwRender('day', val=> val + '日');
}

function dwUpdateLeapAvail(){
  if (DW.calType !== 'lunar') return;
  const lm = window.calendar.leapMonth(DW.sel.y);
  const hasLeap = (lm === DW.sel.m);
  DW.leapChk.disabled = !hasLeap;
  if (!hasLeap){ DW.leapChk.checked = false; DW.sel.leap = false; }
}

function dwClampDay(){
  if (DW.sel.d > DW.values.day.length) DW.sel.d = DW.values.day[DW.values.day.length - 1] || 1;
  if (DW.sel.d < 1) DW.sel.d = 1;
}

function dwCenterOn(unit, idx){
  const col = DW.colEl[unit];
  const items = DW.inner[unit].querySelectorAll('.dp-item');
  if (idx < 0 || idx >= items.length) return;
  col.scrollTop = idx * DW.ITEM_H;
}

function dwApplySel(){
  dwClampDay();
  ['year','month','day','hour'].forEach(u=>{
    const key = u==='year' ? 'y' : (u==='month' ? 'm' : (u==='day' ? 'd' : 'shichen'));
    let idx = DW.values[u].indexOf(DW.sel[key]);
    if (idx < 0) idx = Math.max(0, DW.values[u].length - 1);
    const items = DW.inner[u].querySelectorAll('.dp-item');
    items.forEach((el,i)=> el.classList.toggle('on', i===idx));
    dwCenterOn(u, idx);
  });
}

function dwOnScroll(unit){
  clearTimeout(DW._t[unit]);
  DW._t[unit] = setTimeout(()=>dwSettle(unit), 100);
}

function dwSettle(unit){
  const col = DW.colEl[unit];
  const colRect = col.getBoundingClientRect();
  const centerY = colRect.top + colRect.height/2;
  const items = DW.inner[unit].querySelectorAll('.dp-item');
  let best = -1, bestDist = Infinity;
  items.forEach((el,i)=>{
    const r = el.getBoundingClientRect();
    const c = r.top + r.height/2;
    const dist = Math.abs(c - centerY);
    if (dist < bestDist){ bestDist = dist; best = i; }
  });
  if (best < 0) return;
  const val = DW.values[unit][best];
  if (val == null) return;
  if (unit==='year'){ DW.sel.y = val; dwUpdateLeapAvail(); dwRebuildDay(); }
  else if (unit==='month'){ DW.sel.m = val; dwUpdateLeapAvail(); dwRebuildDay(); }
  else if (unit==='day'){ DW.sel.d = val; }
  else { DW.sel.shichen = val; }
  dwApplySel();
}

function dwConfirm(){
  let y, m, d, leap = DW.sel.leap, shichen = DW.sel.shichen;
  if (DW.calType==='lunar'){
    const cv = window.calendar.lunar2solar(DW.sel.y, DW.sel.m, DW.sel.d, leap);
    if (!cv || cv === -1){ alert('该农历日期不存在，请重新选择'); return; }
    y = cv.cYear; m = cv.cMonth; d = cv.cDay;
  } else {
    y = DW.sel.y; m = DW.sel.m; d = DW.sel.d;
    const max = new Date(y, m, 0).getDate();
    if (!(d > 0 && d <= max)){ alert('该日期不存在，请重新选择'); return; }
  }
  _baziRecordHistory = true;
  Birth.set({ calType:DW.calType, y, m, d, leap, shichen });
  dwClose();
  if (DW.onConfirm) DW.onConfirm(Birth.get());
}

function dwClose(){
  DW.mask.hidden = true;
  document.body.classList.remove('dp-locked');
}

// 主页面 → 弹层：把性别/真太阳时/早夜子时/经度写进弹层控件
function applyMainToSheet(){
  const active = document.querySelector('.panel.active');
  let gval = 'male';
  if (active && active.id === 'name') gval = nameGender || 'male';
  else { const m = document.querySelector('input[name="gender"]:checked'); gval = m ? m.value : 'male'; }
  const s = document.querySelector('input[name="dp-gender"][value="' + gval + '"]');
  if (s) s.checked = true;
  const ts = document.getElementById('dp-truesolar'); if (ts) ts.checked = !!document.getElementById('bazi-truesolar').checked;
  const zi = document.getElementById('dp-zi'); if (zi) zi.checked = !!document.getElementById('bazi-zi').checked;
  const ld = document.getElementById('dp-lng-disp'); if (ld) ld.textContent = document.getElementById('bazi-longitude-disp').textContent;
}

// 弹层 → 主页面：弹层控件改动实时写回主页面（renderBazi 确认时直接读主页面控件）
function applySheetToMain(){
  const s = document.querySelector('input[name="dp-gender"]:checked');
  if (s){
    const active = document.querySelector('.panel.active');
    if (active && active.id === 'name'){
      nameGender = s.value;
      saveGender(s.value);
      // 已生成过候选名字时，滚轮内切换性别自动按新性别重新生成（男女字库不同，避免“切了性别名字没变”）
      const box = document.getElementById('name-candidates');
      if (box && box.querySelector('.cand-card')){ try { doGenerate(); } catch(e){} }
    } else {
      const m = document.querySelector('input[name="gender"][value="' + s.value + '"]'); if (m) m.checked = true;
      saveGender(s.value);
    }
  }
  document.getElementById('bazi-truesolar').checked = !!document.getElementById('dp-truesolar').checked;
  document.getElementById('bazi-zi').checked = !!document.getElementById('dp-zi').checked;
  if (typeof updateBaziDateLabel === 'function') updateBaziDateLabel();
}

// 弹层跟随日期输入框位置（不再是全屏底部弹层）
function getSheetAnchor(){
  // 时间滚轮跟随触发元素：八字页→“新历/农历”切片；数理页→出生日期按钮；起名页→出生时间按钮
  const active = document.querySelector('.panel.active');
  let el = null;
  if (active){
    if (active.id === 'bazi') el = document.getElementById('bazi-caltype-row');
    else if (active.id === 'math') el = document.getElementById('num-birth-btn');
    else if (active.id === 'name') el = document.getElementById('name-birth-btn');
  }
  if (!el || el.offsetParent === null) el = document.getElementById('bazi-daterow') || document.querySelector('.dt-date-disp');
  return el;
}
function positionSheetNearInput(){
  const sheet = DW.sheet; if (!sheet) return;
  const anchor = getSheetAnchor();
  sheet.style.maxHeight = '';
  let left, top;
  const sw = sheet.offsetWidth || 320, sh = sheet.offsetHeight || 420;
  const vw = window.innerWidth, vh = window.innerHeight;
  if (!anchor || anchor.getBoundingClientRect().width === 0){
    // 无有效锚点（如隐藏）时居中兜底
    left = (vw - sw) / 2; top = (vh - sh) / 2;
  } else {
    const r = anchor.getBoundingClientRect();
    left = r.left;
    if (left + sw > vw - 8) left = Math.max(8, vw - sw - 8);
    if (left < 8) left = 8;
    // 时间滚轮卡片上边与触发元素下边平齐（仅留 4px 视觉呼吸）
    top = r.bottom + 4;
    if (top + sh > vh - 8){ top = r.top - 8 - sh; if (top < 8) top = 8; }
  }
  sheet.style.left = left + 'px';
  sheet.style.top = top + 'px';
  sheet.style.maxHeight = Math.min(sh, vh - 16) + 'px';
}

/* 隐藏 select 的当前值刷新到对应显示按钮 */
function updateShichenDisp(targetId){
  const sel = document.getElementById(targetId);
  const disp = document.getElementById(targetId + '-disp');
  if (!sel || !disp) return;
  let idx = +sel.value; if (isNaN(idx) || idx < 0 || idx > 11) idx = 6;
  disp.textContent = BRANCHES[idx] + '时 ' + SHICHEN_RANGES[idx] + '点';
}
function updateDateDisp(calType){
  const btn = document.getElementById((calType==='lunar' ? 'lunar-date-disp' : 'solar-date-disp'));
  if (!btn) return;
  if (calType==='lunar'){
    const l = parseDateInput('lunar-date');
    const leap = document.getElementById('lunar-leap').checked;
    if (l) btn.textContent = `${l.y}年 ${leap?'闰':''}${l.m}月${l.d}日`;
  } else {
    const s = parseDateInput('solar-date');
    if (s) btn.textContent = `${s.y}年${String(s.m).padStart(2,'0')}月${String(s.d).padStart(2,'0')}日`;
  }
}
function refreshDateDisps(){
  updateDateDisp('solar');
  updateDateDisp('lunar');
}

/* 订阅者：任意一页写回 Birth 后，所有相关页自动刷新（单一数据流，无手动互写） */
let _birthSubsReady = false;
function initBirthSubs(){
  if (_birthSubsReady) return;
  _birthSubsReady = true;
  Birth.subscribe(()=>{
    updateBaziDateLabel();
    if (_suppressBirthRender) return;   // applyHistory 回填期间，等界面态就绪后一次性渲染
    if (typeof renderBazi === 'function') renderBazi();
  });
  Birth.subscribe(()=>{
    const nameTab = document.getElementById('name');
    if (nameTab && nameTab.classList.contains('active')){
      syncNameBirthLabel(); computeName();
    }
  });
  Birth.subscribe(()=>{
    const mathTab = document.getElementById('math');
    if (mathTab && mathTab.classList.contains('active')){
      syncNumBirthLabel(); renderNumberMath();
    }
  });
}


/* 出生信息卡下方标签：展示当前所选出生日期摘要（第3条需求） */
function updateBaziDateLabel(){
  const label = document.getElementById('baziDateLabel');
  if (!label) return;
  const calType = document.querySelector('#bazi-caltype-row .seg.on')?.dataset.caltype || 'solar';
  const gender = document.querySelector('input[name=gender]:checked')?.value === 'female' ? '女' : '男';
  const pad = n => String(n).padStart(2,'0');
  const shiSel = (calType === 'lunar' ? document.getElementById('lunar-shichen') : document.getElementById('bazi-shichen'));
  const shi = shiSel ? BRANCHES[+shiSel.value] + '时' : '';
  let txt = '';
  if (calType === 'lunar'){
    const l = parseDateInput('lunar-date');
    const leap = document.getElementById('lunar-leap').checked;
    if (l){
      // 仅作展示：把农历数字日期转成中文月日
      const cv = window.calendar.lunar2solar(l.y, l.m, l.d, leap);
      let lmName = LUNAR_MONTHS[l.m-1] || (l.m + '月');
      let ldName = lunarDayLabel(l.d);
      txt = `农历 ${l.y}年 ${leap?'闰':''}${lmName} ${ldName} ${shi}（${gender}）`;
    }
  } else {
    const s = parseDateInput('solar-date');
    if (s) txt = `公历 ${s.y}年${pad(s.m)}月${pad(s.d)}日 ${shi}（${gender}）`;
  }
  label.textContent = txt;
  updateShichenDisp('bazi-shichen');
  updateShichenDisp('lunar-shichen');
}

// 流月干支：按流年天干（五虎遁）与当前公历月份推算（节气近似用公历月）
function liuyueGanZhi(yearGan){
  const GAN=['甲','乙','丙','丁','戊','己','庚','辛','壬','癸'];
  const ZHI=['子','丑','寅','卯','辰','巳','午','未','申','酉','戌','亥'];
  const FIRST={甲:2,己:2,乙:4,庚:4,丙:6,辛:6,丁:8,壬:8,戊:0,癸:0}; // 正月（寅月）月干序号
  const m = new Date().getMonth()+1; // 1-12
  const gi = (FIRST[yearGan] + m - 1) % 10;
  const zi = (2 + m - 1) % 12; // 寅为地支序号2
  return GAN[gi] + ZHI[zi];
}

// 归一化：去掉八字文案字与字之间的多余空格（含汉字↔汉字、汉字↔数字、汉字↔<标签>）。
// 仅在两侧至少一方为中文/全角标点时删空格，故不会破坏时间(12:30 → 12:45)、年份区间(1900–2100)、
// HTML 标签属性(class="x")与标签间的布局空格。
function despaceCJK(s){
  if (typeof s !== 'string') return s;
  var C = '\u4e00-\u9fff\u3400-\u4dbf';
  var P = '（）【】『』：，。；、·°';
  var re1 = new RegExp('([' + C + P + '])[ \\t]+(?=[' + C + P + '0-9<])', 'g');
  var re2 = new RegExp('([0-9%°>）】』])[ \\t]+(?=[' + C + P + '])', 'g');
  var prev;
  do { prev = s; s = s.replace(re1, '$1').replace(re2, '$1'); } while (s !== prev);
  return s;
}

function renderBazi(){
  document.getElementById('bazi-card').classList.remove('show');   // 点排盘自动折叠出生信息卡
  updateBaziDateLabel();                                           // 刷新下方日期标签
  const calTypeSeg = document.querySelector('#bazi-caltype-row .seg.on');
  const calType = calTypeSeg ? calTypeSeg.dataset.caltype : 'solar';
  let y, m, d, baziIsLeap = false;
  if (calType === 'lunar'){
    // 农历模式：直接读取农历 date 框（YYYY-MM-DD，按农历年/月/日解释）
    const l = parseDateInput('lunar-date');
    if (!l){ alert('请选择农历出生日期'); return; }
    y = l.y; m = l.m; d = l.d; baziIsLeap = document.getElementById('lunar-leap').checked;
    const cv = window.calendar.lunar2solar(y, m, d, baziIsLeap);
    if (!cv || cv === -1){ alert('农历日期不存在（该月无此日，或本年无此闰月）'); return; }
  } else {
    const s = parseDateInput('solar-date');
    if (!s){ alert('请选择公历出生日期'); return; }
    y = s.y; m = s.m; d = s.d;
  }
  const timeSel = (calType === 'lunar' ? document.getElementById('lunar-shichen') : document.getElementById('bazi-shichen'));
  const sc = timeSel ? (+timeSel.value) : 6;
  const shm = shichenToHM(sc);
  const gender = document.querySelector('input[name="gender"]:checked').value;
  const trueSolar = document.getElementById('bazi-truesolar').checked;
  const zi = document.getElementById('bazi-zi').checked;
  const lng = parseFloat(document.getElementById('bazi-longitude').value);
  const b = computeBazi(y, m, d, shm[0], shm[1], gender,
    { calType, trueSolar, longitude: isNaN(lng) ? 116.4 : lng, ziType: zi ? 'traditional' : 'modern', isLeap: baziIsLeap });
  window.lastBazi = b;
  const box = document.getElementById('bazi-result');

  if (b.error){ box.innerHTML = `<p class="hint">${b.error}</p>`; const _hs=document.getElementById('bazi-head-slot'); if(_hs) _hs.innerHTML=''; return; }

  // 写入排盘历史（仅用户显式确认后排盘；始终存公历真值，农历模式由 Birth 单一真相取公历）
  if (_baziRecordHistory) {
    _baziRecordHistory = false;
    try {
      const bv = (typeof Birth !== 'undefined' && Birth) ? Birth.get() : null;
      const sy = bv ? bv.y : y, sm = bv ? bv.m : m, sd = bv ? bv.d : d;
      pushHistory({
        pillars: b.year + b.month + b.day + b.hour,
        solar: [sy, sm, sd],
        gender,
        shichen: sc,
        calType: (calType === 'lunar' ? 'lunar' : 'solar'),
        solarLabel: (typeof formatDateInput === 'function') ? formatDateInput(sy, sm, sd) : (sy + '-' + sm + '-' + sd),
        ts: Date.now()
      });
      if (!document.getElementById('history-panel').hidden) renderHistoryList();
    } catch(e){}
  }

  // 四柱（年/月/日/时）+ 当前大运/当前流年：统一为柱并入出生日期信息卡片。
  // 各柱去线框，仅日柱保留高亮；天干十神标注在天干上方（日柱不标）；
  // 地支藏干纵向排并标注对应十神；大运柱仅当已起运时显示。
  const dm = b.dayMaster, dmWx = b.dayMasterWx;
  const dayGan = b.dayMaster, dayZhi = b.day[1], monthZhi = b.month[1];
  const kwBranches = kongwangBranches(dayGan, dayZhi);
  const makePillar = (role, gz, tg, isDay) => {
    const gan = gz[0], zhi = gz[1];
    const cang = (HIDDEN[zhi] || []).map(g => {
      const ss = shiShen(dm, dmWx, g, GAN_WX[g]);
      return { char:g, wx:GAN_WX[g], ss };
    });
    return {
      role,
      roleLabel: isDay ? (gender==='male' ? '乾造' : '坤造') : role,
      gan, zhi, ganWx: GAN_WX[gan], zhiWx: ZHI_WX[zhi],
      ganSS: (!isDay && tg.gan) ? tg.gan : '',
      cang,
      cs: changshengOf(dayGan, zhi),
      kw: kwBranches.includes(zhi) ? '空' : '',
      sha: shenshaOf(zhi, gan, dayGan, dayZhi, monthZhi),
      isDay
    };
  };
  const pillarData = [
    makePillar('年柱', b.year, b.tenGods.year, false),
    makePillar('月柱', b.month, b.tenGods.month, false),
    makePillar('日柱', b.day, b.tenGods.day, true),
    makePillar('时柱', b.hour, b.tenGods.hour, false)
  ];
  if (b.startedDayun) pillarData.push(makePillar('大运', b.curDayunGz, b.tenGods.dayun, false));
  pillarData.push(makePillar('流年', b.liuNianGz, b.tenGods.liuNian, false));
  const liuYueGz = liuyueGanZhi(b.liuNianGz[0]);
  pillarData.push(makePillar('流月', liuYueGz, {gan: pillarTG(b.dayMaster, b.dayMasterWx, liuYueGz).gan}, false));
  const dayFlags = pillarData.map(p => p.isDay);
  const gCell = (html, i, extra='') => `<div class="g-cell${dayFlags[i]?' is-day':''}${extra?' '+extra:''}">${html}</div>`;
  const gRow = (cells, cls) => `<div class="g-row ${cls}">${cells.join('')}</div>`;
  const roleCells = pillarData.map((p,i)=>gCell(p.isDay?`<span class="day-pill">${p.role}</span>`:p.role,i));
  const ssCells = pillarData.map((p,i)=>gCell(p.isDay?`<span class="zao-tag">${gender==='male'?'乾造':'坤造'}</span>`:(p.ganSS||''),i));
  const gzCells = pillarData.map((p,i)=>gCell(`<span class="wx-${p.ganWx}">${p.gan}</span><span class="wx-${p.zhiWx}">${p.zhi}</span>`,i));
  const cangCells = pillarData.map((p,i)=>gCell(p.cang.map(c=>`<span class="cang-item"><span class="cang-gz">${c.char}</span><i class="cang-ss">${c.ss}</i></span>`).join(''),i));
  const csCells = pillarData.map((p,i)=>gCell(p.cs||'',i));
  const nayinCells = pillarData.map((p,i)=>{
    const ny = AD_NAYIN[p.gan+p.zhi]||'';
    let inner = '';
    if (ny){
      const wxCh = ny.slice(-1);
      const wxKey = {'金':'metal','木':'wood','水':'water','火':'fire','土':'earth'}[wxCh]||'';
      inner = `${ny.slice(0,-1)}<i class="wx-${wxKey}">${wxCh}</i>`;
    }
    return gCell(inner, i);
  });
  const kwCells = pillarData.map((p,i)=>gCell(p.kw||'',i, p.kw?'kw-on':''));
  const shaCells = pillarData.map((p,i)=>gCell(p.sha.map(s=>`<span class="sha-tag">${s}</span>`).join(''),i));
  const pillarsHtml = gRow(roleCells,'g-role')+gRow(ssCells,'g-ss')+gRow(gzCells,'g-gz')+gRow(cangCells,'g-cang')+gRow(csCells,'g-cs')+gRow(nayinCells,'g-nayin')+gRow(shaCells,'g-sha')+gRow(kwCells,'g-kw');

  const maxWx = Math.max(1, ...Object.values(b.wx));
  const wxRows = ['wood','fire','earth','metal','water'].map(w=>{
    const pct = Math.max(6, Math.round(b.wx[w]/maxWx*100));
    return `<div class="wx-row">
      <span class="wx-name">${WX_NAME[w]}</span>
      <div class="wx-track"><div class="wx-fill wx-${w}" style="width:${pct}%"></div></div>
      <span class="wx-num">${b.wx[w]}</span>
    </div>`;
  }).join('');
  // 格局精断内容由 AD_geJuJing（adv.geJuJing）统一生成，避免月令格重复/误判（如比劫当令不入正格）

  const dayunHtml = b.fortuneLines.map((l, i)=>{
    const gan = l.gz[0], zhi = l.gz[1];
    const ganWx = GAN_WX[gan], zhiWx = ZHI_WX[zhi];
    const ganSS = pillarTG(b.dayMaster, GAN_WX[b.dayMaster], l.gz).gan;
    const cang = (HIDDEN[zhi]||[]).map(g => ({ char:g, wx:GAN_WX[g], ss: shiShen(b.dayMaster, GAN_WX[b.dayMaster], g, GAN_WX[g]) }));
    const sy0 = y + l.age, ey0 = y + l.age + 9;
    return `<div class="dayun-item ${l.isXi?'lucky':(l.isJi?'warn':'flat')}" data-idx="${i}">
      <div class="du-top">
        <span class="du-age">${l.age}岁起</span>
        <span class="du-range">${sy0}–${ey0}</span>
      </div>
      <div class="du-axis"><span class="du-dot"></span></div>
      <div class="du-ss">${ganSS}</div>
      <div class="du-gz"><span class="wx-${ganWx}">${gan}</span><span class="wx-${zhiWx}">${zhi}</span></div>
      <div class="du-cang">${cang.map(c=>`<span class="cang-item"><span class="cang-gz">${c.char}</span><span class="cang-ss">${c.ss}</span></span>`).join('')}</div>
    </div>`;
  }).join('');

  // 进阶批断 HTML（神煞 / 纳音 / 刑冲合害 / 调候 / 格局精断（含十神格局） / 十神组合 / 用神分层 / 六亲 / 流年交互）
  const adv = b.advanced || {};
  // 纳音五行已并入八字盘四柱网格（十二长生行下方），不再单列卡片
  const advShaDesc = adv.shenShaDesc || [];
  const advShaHtml = advShaDesc.length ? `<!-- ⑪ 神煞总览 卡片 --><div class="analysis-block"><h3><i class="ico"></i>神煞总览</h3><div class="sha-desc">${advShaDesc.map(x=>`<div class="sha-row"><span class="sha-tag sha-${x.typCls}">${x.typ}</span><span class="sha-name">${x.name}</span>：${x.desc.replace(/[（(][^）)]*[）)]/g,'')}</div>`).join('')}</div></div>` : '';
  const advRelItems = adv.relItems || [];
  const advRelHtml = advRelItems.length ? `<!-- ⑬ 地支关系·刑冲合害破 卡片 --><div class="analysis-block"><h3><i class="ico"></i>地支关系 · 刑冲合害破</h3><div class="adv-list">${advRelItems.map(x=>`<div class="adv-item adv-item-2"><span class="adv-main">${x.text}</span><span class="adv-sub">${x.info}</span></div>`).join('')}</div></div>` : '';
  const advGeHtml = (adv.geJuJing && adv.geJuJing.length)
    ? `<!-- ② 格局精断 卡片 --><div class="analysis-block"><h3><i class="ico"></i>格局精断</h3>`
      + `<div class="adv-list">${adv.geJuJing.map(x=>`<div class="adv-item">${x}</div>`).join('')}</div>`
      + `</div>`
    : '';
  const advYongHtml = `<!-- ③ 用神取用 卡片 --><div class="analysis-block keep-open" data-keep-open="1"><h3><i class="ico"></i>用神取用</h3><div class="adv-list">${(adv.yongShen||[]).map(x=>`<div class="adv-item">${x}</div>`).join('')}</div></div>`;
  const advComboHtml = (adv.combos && adv.combos.length) ? `<!-- ④ 十神组合 卡片 --><div class="analysis-block"><h3><i class="ico"></i>十神组合</h3><div class="adv-list">${adv.combos.map(x=>{ const _lat=/^[（(](潜伏|潜在)/.test(x.symbol); const _state=_lat?'伏象':'显象'; const _sym=x.symbol.replace(/^[（(](潜伏|潜在)[）)]/,'').replace(/，非忌则多不显$/,'').replace(/之符号$/,'');
    return `<div class="adv-item combo-item"><span class="combo-badge combo-${x.typCls}">${x.typ}</span><div class="combo-body"><div class="combo-line"><span class="combo-name">${x.name}（${_state}）</span><span class="combo-symbol">：${_sym}</span></div><div class="combo-cond">${x.cond}</div></div></div>`; }).join('')}</div></div>` : '';
  const advLq = adv.liuQin || {};
  const advLqHtml = `<!-- ⑭ 六亲缘份 卡片 --><div class="analysis-block"><h3><i class="ico"></i>六亲缘份</h3><div class="adv-list lq-list"><div class="adv-item">${advLq.父母||''}</div><div class="adv-item">${advLq.兄弟||''}</div><div class="adv-item">${advLq.子女||''}</div><div class="adv-item">${advLq.夫妻||''}</div></div></div>`;
  // ⑥ 流年批断已并入大运时间轴下方的展开明细（showDayunDetail 内「流年简批」），
  // 不再单列固定年份（2026）子节；打开即定位到当前大运及其当年流年。
  const advHtml = advShaHtml + advLqHtml; // 地支关系卡片已按需删除（advRelHtml 不再渲染）
  // ⑯⑰ 合并：平安提示（身体养护 + 事件防范）
  const safetyParts = [];
  if (b.healthRisk) safetyParts.push('<div class="safety-sub">身体养护</div>' + b.healthRisk);
  if (b.disaster) safetyParts.push('<div class="safety-sub">事件防范</div>' + b.disaster);
  const healthHtml = safetyParts.length
    ? `<!-- ⑯⑰ 平安提示（伤病灾+灾祸合并） --><div class="analysis-block"><h3><i class="ico"></i>平安提示</h3>${safetyParts.join('')}<p class="adv-hint">以上为命局倾向提示，须结合大运流年引动方应；健康请以现代医学检查为准，行事以遵纪守法、注意安全为本。</p></div>`
    : '';

  // 大运走势卡内仅保留「一生命运总势」叙事总断（格局定性 + 大运喜忌分段 + 定论）作简短总括；
  // 「各步大运」列表 / 关键运程 / 六亲应期 / 古籍引用依清理要求移除（各步大运在大运时间轴上已有，且不再引用古籍）
  const yunchengSub = yunchengZongshi(b);

  const headSlot = document.getElementById('bazi-head-slot');
  if (headSlot) headSlot.innerHTML = despaceCJK(`<div class="bazi-head-card"><div class="pillars-scroll"><div class="pillars-grid">${pillarsHtml}</div></div></div>`);
  box.innerHTML = despaceCJK(`
    <div class="analysis-block keep-open" data-keep-open="1">
      <!-- ① 日主强弱 · 喜忌神 卡片 -->
      <h3><i class="ico"></i>日主强弱</h3>
      <p class="strength-narrative">${AD_strengthNarrative({year:b.year, month:b.month, day:b.day, hour:b.hour}, b.dayMaster, b.dayMasterWx, b)}</p>
      <div class="chips">
        <span class="chip xi">喜用神 · ${b.xiNames.join('、')}</span>
        <span class="chip ji">忌神 · ${b.jiNames.join('、')}</span>
      </div>
      <div class="wx-chart">${wxRows}</div>
    </div>
    ${advYongHtml}
    ${advGeHtml}
    ${advComboHtml}
    <div class="analysis-block">
      <!-- ⑤ 大运走势 卡片（一生命运总势总断 + 大运时间轴；点击某步大运展开其下「大运批断 + 流年简批」，自动定位当前大运及当年流年） -->
      <h3><i class="ico"></i>大运走势</h3>
      ${yunchengSub}
      <div class="dayun-axis-wrap"><span class="dayun-axis-label">${b.forward?'顺行':'逆行'} · ${b.qiYun.years}岁${b.qiYun.months}个月起运</span><div class="dayun-scroll"><div class="dayun-list">${dayunHtml}</div></div></div>
      <div class="dayun-detail" id="dayun-detail"></div>
    </div>
    <div class="analysis-block">
      <!-- ⑦ 性格心性 卡片 -->
      <h3><i class="ico"></i>性格心性</h3>
      ${b.lifeStage?AD_lsHtml(b.lifeStage,'char'):''}
      <p>${b.personality}</p>
    </div>
    <div class="analysis-block">
      <!-- ⑧ 财运趋势 卡片 -->
      <h3><i class="ico"></i>财运趋势</h3>
      ${b.lifeStage?AD_lsHtml(b.lifeStage,'wealth'):''}
      <p>${b.wealth}</p>
    </div>
    <div class="analysis-block">
      <!-- ⑨ 事业官运 卡片 -->
      <h3><i class="ico"></i>事业官运</h3>
      ${b.lifeStage?AD_lsHtml(b.lifeStage,'career'):''}
      <p>${b.career}</p>
    </div>
    <div class="analysis-block">
      <!-- ⑩ 姻缘婚姻 卡片 -->
      <h3><i class="ico"></i>姻缘婚姻</h3>
      ${b.lifeStage?AD_lsHtml(b.lifeStage,'marriage'):''}
      <p>${b.marriage}</p>
    </div>
    ${advHtml}
    ${healthHtml}
    <div class="analysis-block chengu-block">
      <!-- ⑮ 袁天罡称骨 卡片 -->
      <h3><i class="ico"></i>袁天罡称骨</h3>
      <div class="chengu">
        <div class="chengu-weight">骨重 ${b.chengu.liang>0?cnNum(b.chengu.liang)+'两':''}${cnNum(b.chengu.qian)}钱</div>
        <blockquote class="chengu-poem">${b.chengu.poem}</blockquote>
      </div>
    </div>
  `);

  // 运程流年：大运左右滑动，点击展开该步大运的十年流年与批断
  setupCollapse(box);
  const dayunList = box.querySelector('.dayun-list');
  if (dayunList){
    const items = dayunList.querySelectorAll('.dayun-item');
    const selectDayun = (idx)=>{
      items.forEach(x=>x.classList.remove('active'));
      if (items[idx]) items[idx].classList.add('active');
      showDayunDetail(b, idx);
    };
    items.forEach((el, i)=> el.onclick = ()=> selectDayun(i));
    if (b.fortuneLines.length) selectDayun(Math.min(b.activeDayunIdx, b.fortuneLines.length - 1));
    else { const d = document.getElementById('dayun-detail'); if (d) d.hidden = true; }
  }

}

// 八字结果卡片折叠：除四柱八字卡（在 #bazi-head-slot，不在 box 内）外，box 内所有 analysis-block 加可折叠头。
// 保留卡片（日主强弱/用神取用/大运走势/神煞总览/袁天罡称骨）默认展开；其余「准备开放中」卡片默认收起且锁定不可展开。
const LOCKED_CARD_TITLES = new Set(['格局精断','十神组合','财运趋势','事业官运','姻缘婚姻','六亲缘份','平安提示']);
function setupCollapse(root){
  if (!root) return;
  root.querySelectorAll('.analysis-block').forEach(function(block){
    if (block.dataset.collapsible === '1') return;          // 已处理过（重排盘时跳过）
    const h3 = block.querySelector(':scope > h3');
    if (!h3) return;
    const title = (h3.textContent || '').trim();
    const locked = LOCKED_CARD_TITLES.has(title);
    const body = document.createElement('div');
    body.className = 'ab-body';
    let n = h3.nextSibling;
    while (n){
      const nx = n.nextSibling;
      body.appendChild(n);          // 把 h3 之后的所有节点（含文本/注释/子元素）移入 body
      n = nx;
    }
    block.appendChild(body);
    block.classList.add('collapsible');
    h3.classList.add('ab-head');
    if (locked){
      // 准备开放中：默认收起 + 锁定，点击不展开
      block.classList.add('collapsed','locked');
      const badge = document.createElement('span');
      badge.className = 'coming-soon-badge';
      badge.textContent = '准备开放中';
      h3.appendChild(badge);
    } else {
      // 保留卡片：默认展开（用户要求 2026-07-20）；点击标题可折叠收起
      h3.addEventListener('click', function(){ block.classList.toggle('collapsed'); });
    }
    block.dataset.collapsible = '1';
  });
}

// 渲染选中大运的十年流年与批断；点击某流年框即在十年流年下方显示该年批断
function swdHtml(swd){
  if (!swd) return '';
  const order = ['career','wealth','emotion','health','helper','family','study','travel','social','aura'];
  const cls = {吉:'swd-ji',平:'swd-ping',凶:'swd-xiong'};
  return order.map(k=>{
    const f = swd[k]; if(!f) return '';
    return '<div class="swd-cell '+(cls[f.level]||'')+'"><div class="swd-top"><span class="swd-name">'+SWD_LAB[k]+'</span><span class="swd-tag">'+f.level+'</span></div><p class="swd-text">'+f.text+'</p></div>';
  }).join('');
}
function showDayunDetail(b, idx){
  const detail = document.getElementById('dayun-detail');
  if (!detail) return;
  const l = b.fortuneLines[idx];
  if (!l){ detail.hidden = true; return; }
  const liuNianHtml = l.liuNian.map((ln, k)=>{
    const lnSS = shiShen(b.dayMaster, b.dayMasterWx, ln.gz[0], GAN_WX[ln.gz[0]]);
    const lnGan = ln.gz[0], lnZhi = ln.gz[1];
    const lnGanWx = GAN_WX[lnGan], lnZhiWx = ZHI_WX[lnZhi];
    const lnCang = (HIDDEN[lnZhi]||[]).map(g => ({ char:g, wx:GAN_WX[g], ss: shiShen(b.dayMaster, GAN_WX[b.dayMaster], g, GAN_WX[g]) }));
    return `
    <div class="ln-item ${k===0?'active':''}" data-k="${k}">
      <div class="ln-top"><span class="ln-age">${ln.age}岁</span><span class="ln-year">${ln.year}</span></div>
      <div class="ln-axis"><span class="ln-dot"></span></div>
      <div class="ln-ss">${lnSS}</div>
      <div class="ln-gz"><span class="wx-${lnGanWx}">${lnGan}</span><span class="wx-${lnZhiWx}">${lnZhi}</span></div>
      <div class="ln-cang">${lnCang.map(c=>`<span class="cang-item"><span class="cang-gz">${c.char}</span><span class="cang-ss">${c.ss}</span></span>`).join('')}</div>
    </div>`;
  }).join('');
  detail.innerHTML = despaceCJK(`
    <div class="dd-head">${l.gz} 大运（${l.age}岁起） · ${l.tag}</div>
    <div class="dd-section">
      <div class="dd-label">大运批断</div>
      <p class="dd-pidian">${l.desc}</p>
    </div>
    <div class="dd-section">
      <div class="dd-label">十维度分领域</div>
      <div class="swd-grid">${swdHtml(l.shiweidu)}</div>
    </div>
    <div class="dd-section">
      <div class="dd-label">流年简批</div>
      <div class="ln-scroll"><div class="ln-list" id="ln-list">${liuNianHtml}</div></div>
      <p class="dd-pidian" id="ln-pidian"></p>
    </div>`);
  detail.hidden = false;
  const lnList = detail.querySelector('#ln-list');
  const lnPid = detail.querySelector('#ln-pidian');
  const selectLn = (k)=>{
    lnList.querySelectorAll('.ln-item').forEach(x=>x.classList.remove('active'));
    const el = lnList.querySelector('.ln-item[data-k="'+k+'"]');
    if (el) el.classList.add('active');
    lnPid.textContent = despaceCJK((l.liuNian[k] && l.liuNian[k].desc) ? l.liuNian[k].desc : '');
  };
  lnList.querySelectorAll('.ln-item').forEach(el=>{ el.onclick = ()=> selectLn(+el.dataset.k); });
  // 自动定位到当年流年（当前大运内含 b.liuNianYear 的那一步）；其余大运默认展示首年
  let defK = 0;
  const curK = l.liuNian.findIndex(x => x.year === b.liuNianYear);
  if (curK >= 0) defK = curK;
  selectLn(defK);
}

/* ===================================================================
 * 四柱反推（网格窗体版）
 * =================================================================== */
const REV_STEMS = ['甲','乙','丙','丁','戊','己','庚','辛','壬','癸'];
const REV_YANG = new Set(['甲','丙','戊','庚','壬']);
const REV_WU_HU = {甲:2,己:2,乙:4,庚:4,丙:6,辛:6,丁:8,壬:8,戊:0,癸:0};
const REV_WU_SHU = {甲:0,己:0,乙:2,庚:2,丙:4,辛:4,丁:6,壬:6,戊:8,癸:8};
let revData = { yearGan:'', yearZhi:'', monthGz:'', dayGan:'', dayZhi:'', hourGz:'' };

// 年/日地支须与天干阴阳同配对（阳干配阳支、阴干配阴支）
function revBranchParityOk(gan, zhi){
  const yangGan = REV_YANG.has(gan);
  const yangZhi = ['子','寅','辰','午','申','戌'].includes(zhi);
  return yangGan === yangZhi;
}
// 五虎遁：依年干推出 12 个合法月柱
function revMonthOpts(yearGan){
  if (!yearGan) return [];
  const st = REV_WU_HU[yearGan];
  const brs = ['寅','卯','辰','巳','午','未','申','酉','戌','亥','子','丑'];
  const list = []; for (let i=0;i<12;i++) list.push(REV_STEMS[(st+i)%10]+brs[i]);
  return list;
}
// 五鼠遁：依日干推出 12 个合法时柱
function revHourOpts(dayGan){
  if (!dayGan) return [];
  const st = REV_WU_SHU[dayGan];
  const brs = ['子','丑','寅','卯','辰','巳','午','未','申','酉','戌','亥'];
  const list = []; for (let i=0;i<12;i++) list.push(REV_STEMS[(st+i)%10]+brs[i]);
  return list;
}
// 当前正在选择的柱与步骤：col=year/month/day/hour，step=gan/zhi
let revSel = { col:null, step:null };
const REV_BRANCHES = ['子','丑','寅','卯','辰','巳','午','未','申','酉','戌','亥'];

// 四柱方框当前显示文本
function revBoxText(){
  return {
    year:  (revData.yearGan && revData.yearZhi) ? revData.yearGan+revData.yearZhi : '—',
    month: revData.monthGz || '—',
    day:   (revData.dayGan && revData.dayZhi) ? revData.dayGan+revData.dayZhi : '—',
    hour:  revData.hourGz || '—'
  };
}
function revRenderBoxes(){
  const txt = revBoxText();
  ['year','month','day','hour'].forEach(col=>{
    const box = document.querySelector('.rev-box[data-col="'+col+'"]');
    if (!box) return;
    box.textContent = txt[col];
    box.classList.toggle('filled', txt[col] !== '—');
    box.classList.toggle('active', revSel.col === col);
  });
}
// 渲染当前步骤的选择器（年/日两步：天干→地支阴阳过滤；月/时一步：五虎遁/五鼠遁完整列表）
function revRenderPicker(){
  const pk = document.getElementById('rev-picker');
  if (!pk) return;
  if (!revSel.col){
    pk.innerHTML = '<p class="rev-pk-hint">点击上方「年 / 月 / 日 / 时柱」方框，逐步选择干支。</p>';
    return;
  }
  const col = revSel.col, step = revSel.step;
  if (col === 'year' || col === 'day'){
    const ganKey = col==='year' ? 'yearGan' : 'dayGan';
    const zhiKey = col==='year' ? 'yearZhi' : 'dayZhi';
    if (step === 'gan'){
      pk.innerHTML = '<p class="rev-pk-tip">选择「'+(col==='year'?'年':'日')+'柱」天干</p>' +
        '<div class="rev-pk-row">' + REV_STEMS.map(g =>
          '<button type="button" class="rev-pk-btn'+(revData[ganKey]===g?' on':'')+'" data-gan="'+g+'">'+g+'</button>').join('') + '</div>';
    } else {
      const selGan = revData[ganKey];
      const yang = REV_YANG.has(selGan);
      const zhis = REV_BRANCHES.filter(z => revBranchParityOk(selGan, z));
      pk.innerHTML = '<p class="rev-pk-tip">「'+(col==='year'?'年':'日')+'干 '+selGan+'」为'+(yang?'阳':'阴')+'干，配'+(yang?'阳':'阴')+'支</p>' +
        '<div class="rev-pk-row">' + zhis.map(z =>
          '<button type="button" class="rev-pk-btn'+(revData[zhiKey]===z?' on':'')+'" data-zhi="'+z+'">'+z+'</button>').join('') + '</div>';
    }
  } else if (col === 'month'){
    const mOpts = revMonthOpts(revData.yearGan);
    const startGan = REV_STEMS[REV_WU_HU[revData.yearGan]];
    pk.innerHTML = '<p class="rev-pk-tip">依年干 '+revData.yearGan+' 五虎遁，月干起于 '+startGan+'</p>' +
      '<div class="rev-pk-row">' + mOpts.map(gz =>
        '<button type="button" class="rev-pk-btn'+(revData.monthGz===gz?' on':'')+'" data-gz="'+gz+'">'+gz+'</button>').join('') + '</div>';
  } else if (col === 'hour'){
    const hOpts = revHourOpts(revData.dayGan);
    const startGan = REV_STEMS[REV_WU_SHU[revData.dayGan]];
    pk.innerHTML = '<p class="rev-pk-tip">依日干 '+revData.dayGan+' 五鼠遁，时干起于 '+startGan+'</p>' +
      '<div class="rev-pk-row">' + hOpts.map(gz =>
        '<button type="button" class="rev-pk-btn'+(revData.hourGz===gz?' on':'')+'" data-gz="'+gz+'">'+gz+'</button>').join('') + '</div>';
  }
  pk.querySelectorAll('.rev-pk-btn').forEach(el => {
    el.onclick = function(){
      if (el.dataset.gan) revOnGan(col, el.dataset.gan);
      else if (el.dataset.zhi) revOnZhi(col, el.dataset.zhi);
      else if (el.dataset.gz) revOnGz(col, el.dataset.gz);
    };
  });
}
function revOnGan(col, g){
  const ganKey = col==='year' ? 'yearGan' : 'dayGan';
  const zhiKey = col==='year' ? 'yearZhi' : 'dayZhi';
  revData[ganKey] = g;
  revData[zhiKey] = '';                 // 换天干则清空地支
  if (col==='year') revData.monthGz = ''; else revData.hourGz = '';  // 年/日变则依赖它的月/时失效
  revSel.step = 'zhi';
  revRenderBoxes(); revRenderPicker();
}
function revOnZhi(col, z){
  const zhiKey = col==='year' ? 'yearZhi' : 'dayZhi';
  revData[zhiKey] = z;
  revSel = { col:null, step:null };     // 完成该柱
  revRenderBoxes(); revRenderPicker(); maybeAutoReverse();
}
function revOnGz(col, gz){
  if (col==='month') revData.monthGz = gz; else revData.hourGz = gz;
  revSel = { col:null, step:null };
  revRenderBoxes(); revRenderPicker(); maybeAutoReverse();
}
function revFlashPick(msg){
  const pk = document.getElementById('rev-picker');
  if (pk) pk.innerHTML = '<p class="rev-pk-warn">'+msg+'</p>';
}
// 点击某柱方框：决定进入哪一步（月/时需先有年/日干；年/日已选全则重置重选）
function revOnBoxClick(col){
  if (col === 'month'){
    if (!revData.yearGan){ revFlashPick('请先选择「年柱」（月柱依年干五虎遁）。'); return; }
    revSel = { col:'month', step:'zhi' };
  } else if (col === 'hour'){
    if (!revData.dayGan){ revFlashPick('请先选择「日柱」（时柱依日干五鼠遁）。'); return; }
    revSel = { col:'hour', step:'zhi' };
  } else {
    const ganKey = col==='year' ? 'yearGan' : 'dayGan';
    const zhiKey = col==='year' ? 'yearZhi' : 'dayZhi';
    if (revData[ganKey] && revData[zhiKey]){   // 已选全 → 重置该柱（连带失效依赖柱）
      revData[ganKey] = ''; revData[zhiKey] = '';
      if (col==='year') revData.monthGz = ''; else revData.hourGz = '';
    }
    revSel = { col, step:'gan' };
  }
  revRenderBoxes(); revRenderPicker();
}
// 四柱选齐即自动匹配（无需「确定」按钮）
function maybeAutoReverse(){
  const year = (revData.yearGan && revData.yearZhi) ? revData.yearGan+revData.yearZhi : null;
  const month = revData.monthGz || null;
  const day = (revData.dayGan && revData.dayZhi) ? revData.dayGan+revData.dayZhi : null;
  const hour = revData.hourGz || null;
  const box = document.getElementById('reverse-result');
  if (!box) return;
  if (!(year && month && day && hour)){ box.innerHTML = ''; return; } // 未选齐：清空旧结果
  let ys = parseInt(document.getElementById('rev-ys').value, 10) || 1900;
  let ye = parseInt(document.getElementById('rev-ye').value, 10) || new Date().getFullYear();
  if (ys > ye){ const t=ys; ys=ye; ye=t; }
  box.innerHTML = '<p class="hint">匹配中…</p>';
  setTimeout(function(){
    const r = BaziReverse.reverseBazi({ year:year, month:month, day:day, hour:hour }, { ys:ys, ye:ye, ziType:'modern' }, window.calendar);
    renderRevResults(r);
  }, 10);
}

function renderRevResults(r){
  const box = document.getElementById('reverse-result');
  if (!box) return;
  if (r.error){ box.innerHTML = '<p class="hint">请至少输入一柱。</p>'; return; }
  const seen = new Set(); const merged = [];
  for (let i=0;i<r.results.length;i++){
    const it = r.results[i];
    const k = it.y+'-'+it.m+'-'+it.d;
    if (!seen.has(k)){ seen.add(k); merged.push(it); }
  }
  if (merged.length === 0){ box.innerHTML = '<p class="hint">未找到匹配的数据。</p>'; return; }
  box.innerHTML = despaceCJK('<div class="rev-hint">找到 '+merged.length+' 个结果：</div><div class="rev-list">' +
    merged.map(function(it){
      var label = it.y+'年'+it.m+'月'+it.d+'日';
      if (it.hour !== null){
        var br = (it.hour === 23) ? 0 : Math.floor((it.hour + 1) / 2);
        var bNames = ['子','丑','寅','卯','辰','巳','午','未','申','酉','戌','亥'];
        var ss, ee;
        if (br === 0){ ss = 23; ee = 1; } else { ss = 2*br - 1; ee = 2*br + 1; }
        label += bNames[br] + '时' + ss + '-' + ee + '点';
      }
      return '<button type="button" class="rev-item" data-y="'+it.y+'" data-m="'+it.m+'" data-d="'+it.d+'" data-h="'+(it.hour!==null?it.hour:'')+'">'+label+'</button>';
    }).join('') +
    '</div>');
  box.querySelectorAll('.rev-item').forEach(function(el){
    el.onclick = function(){
      const solarEl = document.getElementById('solar-date');
      if (solarEl) solarEl.value = formatDateInput(+el.dataset.y, +el.dataset.m, +el.dataset.d);
      const cRow = document.getElementById('bazi-caltype-row');
      if (cRow){ cRow.querySelectorAll('.seg[data-caltype]').forEach(x=>x.classList.remove('on')); const cSolar = cRow.querySelector('.seg[data-caltype="solar"]'); if (cSolar) cSolar.classList.add('on'); }
      if (el.dataset.h !== '' && el.dataset.h != null){
        const h = +el.dataset.h;
        const sc = (h === 23 ? 0 : Math.floor((h + 1) / 2));
        const ss = document.getElementById('bazi-shichen');
        if (ss) ss.value = sc;
        updateShichenDisp('bazi-shichen');
      }
      _baziRecordHistory = true;
      renderBazi();
      closeRevModal();
    };
  });
}

function initReverseModal(){
  document.getElementById('rev-modal-close').onclick = closeRevModal;
  document.getElementById('rev-modal-reset').onclick = function(){
    revData = { yearGan:'', yearZhi:'', monthGz:'', dayGan:'', dayZhi:'', hourGz:'' };
    revSel = { col:null, step:null };
    const box = document.getElementById('reverse-result'); if (box) box.innerHTML = '';
    revRenderBoxes(); revRenderPicker();
  };
  document.querySelectorAll('.rev-box').forEach(function(b){
    b.onclick = function(){ revOnBoxClick(b.getAttribute('data-col')); };
  });
  const modal = document.getElementById('reverse-modal');
  if (modal) modal.onclick = function(e){ if (e.target === this) closeRevModal(); };
}
function openRevModal(){
  revData = { yearGan:'', yearZhi:'', monthGz:'', dayGan:'', dayZhi:'', hourGz:'' };
  revSel = { col:null, step:null };
  const box = document.getElementById('reverse-result'); if (box) box.innerHTML = '';
  revRenderBoxes(); revRenderPicker();
  const modal = document.getElementById('reverse-modal');
  // 弹层卡片「跟随」四柱反推切片：锚定卡片顶部到切片下方
  const rtBtn = document.getElementById('reverse-toggle');
  if (rtBtn && modal){
    const r = rtBtn.getBoundingClientRect();
    modal.style.setProperty('--rev-anchor', (r.bottom + 8) + 'px');
  }
  if (modal) modal.hidden = false;
  // 与四柱反推互斥：隐藏出生信息卡、取消历法高亮
  const card = document.getElementById('bazi-card'); if (card) card.classList.remove('show');
  const cRow = document.getElementById('bazi-caltype-row');
  if (cRow) cRow.querySelectorAll('.seg[data-caltype]').forEach(x=>x.classList.remove('on'));
}
function closeRevModal(){
  const modal = document.getElementById('reverse-modal'); if (modal) modal.hidden = true;
  const rt = document.getElementById('reverse-toggle');
  if (rt){ rt.setAttribute('aria-expanded','false'); rt.classList.remove('rev-on'); }
  const cRow = document.getElementById('bazi-caltype-row');
  if (cRow){ cRow.querySelectorAll('.seg[data-caltype]').forEach(x=>x.classList.remove('on')); const solarSeg = cRow.querySelector('.seg[data-caltype="solar"]'); if (solarSeg) solarSeg.classList.add('on'); }
}

/* ===================================================================
 * 黄历（老黄历 / 通书）
 * 依据日干支、节气月建推导：建除十二神、宜忌、冲煞、值神黄黑道、
 * 彭祖百忌、吉神方位、二十八宿值日。
 * =================================================================== */
const BRANCH_NUM = {'子':0,'丑':1,'寅':2,'卯':3,'辰':4,'巳':5,'午':6,'未':7,'申':8,'酉':9,'戌':10,'亥':11};

// 建除十二神：神名 / 值神 / 黄黑道 / 宜 / 忌
const JIANCHU = [
  {shen:'建', star:'青龙', lu:'黄', yi:['出行','祈福','动土','订盟','纳采','嫁娶','移徙','入宅'], ji:['掘井','乘船','开仓','修仓库']},
  {shen:'除', star:'明堂', lu:'黄', yi:['祭祀','解除','沐浴','整容','剃头','疗病','出行','移徙'], ji:['求官','上任','远行','嫁娶','开市']},
  {shen:'满', star:'天刑', lu:'黑', yi:['祭祀','祈福','开市','交易','立券','纳财','造仓'], ji:['动土','移徙','入宅','安葬','破土']},
  {shen:'平', star:'朱雀', lu:'黑', yi:['祭祀','修饰垣墙','平治道涂'], ji:['祈福','求嗣','词讼','栽种','嫁娶','出行']},
  {shen:'定', star:'金匮', lu:'黄', yi:['祭祀','祈福','嫁娶','造屋','装修','入宅','安香','安葬','交易'], ji:['词讼','出行','医疗','交涉','纳畜']},
  {shen:'执', star:'天德', lu:'黄', yi:['造屋','收购','修造','嫁娶','捕捉','纳财','立券'], ji:['开市','移徙','出行','入宅','求医']},
  {shen:'破', star:'白虎', lu:'黑', yi:['破屋坏垣','求医治病','解除'], ji:['嫁娶','出行','签约','交涉','开市','动土','安葬']},
  {shen:'危', star:'玉堂', lu:'黄', yi:['安床','祭祀','祈福','捕捉','入殓','成服'], ji:['登高','出行','乘船','入宅','嫁娶','移徙']},
  {shen:'成', star:'天牢', lu:'黑', yi:['结婚','开市','入学','安床','动土','出行','交易','立契','纳财'], ji:['词讼','诉讼','争端']},
  {shen:'收', star:'玄武', lu:'黑', yi:['收购','纳财','嫁娶','入仓','捕捉','纳畜'], ji:['放债','新船下水','出行','安葬']},
  {shen:'开', star:'司命', lu:'黄', yi:['祭祀','祈福','入学','开市','动土','出行','求医'], ji:['安葬','嫁娶','放债']},
  {shen:'闭', star:'勾陈', lu:'黑', yi:['筑堤','埋穴','补垣','安葬','纳财'], ji:['开市','出行','求医','手术','疗病']}
];

// 彭祖百忌（日干 / 日支）
const PENGZU_GAN = {
  '甲':'甲不开仓财物耗散','乙':'乙不栽植千株不长','丙':'丙不修灶必见灾殃','丁':'丁不剃头头必生疮',
  '戊':'戊不受田田主不祥','己':'己不破券二比并亡','庚':'庚不经络织机虚张','辛':'辛不合酱主人不尝',
  '壬':'壬不汲水更难提防','癸':'癸不词讼理弱敌强'
};
const PENGZU_ZHI = {
  '子':'子不问卜自惹祸殃','丑':'丑不冠带主不还乡','寅':'寅不祭祀神鬼不尝','卯':'卯不穿井水泉不香',
  '辰':'辰不哭泣必主重丧','巳':'巳不远行财物伏藏','午':'午不苫盖屋主更张','未':'未不服药毒气入肠',
  '申':'申不安床鬼祟入房','酉':'酉不会客醉坐颠狂','戌':'戌不吃犬作怪上床','亥':'亥不嫁娶不利新郎'
};

// 六冲地支 / 地支生肖
const CHONG = {'子':'午','丑':'未','寅':'申','卯':'酉','辰':'戌','巳':'亥','午':'子','未':'丑','申':'寅','酉':'卯','戌':'辰','亥':'巳'};
const BRANCH_ANIMAL = {'子':'鼠','丑':'牛','寅':'虎','卯':'兔','辰':'龙','巳':'蛇','午':'马','未':'羊','申':'猴','酉':'鸡','戌':'狗','亥':'猪'};
// 三合局 → 煞方
const SANHE_SHA = {'申':'南','子':'南','辰':'南','亥':'西','卯':'西','未':'西','寅':'北','午':'北','戌':'北','巳':'东','酉':'东','丑':'东'};
// 喜神 / 财神 方位（按日干）
const XISHEN = {'甲':'东北','己':'东北','乙':'西北','庚':'西北','丙':'西南','辛':'西南','丁':'正南','壬':'正南','戊':'东南','癸':'东南'};
const CAISHEN = {'甲':'东北','乙':'东北','丙':'西南','丁':'西南','戊':'正北','己':'正北','庚':'正东','辛':'正东','壬':'正南','癸':'正南'};
// 二十八宿（值日星宿）；锚点：2000-01-07 为角宿（公开实现常用基准）
const XINGXIU = ['角','亢','氐','房','心','尾','箕','斗','牛','女','虚','危','室','壁','奎','娄','胃','昴','毕','觜','参','井','鬼','柳','星','张','翼','轸'];
const XINGXIU_FULL = ['角木蛟','亢金龙','氐土貉','房日兔','心月狐','尾火虎','箕水豹','斗木獬','牛金牛','女土蝠','虚日鼠','危月燕','室火猪','壁水貐','奎木狼','娄金狗','胃土彘','昴日鸡','毕月乌','觜火猴','参水猿','井木犴','鬼金羊','柳土獐','星日马','张月鹿','翼火蛇','轸水蚓'];

function getXingXiuIdx(y, m, d){
  const t = Date.UTC(y, m-1, d);
  const base = Date.UTC(2000, 0, 7);
  const diff = Math.round((t - base) / 86400000);
  return ((diff % 28) + 28) % 28;
}

function computeHuangli(y, m, d){
  const o = calendar.solar2lunar(y, m, d);
  const dayGZ = o.gzDay;
  const stem = dayGZ[0], branch = dayGZ[1];
  const monthBranch = o.gzMonth[1];                 // 节气月建（月支）
  const jcIdx = (BRANCH_NUM[branch] - BRANCH_NUM[monthBranch] + 12) % 12;
  const jc = JIANCHU[jcIdx];
  const chongBranch = CHONG[branch];
  let astro = '';
  try { astro = calendar.toAstro(m, d); } catch(e){}
  return {
    lunar: o, stem, branch, dayGZ,
    jc,
    chong: { animal: BRANCH_ANIMAL[chongBranch], branch: chongBranch },
    sha: SANHE_SHA[branch],
    xishen: XISHEN[stem], caishen: CAISHEN[stem],
    xingxiu: XINGXIU[getXingXiuIdx(y, m, d)],
    xingxiuFull: XINGXIU_FULL[getXingXiuIdx(y, m, d)],
    pengzu: [PENGZU_GAN[stem], PENGZU_ZHI[branch]],
    astro
  };
}

const LIUHE = {'子':'丑','丑':'子','寅':'亥','亥':'寅','卯':'戌','戌':'卯','辰':'酉','酉':'辰','巳':'申','申':'巳','午':'未','未':'午'};
const SANHE = {'申':['子','辰'],'子':['申','辰'],'辰':['申','子'],'亥':['卯','未'],'卯':['亥','未'],'未':['亥','卯'],'寅':['午','戌'],'午':['寅','戌'],'戌':['寅','午'],'巳':['酉','丑'],'酉':['巳','丑'],'丑':['巳','酉']};
const WU_SHUN_DUN = {'甲':0,'己':0,'乙':2,'庚':2,'丙':4,'辛':4,'丁':6,'壬':6,'戊':8,'癸':8}; // 五鼠遁子时天干索引

function hourGrade(dayStem, dayBranch, hourBranch){
  // 时辰与日支六合/三合 → 吉；相冲 → 凶；其他 → 平
  const b = hourBranch;
  const d = dayBranch;
  if (b === d) return { grade:'平', cls:'mid' };
  if (LIUHE[b] === d || LIUHE[d] === b) return { grade:'吉', cls:'good' };
  if (SANHE[b] && SANHE[b].includes(d)) return { grade:'吉', cls:'good' };
  if (CHONG[b] === d || CHONG[d] === b) return { grade:'凶', cls:'bad' };
  return { grade:'平', cls:'mid' };
}

function renderHuangliDetail(y, m, d){
  const h = computeHuangli(y, m, d);
  const o = h.lunar;
  const luTag = h.jc.lu === '黄'
    ? '<span class="lu-yellow">黄道吉</span>'
    : '<span class="lu-black">黑道凶</span>';
  const yi = h.jc.yi.map(x => `<span class="act yi">${x}</span>`).join('');
  const ji = h.jc.ji.map(x => `<span class="act ji">${x}</span>`).join('');
  const wxText = `${WX_NAME[GAN_WX[h.stem]]}${WX_NAME[ZHI_WX[h.branch]]}`;
  const inlineDate = document.getElementById('hl-date-inline');
  if (inlineDate) inlineDate.textContent = `${y}年${m}月${d}日`;
  const lunarInline = document.getElementById('hl-lunar-inline');
  if (lunarInline) lunarInline.textContent = `${o.gzYear}年 ${o.IMonthCn}${o.IDayCn}${o.isLeap ? '（闰）' : ''}`;

  // === 摘要卡片 ===
  const isGood = h.jc.lu === '黄';
  const yiCount = h.jc.yi.length;
  const jiCount = h.jc.ji.length;
  const summaryCard = `<div class="hl-summary">
    <div class="hls-top">
      <span class="hls-badge ${isGood?'good':'bad'}">${isGood?'黄道吉日':'黑道凶日'}</span>
      <span class="hls-stat">宜${yiCount}事 ｜ 忌${jiCount}事</span>
    </div>
    <div class="hls-tags">
      <span class="hls-tag">冲${h.chong.animal}（${h.chong.branch}）煞${h.sha}</span>
      <span class="hls-tag">${h.jc.shen}日 · ${h.jc.star}</span>
    </div>
  </div>`;

  // === 宜忌双侧对比 ===
  const yjHtml = `<div class="hl-yj">
    <div class="hl-yi-card"><div class="hl-yj-title">宜</div><div class="hl-yj-items">${yi || '<span class="hint">—</span>'}</div></div>
    <div class="hl-ji-card"><div class="hl-yj-title">忌</div><div class="hl-yj-items">${ji || '<span class="hint">—</span>'}</div></div>
  </div>`;

  // === 吉神徽章（值日星宿并排到喜神/财神后面）===
  const badgeHtml = `<div class="hl-badges">
    <span class="hl-badge">喜神 ${h.xishen}</span>
    <span class="hl-badge">财神 ${h.caishen}</span>
    <span class="hl-badge">值日星宿 ${h.xingxiuFull}</span>
    <span class="hl-badge">彭祖忌 ${h.pengzu[0]} ｜ ${h.pengzu[1]}</span>
  </div>`;

  // === 时辰吉凶 ===
  const hourNames = ['子时','丑时','寅时','卯时','辰时','巳时','午时','未时','申时','酉时','戌时','亥时'];
  const hourStart = WU_SHUN_DUN[h.stem]; // 子时天干索引
  const hourCells = BRANCHES.map((br, i) => {
    const g = hourGrade(h.stem, h.branch, br);
    const stemIdx = (hourStart + i) % 10;
    return `<div class="hc-cell ${g.cls}"><span class="hc-time">${hourNames[i]}</span><span class="hc-g">${g.grade}</span></div>`;
  }).join('');
  const hourHtml = `<div class="hl-hours">
    <div class="hl-section-title">十二时辰吉凶</div>
    <div class="hc-grid hc-grid-12">${hourCells}</div>
  </div>`;

  // === 前后几天对比 ===
  const dayMs = 86400000;
  const today = new Date(y, m-1, d);
  const compareDays = [-3,-2,-1,0,1,2,3];
  const compItems = compareDays.map(offset => {
    const dt = new Date(today.getTime() + offset * dayMs);
    const yy = dt.getFullYear(), mm = dt.getMonth()+1, dd = dt.getDate();
    const hh = computeHuangli(yy, mm, dd);
    const isGoodDay = hh.jc.lu === '黄';
    const label = offset === 0 ? '今日' : `${mm}/${dd}`;
    return `<div class="cp-item${offset===0?' cp-today':''}">
      <div class="cp-date">${label}</div>
      <div class="cp-badge ${isGoodDay?'good':'bad'}">${isGoodDay?'吉':'凶'}</div>
      <div class="cp-shen">${hh.jc.shen}</div>
      <div class="cp-yj">宜${hh.jc.yi.length}忌${hh.jc.ji.length}</div>
    </div>`;
  }).join('');
  const compareHtml = `<div class="hl-compare">
    <div class="hl-section-title">前后几日黄历对比</div>
    <div class="cp-grid">${compItems}</div>
  </div>`;

  // === 详细行（按需求精简：日干支/年月干支/值日星宿/星期等整块删除，仅保留节气提示）===
  const detailRows = `${o.isTerm ? `<div class="hl-detail-rows"><div class="hl-row"><span class="hl-k">节气</span><span class="hl-v">${o.Term}</span></div></div>` : ''}`;

  document.getElementById('huangli-detail').innerHTML = `
    <div class="hl-result">
      ${summaryCard}
      ${yjHtml}
      ${badgeHtml}
      ${hourHtml}
      ${compareHtml}
      ${detailRows}
    </div>`;
}

/* ===================================================================
 * 万年历
 * =================================================================== */
let calSelDay = 1; // 当前选中日（万年历视图内）

function initCalendar(){
  const ySel = document.getElementById('cal-year');
  const mSel = document.getElementById('cal-month');
  const now = new Date();
  for (let y=1900; y<=2100; y++){
    const o = document.createElement('option'); o.value=y; o.textContent=y+'年'; ySel.appendChild(o);
  }
  for (let m=1; m<=12; m++){
    const o = document.createElement('option'); o.value=m; o.textContent=m+'月'; mSel.appendChild(o);
  }
  ySel.value = now.getFullYear();
  mSel.value = now.getMonth()+1;
  calSelDay = now.getDate();

  // 年/月/日选择器（复用八字排盘 .lunar-trigger / .lunar-popup / .lp-* 款式）
  const ymLabel = document.getElementById('cal-ym-label');
  const ymBtn = document.getElementById('cal-ym');
  const popup = document.getElementById('cal-popup');
  const yearList = document.getElementById('cal-year-list');
  const monthGrid = document.getElementById('cal-month-grid');
  function updateYMLabel(){ ymLabel.textContent = `${ySel.value}年${mSel.value}月`; }
  function closeCalPopup(){ popup.hidden = true; ymBtn.setAttribute('aria-expanded','false'); }
  function markSel(){
    yearList.querySelectorAll('.lp-year-item').forEach(it=> it.classList.toggle('sel', +it.dataset.y === +ySel.value));
    monthGrid.querySelectorAll('.lp-month-item').forEach(it=> it.classList.toggle('sel', +it.dataset.m === +mSel.value));
  }
  for (let y=1900; y<=2100; y++){
    const b = document.createElement('button');
    b.type='button'; b.className='lp-year-item'; b.dataset.y=y; b.textContent=y+'年';
    b.onclick = ()=>{ ySel.value=y; updateYMLabel(); markSel(); renderCalendar(); };
    yearList.appendChild(b);
  }
  for (let m=1; m<=12; m++){
    const b = document.createElement('button');
    b.type='button'; b.className='lp-month-item'; b.dataset.m=m; b.textContent=m+'月';
    b.onclick = ()=>{ mSel.value=m; updateYMLabel(); markSel(); renderCalendar(); closeCalPopup(); };
    monthGrid.appendChild(b);
  }
  markSel(); updateYMLabel();

  ymBtn.onclick = (e)=>{
    e.stopPropagation();
    const open = popup.hidden;
    popup.hidden = !open;
    ymBtn.setAttribute('aria-expanded', String(open));
    if (open){
      markSel();
      popup.style.top = (ymBtn.getBoundingClientRect().bottom + 8) + 'px';
      yearList.scrollTop = Math.max(0, (ySel.value - 1900) * 30 - 110);
    }
  };
  document.addEventListener('click', (e)=>{
    if (!popup.hidden && !popup.contains(e.target) && e.target !== ymBtn){
      popup.hidden = true; ymBtn.setAttribute('aria-expanded','false');
    }
  });

  document.getElementById('cal-prev').onclick = ()=> stepMonth(-1);
  document.getElementById('cal-next').onclick = ()=> stepMonth(1);
  document.getElementById('cal-today').onclick = ()=>{
    const n = new Date();
    ySel.value = n.getFullYear(); mSel.value = n.getMonth()+1;
    calSelDay = n.getDate();
    updateYMLabel(); markSel(); renderCalendar();
  };
  renderCalendar();
}

function stepMonth(delta){
  const ySel = document.getElementById('cal-year');
  const mSel = document.getElementById('cal-month');
  let y = +ySel.value, m = +mSel.value + delta;
  if (m < 1){ m = 12; y--; } else if (m > 12){ m = 1; y++; }
  if (y < 1900) y = 1900; if (y > 2100) y = 2100;
  ySel.value = y; mSel.value = m;
  calSelDay = Math.min(calSelDay, new Date(y, m, 0).getDate());
  const lbl = document.getElementById('cal-ym-label');
  if (lbl) lbl.textContent = `${y}年${m}月`;
  renderCalendar();
}

// 日历格农历显示：每月初一显示X月 初一，其余只显示日（去掉每日重复的月份数）
function lunarCell(o){
  return o.IDayCn === '初一' ? o.IMonthCn : o.IDayCn;
}

function renderCalendar(){
  // 兜底：若农历库尚未就绪（部分预览器异步注入脚本），稍后重试，避免首屏万年历空白
  if (typeof calendar === 'undefined' || typeof calendar.solar2lunar !== 'function'){
    setTimeout(renderCalendar, 50); return;
  }
  const y = +document.getElementById('cal-year').value;
  const m = +document.getElementById('cal-month').value;
  const grid = document.getElementById('cal-grid');
  const wkCls = ['日','一','二','三','四','五','六'];
  let html = wkCls.map((w,i)=>`<div class="weekday ${i===0?'wd-sun':(i===6?'wd-sat':'')}">${w}</div>`).join('');
  const first = new Date(y, m-1, 1).getDay();
  const days = new Date(y, m, 0).getDate();
  const today = new Date();
  const isToday = (dd)=> today.getFullYear()===y && today.getMonth()+1===m && today.getDate()===dd;
  // 相邻月份日期，用于补齐网格首尾空格：无边框、淡色
  let py=y, pm=m-1; if (pm<1){ pm=12; py=y-1; }
  const prevDays = new Date(py, pm, 0).getDate();
  let ny=y, nm=m+1; if (nm>12){ nm=1; ny=y+1; }
  const adjLunar = (yy,mm,dd)=>{ const o=calendar.solar2lunar(yy,mm,dd);
    if (o.isTerm) return o.Term; if (o.lunarFestival) return o.lunarFestival;
    if (o.festival) return o.festival; return o.IDayCn==='初一'?o.IMonthCn:o.IDayCn; };
  for (let i=0;i<first;i++){ const d=prevDays-first+1+i;
    html += `<div class="cal-cell adj"><div class="g">${d}</div><div class="cell-info"><div class="l">${adjLunar(py,pm,d)}</div></div></div>`;
  }
  for (let dd=1; dd<=days; dd++){
    const h = computeHuangli(y, m, dd);
    const o = h.lunar;
    // 节气 / 节日：其名直接替代农历显示（不附农历）
    let lText = lunarCell(o);
    let lClass = 'l';
    let sub = '';
    if (o.isTerm) { lText = o.Term; lClass = 'l event term'; }
    else if (o.lunarFestival) { lText = o.lunarFestival; lClass = 'l event fest'; }
    else if (o.festival) { lText = o.festival; lClass = 'l event fest'; }
    const lu = h.jc.lu === '黄' ? 'huang' : 'hei';
    const isEvent = (o.isTerm || o.lunarFestival || o.festival) ? 'cell-event' : '';
    const gz = o.gzDay || '';
    const gCls = (gz[0] && GAN_WX[gz[0]]) ? 'wx-' + GAN_WX[gz[0]] : '';
    const zCls = (gz[1] && ZHI_WX[gz[1]]) ? 'wx-' + ZHI_WX[gz[1]] : '';
    const wd = (first + dd - 1) % 7;
    const weekend = (wd === 0 || wd === 6) ? 'weekend' : '';
    html += `<div class="cal-cell ${isToday(dd)?'today':''} ${lu} ${isEvent} ${weekend}" data-d="${dd}">
      <div class="g">${dd}</div>
      <div class="cell-info">
        <div class="${lClass}">${lText}</div>
        <div class="d"><span class="${gCls}">${gz[0]||''}</span><span class="${zCls}">${gz[1]||''}</span></div>
      </div>
    </div>`;
  }
  const trail = (7 - ((first + days) % 7)) % 7;
  for (let i=1;i<=trail;i++){
    html += `<div class="cal-cell adj"><div class="g">${i}</div><div class="cell-info"><div class="l">${adjLunar(ny,nm,i)}</div></div></div>`;
  }
  grid.innerHTML = html;
  grid.querySelectorAll('.cal-cell').forEach(cell=>{
    cell.onclick = ()=>{
      const dd = +cell.dataset.d; if (!dd) return;
      grid.querySelectorAll('.cal-cell').forEach(c=> c.classList.remove('selected'));
      cell.classList.add('selected');
      calSelDay = dd;
      renderHuangliDetail(y, m, dd);
    };
  });
  // 默认选中：优先用已选日（跨月时夹紧），否则当月选今天、其它月选 1 号
  const maxD = new Date(y, m, 0).getDate();
  let selDay = calSelDay;
  if (!selDay || selDay > maxD) selDay = (today.getFullYear()===y && today.getMonth()+1===m) ? today.getDate() : 1;
  calSelDay = selDay;
  const lbl = document.getElementById('cal-ym-label');
  if (lbl) lbl.textContent = `${y}年${m}月`;
  const selCell = grid.querySelector(`.cal-cell[data-d="${selDay}"]`);
  if (selCell){ selCell.classList.add('selected'); renderHuangliDetail(y, m, selDay); }
}

/* ===================================================================
 * 古籍收集
 * =================================================================== */
function bookVisibleList(){
  const q = booksQuery.trim();
  return BOOKS.filter(b=>{
    if (booksFilter !== 'all' && b.cat !== booksFilter) return false;
    if (q && !(b.name.includes(q) || b.meta.includes(q) || (b.school||'').includes(q))) return false;
    return true;
  });
}
function renderBooks(){
  const grid = document.getElementById('books-grid');
  const chips = document.getElementById('books-chips');
  const status = loadBookStatus();
  // 分类筛选 chips（全部 + 数据中实际存在的部类）
  const cats = [...new Set(BOOKS.map(b=>b.cat))];
  const chipData = [{key:'all', label:'全部'}].concat(cats.map(c=>({key:c, label:BOOK_CAT[c].label})));
  chips.innerHTML = chipData.map(c=>`<button class="books-chip${booksFilter===c.key?' active':''}" data-cat="${c.key}">${c.label}</button>`).join('');
  chips.querySelectorAll('.books-chip').forEach(btn=>{
    btn.onclick = ()=>{ booksFilter = btn.dataset.cat; renderBooks(); };
  });
  // 选中项若被筛掉则收起
  const list = bookVisibleList();
  if (booksSelected && !list.some(b=>b.name===booksSelected)) booksSelected = null;
  // 卡片网格
  grid.innerHTML = list.map(b=>{
    const cat = BOOK_CAT[b.cat];
    const st = status[b.name];
    const badge = st ? `<span class="book-badge" style="background:${BOOK_STATUS[st].color}">${BOOK_STATUS[st].label}</span>` : '';
    return `<div class="book-card" data-name="${b.name}" style="border-left:3px solid ${cat.color}">
      <div class="book-top"><span class="book-tag" style="color:${cat.color}">${cat.label}${b.school?' · '+b.school:''}</span>${badge}</div>
      <h3>${b.name}</h3>
      <div class="meta">${b.meta}</div>
      <div class="desc">${b.desc}</div>
      <span class="book-more">阅读状态 ›</span>
    </div>`;
  }).join('') || '<p class="hint">没有匹配的古籍。</p>';
  grid.querySelectorAll('.book-card').forEach(card=>{
    card.onclick = ()=>{
      booksSelected = card.dataset.name;
      renderBookDetail();      // 渲染并就近浮动显示（不再跳转/滚动到底部）
      renderBooksStatusbar();
    };
  });
  renderBookDetail();
  renderBooksStatusbar();
}
/* 古籍「阅读状态」就近浮动：点击书籍后，popover 出现在该书籍卡附近，而非页面底部外卡 */
let docCloseBound = false;
function positionBookPopover(card){
  const det = document.getElementById('book-detail');
  if (!det) return;
  const pw = Math.min(360, window.innerWidth - 16);
  const ph = det.offsetHeight || 160;
  const vw = window.innerWidth, vh = window.innerHeight;
  let left = 8, top = 8;
  if (card){
    const r = card.getBoundingClientRect();
    left = r.left + r.width/2 - pw/2;
    top  = r.bottom + 8;
    if (left + pw > vw - 8) left = vw - pw - 8;
    if (left < 8) left = 8;
    if (top + ph > vh - 8) top = Math.max(8, r.top - ph - 8);  // 下方不够则翻到卡上方
  }
  det.style.width = pw + 'px';
  det.style.left = left + 'px';
  det.style.top = top + 'px';
}
function onDocClickClose(e){
  const det = document.getElementById('book-detail');
  if (!det || det.hidden) return;
  if (det.contains(e.target)) return;                 // 点在 popover 内不关
  if (e.target.closest && e.target.closest('.book-card')) return; // 点别的书卡交给卡片切换
  hideBookPopover();
}
function hideBookPopover(){
  const det = document.getElementById('book-detail');
  if (det) det.hidden = true;
  booksSelected = null;
  renderBooksStatusbar();
}
function renderBookDetail(){
  const el = document.getElementById('book-detail');
  if (!booksSelected){ el.hidden = true; el.innerHTML = ''; return; }
  const b = BOOKS.find(x=>x.name===booksSelected);
  if (!b){ el.hidden = true; el.innerHTML = ''; return; }
  const status = loadBookStatus();
  const st = status[b.name];
  const cat = BOOK_CAT[b.cat];
  // 全本：有 bookKey 且 window.BOOK_TEXT 含该书全文时视为「已有全本」
  const hasFull = !!(window.BOOK_TEXT && b.bookKey && window.BOOK_TEXT[b.bookKey]);
  // 阅读状态按钮（合并进小卡顶部，各书共有、随时可设）
  const statusBtns = Object.keys(BOOK_STATUS).map(k=>{
    const on = st === k;
    const style = on ? `background:${BOOK_STATUS[k].color};border-color:${BOOK_STATUS[k].color};color:#fff` : '';
    return `<button type="button" class="book-status-btn${on?' active':''}" data-status="${k}" style="${style}">${BOOK_STATUS[k].label}</button>`;
  }).join('') + `<button type="button" class="book-status-btn clear" data-status="">清除</button>`;
  // 继续阅读：记录每本书进度，进入阅读视图（全本读全文，非全本读精选）
  const prog = loadBookProgress(b.name);
  const contLabel = hasFull ? (prog ? `继续阅读 · ${prog.pct}%` : '开始阅读') : '阅读精选';
  el.hidden = false;
  el.innerHTML = `
    <div class="bd-mini">
      <div class="bd-mini-cap">《${b.name}》阅读状态</div>
      <div class="bd-status-btns">
        ${statusBtns}
      </div>
      <div class="bd-mini-actions">
        <button type="button" class="bd-cont-btn" id="bd-cont">${contLabel}</button>
        <button type="button" class="bd-close" id="bd-close">收起</button>
      </div>
    </div>
  `;
  // 就近浮动定位到该书籍卡（卡片可能被筛选重渲染，故按 data-name 重新查找）
  const card = document.querySelector('.book-card[data-name="' + (booksSelected||'').replace(/"/g,'\\"') + '"]');
  positionBookPopover(card);
  if (!docCloseBound){ document.addEventListener('click', onDocClickClose, true); docCloseBound = true; }
  el.querySelector('#bd-close').onclick = ()=>{ booksSelected = null; renderBookDetail(); renderBooksStatusbar(); };
  el.querySelector('#bd-cont').onclick = ()=>{ const d = document.getElementById('book-detail'); if (d) d.hidden = true; openReader(b, hasFull); };
  // 阅读状态按钮：点击即设/清除，更新卡片徽标与高亮
  el.querySelectorAll('.book-status-btn').forEach(btn=>{
    btn.onclick = ()=>{
      if (!booksSelected) return;
      const s = btn.dataset.status || null;
      const m = loadBookStatus();
      if (s) m[booksSelected] = s; else delete m[booksSelected];
      saveBookStatus(m);
      renderBooks();          // 更新卡片徽标
      renderBooksStatusbar(); // 同步高亮
    };
  });
}

/* ===================== 书籍阅读进度（每本书独立记录） ===================== */
function loadBookProgress(name){
  try { const m = JSON.parse(localStorage.getItem('claw_book_progress_v1') || '{}'); return m[name] || null; }
  catch (e) { return null; }
}
function saveBookProgress(name, pct, pos){
  try {
    const m = JSON.parse(localStorage.getItem('claw_book_progress_v1') || '{}');
    m[name] = { pct: Math.max(0, Math.min(100, Math.round(pct||0))), pos: pos||0, ts: Date.now() };
    localStorage.setItem('claw_book_progress_v1', JSON.stringify(m));
  } catch (e) {}
}

/* ===================== 阅读器（继续阅读 / 全书内容 / 精选） ===================== */
let readerState = null;
function escHtml(s){ return String(s==null?'':s).replace(/[&<>]/g, function(c){ return ({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]); }); }
// 把一本书拆成「章节」数组：全本按章节标题切分；精选按 excerpt 切分
function buildSections(b, hasFull){
  if (hasFull){
    const raw = (window.BOOK_TEXT && window.BOOK_TEXT[b.bookKey]) || '';
    const lines = raw.split(/\r?\n/);
    // 只把「短标题行」当章节，避免把 【原注】/【任氏曰】/命例【干支】等正文/注释误判为目录：
    // 卷一·… / 卷首中下末 / 第X章回节篇 / 上下篇·… / 一、… / 《论…》 / 甲木调候 / 序·… / 前言附录等
    const chapRe = /^(卷[一二三四五六七八九十百千0-9首中下末终][^\n]{0,20}|第[一二三四五六七八九十百千0-9]+[章回节篇集][^\n]{0,20}|[上中下]篇[·、][^\n]{0,18}|[一二三四五六七八九十百千]+、[^\n]{0,22}|《[^》]{1,20}》[^\n]{0,8}|[甲乙丙丁戊己庚辛壬癸][木火土金水]调候|调候总则|调候应用规则|序[·、][^\n]{0,18}|自序|原序|凡例|前言|附录|后记|引子|楔子)$/;
    const sections = [];
    let cur = null;
    lines.forEach(function(ln){
      const t = ln.trim();
      if (!t) return;
      if (t.length <= 26 && chapRe.test(t)){
        cur = { title: t.slice(0, 34), lines: [] };
        sections.push(cur);
      } else {
        if (!cur){ cur = { title: '', lines: [] }; sections.push(cur); }
        cur.lines.push(t);
      }
    });
    return sections;
  }
  return (b.excerpts||[]).map(function(e, i){ return {
    title: e.title || ('选段 ' + (i+1)),
    lines: [e.source, e.translation ? ('【译文】' + e.translation) : ''].filter(Boolean)
  }; });
}
function loadReaderFs(){ const v = parseInt(localStorage.getItem('claw_reader_fs'),10); return isNaN(v)?18:v; }
function saveReaderFs(v){ try{ localStorage.setItem('claw_reader_fs', String(v)); }catch(e){} }
function updateReaderProg(body){
  const max = body.scrollHeight - body.clientHeight;
  const pct = max>0 ? Math.round((body.scrollTop/max)*100) : 0;
  const bar = document.getElementById('rd-prog-bar');
  if (bar) bar.style.width = pct + '%';
  const cont = document.getElementById('bd-cont');
  if (cont && booksSelected) cont.textContent = `继续阅读 · ${pct}%`;
}
function saveReaderPos(body, name){
  const max = body.scrollHeight - body.clientHeight;
  const pct = max>0 ? (body.scrollTop/max)*100 : 0;
  saveBookProgress(name, pct, body.scrollTop);
  updateReaderProg(body);
}
function openReader(b, hasFull){
  const sections = buildSections(b, hasFull);
  if (!sections.length || !sections.some(function(s){ return s.lines.length || s.title; })){ alert('该书暂无可读内容'); return; }
  const old = document.getElementById('reader-overlay');
  if (old) old.remove();
  const ov = document.createElement('div');
  ov.id = 'reader-overlay';
  ov.innerHTML = `
    <div class="reader-head">
      <div class="reader-title">《${b.name}》</div>
        <div class="reader-tools">
          <button type="button" class="reader-btn" id="rd-toc" title="章节目录">目录</button>
          <button type="button" class="reader-btn" id="rd-fs-down" title="缩小字体">A-</button>
          <button type="button" class="reader-btn" id="rd-fs-up" title="放大字体">A+</button>
          <button type="button" class="reader-btn" id="rd-voice" title="语音朗读">语音</button>
          <button type="button" class="reader-btn" id="rd-close" title="关闭">关闭</button>
        </div>
    </div>
    <div class="reader-prog"><div class="reader-prog-bar" id="rd-prog-bar"></div></div>
    <div class="reader-body" id="rd-body"></div>
    <div class="reader-toc-mask" id="rd-toc-mask"></div>
    <div class="reader-toc" id="rd-toc-panel">
      <div class="reader-toc-head">目录<button type="button" id="rd-toc-close" aria-label="收起目录">×</button></div>
      <div class="reader-toc-list" id="rd-toc-list"></div>
    </div>
    ${b.url && !hasFull ? `<div class="reader-foot"><a href="${b.url}" target="_blank" rel="noopener">查看原文站点 ↗</a></div>` : ''}
  `;
  document.body.appendChild(ov);
  document.body.style.overflow = 'hidden';
  const body = ov.querySelector('#rd-body');
  body.innerHTML = (function(){
    let h = '';
    sections.forEach(function(s,i){
      const secId = 'rd-sec-' + i;
      if (s.title) h += '<h3 class="reader-chap" id="' + secId + '">' + escHtml(s.title) + '</h3>';
      h += '<div class="reader-sec-body">' + s.lines.map(function(l){ return l ? '<p>' + escHtml(l) + '</p>' : ''; }).join('') + '</div>';
    });
    return h;
  })();
  // 章节目录：列出全部章节标题，点击平滑滚动到对应锚点
  const tocList = ov.querySelector('#rd-toc-list');
  const tocItemsHtml = sections.map(function(s,i){ return s.title ? '<button type="button" class="reader-toc-item" data-sec="' + i + '">' + escHtml(s.title) + '</button>' : ''; }).filter(Boolean).join('');
  const tocPanel = ov.querySelector('#rd-toc-panel');
  const tocMask = ov.querySelector('#rd-toc-mask');
  const tocBtn = ov.querySelector('#rd-toc');
  const closeToc = function(){ tocPanel.classList.remove('open'); tocMask.classList.remove('open'); };
  if (!tocItemsHtml){
    // 无可用章节：隐藏「目录」按钮，避免弹出空/错目录
    if (tocBtn) tocBtn.style.display = 'none';
    tocPanel.remove(); tocMask.remove();
  } else {
    tocList.innerHTML = tocItemsHtml;
    tocBtn.onclick = function(){ tocPanel.classList.add('open'); tocMask.classList.add('open'); };
    ov.querySelector('#rd-toc-close').onclick = closeToc;
    tocMask.onclick = closeToc;   // 点目录以外区域关闭
    tocList.querySelectorAll('.reader-toc-item').forEach(function(it){
      it.onclick = function(){ var el = document.getElementById('rd-sec-' + it.dataset.sec); if (el) el.scrollIntoView({ behavior:'smooth', block:'start' }); closeToc(); };
    });                 // 纯文本，避免注入
  }
  let fs = loadReaderFs();
  const applyFs = ()=>{ body.style.fontSize = fs + 'px'; };
  applyFs();
  // 恢复上次阅读进度
  const prog = loadBookProgress(b.name);
  requestAnimationFrame(()=>{
    if (prog && prog.pos) body.scrollTop = prog.pos;
    updateReaderProg(body);
  });
  // 滚动记录进度
  let raf = null;
  body.onscroll = ()=>{ if (raf) cancelAnimationFrame(raf); raf = requestAnimationFrame(()=>{ saveReaderPos(body, b.name); }); };
  // 字体缩放
  ov.querySelector('#rd-fs-up').onclick = ()=>{ fs = Math.min(42, fs+2); saveReaderFs(fs); applyFs(); };
  ov.querySelector('#rd-fs-down').onclick = ()=>{ fs = Math.max(12, fs-2); saveReaderFs(fs); applyFs(); };
  ov.querySelector('#rd-close').onclick = ()=> closeReader(ov);
  ov.querySelector('#rd-voice').onclick = (e)=> toggleVoice(body.innerText, e.currentTarget);
  readerState = { name: b.name, ov, body };
}
function closeReader(ov){
  stopVoice();
  if (readerState && readerState.body) saveReaderPos(readerState.body, readerState.name);
  ov.remove();
  document.body.style.overflow = '';
  readerState = null;
}

/* ===================== 语音朗读 =====================
 * 优先用原生 TTS 插件（@capacitor-community/text-to-speech）——安卓 WebView 普遍没有 Web Speech API，
 * 之前显示「语音不可用」正因如此。装了原生插件后走系统 TTS 引擎（多数国产机自带中文语音）。
 * 无插件时（如浏览器网页版）回退 Web Speech API。 */
let voiceUtter = null;
let voiceOn = false;
function getNativeTTS(){
  try{ return (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.TextToSpeech) || null; }catch(e){ return null; }
}
async function toggleVoice(text, btn){
  const tts = getNativeTTS();
  if (tts){
    if (voiceOn){ voiceOn = false; try{ await tts.stop(); }catch(e){} btn.textContent = '语音'; return; }
    voiceOn = true; btn.textContent = '停止';
    const chunks = String(text||'').split(/\n+/).map(s=>s.trim()).filter(Boolean);
    try{
      for (let i=0;i<chunks.length;i++){
        if (!voiceOn) break;
        await tts.speak({ text: chunks[i], lang: 'zh-CN', rate: 1.0 });
      }
    }catch(e){}
    voiceOn = false; btn.textContent = '语音';
    return;
  }
  // ---- Web Speech 回退（浏览器网页版）----
  if (!('speechSynthesis' in window)){ btn.textContent = '语音不可用'; btn.disabled = true; return; }
  const synth = window.speechSynthesis;
  if (synth.speaking && !synth.paused){ synth.pause(); btn.textContent = '继续朗读'; return; }
  if (synth.paused){ synth.resume(); btn.textContent = '暂停'; return; }
  synth.cancel();
  const paras = text.split(/\n+/).filter(p=>p.trim());
  let idx = 0;
  const speakNext = ()=>{
    if (idx >= paras.length){ btn.textContent = '语音'; return; }
    const u = new SpeechSynthesisUtterance(paras[idx]);
    u.lang = 'zh-CN'; u.rate = 0.95;
    u.onend = ()=>{ idx++; speakNext(); };
    u.onerror = ()=>{ btn.textContent = '语音'; };
    voiceUtter = u; synth.speak(u);
  };
  btn.textContent = '暂停';
  speakNext();
}
function stopVoice(){
  voiceOn = false;
  const tts = getNativeTTS();
  if (tts){ try{ tts.stop(); }catch(e){} }
  if ('speechSynthesis' in window){ try{ window.speechSynthesis.cancel(); }catch(e){} }
  voiceUtter = null;
}

// 阅读状态同步：详情卡已内嵌状态按钮，这里仅根据当前选中书籍高亮对应项
function renderBooksStatusbar(){
  const bar = document.getElementById('bd-status-btns');
  if (!bar) return;
  const status = loadBookStatus();
  const st = booksSelected ? status[booksSelected] : null;
  bar.querySelectorAll('.book-status-btn').forEach(btn=>{
    if (btn.classList.contains('clear')) return; // 清除按钮不高亮
    const k = btn.dataset.status || null;
    btn.classList.toggle('active', k === (st || ''));
  });
}

/* ===================================================================
 * 数理分析
 * =================================================================== */
/* ===================================================================
 * 梅花易数（数字起卦）— 与小程序引擎同源
 * 先天八卦数：乾1 兑2 离3 震4 巽5 坎6 艮7 坤8
 * =================================================================== */
const BAGUA_XT = {1:'乾',2:'兑',3:'离',4:'震',5:'巽',6:'坎',7:'艮',8:'坤'};
const XT_BAGUA = {'乾':1,'兑':2,'离':3,'震':4,'巽':5,'坎':6,'艮':7,'坤':8};
const BAGUA_WX = {'乾':'metal','兑':'metal','离':'fire','震':'wood','巽':'wood','坎':'water','艮':'earth','坤':'earth'};
const TRIGRAM_BITS = {'乾':[1,1,1],'兑':[0,1,1],'离':[1,0,1],'震':[0,0,1],'巽':[1,1,0],'坎':[0,1,0],'艮':[1,0,0],'坤':[0,0,0]};
// 由本/互/变卦的上下卦名渲染六爻卦符：bit=1 阳爻(实线)，0 阴爻(中间分隔的断线)
function guaLinesHtml(info){
  if (!info || !info.upT || !info.downT) return '';
  const bits = guaBits(info.upT, info.downT); // [下初,下二,下三,上初,上二,上三]，index0=初爻(底)
  let s = '<div class="gua-lines">';
  for (let i = 5; i >= 0; i--){            // 从顶爻(5)排到底爻(0)
    s += bits[i]
      ? '<div class="gl-row gl-yang"></div>'
      : '<div class="gl-row gl-yin"><span></span><span></span></div>';
  }
  return s + '</div>';
}
const GUA_64 = {
  '11':'乾为天','12':'天泽履','13':'天火同人','14':'天雷无妄','15':'天风姤','16':'天水讼','17':'天山遁','18':'天地否',
  '21':'泽天夬','22':'兑为泽','23':'泽火革','24':'泽雷随','25':'泽风大过','26':'泽水困','27':'泽山咸','28':'泽地萃',
  '31':'火天大有','32':'火泽睽','33':'离为火','34':'火雷噬嗑','35':'火风鼎','36':'火水未济','37':'火山旅','38':'火地晋',
  '41':'雷天大壮','42':'雷泽归妹','43':'雷火丰','44':'震为雷','45':'雷风恒','46':'雷水解','47':'雷山小过','48':'雷地豫',
  '51':'风天小畜','52':'风泽中孚','53':'风火家人','54':'风雷益','55':'巽为风','56':'风水涣','57':'风山渐','58':'风地观',
  '61':'水天需','62':'水泽节','63':'水火既济','64':'水雷屯','65':'水风井','66':'坎为水','67':'水山蹇','68':'水地比',
  '71':'山天大畜','72':'山泽损','73':'山火贲','74':'山雷颐','75':'山风蛊','76':'山水蒙','77':'艮为山','78':'山地剥',
  '81':'地天泰','82':'地泽临','83':'地火明夷','84':'地雷复','85':'地风升','86':'地水师','87':'地山谦','88':'坤为地'
};
const GUA_DESC = {
  '11':'刚健中正，自强不息','12':'履虎尾，慎行免咎','13':'和同于人，协力共进','14':'不妄为，顺天合道','15':'遇合之初，防阴渐长','16':'争讼，慎防口舌官非','17':'退避以全，适时而隐','18':'闭塞不通，待机转泰',
  '21':'决而能和，刚断去小人','22':'喜悦和顺，口舌生财','23':'顺天应人，变革更新','24':'随时而动，从善得吉','25':'非常之事，独立不惧','26':'困穷守正，静待其通','27':'感应交欢，少男少女','28':'荟萃聚集，人才汇拢',
  '31':'富有日新，大而能谦','32':'乖离反常，求同存异','33':'光明附丽，柔顺得中','34':'咬合去梗，决断除碍','35':'鼎新取象，稳重养贤','36':'事未成，慎终如始','37':'行旅在外，依义安身','38':'进长光明，步步高升',
  '41':'阳刚壮盛，戒躁用壮','42':'归妹依礼，失正则凶','43':'丰大光明，盛极当忧','44':'震动奋发，恐惧修省','45':'恒久不已，持之以正','46':'险难消解，舒缓解脱','47':'小有过越，宜下不宜上','48':'欢悦顺动，备豫有乐',
  '51':'小有蓄积，待时而发','52':'诚信感格，心交信孚','53':'齐家有序，内睦外安','54':'损上益下，与时偕行','55':'谦顺而入，渐进得通','56':'涣散离析，散财聚神','57':'渐次而进，女归吉渐','58':'观察风化，省方设教',
  '61':'等待时机，饮食宴乐','62':'节制有度，适可而止','63':'事已成，防初吉终乱','64':'万物始生，艰难创基','65':'养而不穷，井渫不食','66':'重险陷难，维心亨通','67':'见险止行，反身修德','68':'亲比相辅，择善而从',
  '71':'厚积德载，止健笃实','72':'损下益上，惩忿窒欲','73':'文饰之美，质素为本','74':'颐养正道，慎言节食','75':'蛊坏整治，振民育德','76':'启蒙养正，匪我求童','77':'止而有节，动静以时','78':'剥落侵蚀，顺止避害',
  '81':'天地交泰，安稳通达','82':'临下亲民，阳气渐长','83':'明入地中，韬光养晦','84':'一阳来复，生机重启','85':'柔顺上升，积小成高','86':'兵众用师，忧劳得正','87':'谦尊而光，卑而不可踰','88':'厚德载物，柔顺承天'
};
function guaBits(upT, downT){ return TRIGRAM_BITS[downT].concat(TRIGRAM_BITS[upT]); }
function bitsToTrigrams(bits){
  const down = bits.slice(0,3), up = bits.slice(3,6);
  const toT = b => Object.keys(TRIGRAM_BITS).find(k=>{ const v=TRIGRAM_BITS[k]; return v[0]===b[0]&&v[1]===b[1]&&v[2]===b[2]; });
  return { up: toT(up), down: toT(down) };
}
function huaGuaBits(bits){ return [bits[1],bits[2],bits[3]].concat([bits[2],bits[3],bits[4]]); }
function bianGuaBits(bits, dong){ const b = bits.slice(); b[dong-1] = b[dong-1] ? 0 : 1; return b; }
function guaInfoFromBits(bits){
  const t = bitsToTrigrams(bits);
  const u = XT_BAGUA[t.up], d = XT_BAGUA[t.down];
  return { up:u, down:d, upT:t.up, downT:t.down, name: GUA_64[`${u}${d}`] || '', desc: GUA_DESC[`${u}${d}`] || '' };
}
function meihuaGua(digits){
  if (!digits || digits.length < 2) return null;
  const n = digits.length;
  const mid = Math.ceil(n/2);
  const upSum = digits.slice(0, mid).reduce((a,b)=>a+b,0);
  const downSum = digits.slice(mid).reduce((a,b)=>a+b,0);
  const up = ((upSum - 1) % 8) + 1;
  const down = ((downSum - 1) % 8) + 1;
  const total = digits.reduce((a,b)=>a+b,0);
  const dong = ((total - 1) % 6) + 1;
  const benBits = guaBits(BAGUA_XT[up], BAGUA_XT[down]);
  const ben = { up, down, upT: BAGUA_XT[up], downT: BAGUA_XT[down], name: GUA_64[`${up}${down}`], desc: GUA_DESC[`${up}${down}`] || '' };
  const hua = guaInfoFromBits(huaGuaBits(benBits));
  const bian = guaInfoFromBits(bianGuaBits(benBits, dong));
  const yongIsDown = dong <= 3;
  const tiT = yongIsDown ? ben.upT : ben.downT;
  const yongT = yongIsDown ? ben.downT : ben.upT;
  const tiWx = BAGUA_WX[tiT], yongWx = BAGUA_WX[yongT];
  let tiYong;
  if (tiWx === yongWx) tiYong = '体用比和（平）';
  else if (WX_SHENG[tiWx] === yongWx) tiYong = '用生体（吉）';
  else if (WX_SHENG[yongWx] === tiWx) tiYong = '体生用（小耗）';
  else if (WX_KE[tiWx] === yongWx) tiYong = '体克用（吉）';
  else tiYong = '用克体（凶）';
  return { dong, ben, hua, bian, tiT, yongT, tiWx, yongWx, tiWxName: WX_NAME[tiWx], yongWxName: WX_NAME[yongWx], tiYong, xtRef: '先天八卦数：乾1 兑2 离3 震4 巽5 坎6 艮7 坤8' };
}

function baziMathHtml(b){
  if (!b) return '<p class="hint">请先在八字排盘中排盘，再来查看八字数理。</p>';
  const GAN_YIN = {甲:1,丙:1,戊:1,庚:1,壬:1};           // 阳干
  const ZHI_YIN = {子:1,寅:1,辰:1,午:1,申:1,戌:1};       // 阳支
  const HETU = {wood:'3·8',fire:'2·7',earth:'5·10',metal:'4·9',water:'1·6'}; // 河图生成数
  const pillars = [['年柱',b.year],['月柱',b.month],['日柱',b.day],['时柱',b.hour]];

  // —— 五行数理（个数 · 旺衰）——
  const wx = b.wx || {wood:0,fire:0,earth:0,metal:0,water:0};
  const wxArr = [['wood','木'],['fire','火'],['earth','土'],['metal','金'],['water','水']];
  const maxWx = Math.max(...wxArr.map(([k])=>wx[k]));
  const minWx = Math.min(...wxArr.map(([k])=>wx[k]));
  const wxRows = wxArr.map(([k,name])=>{
    const v = wx[k]; const pct = Math.max(6, Math.round(v/maxWx*100));
    const tag = v===maxWx ? ' <i class="wx-strong">旺</i>' : (v===minWx && v<maxWx ? ' <i class="wx-weak">弱</i>' : '');
    return `<div class="wx-row"><span class="wx-name">${name}${tag}</span><div class="wx-track"><div class="wx-fill wx-${k}" style="width:${pct}%"></div></div><span class="wx-num">${v}</span></div>`;
  }).join('');

  // —— 十神格局（天干 + 地支藏干）——
  const SS = ['比肩','劫财','食神','伤官','正财','偏财','正官','七杀','正印','偏印'];
  const ssCount = {}; SS.forEach(s=>ssCount[s]=0);
  pillars.forEach(([,gz])=>{
    const s1 = shiShen(b.dayMaster, b.dayMasterWx, gz[0], GAN_WX[gz[0]]); if (s1) ssCount[s1]++;
    (HIDDEN[gz[1]]||[]).forEach(hg=>{ const s2 = shiShen(b.dayMaster, b.dayMasterWx, hg, GAN_WX[hg]); if (s2) ssCount[s2]++; });
  });
  const ssHtml = SS.map(s=> ssCount[s] ? `<span class="ss-chip">${s}<i>${ssCount[s]}</i></span>` : '').filter(Boolean).join('') || '<span class="hint">—</span>';

  // —— 四柱纳音 ——
  const nayinRows = pillars.map(([r,gz])=>{
    const ny = AD_NAYIN[gz] || '';
    return `<tr><td>${r}</td><td>${gz}</td><td>${ny}</td><td>${AD_NAYIN_GONG[r]}</td><td class="ny-desc">${AD_NAYIN_DESC[ny]||''}</td></tr>`;
  }).join('');

  // —— 各柱详表：阴阳 / 五行 / 天干十神 / 河图生成数 ——
  const rows = pillars.map(([r,gz])=>{
    const g = gz[0], z = gz[1];
    const yinG = GAN_YIN[g]?'阳':'阴', yinZ = ZHI_YIN[z]?'阳':'阴';
    const ssG = shiShen(b.dayMaster, b.dayMasterWx, g, GAN_WX[g]);
    return `<tr><td>${r}</td><td>${gz}</td><td>${yinG}${yinZ}</td>
        <td>${wxTag(GAN_WX[g])} / ${wxTag(ZHI_WX[z])}</td>
        <td>${ssG||'—'}</td><td>${HETU[GAN_WX[g]]} / ${HETU[ZHI_WX[z]]}</td></tr>`;
  }).join('');

  const xi = (b.xiNames||[]).join('、') || '—';
  const ji = (b.jiNames||[]).join('、') || '—';
  const strength = b.strengthLabel ? `；日主强弱：<b>${b.strengthLabel}</b>` : '';
  return `
    <p class="hint">日主 <b>${b.dayMaster}</b>（${WX_NAME[b.dayMasterWx]}）${strength}。</p>
    <div class="bm-block">
      <div class="bm-sub">五行数理<span class="bm-sub-note">（各五行出现次数 · 旺衰）</span></div>
      <div class="wx-chart">${wxRows}</div>
    </div>
    <div class="bm-block">
      <div class="bm-sub">十神格局<span class="bm-sub-note">（天干与地支藏干分布）</span></div>
      <div class="ss-wrap">${ssHtml}</div>
    </div>
    <div class="bm-block">
      <div class="bm-sub">四柱纳音</div>
      <table>
        <thead><tr><th>柱</th><th>干支</th><th>纳音</th><th>宫位</th><th>简释</th></tr></thead>
        <tbody>${nayinRows}</tbody>
      </table>
    </div>
    <table>
      <thead><tr><th>柱</th><th>干支</th><th>阴阳</th><th>五行（干/支）</th><th>天干十神</th><th>河图生成数</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>
    <p class="hint" style="margin-top:14px">喜用神：<b class="good">${xi}</b>；忌神：<b class="bad">${ji}</b>。
      五行分布：木${b.wx.wood} 火${b.wx.fire} 土${b.wx.earth} 金${b.wx.metal} 水${b.wx.water}。
      河图数取天一生水…地十成之生成之数，仅作术数趣味参考。</p>`;
}
function renderBaziMath(){
  const html = window.lastBazi ? baziMathHtml(window.lastBazi)
    : '<p class="hint">请先在八字排盘中排盘。</p>';
  const out = document.getElementById('bazi-math-out');
  if (out) out.innerHTML = html;
  const inline = document.getElementById('bazi-math-inline');
  if (inline) inline.innerHTML = html;
}

function renderNameStrokes(){
  const s = document.getElementById('name-surname').value.trim();
  const g = document.getElementById('name-given').value.trim();
  syncStrokeOverride(s + g);
  if (s && g) {
    computeName();
  } else {
    // 只填了一个字段时清空结果
    document.getElementById('name-math-out').innerHTML = '';
  }
}
function syncStrokeOverride(chars){
  const wrap = document.getElementById('name-stroke-override');
  if (!wrap) return;
  const row = document.getElementById('name-stroke-row');
  const list = (chars || '').split('').filter(c => c);
  let html = '';
  list.forEach((c, i) => {
    const def = STROKE[c] ? STROKE[c] : '';
    html += `<label class="nsr-item">${c}<input type="number" min="1" max="60" data-i="${i}" value="${def}" placeholder="笔" /></label>`;
  });
  wrap.innerHTML = html;
  // 标签与微调输入框同步显示/隐藏：没有姓名汉字时不显示整行，避免“空标签”
  if (row) row.style.display = list.length ? '' : 'none';
  wrap.querySelectorAll('input').forEach(inp => { inp.addEventListener('input', computeName); });
}

/* ---------- 起名：八字喜用神结合 ---------- */
const WX_KEY = {'木':'wood','火':'fire','土':'earth','金':'metal','水':'water'};
const SHENGXIAO = {
  子:{wx:'water', xi:['metal','water','wood'], ji:['earth','fire'], label:'鼠'},
  丑:{wx:'earth', xi:['fire','earth','metal'], ji:['water','wood'], label:'牛'},
  寅:{wx:'wood', xi:['water','wood','fire'], ji:['metal','earth'], label:'虎'},
  卯:{wx:'wood', xi:['water','wood'], ji:['metal'], label:'兔'},
  辰:{wx:'earth', xi:['water','fire','earth','metal'], ji:['wood'], label:'龙'},
  巳:{wx:'fire', xi:['wood','fire','earth'], ji:['water','metal'], label:'蛇'},
  午:{wx:'fire', xi:['wood','fire','earth'], ji:['water','metal'], label:'马'},
  未:{wx:'earth', xi:['fire','earth','metal'], ji:['water','wood'], label:'羊'},
  申:{wx:'metal', xi:['earth','metal','water'], ji:['fire','wood'], label:'猴'},
  酉:{wx:'metal', xi:['earth','metal','water'], ji:['fire','wood'], label:'鸡'},
  戌:{wx:'earth', xi:['fire','earth','metal'], ji:['water','wood'], label:'狗'},
  亥:{wx:'water', xi:['metal','water','wood'], ji:['earth','fire'], label:'猪'}
};
let nameBirthYear = null;  // 手动输入的出生年（用于生肖）
let nameGender = 'male';   // 起名页性别（原起名页男/女按钮已并入共享时间滚轮，由 dp-gender 同步读写）
// 性别持久化：与 Birth（clawBirth）一样需要跨 App 关闭/重启保留，否则重启复位“男”
const GENDER_KEY = 'clawGender';
function saveGender(g){ try{ if (g==='male'||g==='female') localStorage.setItem(GENDER_KEY, g); }catch(e){} }
function loadGender(){ try{ const g = localStorage.getItem(GENDER_KEY); return (g==='male'||g==='female')?g:'male'; }catch(e){ return 'male'; } }
function restoreGender(){
  const g = loadGender();
  nameGender = g;
  const r = document.querySelector('input[name="gender"][value="'+g+'"]'); if (r) r.checked = true;
}

/* ---------- 三才五格分析 ---------- */
function wxRelation(aWx, bWx){
  if (!aWx || !bWx) return { type:'—', grade:'', desc:'' };
  if (aWx === bWx) return { type:'比和', grade:'吉', desc:'五行相同，相互助益' };
  if (WX_SHENG[aWx] === bWx) return { type:'相生', grade:'吉', desc:'相生相助' };
  if (WX_SHENG[bWx] === aWx) return { type:'相生', grade:'半吉', desc:'反向相生' };
  return { type:'相克', grade:'凶', desc:'相克制约' };
}
function getWx(num){
  const L = liuShu(num);
  return L.wx;
}
function sancaiDetail(tian, ren, di, cells){
  const tianWx = getWx(tian);
  const renWx = getWx(ren);
  const diWx = getWx(di);
  const t2r = wxRelation(tianWx, renWx);
  const r2d = wxRelation(renWx, diWx);
  const scoreMap = { '吉':2, '半吉':1, '凶':0 };
  const sum = (scoreMap[t2r.grade]||0) + (scoreMap[r2d.grade]||0);
  let summary, suggestion;
  if (sum >= 3) {
    summary = '三才配置优良，五行流通有情，整体趋向通达。';
    suggestion = '此姓名配置相生相助，天地人三才和谐，可充分扬其所长。';
  } else if (sum === 2) {
    summary = '三才配置尚可，五行配合度较好，个别方面需注意搭配。';
    suggestion = '可考虑在姓名使用中注意补齐被克之五行。';
  } else {
    summary = '三才配置欠佳，五行有克无生，建议斟酌搭配。';
    suggestion = '建议调整姓名用字，使天格→人格→地格五行相生流通。';
  }
  const totalCell = cells ? cells.find(c=>c.name==='总格') : null;
  const jxScore = { '吉':85, '半吉':65, '凶':40 };
  let scores = cells ? cells.map(c => jxScore[c.jx] || 50) : [60];
  if (totalCell) {
    const ti = cells.findIndex(c => c.name==='总格');
    if (ti >= 0) scores[ti] = (scores[ti] || 50) * 1.2;
  }
  const overallScore = Math.round(scores.reduce((a,b)=>a+b,0) / scores.length);
  const goodCount = cells ? cells.filter(c=>c.jx==='吉').length : 0;
  const badCount = cells ? cells.filter(c=>c.jx==='凶').length : 0;
  return {
    tianWx: WX_NAME[tianWx]||'',
    renWx: WX_NAME[renWx]||'',
    diWx: WX_NAME[diWx]||'',
    t2r, r2d,
    summary, suggestion,
    overallScore,
    stable: goodCount >= 3 && badCount === 0
  };
}

/* 评估一个具体名字：五格三才 + 八字补益，返回结构化结果（不渲染） */
function evaluateName(surname, given, compound, bazi){
  const chars = (surname + given).split('');
  const strokes = chars.map(c => STROKE[c]);
  if (strokes.some(s => !s)) return null;
  const s1 = strokes[0];
  const s2 = chars.length>1 && surname.length>1 ? strokes[1] : 0;
  const g1 = strokes[surname.length];
  const g2 = chars.length > surname.length+1 ? strokes[surname.length+1] : 0;
  const isCompound = (surname.length>=2) && compound;
  let tian, ren, di, wai, zong;
  if (isCompound){ tian=s1+s2; ren=s2+g1; di=g2?g1+g2:g1+1; zong=s1+s2+g1+(g2||0); wai=s1+(g2||1); }
  else { tian=s1+1; ren=s1+g1; di=g2?g1+g2:g1+1; zong=s1+g1+(g2||0); wai=g2?(g2+1):2; }
  const jxClass = j => j==='吉'?'good':(j==='凶'?'bad':'mid');
  const cells = [['天格',tian],['人格',ren],['地格',di],['外格',wai],['总格',zong]].map(([name,num])=>{
    const L = liuShu(num);
    return { name, num, wx:L.wx, wxName:WX_NAME[L.wx], jx:L.jx, jxClass:jxClass(L.jx), desc:L.desc };
  });
  const sancai = sancaiDetail(tian, ren, di, cells);
  let baziInfo = null;
  if (bazi){
    const xiKeys = [...new Set((bazi.xiNames||[]).map(n=>WX_KEY[n]).filter(Boolean))];
    const jiKeys = [...new Set((bazi.jiNames||[]).map(n=>WX_KEY[n]).filter(Boolean))];
    const nameWx = strokes.map(s=> liuShu(s).wx);
    const hitXi = xiKeys.filter(k=> nameWx.includes(k));
    const hitJi = jiKeys.filter(k=> nameWx.includes(k));
    if (hitJi.length>0) sancai.overallScore = Math.max(30, sancai.overallScore - 15);
    else if (hitXi.length>0) sancai.overallScore = Math.min(96, sancai.overallScore + 10);
    let verdict;
    if (hitJi.length>0) verdict = {cls:'bad', text:`含忌神（${hitJi.map(k=>WX_NAME[k]).join('、')}），与八字相损`};
    else if (hitXi.length>0) verdict = {cls:'good', text:`含喜用神（${hitXi.map(k=>WX_NAME[k]).join('、')}），可补益命局`};
    else verdict = {cls:'mid', text:`未直接补益喜用神（喜：${xiKeys.map(k=>WX_NAME[k]).join('、')}）`};
    baziInfo = { xiKeys, jiKeys, hitXi, hitJi, verdict };
  }
  return { chars, surname, given, compound:isCompound, strokes, ge:{tian,ren,di,wai,zong}, cells, sancai, bazi:baziInfo, score:sancai.overallScore };
}

/* 批量生成候选名字 */
function generateNames(surname, gender, bazi, wordCount){
  if (!surname) return [];
  const compound = surname.length>=2;
  const gk = (gender==='male'||gender==='m') ? 'm' : (gender==='female'||gender==='f') ? 'f' : gender;
  let pool = NAME_WORDS.filter(w => w.g===gk || w.g==='u');
  if (!pool.length) pool = NAME_WORDS.slice();
  const xiKeys = (bazi && bazi.xiNames) ? [...new Set((bazi.xiNames||[]).map(n=>WX_KEY[n]).filter(Boolean))] : [];
  const ranked = pool.slice().sort((a,b)=> b.lv - a.lv);
  const top = ranked.slice(0, Math.min(50, ranked.length));
  const results = [];
  if (wordCount === 1){
    top.forEach(w => { const r = evaluateName(surname, w.c, compound, bazi); if (r) results.push(r); });
  } else {
    for (let i=0;i<top.length;i++){
      for (let j=0;j<top.length;j++){
        if (i===j) continue;
        const r = evaluateName(surname, top[i].c+top[j].c, compound, bazi);
        if (r) results.push(r);
      }
    }
  }
  results.forEach(r=>{
    r.lvTotal = r.chars.reduce((s,c)=>{ const wd = NAME_WORDS.find(x=>x.c===c); return s + (wd?wd.lv:0); }, 0);
    if (xiKeys.length && r.bazi && r.bazi.hitXi.length===0 && r.bazi.hitJi.length===0) r.score = Math.max(20, r.score - 8);
  });
  // 排序：先按综合评分，再用“喜忌命中”作为显式次级键——命中喜用神加分靠前、命中忌神减分靠后。
  // 这样八字（喜忌）一变，候选顺序会明显不同（常理：补益命局的字应排在前面）。
  results.sort((a,b)=>{
    const aw = a.bazi ? (a.bazi.hitXi.length*3 - a.bazi.hitJi.length*4) : 0;
    const bw = b.bazi ? (b.bazi.hitXi.length*3 - b.bazi.hitJi.length*4) : 0;
    return (b.score - a.score) || (bw - aw) || (b.lvTotal - a.lvTotal);
  });
  return results.slice(0, wordCount===1 ? 20 : 24);
}

/* 渲染候选列表 */
function renderCandidates(list){
  const box = document.getElementById('name-candidates');
  if (!box) return;
  if (!list || !list.length){ box.innerHTML = '<p class="hint">暂未生成候选名字。请先在上方填写姓氏（建议同时填出生信息或载入八字页命盘以按喜用神补益），再点生成候选名字。</p>'; return; }
  const cards = list.map(r=>{
    const nameStr = r.chars.join('');
    const strokeTags = r.chars.map((c,i)=>`${c}<small class="ns-stroke">${r.strokes[i]}</small>`).join(' ');
    const geCells = r.cells.map(c=>`<span class="nc-mini ${c.jxClass}">${c.name}${c.num}<i>${c.jx}</i></span>`).join('');
    const wxChips = r.chars.map((c,i)=>{ const w=liuShu(r.strokes[i]).wx; return `<span class="bx-chip wx-${w}">${WX_NAME[w]}</span>`; }).join('');
    const mean = r.chars.map(c=>{ const wd=NAME_WORDS.find(x=>x.c===c); return wd?wd.m:''; }).filter(Boolean).join('；');
    const bx = r.bazi ? `<div class="bx-verdict ${r.bazi.verdict.cls}">${r.bazi.verdict.text}</div>` : '';
    return `<div class="cand-card" data-surname="${r.surname}" data-given="${r.given}">
      <div class="cand-head"><span class="cand-name">${nameStr}</span><span class="cand-score ${r.score>=70?'good':'mid'}">${r.score}<small>分</small></span></div>
      <div class="cand-strokes">${strokeTags}</div>
      <div class="cand-ge">${geCells}</div>
      <div class="cand-wx">五行 ${wxChips}</div>
      ${bx}
      <div class="cand-sancai">三才：${r.sancai.summary}</div>
      <div class="cand-mean">寓意：${mean}</div>
    </div>`;
  }).join('');
  box.innerHTML = cards;   // 直接平铺候选卡（二层结构：候选区 > 候选卡），不再套外层 cand-list
  // 点击候选卡 → 载入到上方「姓名分析」框，展示完整五格三才 / 八字补益 / 生肖宜忌
  box.querySelectorAll('.cand-card').forEach(el => {
    el.addEventListener('click', () => {
      // 候选卡自成一体（已含分数/五格/三才/寓意），点选仅高亮标记「已选」。
      // 不再写入上方「起名信息」输入框——那里是为「已有名字」服务、供「综合评分」解析，
      // 两块功能彻底解耦、互不干扰（候选生成属独立工具）。
      box.querySelectorAll('.cand-card').forEach(x => x.classList.remove('sel'));
      el.classList.add('sel');
    });
  });
}

/* 触发智能起名 */
function doGenerate(){
  const surname = (document.getElementById('name-surname').value || '').trim();
  if (!surname){ const box=document.getElementById('name-candidates'); if(box) box.innerHTML='<p class="form-warn"><svg class="fw-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2.6 L22.6 21 H1.4 Z" fill="#e23b3b"/><rect x="11" y="8.4" width="2" height="6.6" rx="1" fill="#fff"/><circle cx="12" cy="18" r="1.35" fill="#fff"/></svg>请先在上方填写姓氏</p>'; return; }
  const gender = nameGender || 'male';
  const wcEl = document.querySelector('input[name="name-count"]:checked');
  const wordCount = wcEl ? (wcEl.value === '1' ? 1 : 2) : 2;
  // 是否结合八字喜用：勾选才传命盘（八字页命盘或按出生时间所算），取消则纯按五格三才+寓意起名，
  // 这样“结合八字喜用”勾选/取消会明显改变候选顺序与补益结论，开关才有意义。
  const useBazi = document.getElementById('name-use-bazi').checked;
  let bazi = null;
  if (useBazi){
    if (window.lastBazi) bazi = window.lastBazi;   // 直接引用八字页命盘（与 computeName 同源）
    else {
      const b = Birth.get();   // 统一出生时间数据源
      const by = b.y, bm = b.m, bd = b.d, bh = b.shichen;
      if (by>=1900 && bm>=1 && bd>=1){
        const hm = shichenToHM(bh);
        const r = computeBazi(by,bm,bd,hm[0],hm[1],gender,{calType:'solar'});
        if (r && !r.error){ bazi = r; nameBirthYear = by; }
      }
    }
  }
  renderCandidates(generateNames(surname, gender, bazi, wordCount));
}

function computeName(){
  const s = document.getElementById('name-surname').value.trim();
  const g = document.getElementById('name-given').value.trim();
  const compound = s.length >= 2;  // 复姓以“姓氏长度≥2”统一判定（与 generateNames 一致，不再依赖复姓勾选框）
  const sOverride = readStrokeOverride();
  const chars = (s + g).split('');
  if (chars.length === 0){ document.getElementById('name-math-out').innerHTML=''; return; }
  // 只有姓氏、还没有名字（如新生儿）：五格三才需名字才能算，缺失名字笔画会得到 NaN 并崩溃，给出温和提示后返回
  if (!g){ document.getElementById('name-math-out').innerHTML = '<p class="hint">输入名字后可查看五格三才分析；新生儿只有姓氏时，可直接点下方「生成候选名字」按性别取名。</p>'; return; }
  // 从康熙字典自动取笔画（允许笔画微调覆盖）
  let strokes = chars.map(c => STROKE[c]);
  if (sOverride && sOverride.length === chars.length) strokes = strokes.map((v,i)=> sOverride[i] > 0 ? sOverride[i] : v);
  const unknown = chars.filter((c,i) => !strokes[i]);
  if (unknown.length > 0){
    document.getElementById('name-math-out').innerHTML = `<p class="hint">以下字不在笔画字典中：${unknown.join('、')}，请检查输入；或在下方笔画微调手动填写康熙笔画。</p>`;
    return;
  }
  const s1 = strokes[0];
  const s2 = chars.length>1 && s.length>1 ? strokes[1] : 0;
  const g1 = strokes[s.length];
  const g2 = chars.length > s.length+1 ? strokes[s.length+1] : 0;
  const isCompound = (s.length>=2) && compound;

  let tian, ren, di, zong, wai;
  if (isCompound){
    tian = s1 + s2; ren = s2 + g1;
    di = g2 ? g1+g2 : g1+1; zong = s1 + s2 + g1 + (g2||0); wai = s1 + (g2||1);
  } else {
    tian = s1 + 1; ren = s1 + g1;
    di = g2 ? g1+g2 : g1+1; zong = s1 + g1 + (g2||0); wai = g2 ? (g2+1) : 2;
  }

  const jxClass = j => j==='吉'?'good':(j==='凶'?'bad':'mid');
  const WX_SYMBOL = {wood:'木',fire:'火',earth:'土',metal:'金',water:'水'};
  const GE_YI = {
    '天格':'祖先根基·家风渊源，主先天格局与长辈缘分',
    '人格':'姓名核心，主一生主运、性格与事业中枢',
    '地格':'前运青年运，主少年至中年根基与家庭',
    '外格':'副运·社交人际，主外界助力与人际缘分',
    '总格':'后运一生总纲，主中晚年的综合成就'
  };
  const cells = [['天格',tian],['人格',ren],['地格',di],['外格',wai],['总格',zong]].map(([name,num])=>{
    const L = liuShu(num);
    return { name, num, wx:L.wx, wxName:WX_NAME[L.wx], jx:L.jx, jxClass:jxClass(L.jx), desc:L.desc, yi:GE_YI[name] };
  });

  const sancai = sancaiDetail(tian, ren, di, cells);

  // ===== 八字喜用神结合分析 =====
  const useBazi = document.getElementById('name-use-bazi').checked;
  let bazi = null, baziErr = '';
  if (useBazi){
    // 优先引用八字页已算好的命盘（与数理页同范式：直接引用，不依赖手动点载入）；其次用统一出生时间所算
    if (window.lastBazi) { bazi = window.lastBazi; }
    else {
      const b = Birth.get();
      let by, bm, bd, bh;
      if (b && b.y>=1900 && b.m>=1 && b.d>=1){
        by = b.y; bm = b.m; bd = b.d; bh = (b.shichen != null) ? b.shichen : 6;
      }
      const bg = nameGender || 'male';
      if (by>=1900 && bm>=1 && bd>=1){
        nameBirthYear = by;
        const hm = shichenToHM(bh);
        const r = computeBazi(by, bm, bd, hm[0], hm[1], bg, { calType:'solar' });
        if (r && r.error) baziErr = r.error; else bazi = r;
      }
    }
  }
  let baziHtml = '';
  if (baziErr){
    baziHtml = `<div class="nr-bazi"><div class="nb-err">⚠ 八字排盘：${baziErr}</div></div>`;
  } else if (bazi){
    const xiKeys = [...new Set((bazi.xiNames||[]).map(n=>WX_KEY[n]).filter(Boolean))];
    const jiKeys = [...new Set((bazi.jiNames||[]).map(n=>WX_KEY[n]).filter(Boolean))];
    const nameWx = strokes.map(s=> liuShu(s).wx);
    const hitXi = xiKeys.filter(k=> nameWx.includes(k));
    const hitJi = jiKeys.filter(k=> nameWx.includes(k));
    if (hitJi.length>0) sancai.overallScore = Math.max(30, sancai.overallScore - 15);
    else if (hitXi.length>0) sancai.overallScore = Math.min(96, sancai.overallScore + 10);
    const xiChips = xiKeys.map(k=>`<span class="bx-chip wx-${k}">${WX_NAME[k]}</span>`).join('');
    const jiChips = jiKeys.map(k=>`<span class="bx-chip bx-ji wx-${k}">${WX_NAME[k]}</span>`).join('');
    let bxVerdict;
    if (hitJi.length>0) bxVerdict = `<div class="bx-verdict bad">⚠ 名字五行含<b>忌神（${hitJi.map(k=>WX_NAME[k]).join('、')}）</b>，与八字相损，建议替换为喜用神之字。</div>`;
    else if (hitXi.length>0) bxVerdict = `<div class="bx-verdict good">✓ 名字五行含<b>喜用神（${hitXi.map(k=>WX_NAME[k]).join('、')}）</b>，可补益八字、助旺命局。</div>`;
    else bxVerdict = `<div class="bx-verdict mid">○ 名字五行未直接补益喜用神（喜：${xiKeys.map(k=>WX_NAME[k]).join('、')}），可改用含该五行之字增强。</div>`;
    let sxHtml = '';
    if (nameBirthYear && !isNaN(nameBirthYear)){
      const ZHIS = ['子','丑','寅','卯','辰','巳','午','未','申','酉','戌','亥'];
      const branch = ZHIS[((nameBirthYear-4)%12+12)%12];
      const sx = SHENGXIAO[branch];
      if (sx){
        const sxXi = sx.xi.map(k=>`<span class="bx-chip wx-${k}">${WX_NAME[k]}</span>`).join('');
        const sxJi = sx.ji.map(k=>`<span class="bx-chip bx-ji wx-${k}">${WX_NAME[k]}</span>`).join('');
        sxHtml = `<div class="bx-sx"><span class="bx-sx-label">生肖${sx.label}喜忌</span> 喜用 ${sxXi} ｜ 宜避 ${sxJi}</div>`;
      }
    }
    const srcNote = window.lastBazi ? '（数据来自八字页已排命盘）' : '（依所填公历出生时间排盘）';
    baziHtml = `<div class="nr-bazi">
        <div class="nb-title">八字喜用神 · 起名补益${srcNote}</div>
        <div class="bx-line">日主 <b>${bazi.dayMaster}</b>（${WX_NAME[bazi.dayMasterWx]}）｜强弱 <b>${bazi.strengthLabel||'—'}</b></div>
        <div class="bx-row"><span class="bx-k">喜用神</span> ${xiChips}</div>
        <div class="bx-row"><span class="bx-k">忌神</span> ${jiChips}</div>
        ${bxVerdict}
        ${sxHtml}
      </div>`;
  }

  // 五格卡片
  const cardsHtml = cells.map(c => `
    <div class="nc-card ${c.jxClass}">
      <div class="ncc-title">${c.name}</div>
      <div class="ncc-num">${c.num}</div>
      <div class="ncc-wx wx-${c.wx}">${c.wxName}</div>
      <div class="ncc-jx ${c.jxClass}">${c.jx}</div>
      <div class="ncc-desc">${c.desc}</div>
    </div>
  `).join('');
  // 五格释义
  const yiHtml = cells.map(c => `<span class="ge-yi"><b>${c.name}</b>：${c.yi}</span>`).join('');

  // 三才流（标注成功运 / 基础运）
  const arrowClass = g => g==='吉'?'good':(g==='凶'?'bad':'mid');
  const scHtml = `
    <div class="sc-node">天<span class="sc-wx">${sancai.tianWx}</span></div>
    <div class="sc-arrow ${arrowClass(sancai.t2r.grade)}">${sancai.t2r.type}</div>
    <div class="sc-label">成功运</div>
    <div class="sc-node">人<span class="sc-wx">${sancai.renWx}</span></div>
    <div class="sc-arrow ${arrowClass(sancai.r2d.grade)}">${sancai.r2d.type}</div>
    <div class="sc-label">基础运</div>
    <div class="sc-node">地<span class="sc-wx">${sancai.diWx}</span></div>
  `;

  document.getElementById('name-math-out').innerHTML = `
    <div class="nr-result">
      <div class="nr-header">
        <span class="nr-title">${chars.map((c,i)=> c+'<small class=\"ns-stroke\">'+strokes[i]+'</small>').join(' ')}${isCompound?'（复姓）':''}</span>
        <span class="nr-score ${sancai.overallScore>=70?'good':'mid'}">综合评分 <b>${sancai.overallScore}</b></span>
      </div>
      <div class="nr-cards">${cardsHtml}</div>
      <div class="nr-geyi">${yiHtml}</div>
      <div class="nr-sancai">
        <div class="ns-title">三才配置（天→人→地）</div>
        <div class="sc-flow">${scHtml}</div>
        <p class="sc-summary">${sancai.summary}</p>
        <p class="sc-suggest">💡 ${sancai.suggestion}</p>
      </div>
      ${baziHtml}
    </div>`;
}
function readStrokeOverride(){
  const wrap = document.getElementById('name-stroke-override');
  if (!wrap) return null;
  const inputs = wrap.querySelectorAll('input');
  if (!inputs.length) return null;
  const vals = Array.from(inputs).map(i => parseInt(i.value, 10));
  return vals.some(v => !isNaN(v) && v > 0) ? vals : null;
}

function initNameBirth(){
  const birthBtn = document.getElementById('name-birth-btn');
  if (birthBtn) birthBtn.addEventListener('click', ()=>dwOpen({ calType:'solar' }));
  const ub = document.getElementById('name-use-bazi');
  if (ub){
    const onToggle = () => {
      syncNameBirthLabel(true);
      computeName();
      // 勾选/取消结合八字喜用：若已生成候选名字，实时按新喜忌重算候选列表（否则切了开关名字不变）
      const nbox = document.getElementById('name-candidates');
      if (nbox && nbox.querySelector('.cand-card')){ try { doGenerate(); } catch(e){} }
    };
    ub.addEventListener('input', onToggle);
    ub.addEventListener('change', onToggle);
  }
  const genBtn = document.getElementById('name-generate');
  if (genBtn) genBtn.addEventListener('click', doGenerate);
  // 单字名/双字名 单选切换：若已生成候选，实时按新字数重算候选列表
  document.querySelectorAll('input[name="name-count"]').forEach(r=> r.addEventListener('change', ()=>{
    const nbox = document.getElementById('name-candidates');
    if (nbox && nbox.querySelector('.cand-card')){ try { doGenerate(); } catch(e){} }
  }));
}

/* ===================================================================
 * 常见数字数理（身份证 / 车牌 / 手机 / 门牌）
 * 数字五行：1,2 木；3,4 火；5,6 土；7,8 金；9,0 水
 * =================================================================== */
const DIGIT_WX = {1:'wood',2:'wood',3:'fire',4:'fire',5:'earth',6:'earth',7:'metal',8:'metal',9:'water',0:'water'};

/* ---------- 八星数字能量学（手机 / 车牌选号主流体系） ---------- */
const BAXING = {
  '天医': { cls:'bx-good', nums:['13','31','68','86','49','94','27','72'], yi:'主财运、婚姻、贵人，最吉之星',
    detail:[
      '财运：正财稳健、易遇贵人，利积蓄与长期经营。',
      '感情：婚恋和谐、彼此体贴，为上婚组合。',
      '健康：气场温润、身康少疾（民俗说法，非医学结论）。',
      '性格：宽厚包容，乐助人也得人助。'
    ]},
  '延年': { cls:'bx-good', nums:['19','91','78','87','26','62','34','43'], yi:'主事业、能力、领导力，次吉',
    detail:[
      '事业：责任心强、能扛事，利管理与专业深耕。',
      '财运：凭能力得正财，稳中有进，不尚投机。',
      '健康：精力充沛，但易操劳过耗。',
      '性格：主见分明、自主果断。'
    ]},
  '生气': { cls:'bx-good', nums:['14','41','67','76','28','82','39','93'], yi:'主贵人、乐观、人缘，吉',
    detail:[
      '人际：人缘佳、贵人多，逢难常得帮扶。',
      '心态：乐观豁达，抗压与复原力强。',
      '财运：机会型进益，随缘而生。',
      '性格：随和开朗、不拘小节。'
    ]},
  '伏位': { cls:'bx-mid',  nums:['11','22','44','66','33','77','88','99'], yi:'主延续、平稳、保守，平',
    detail:[
      '趋势：延续前态、循序渐进，少大起大落。',
      '事业：守成稳定，宜深耕不宜冒进。',
      '感情：平稳持久，但稍欠激情。',
      '性格：踏实谨慎、念旧固执。'
    ]},
  '六煞': { cls:'bx-bad', nums:['16','61','47','74','38','83','29','92'], yi:'主情感纠缠、人际困扰',
    detail:[
      '感情：易生纠葛、多角或冷战，沟通耗神。',
      '人际：敏感多疑，关系起伏不定。',
      '事业：易受情绪干扰、效率下滑。',
      '健康：多思伤神，注意睡眠与情志。'
    ]},
  '祸害': { cls:'bx-bad', nums:['17','71','89','98','46','64','23','32'], yi:'主口舌、是非、健康耗损',
    detail:[
      '人际：口舌是非多，易因言招怨。',
      '健康：传统认为耗气伤身，需养息（非诊断）。',
      '事业：是非缠身，宜谨言慎行。',
      '性格：好辩要强、易起冲突。'
    ]},
  '五鬼': { cls:'bx-bad', nums:['18','81','79','97','36','63','24','42'], yi:'主动荡、破财、血光之险',
    detail:[
      '趋势：变数大、起伏剧烈，主意外波折。',
      '财运：易破财、资金流动不稳。',
      '健康：传统视为血光意外之象，务必注意安全（非诊断）。',
      '性格：想法多变、内心不安。'
    ]},
  '绝命': { cls:'bx-bad', nums:['12','21','69','96','48','84','37','73'], yi:'主大起大落、破财伤身，大凶',
    detail:[
      '趋势：极盛极衰、大起大落，风险极高。',
      '财运：大进大出，易因冒进破财。',
      '健康：传统认为耗损最甚，须格外自爱（非诊断）。',
      '性格：敢拼敢赌、冲动极端。'
    ]}
};
const PAIR_BAXING = {};
Object.keys(BAXING).forEach(star => BAXING[star].nums.forEach(n => PAIR_BAXING[n] = star));

// 字母 → 数字（T9 键盘映射）：数字能量学遇到含字母输入（车牌 / 域名 / 英文名）时，
// 按手机键盘把字母并成单位数再纳入八星滑窗；非字母非数字（含汉字）忽略。
const T9_MAP = {'A':2,'B':2,'C':2,'D':3,'E':3,'F':3,'G':4,'H':4,'I':4,'J':5,'K':5,'L':5,'M':6,'N':6,'O':6,'P':7,'Q':7,'R':7,'S':7,'T':8,'U':8,'V':8,'W':9,'X':9,'Y':9,'Z':9};
function toDigits(raw){
  const s = (raw||'').toUpperCase();
  let out = '';
  for (const ch of s){
    if (ch >= '0' && ch <= '9') out += ch;
    else if (T9_MAP[ch] != null) out += T9_MAP[ch];
  }
  return out;
}
function baxingAnalyze(digits){
  const groups = [];
  for (let i=0; i<digits.length-1; i++){
    const pair = '' + digits[i] + digits[i+1];
    const star = PAIR_BAXING[pair];
    if (star) groups.push({ pos:i+1, pair, star });
  }
  const cnt = {}; Object.keys(BAXING).forEach(s=>cnt[s]=0);
  groups.forEach(g=>cnt[g.star]++);
  const goodStars = ['天医','延年','生气'], badStars = ['六煞','祸害','五鬼','绝命'];
  const goodN = goodStars.reduce((s,k)=>s+cnt[k],0);
  const badN = badStars.reduce((s,k)=>s+cnt[k],0);
  let verdict;
  if (groups.length === 0) verdict = '号码中未出现典型八星组合，可结合数字五行与八十一数理参看。';
  else if (badN === 0 && goodN > 0) verdict = '吉星汇聚（天医 / 延年 / 生气），利财运事业人缘，整体佳。';
  else if (goodN === 0 && badN > 0) verdict = '凶星偏多（六煞 / 祸害 / 五鬼 / 绝命），易惹是非破耗，建议斟酌。';
  else if (goodN >= badN) verdict = '吉星多于凶星，整体平稳向好，留意凶星所在位置即可。';
  else verdict = '凶星多于吉星，需留意相应象意，建议调整号码组合。';
  return { groups, cnt, goodN, badN, verdict };
}

function analyzeNumber(raw){
  const digits = toDigits(raw).split('').map(Number);
  if (!digits.length) return null;
  const total = digits.reduce((a,b)=>a+b,0);
  const totalL = liuShu(total);
  const head = digits[0], tail = digits[digits.length-1];
  const headL = liuShu(head), tailL = liuShu(tail);
  const dist = {wood:0,fire:0,earth:0,metal:0,water:0};
  digits.forEach(d => dist[DIGIT_WX[d]]++);
  const maxWx = Math.max(1, ...Object.values(dist));
  const wxRows = ['wood','fire','earth','metal','water'].map(w=>{
    const pct = Math.max(6, Math.round(dist[w]/maxWx*100));
    return `<div class="wx-row"><span class="wx-name">${WX_NAME[w]}</span><div class="wx-track"><div class="wx-fill wx-${w}" style="width:${pct}%"></div></div><span class="wx-num">${dist[w]}</span></div>`;
  }).join('');
  const jxClass = j => j==='吉'?'good':(j==='凶'?'bad':'mid');
  const itemCell = (name, num, L) => ({ name, num, wx: L.wx, wxName: WX_NAME[L.wx], jx: L.jx, jxClass: jxClass(L.jx), desc: L.desc });
  const cellItems = [itemCell('总格', total, totalL), itemCell('尾数', tail, tailL)];
  const digitChips = digits.map(d=>`<span class="num-wx-chip wx-${DIGIT_WX[d]}">${d}<i>${WX_NAME[DIGIT_WX[d]]}</i></span>`).join('');

  // 阴阳分析
  const yang = digits.filter(d => d % 2 === 1).length;
  const yin = digits.filter(d => d % 2 === 0).length;
  const yinYang = yin > yang ? '阴盛阳衰' : (yang > yin ? '阳盛阴衰' : '阴阳平衡');

  // 数字频率（0-9）
  const freq = Array(10).fill(0);
  digits.forEach(d => freq[d]++);
  const freqText = freq.map((n,i) => n > 0 ? `${i}出现${n}次` : '').filter(Boolean).join('，');

  // 五行评语
  const wxNames = {wood:'木',fire:'火',earth:'土',metal:'金',water:'水'};
  const maxWxVal = Math.max(...Object.values(dist));
  const minWxVal = Math.min(...Object.values(dist));
  const strongWx = Object.keys(dist).filter(k => dist[k] === maxWxVal).map(k => wxNames[k]).join('、');
  const weakWx = Object.keys(dist).filter(k => dist[k] === minWxVal).map(k => wxNames[k]).join('、');
  let wxComment = (maxWxVal === minWxVal) ? '五行均匀，各元素力量均衡。'
    : `五行${strongWx}偏旺，${weakWx}偏弱${maxWxVal >= digits.length*0.4 ? `，${strongWx}较集中，建议平衡搭配` : ''}。`;

  // 八星数字能量
  const baxing = baxingAnalyze(digits);

  // 总评与建议：以八十一数理（总格/尾数）为主下结论，结合五行均衡；八星仅作象意参考、不下结论
  const totalIsGood = totalL.jx === '吉';
  const balanced = maxWxVal - minWxVal <= 1;
  let overall;
  if (totalIsGood && balanced) overall = `总格数理${total}为吉、五行均衡，配置上佳。`;
  else if (totalIsGood) overall = `总格数理${total}为吉，五行略有偏颇，可作参考。`;
  else overall = `总格数理${total}为${totalL.jx}，结合命局喜忌参看。`;

  const WX_DIGIT = {wood:'1、2',fire:'3、4',earth:'5、6',metal:'7、8',water:'9、0'};
  const suggestions = [];
  if (baxing.badN > baxing.goodN){
    const badList = Object.keys(BAXING).filter(k => BAXING[k].cls==='bx-bad' && baxing.cnt[k]>0).map(k=>`${k}(${baxing.cnt[k]})`).join('、');
    if (badList) suggestions.push(`号码含凶星组合：${badList}，可考虑替换对应位置数字以化解。`);
  }
  if (totalL.jx !== '吉'){
    const goodNums = LIUSHIYI.filter(r => r[2]==='吉').map(r => r[0]);
    suggestions.push(`总格${total}数理为${totalL.jx}，可调整号码使数字总和趋于吉数（如 ${goodNums.slice(0,5).join('、')} 等）。`);
  }
  if (maxWxVal !== minWxVal){
    const weakKeys = Object.keys(dist).filter(k => dist[k] === minWxVal);
    if (weakKeys.length){
      const weak = weakKeys[0];
      suggestions.push(`五行${wxNames[weak]}偏弱（仅${dist[weak]}个），建议增加${wxNames[weak]}属性数字（${WX_DIGIT[weak]}）平衡。`);
    }
  }
  if (yang !== yin && digits.length >= 3){
    if (yin > yang * 1.5) suggestions.push('阴数偏多，建议适当增加阳数（奇数1、3、5、7、9）调节。');
    else if (yang > yin * 1.5) suggestions.push('阳数偏多，建议适当增加阴数（偶数2、4、6、8、0）调节。');
  }
  const suggestion = suggestions.length ? suggestions.join('') : '此号码配置良好，无需特别调整。';

  const freqRows = freq.map((n,i) => n > 0 ? `<span class="fd-item">${i}<small>×${n}</small></span>` : '').filter(Boolean).join('');

  // ===== 量化总评（综合评分 / 星级 / 等级）=====
  let score = 50;
  score += baxing.goodN * 10 - baxing.badN * 12;
  score += (totalL.jx === '吉' ? 20 : (totalL.jx === '凶' ? -15 : 5));
  score += (maxWxVal - minWxVal <= 1 ? 10 : (maxWxVal - minWxVal >= 3 ? -10 : 0));
  score += (Math.abs(yang - yin) <= 1 ? 5 : 0);
  // 八字喜用联动（差异化核心）：若已排盘，号码五行补益喜用则加分
  let baziFit = null;
  try {
    const lb = window.lastBazi;
    if (lb && lb.xiNames && lb.xiNames.length) {
      const xiKeys = [...new Set(lb.xiNames.map(n => WX_KEY[n]).filter(Boolean))];
      const jiKeys = [...new Set((lb.jiNames || []).map(n => WX_KEY[n]).filter(Boolean))];
      let xiN = 0, jiN = 0;
      Object.keys(dist).forEach(k => { if (xiKeys.includes(k)) xiN += dist[k]; if (jiKeys.includes(k)) jiN += dist[k]; });
      const fit = Math.round(xiN / digits.length * 100);
      score += (fit - 50) / 50 * 15;
      const hitXi = xiKeys.filter(k => dist[k] > 0).map(k => WX_NAME[k]);
      const hitJi = jiKeys.filter(k => dist[k] > 0).map(k => WX_NAME[k]);
      let verdict, cls;
      if (fit >= 50) { verdict = `号码五行多补益你的喜用神（${hitXi.join('、') || '—'}），与命局相洽`; cls = 'good'; }
      else if (fit >= 30) { verdict = `号码五行与你的喜用神（${lb.xiNames.join('、')}）部分契合，可作平配`; cls = 'mid'; }
      else { verdict = `号码五行偏向你所忌（${hitJi.join('、') || (lb.jiNames || []).join('、')}），补益有限`; cls = 'bad'; }
      baziFit = { fit, xiNames: lb.xiNames, jiNames: lb.jiNames || [], hitXi, hitJi, verdict, cls };
    }
  } catch (e) {}
  score = Math.max(0, Math.min(100, Math.round(score)));
  let level, levelKey, stars;
  if (score >= 80) { level = '大吉'; levelKey = 'great'; stars = 5; }
  else if (score >= 65) { level = '吉'; levelKey = 'good'; stars = 4; }
  else if (score >= 50) { level = '中平'; levelKey = 'mid'; stars = 3; }
  else if (score >= 35) { level = '小凶'; levelKey = 'bad'; stars = 2; }
  else { level = '凶'; levelKey = 'worst'; stars = 1; }

  return {
    count: digits.length, digitChips, wxRows,
    cells: cellItems,
    yinYang: { yang, yin, text: yinYang },
    freq, freqText, freqRows,
    wxComment, wxDist: dist,
    overall,
    suggestion,
    score, level, levelKey, stars,
    baziFit,
    baxing
  };
}
function renderNumberMath(){
  const out = document.getElementById('number-math-out');
  if (!out) return;
  const valEl = document.getElementById('num-value');
  const raw = valEl ? valEl.value.trim() : '';
  if (!raw){
    out.innerHTML = '';
    return;
  }
  const r = analyzeNumber(raw);
  if (!r){ out.innerHTML = '<p class="hint">未识别到数字，请检查输入。</p>'; return; }
  const cards = r.cells.map(c => `
    <div class="nc-card ${c.jxClass}">
      <div class="ncc-title">${c.name}</div>
      <div class="ncc-num">${c.num}</div>
      <div class="ncc-wx wx-${c.wx}">${c.wxName}</div>
      <div class="ncc-jx ${c.jxClass}">${c.jx}</div>
      <div class="ncc-desc">${c.desc}</div>
    </div>`).join('');

  // 八星数字能量
  const bx = r.baxing;
  const starCards = Object.keys(BAXING).map(star=>{
    const info = BAXING[star];
    const n = bx.cnt[star];
    const items = bx.groups.filter(g=>g.star===star).map(g=>`<span class="bx-pair">${g.pair}<small>第${g.pos}位</small></span>`).join('');
    const detailHtml = n > 0 ? `<ul class="bx-detail">${info.detail.map(d=>`<li>${d}</li>`).join('')}</ul>` : '';
    return `<div class="bx-cell ${info.cls}">
        <div class="bx-name">${star}<i class="bx-n">${n}</i></div>
        <div class="bx-yi">${info.yi}</div>
        ${detailHtml}
        <div class="bx-pairs">${items || '<span class="bx-none">—</span>'}</div>
      </div>`;
  }).join('');
  const colorStar = s => `<span class="bx-star ${BAXING[s].cls}">${s}</span>`;
  const bxIntro = `数字能量学（八星）是手机 / 车牌选号的主流民俗体系：将相邻两位数字组合归入四吉星（${colorStar('天医')}、${colorStar('延年')}、${colorStar('生气')}、${colorStar('伏位')}）与四凶星（${colorStar('六煞')}、${colorStar('祸害')}、${colorStar('五鬼')}、${colorStar('绝命')}），借以参看号码的象意倾向。下方为号码中实际出现的星性及分维度详解。八星仅作象意参考，不作吉凶定论；号码总评以八十一数理为准。`;

  const scoreCard = `<div class="num-score ${r.levelKey}">
      <div class="ns-score">${r.score}<span>分</span></div>
      <div class="ns-stars">${'★'.repeat(r.stars)}${'☆'.repeat(5 - r.stars)}</div>
      <div class="ns-level">${r.level}</div>
    </div>`;
  const numUseBazi = (() => { try { return localStorage.getItem('numUseBazi') === '1'; } catch (e) { return false; } })();
  const baziFitCard = (numUseBazi && r.baziFit) ? `<div class="num-section num-bazi-fit ${r.baziFit.cls}">
      <span class="ns-label">与你的八字契合度</span> <b class="nbf-fit">${r.baziFit.fit}%</b>
      <p class="nbf-verdict">${r.baziFit.verdict}</p>
      <div class="nbf-chips">喜用神 ${r.baziFit.xiNames.join('、')} ｜ 忌神 ${r.baziFit.jiNames.join('、')}</div>
    </div>` : '';
  const wxCommentText = (r.wxComment || '').replace(/^五行/, '');
  out.innerHTML = `<div class="num-result">
    ${scoreCard}
    <div class="num-section num-81"><span class="ns-label">八十一数理</span> 总格与尾数按八十一数理（姓名学 / 数字数理共用）判吉凶</div>
    <div class="nr-cards">${cards}</div>
    ${baziFitCard}
    <div class="num-section num-baxing">
      <span class="ns-label">八星数字能量</span>
      <p class="bx-intro">${bxIntro}</p>
      <div class="bx-grid">${starCards}</div>
    </div>
    <div class="num-section num-basic">
      <div class="ns-block">
        <div class="num-digits-label">数字五行分布：<small>共 ${r.count} 位</small></div>
        <div class="num-chips">${r.digitChips}</div>
        <div class="num-wx-chart wx-chart">${r.wxRows}</div>
      </div>
      <div class="ns-block"><span class="ns-label">五行</span> ${wxCommentText}</div>
      <div class="ns-block"><span class="ns-label">阴阳</span> 阳 ${r.yinYang.yang} ｜ 阴 ${r.yinYang.yin} ｜ ${r.yinYang.text}</div>
      <div class="ns-block"><span class="ns-label">数字频率</span> ${r.freqRows}</div>
    </div>
    <div class="num-overall-card">
      <div class="num-overall">${r.overall}</div>
      ${r.suggestion ? `<div class="num-suggestion">💡 改善建议：${r.suggestion}</div>` : ''}
    </div>
  </div>`;
}

/* ---------- 选号生成器（按八字喜用神 / 八星吉星 / 八十一数理生成吉祥号码） ---------- */
function genLuckyNumbers(len, count, mobile){
  len = len || 11; count = count || 8;
  mobile = mobile !== false;  // 默认手机号模式（首位1、第二位限定）；custom 模式首位1-9任意、长度由调用方指定
  let numUseBazi = false;
  try { numUseBazi = localStorage.getItem('numUseBazi') === '1'; } catch (e) {}
  const lb = window.lastBazi;
  let xiKeys = [], jiKeys = [];
  if (numUseBazi && lb && lb.xiNames && lb.xiNames.length){
    xiKeys = [...new Set(lb.xiNames.map(n => WX_KEY[n]).filter(Boolean))];
    jiKeys = [...new Set((lb.jiNames || []).map(n => WX_KEY[n]).filter(Boolean))];
  }
  const WXD = { wood:'1、2', fire:'3、4', earth:'5、6', metal:'7、8', water:'9、0' };
  const baseW = {}; for (let d = 0; d <= 9; d++) baseW[d] = 1;
  // 八星吉星数字加成
  ['天医','延年','生气'].forEach(s => BAXING[s].nums.forEach(p => { baseW[+p[0]] += 2; baseW[+p[1]] += 2; }));
  // 八字喜用神加权 / 忌神降权
  xiKeys.forEach(k => (WXD[k] || '').split('、').map(Number).forEach(d => baseW[d] *= 3));
  jiKeys.forEach(k => (WXD[k] || '').split('、').map(Number).forEach(d => baseW[d] *= 0.2));
  // 凶星相邻对（生成时规避）
  const BAD = []; ['六煞','祸害','五鬼','绝命'].forEach(s => BAXING[s].nums.forEach(p => BAD.push(p)));
  function wpick(w){
    let tot = 0; for (const k in w) tot += Math.max(0, w[k]);
    let r = Math.random() * tot;
    for (const k in w){ r -= Math.max(0, w[k]); if (r <= 0) return +k; }
    return 8;
  }
  function genOnce(){
    const arr = [];
    if (mobile){
      arr.push(1);                                            // 手机号首位固定 1
      arr.push([3,5,7,8,9][Math.floor(Math.random() * 5)]);
    } else {
      arr.push(1 + Math.floor(Math.random() * 9));             // 自定义：首位 1-9（无前导 0）
    }
    while (arr.length < len){
      const prev = arr[arr.length - 1];
      // 30% 概率尝试插入吉星相邻对
      if (Math.random() < 0.3){
        const goodNext = [];
        ['天医','延年','生气','伏位'].forEach(s => BAXING[s].nums.forEach(p => { if (+p[0] === prev) goodNext.push(+p[1]); }));
        if (goodNext.length){ arr.push(goodNext[Math.floor(Math.random() * goodNext.length)]); continue; }
      }
      const w = {};
      for (let d = 0; d <= 9; d++){ if (BAD.includes('' + prev + d)) continue; w[d] = baseW[d]; }
      arr.push(wpick(w));
    }
    return arr.join('');
  }
  const pool = [];
  const tries = count * 6;
  for (let i = 0; i < tries; i++) pool.push(genOnce());
  const scored = pool.map(num => { const r = analyzeNumber(num); return { num, score: r.score, level: r.level, levelKey: r.levelKey }; });
  scored.sort((a, b) => b.score - a.score);
  return scored.slice(0, count);
}

function renderLuckyNumbers(){
  const out = document.getElementById('num-gen-out');
  if (!out) return;
  // 选项 A：直接读号码输入框当种子，长度=位数、模式=长度11且^1[35789]→手机否则自定义（空→11位手机）
  const seedEl = document.getElementById('num-value');
  const seedDigits = seedEl ? (seedEl.value || '').replace(/\D/g, '') : '';
  let len, isMobile;
  if (seedDigits.length){
    len = Math.max(3, Math.min(20, seedDigits.length));
    isMobile = len === 11 && /^1[35789]/.test(seedDigits);
  } else {
    len = 11; isMobile = true;
  }
  const cands = genLuckyNumbers(len, 8, isMobile);
  if (!cands.length){ out.innerHTML = '<p class="hint">生成失败，请稍后重试。</p>'; return; }
  let numUseBazi = false;
  try { numUseBazi = localStorage.getItem('numUseBazi') === '1'; } catch (e) {}
  const hasBazi = numUseBazi && window.lastBazi && window.lastBazi.xiNames && window.lastBazi.xiNames.length;
  const tip = hasBazi
    ? `已按你的喜用神（${window.lastBazi.xiNames.join('、')}）优先生成；点选号码即可载入分析。`
    : `按八星吉星与八十一数理生成 ${len} 位${isMobile ? '（手机号风格）' : '（自定义）'}号码；开启「结合八字」可更合你命局。`;
  out.innerHTML = `<div class="num-gen-list">` + cands.map(c => `
    <div class="num-gen-item ${c.levelKey}" data-num="${c.num}">
      <div class="ngi-num">${c.num}</div>
      <div class="ngi-meta"><b class="ngi-score">${c.score}</b>分 · ${c.level}</div>
    </div>`).join('') + `</div>
    <p class="num-gen-tip">${tip}</p>`;
  out.querySelectorAll('.num-gen-item').forEach(el => {
    el.onclick = () => {
      const inp = document.getElementById('num-value');
      if (inp){ inp.value = el.dataset.num; renderNumberMath(); }
      out.querySelectorAll('.num-gen-item').forEach(x => x.classList.remove('sel'));
      el.classList.add('sel');
      const tgt = document.getElementById('number-math-out');
      if (tgt) tgt.scrollIntoView({ behavior: 'smooth', block: 'start' });
    };
  });
}

function meihuaCardsHtml(g){
  if (!g) return '';
  const gCard = (t, info) => `<div class="gua-card">
      <div class="gua-tag">${t}</div>
      <div class="gua-name">${info.name}</div>
      ${guaLinesHtml(info)}
      <div class="gua-trigram">上${info.upT}下${info.downT}</div>
      <div class="gua-desc">${info.desc}</div>
    </div>`;
  return `<div class="gua-flow">
      ${gCard('本卦', g.ben)}
      ${gCard('互卦', g.hua)}
      ${gCard('变卦', g.bian)}
    </div>
    <div class="gua-meta">动爻第 <b>${g.dong}</b> 爻（初爻起）｜ 体卦 <b class="wx-${g.tiWx}">${g.tiT}</b>（${g.tiWxName}）· 用卦 <b class="wx-${g.yongWx}">${g.yongT}</b>（${g.yongWxName}）｜ <b>${g.tiYong}</b></div>
    <div class="gua-ref">${g.xtRef}</div>`;
}
function meihuaExplainHtml(g){
  const TIYONG_TEXT = {
    '体用比和（平）': '体卦与用卦五行相同、比和相助，事情多半平顺少波折，宜守成稳进、不宜冒进。',
    '用生体（吉）': '用卦生助体卦，表示外力相助、得人扶持，谋事易成、多有进益，宜把握时机。',
    '体生用（小耗）': '体卦生用卦，表示我方耗力以成事，付出多而回报缓，须防资源外泄、量力而行。',
    '体克用（吉）': '体卦克用卦，表示我主其事、能控局面，主动进取可成，但需亲力亲为、稍费心力。',
    '用克体（凶）': '用卦克体卦，表示外力压制、受阻不顺，谋事多艰，宜守不宜攻、暂避其锋。'
  };
  const ty = TIYONG_TEXT[g.tiYong] || '';
  const dongYao = `动爻落在第 <b>${g.dong}</b> 爻（由初爻起算）。动爻是卦中由阳变阴、或由阴变阳的那一爻，它牵引本卦走向变卦，是事情发生转变的关键节点。`;
  const roles = [
    ['本卦', '所占之事的现状 / 起始——事情当下的态势与根基。'],
    ['互卦', '事情发展的过程 / 内情——由本卦二、三、四、五爻重组而成，揭示演变中的隐藏环节。'],
    ['变卦', '事情的结果 / 趋向——动爻变化后所成的卦，预示最终走向。']
  ];
  const roleHtml = roles.map(([t,d])=>`<div class="mx-role"><b>${t}</b>：${d}</div>`).join('');
  const summary = `综合来看：以本卦《${g.ben.name}》（${g.ben.desc}）为起始，经互卦《${g.hua.name}》之过程，终成变卦《${g.bian.name}》（${g.bian.desc}）；体卦为${g.tiT}（${g.tiWxName}）、用卦为${g.yongT}（${g.yongWxName}），二者关系${g.tiYong}。`;
  return `<div class="meihua-read">
    <div class="mx-block">
      <div class="mx-h">如何读这三卦</div>
      ${roleHtml}
    </div>
    <div class="mx-block">
      <div class="mx-h">体用生克</div>
      <div class="mx-tiyong">${g.tiYong} —— ${ty}</div>
    </div>
    <div class="mx-block">
      <div class="mx-h">动爻</div>
      <div class="mx-dong">${dongYao}</div>
    </div>
    <div class="mx-block mx-summary">
      <div class="mx-h">综合解读</div>
      <div class="mx-sum">${summary}</div>
    </div>
  </div>`;
}
function renderMeihua(){
  const out = document.getElementById('meihua-out');
  if (!out) return;
  const valEl = document.getElementById('meihua-value');
  const raw = valEl ? valEl.value.trim() : '';
  if (!raw){
    out.innerHTML = '';
    return;
  }
  const digits = (raw.replace(/\D/g,'')).split('').map(Number);
  if (digits.length < 2){ out.innerHTML = '<p class="hint">至少输入 2 位数字方可起卦。</p>'; return; }
  const g = meihuaGua(digits);
  if (!g){ out.innerHTML = '<p class="hint">数字不足，无法起卦。</p>'; return; }
  out.innerHTML = `<div class="num-result">${meihuaCardsHtml(g)}${meihuaExplainHtml(g)}</div>`;
}
/* ===================================================================
 * 罗盘（二十四山 + 八卦内环）
 * =================================================================== */
const LUOPAN_24 = [
  ['子','坎','water','正北'],['癸','坎','water','北偏西'],['丑','艮','earth','东北偏北'],['艮','艮','earth','东北'],
  ['寅','艮','wood','东北偏东'],['甲','震','wood','东偏北'],['卯','震','wood','正东'],['乙','震','wood','东偏南'],
  ['辰','巽','earth','东南偏东'],['巽','巽','wood','东南'],['巳','巽','fire','东南偏南'],['丙','离','fire','南偏东'],
  ['午','离','fire','正南'],['丁','离','fire','南偏西'],['未','坤','earth','西南偏南'],['坤','坤','earth','西南'],
  ['申','坤','metal','西南偏西'],['庚','兑','metal','西偏南'],['酉','兑','metal','正西'],['辛','兑','metal','西偏北'],
  ['戌','乾','earth','西北偏西'],['乾','乾','metal','西北'],['亥','乾','water','西北偏北'],['壬','坎','water','北偏东']
];
const BAGUA_INFO = {
  '坎':{wx:'water',dir:'北',desc:'坎为水：主智慧、险陷，方位正北，五行属水。'},
  '艮':{wx:'earth',dir:'东北',desc:'艮为山：主静止、安稳，方位东北，五行属土。'},
  '震':{wx:'wood',dir:'东',desc:'震为雷：主动、奋发，方位正东，五行属木。'},
  '巽':{wx:'wood',dir:'东南',desc:'巽为风：主谦逊、顺入，方位东南，五行属木。'},
  '离':{wx:'fire',dir:'南',desc:'离为火：主光明、华丽，方位正南，五行属火。'},
  '坤':{wx:'earth',dir:'西南',desc:'坤为地：主柔顺、承载，方位西南，五行属土。'},
  '兑':{wx:'metal',dir:'西',desc:'兑为泽：主喜悦、口舌，方位正西，五行属金。'},
  '乾':{wx:'metal',dir:'西北',desc:'乾为天：主刚健、强健，方位西北，五行属金。'}
};
// 八卦对应卦符（三爻）：乾☰ 坤☷ 震☳ 艮☶ 兑☱ 巽☴ 离☲ 坎☵
const BAGUA_SYM = {'乾':'☰','坤':'☷','震':'☳','艮':'☶','兑':'☱','巽':'☴','离':'☲','坎':'☵'};
// 罗盘上以红底白字突出的十二山/卦；其余天干地支统一为单一颜色
const LUOPAN_RED = new Set(['甲','乙','辰','午','坤','申','戌','乾','壬','子','癸','寅']);
function _lpPt(cx,cy,r,deg){ const a=(deg-90)*Math.PI/180; return [cx+r*Math.cos(a), cy+r*Math.sin(a)]; }
function _lpAnnular(cx,cy,r1,r2,a0,a1){
  const [x1,y1]=_lpPt(cx,cy,r2,a0),[x2,y2]=_lpPt(cx,cy,r2,a1);
  const [x3,y3]=_lpPt(cx,cy,r1,a1),[x4,y4]=_lpPt(cx,cy,r1,a0);
  const large=(a1-a0)>180?1:0;
  return `M${x1} ${y1} A${r2} ${r2} 0 ${large} 1 ${x2} ${y2} L${x3} ${y3} A${r1} ${r1} 0 ${large} 0 ${x4} ${y4} Z`;
}
function buildLuopanSVG(){
  // 传统罗盘：三盘三针（天盘缝针 +7.5° / 地盘正针 0° / 人盘中针 −7.5°）+ 八卦内环 + 周天刻度
  const cx=220, cy=220;
  const WX = {
    wood:{d:'#3f7d4f', l:'#cfe6d6', t:'#fff'},
    fire:{d:'#c0392b', l:'#f3cdc7', t:'#fff'},
    earth:{d:'#b8893b', l:'#ecd9b0', t:'#fff'},
    metal:{d:'#8a8f98', l:'#e2e4e9', t:'#fff'},
    water:{d:'#2f6f9f', l:'#c6dcef', t:'#fff'}
  };
  const plates = [
    { key:'earth',  name:'地盘正针', off: 0,    R_out:135, R_in:109, fs:13, light:false },
    { key:'human',  name:'人盘中针', off:-7.5, R_out:169, R_in:139, fs:13, light:true },
    { key:'heaven', name:'天盘缝针', off: 7.5, R_out:200, R_in:173, fs:13, light:true }
  ];
  // 向心文字：以 (x,y) 为锚点，整字旋转 deg 度，字顶统一朝向天池中心
  function radialText(x,y,deg,ch,fs,w,fill){
    return `<text x="0" y="0" transform="translate(${x.toFixed(1)} ${y.toFixed(1)}) rotate(${deg.toFixed(1)})" font-size="${fs}" font-weight="${w}" fill="${fill}" text-anchor="middle" dominant-baseline="central" class="lp-text" pointer-events="none">${ch}</text>`;
  }
  let s = `<svg viewBox="-12 -12 464 464" class="luopan-svg" id="luopan-svg" role="img" aria-label="风水罗盘">`;
  s += `<circle cx="${cx}" cy="${cy}" r="214" class="lp-rim"/>`;
  // 周天 360° 刻度：每 5° 一细线，每 10° 一中线，每 30° 一粗线；刻度值（度数）置于刻度环之外（r=221），避免与刻度线重叠
  let ticks = '', deg = '';
  for (let d=0; d<360; d+=5){
    const heavy = (Math.round(d) % 30 === 0);
    const med = !heavy && (Math.round(d) % 10 === 0);
    const rin = heavy ? 200 : (med ? 203 : 207);
    const p1 = _lpPt(cx,cy,214,d), p2 = _lpPt(cx,cy, rin, d);
    ticks += `<line x1="${p1[0].toFixed(1)}" y1="${p1[1].toFixed(1)}" x2="${p2[0].toFixed(1)}" y2="${p2[1].toFixed(1)}" class="lp-tick${heavy?' heavy':med?' med':''}"/>`;
    if (Math.round(d) % 10 !== 0){
      const p = _lpPt(cx,cy,221,d);   // 移至刻度环外（rim=214），刻度值不再压线
      deg += radialText(p[0], p[1], d+180, d, 7, 400, '#8a6d3b');
    }
  }
  s += ticks + deg;
  // 金色分隔圈
  [201,170,136,106,74].forEach(r=>{ s += `<circle cx="${cx}" cy="${cy}" r="${r}" class="lp-ring"/>`; });
  // 三盘
  plates.forEach(pg=>{
    LUOPAN_24.forEach((m,i)=>{
      const a0 = i*15 + pg.off - 7.5, a1 = i*15 + pg.off + 7.5;
      const isRed = (pg.key === 'earth') && LUOPAN_RED.has(m[0]);
      const fill = isRed ? '#c0392b' : '#e7d9bc';
      const txt  = isRed ? '#ffffff' : '#4a3b2a';
      const ang = i*15 + pg.off;
      const p = _lpPt(cx,cy,(pg.R_out+pg.R_in)/2, ang);
      s += `<path d="${_lpAnnular(cx,cy,pg.R_out,pg.R_in,a0,a1)}" fill="${fill}" stroke="#fff" stroke-width="1" class="lp-sector" data-plate="${pg.key}" data-idx="${i}" opacity="0.97"/>`;
      s += radialText(p[0], p[1], ang+180, m[0], pg.fs, isRed?800:700, txt);
    });
  });
  // 八卦内环（后天八卦：坎北·艮东北·震东·巽东南·离南·坤西南·兑西·乾西北）
  // 每个卦居中于其本宫山角度（坎=子0°·艮=艮45°·震=卯90°·巽=巽135°·离=午180°·坤=坤225°·兑=酉270°·乾=乾315°），
  // 即每卦跨 ±22.5°，正好覆盖所辖三山（如震=甲卯乙、巽=辰巽巳）。
  Object.keys(BAGUA_INFO).forEach((g,i)=>{
    const a0=i*45-22.5, a1=i*45+22.5;
    const fill = '#e7d9bc';
    const txt  = '#4a3b2a';
    const ang = i*45;
    const pName = _lpPt(cx,cy,100, ang);
    const pSym  = _lpPt(cx,cy,83, ang);
    s += `<path d="${_lpAnnular(cx,cy,105,75,a0,a1)}" fill="${fill}" stroke="#fff" stroke-width="1" class="lp-gua" data-gua="${g}" opacity="0.97"/>`;
    s += radialText(pName[0], pName[1], ang+180, g, 11, 700, txt);
    s += radialText(pSym[0], pSym[1], ang+180, BAGUA_SYM[g], 15, 700, txt);
  });
  s += `</svg>`;
  return s;
}
function selectLuopan(i){
  const m=LUOPAN_24[i], body=document.getElementById('luopan-info-body');
  if (!body) return;
  body.innerHTML='';
  _lpManual = true;
}
function selectGua(g){
  const body=document.getElementById('luopan-info-body');
  if (!body) return;
  const info = BAGUA_INFO[g];
  if (info){
    body.innerHTML = `<div class="lp-gua-card">
      <div class="lp-gua-sym">${BAGUA_SYM[g]}</div>
      <div class="lp-gua-name">${g}卦</div>
      <div class="lp-gua-meta">方位 ${info.dir}　·　五行 ${WX_NAME[info.wx]}</div>
      <div class="lp-gua-desc">${info.desc}</div>
    </div>`;
  } else { body.innerHTML=''; }
  _lpManual = true;
}
function fetchLuopanLocation(){
  const locEl = document.getElementById('luopan-loc');
  if (!locEl) return;
  if (!navigator.geolocation){ locEl.textContent = '经纬度：环境不支持'; return; }
  locEl.textContent = '经纬度：定位中…';
  let settled = false;
  const t = setTimeout(function(){
    if (!settled){ settled = true; if (locEl.textContent === '经纬度：定位中…') locEl.textContent = '经纬度：定位超时（请检查定位权限 / 需 HTTPS 或 localhost）'; }
  }, 8000);
  navigator.geolocation.getCurrentPosition(function(pos){
    if (settled) return; settled = true; clearTimeout(t);
    locEl.textContent = '纬度 ' + pos.coords.latitude.toFixed(3) + '°　经度 ' + pos.coords.longitude.toFixed(3) + '°';
  }, function(err){
    if (settled) return; settled = true; clearTimeout(t);
    const why = (err && err.code === 1) ? '未授权定位' : '定位不可用';
    locEl.textContent = '经纬度：获取失败（' + why + '）';
  }, { enableHighAccuracy:true, timeout:8000 });
}
function renderLuopan(){
  const box=document.getElementById('luopan-out');
  if (!box || box.dataset.built) return;
  box.innerHTML=buildLuopanSVG();
  box.dataset.built='1';
  box.querySelectorAll('.lp-sector').forEach(p=>{ p.style.cursor='pointer'; p.addEventListener('click',()=>selectLuopan(+p.dataset.idx)); });
  box.querySelectorAll('.lp-gua').forEach(p=>{ p.style.cursor='pointer'; p.addEventListener('click',()=>selectGua(p.dataset.gua)); });
  // 初始坐向信息（正北·子山），未启动指南针时显示；转动后由 lpUpdateReadout 动态更新
  const body0 = document.getElementById('luopan-info-body');
  if (body0){ body0.innerHTML = ''; }
}

let _lpAngle = 0, _lpTarget = null, _lpHandler = null, _lpLocked = false, _lpRAF = false, _lpManual = false;
let _lpNeedle = null, _lpOut = null;

// 缓存磁针与盘面元素（避免每帧查 DOM）
function lpCacheEls(){
  _lpNeedle = document.querySelector('.lp-tianchi svg');
  _lpOut = document.getElementById('luopan-out');
  return _lpNeedle && _lpOut;
}

// 坐/向读数（仅在未锁定时刷新，锁定后冻结）
function lpUpdateReadout(h){
  const headingEl = document.getElementById('luopan-heading');
  if (headingEl) headingEl.textContent = '朝向：' + Math.round(h) + '°';
  const idx = Math.round(h/15) % 24;
  const facing = LUOPAN_24[idx], sitting = LUOPAN_24[(idx+12)%24];
  const readout = document.getElementById('luopan-readout');
  if (readout) readout.innerHTML = '<div class="lp-readout-main">坐 <b class="wx-'+sitting[2]+'">'+sitting[0]+'</b> <span class="lp-sub-sm">'+sitting[3]+'（'+WX_NAME[sitting[2]]+'）</span> 向 <b class="wx-'+facing[2]+'">'+facing[0]+'</b> <span class="lp-sub-sm">'+facing[3]+'（'+WX_NAME[facing[2]]+'）</span> <b class="lp-deg">'+Math.round(h)+'°</b></div>';
  // 未手动点选某山/卦时，坐山五行随当前朝向动态更新（解决子山·五行水固定不变）
  if (!_lpManual){
    const body = document.getElementById('luopan-info-body');
    if (body){ body.innerHTML = ''; }
  }
}

// 平滑跟随渲染循环：持续把盘面缓动到目标角——既灵敏跟手又稳居南北；锁定则冻结
function lpTick(){
  if (_lpTarget != null && !_lpLocked && _lpNeedle && _lpOut){
    let diff = _lpTarget - _lpAngle;
    while (diff > 180) diff -= 360;
    while (diff < -180) diff += 360;
    // 自适应缓动：转动幅度越大系数越高（更跟手），小幅微动时保持平稳；整体比旧版(0.2)灵敏很多
    const ease = Math.min(0.6, 0.4 + Math.abs(diff) / 180 * 0.2);
    _lpAngle += diff * ease;
    if (Math.abs(diff) < 0.05) _lpAngle = _lpTarget;
    _lpNeedle.style.transform = 'rotate(' + _lpAngle + 'deg)';
    _lpOut.style.transform = 'rotate(' + _lpAngle + 'deg)';   // 盘面随磁针同步旋转，使子午始终对准磁针
  }
  requestAnimationFrame(lpTick);
}

// 传感器回调：仅采用绝对朝向（iOS 的 webkitCompassHeading 或 Android 的 absolute alpha），
// 拒绝相对 alpha（相对设备启动朝向，迟钝且漂移），解决磁针不指南北/灵敏度差
function onOrient(e){
  let h = null;
  if (typeof e.webkitCompassHeading === 'number') h = e.webkitCompassHeading;
  else if (e.absolute === true && typeof e.alpha === 'number') h = (360 - e.alpha) % 360;
  if (h == null) return;
  h = (h % 360 + 360) % 360;
  _lpTarget = -h;                          // 显示目标角：手机朝北(h=0)→0；朝东(h=90)→-90（子端指向屏幕左侧=北）
  if (_lpLocked) return;                   // 已锁定坐向 → 冻结盘面，不再跟随
  lpUpdateReadout(h);
}

// 进入罗盘页默认调用：挂载传感器监听（幂等），盘面默认即可转动
function startLuopanCompass(){
  if (_lpHandler) return;
  const btn = document.getElementById('luopan-compass-btn');
  const needHttps = location.protocol !== 'https:' && location.hostname !== 'localhost' && location.hostname !== '127.0.0.1';
  const attach = ()=>{
    _lpHandler = onOrient;
    if (window.DeviceOrientationEvent && 'ondeviceorientationabsolute' in window) window.addEventListener('deviceorientationabsolute', onOrient, true);
    window.addEventListener('deviceorientation', onOrient, true);
    lpCacheEls();
    if (!_lpRAF){ _lpRAF = true; requestAnimationFrame(lpTick); }
    if (btn) btn.textContent = _lpLocked ? '解除锁定坐向' : '锁定坐山朝向';
    fetchLuopanLocation();
  };
  if (typeof DeviceOrientationEvent !== 'undefined' && typeof DeviceOrientationEvent.requestPermission === 'function'){
    DeviceOrientationEvent.requestPermission().then(function(state){
      if (state === 'granted') attach();
      else alert('未授权设备方向权限，无法启动指南针。');
    }).catch(function(){ alert('无法获取设备方向权限（可能需 HTTPS 环境）。'); });
  } else if (needHttps){
    alert('指南针需要 HTTPS 或本机（localhost）环境才能读取设备方向。当前为 HTTP，无法启动；你可点击罗盘上的二十四山手动查看。');
  } else {
    attach();
  }
}

// 点锁定坐山朝向→ 启动并立即锁定（单击即生效，不再需点两次）；再点解除锁定坐向→ 恢复跟随
function toggleLuopanLock(){
  const btn = document.getElementById('luopan-compass-btn');
  if (!_lpHandler){ startLuopanCompass(); _lpLocked = true; if (btn) btn.textContent = '解除锁定坐向'; return; }
  _lpLocked = !_lpLocked;
  if (btn) btn.textContent = _lpLocked ? '解除锁定坐向' : '锁定坐山朝向';
  if (!_lpLocked){ _lpTarget = null; lpCacheEls(); _lpManual = false; }   // 解除后重新跟随坐向（含坐山五行）
}

/* ===================================================================
 * 标签切换 & 初始化
 * =================================================================== */
const TAB_TITLES = { bazi:'八字排盘', calendar:'黄历', books:'古籍收集', math:'数理分析', name:'起名', luopan:'罗盘', about:'关于' };
// 各页面底部免责声明文案（随当前页切换，对应页面对应的方案）
const FOOTER_TEXT = {
  bazi: '内容仅供传统文化娱乐参考，不作决策依据。',
  calendar: '内容仅供传统文化娱乐参考，不作决策依据。',
  books: '内容仅供传统文化娱乐参考，不作决策依据。',
  math: '内容仅供传统文化娱乐参考，不作决策依据。',
  name: '内容仅供传统文化娱乐参考，不作决策依据。',
  luopan: '内容仅供传统文化娱乐参考，不作决策依据。',
  about: '感谢使用简策集，如有建议欢迎联系。'
};
// 全局构建信息（由 loadBuildInfo 从 version.json 读取，CI 构建时写入）
let APP_BUILD = '';
function loadBuildInfo(){
  try {
    fetch('version.json', { cache:'no-store' })
      .then(r=> r.ok ? r.json() : null)
      .then(d=>{
        if (!d) return;
        APP_BUILD = (d.buildHash ? d.buildHash : '') + (d.buildAt ? ' · ' + d.buildAt : '');
        if (d.appVersion){ const v=document.getElementById('about-version'); if(v) v.textContent=d.appVersion; }
        const ab=document.getElementById('about-build'); if(ab){ ab.textContent=(d.buildHash||'—')+(d.buildAt?' · '+d.buildAt:''); }
        // 刷新底部哈希（若当前页已渲染 footer）
        const cur = document.querySelector('#tabs .tab.active');
        if (cur) updateFooter(cur.dataset.tab);
      })
      .catch(()=>{});
  } catch(e){}
}
function updateFooter(tab){
  const f = document.querySelector('.site-footer');
  if (!f) return;
  f.style.display = '';
  const span = f.querySelector('span');
  if (span){
    let txt = FOOTER_TEXT[tab] || FOOTER_TEXT.bazi;
    span.textContent = txt;
  }
}
// 统计埋点：仅在 APP 内（存在 window.UmengStats）且非排版编辑器模式调用；桌面预览无此接口，安全降级
function trackPage(tab){
  try {
    if (window.UmengStats && !/editor=1/.test(location.search)) {
      window.UmengStats.track(tab);
    }
  } catch(e){}
}

// 数字能量的出生日期直接复用「八字」页日期（八字页是权威来源，始终是默认/已设日期）
function syncNumBirthLabel(){
  const btn = document.getElementById('num-birth-btn');
  const sw = document.getElementById('num-use-bazi');
  if (!btn || !sw || !sw.checked) return;
  const s = parseDateInput('solar-date');          // 八字页公历日期，始终存在
  btn.textContent = s
    ? `出生日期：${s.y}年${String(s.m).padStart(2,'0')}月${String(s.d).padStart(2,'0')}日`
        : '请选择出生日期';
}

/* 起名页：结合八字喜用勾选时，把出生时间下拉框默认显示为八字页已排的出生日期（y/m/d + 时辰） */
function showBuildTag(){
  const el = document.getElementById('name-build-tag');
  if (!el) return;
  const fallback = '7a05c4e';
  el.textContent = '当前包版本：' + fallback;
  try {
    if (typeof fetch === 'function'){
      fetch('version.json').then(r=>r.json()).then(j=>{
        if (j && j.buildHash) el.textContent = '当前包版本：' + j.buildHash;
      }).catch(()=>{});
    }
  } catch(e){}
}

function syncNameBirthLabel(force){
  const btn = document.getElementById('name-birth-btn');
  const ub = document.getElementById('name-use-bazi');
  if (!btn || !ub || !ub.checked) return;
  const b = Birth.get();   // 统一出生时间数据源（权威源）
  if (!b || b.y < 1900){ btn.textContent = '请选择出生时间'; return; }
  // 时辰：优先用八字页已算命盘的时柱地支；否则用统一数据源的时辰
  let h = b.shichen;
  const lb = window.lastBazi;
  if (lb && lb.hour && lb.hour.length >= 2){
    const idx = BRANCHES.indexOf(lb.hour[1]);
    if (idx >= 0) h = idx;
  }
  btn.textContent = `${b.y}年${String(b.m).padStart(2,'0')}月${String(b.d).padStart(2,'0')}日 ${BRANCHES[h]}时`;
}

function initTabs(){
  document.querySelectorAll('#tabs .tab').forEach(t=>{
    t.onclick = ()=>{
      document.querySelectorAll('#tabs .tab').forEach(x=>x.classList.remove('active'));
      document.querySelectorAll('main .panel').forEach(x=>x.classList.remove('active'));
      t.classList.add('active');
      const tab = t.dataset.tab;
      document.getElementById(tab).classList.add('active');
      const otaEl = document.getElementById('ota-ver');
      if (otaEl) otaEl.style.display = (tab === 'about') ? '' : 'none'; // 版本角标仅【关于】页显示
      const mainEl = document.querySelector('main'); if (mainEl) mainEl.scrollTop = 0; // 切页回顶（内容区滚动）
      const tt = document.getElementById('top-page-title');
      if (tt && TAB_TITLES[tab]) tt.textContent = TAB_TITLES[tab];
      updateFooter(tab);
      trackPage(tab);
      if (tab === 'calendar') renderCalendar(); // 进入黄历时默认显示当天日期与黄历
      if (tab === 'name') {
        renderNameStrokes(); syncNameBirthLabel(); computeName(); showBuildTag();
        // 再次进入起名页（如八字页改日期重新排盘后返回）：若已生成过候选，用最新八字喜用自动重生成，
        // 确保候选随八字（喜忌）变化而更新，而不是停留在上一次的旧候选
        const nbox = document.getElementById('name-candidates');
        if (nbox && nbox.querySelector('.cand-card')) { try { doGenerate(); } catch(e){} }
      }
      if (tab === 'luopan') { renderLuopan(); setTimeout(startLuopanCompass, 300); }
      if (tab === 'math'){
        // 从八字页排盘返回数理页时，刷新出生日期标签与契合度（复用八字页最新日期/命盘）
        const act = document.querySelector('#math-subtabs .subtab.active');
        const sub = act ? act.dataset.sub : 'number-math';
        if (sub === 'number-math'){ syncNumBirthLabel(); renderNumberMath(); }
      }
    };
  });
  document.querySelectorAll('#math-subtabs .subtab').forEach(t=>{
    t.onclick = ()=>{
      document.querySelectorAll('#math-subtabs .subtab').forEach(x=>x.classList.remove('active'));
      document.querySelectorAll('#math .subpanel').forEach(x=>x.classList.remove('active'));
      t.classList.add('active');
      const sub = t.dataset.sub;
      document.getElementById(sub).classList.add('active');
      if (sub === 'number-math'){ renderNumberMath(); syncNumBirthLabel(); }
      if (sub === 'meihua') renderMeihua();
    };
  });
  // 初始页脚文案（默认 八字 页）
  const defTab = document.querySelector('#tabs .tab.active');
  updateFooter(defTab ? defTab.dataset.tab : 'bazi');
  trackPage(defTab ? defTab.dataset.tab : 'bazi');
  // 版本角标仅【关于】页显示：默认非 about 则隐藏
  const otaEl0 = document.getElementById('ota-ver');
  if (otaEl0) otaEl0.style.display = (defTab && defTab.dataset.tab === 'about') ? '' : 'none';
}

let _appStarted = false;
function initApp(){
  if (_appStarted) return;
  // 预览器等环境会异步加载 calendar.js，需等其就绪再初始化，否则首屏渲染会因
  // calendar 未定义而抛错，导致万年历/八字空白（手动点击后 calendar 已加载才正常）。
  if (typeof calendar === 'undefined' || !(calendar && typeof calendar.solar2lunar === 'function')) {
    setTimeout(initApp, 30); return;
  }
  _appStarted = true;
  loadBuildInfo();
  initTabs();
  // 全局夜间模式：启动应用保存的主题，并绑定标题栏切换按钮（全局各页面共享 header）
  (function(){
    const root = document.documentElement;
    const btn = document.getElementById('theme-toggle');
    const apply = (dark)=>{
      if (dark){ root.setAttribute('data-theme','dark'); if (btn){ btn.textContent='☀️'; btn.title='日间模式'; } }
      else { root.removeAttribute('data-theme'); if (btn){ btn.textContent='🌙'; btn.title='夜间模式'; } }
    };
    try { apply(localStorage.getItem('claw_theme')==='dark'); } catch(e){}
    if (btn) btn.onclick = ()=>{
      const dark = root.getAttribute('data-theme')==='dark';
      apply(!dark);
      try { localStorage.setItem('claw_theme', dark?'light':'dark'); } catch(e){}
    };
  })();
  document.getElementById('bazi-btn').onclick = renderBazi;
  initReverseModal();
  const _revYe = document.getElementById('rev-ye');
  if (_revYe && (_revYe.value === '2100' || !_revYe.value)) _revYe.value = new Date().getFullYear();
  const rt = document.getElementById('reverse-toggle');
  if (rt) rt.onclick = ()=>{
    openRevModal();
    rt.setAttribute('aria-expanded', 'true');
    rt.classList.add('rev-on');
  };
  restoreGender();   // 恢复上次选择的性别（与日期 clawBirth 一样跨重启保留）
  initBaziForm();
  initBirthSubs();   // 注册出生时间订阅者：任一页写回 Birth 后所有相关页自动刷新
  initLngPicker();
  initCalendar();
  renderBooks();
  const bs = document.getElementById('books-search');
  if (bs) bs.addEventListener('input', ()=>{ booksQuery = bs.value; renderBooks(); });
  document.getElementById('name-surname').addEventListener('input', renderNameStrokes);
  document.getElementById('name-given').addEventListener('input', renderNameStrokes);
  document.getElementById('num-value').addEventListener('input', renderNumberMath);
  const numBaziSw = document.getElementById('num-use-bazi');
  const numBirthBtn = document.getElementById('num-birth-btn');
  const syncNumBaziUI = () => {
    const on = numBaziSw && numBaziSw.checked;
    if (numBirthBtn) numBirthBtn.hidden = !on;
    syncNumBirthLabel();   // 直接读八字页日期作为数字能量的出生日期
  };
  if (numBaziSw) {
    try { if (localStorage.getItem('numUseBazi') === '1') numBaziSw.checked = true; } catch (e) {}
    syncNumBaziUI();
    numBaziSw.addEventListener('change', () => {
      const on = numBaziSw.checked;
      try { localStorage.setItem('numUseBazi', on ? '1' : '0'); } catch (e) {}
      syncNumBaziUI();
      renderNumberMath();
      // 勾选/取消结合八字喜用：实时重算吉祥号码候选列表（含提示语），否则要再点一次生成才生效
      const genOut = document.getElementById('num-gen-out');
      if (genOut && genOut.querySelector('.num-gen-item')) renderLuckyNumbers();
    });
    // 数字能量本地弹滚轮选出生日期（预填八字页日期，确认后双向同步）
    if (numBirthBtn) numBirthBtn.addEventListener('click', ()=>dwOpen({ calType:'solar' }));
  }
  const genBtn = document.getElementById('num-gen-btn');
  if (genBtn) genBtn.onclick = renderLuckyNumbers;
  const meihuaInput = document.getElementById('meihua-value');
  if (meihuaInput) meihuaInput.addEventListener('input', renderMeihua);
  const lpBtn = document.getElementById('luopan-compass-btn');
  if (lpBtn) lpBtn.onclick = toggleLuopanLock;
  renderBazi();           // 默认排一卦
  renderNumberMath();     // 数理页默认激活数字能量子页，载入即显示该页
  initNameBirth();
  renderNameStrokes();
  initAboutPage();
}

// 复制文本到剪贴板（优先异步 API，file:// WebView 用 execCommand 兜底）
function _copyText(url, btn){
  const done = ()=> _flashBtn(btn, '链接已复制');
  const fail = ()=> _flashBtn(btn, '复制失败，长按链接');
  try {
    if (navigator.clipboard && navigator.clipboard.writeText){
      navigator.clipboard.writeText(url).then(done, fail);
    } else {
      const ta = document.createElement('textarea');
      ta.value = url; ta.style.position = 'fixed'; ta.style.left = '-9999px';
      document.body.appendChild(ta); ta.select();
      const ok = document.execCommand('copy');
      document.body.removeChild(ta);
      ok ? done() : fail();
    }
  } catch(e){ fail(); }
}
function _flashBtn(btn, msg){
  if (!btn) return;
  const orig = btn.innerHTML;
  btn.innerHTML = '<span>' + msg + '</span>';
  setTimeout(()=>{ btn.innerHTML = orig; }, 1600);
}

function initAboutPage(){
  const copyBtn = document.getElementById('about-copy-email');
  const emailEl = document.getElementById('about-email');
  if (copyBtn && emailEl){
    copyBtn.addEventListener('click', async ()=>{
      const email = emailEl.textContent;
      try {
        if (navigator.clipboard && navigator.clipboard.writeText){
          await navigator.clipboard.writeText(email);
        } else {
          const ta = document.createElement('textarea');
          ta.value = email; ta.style.position = 'fixed'; ta.style.left = '-9999px';
          document.body.appendChild(ta);
          ta.select();
          document.execCommand('copy');
          document.body.removeChild(ta);
        }
        const orig = copyBtn.innerHTML;
        copyBtn.innerHTML = '<span>已复制</span><small>' + email + '</small>';
        setTimeout(()=> copyBtn.innerHTML = orig, 1600);
      } catch(e){}
    });
  }
  const qr = document.getElementById('about-qr');
  if (qr){
    qr.addEventListener('error', ()=>{
      var wrap = document.getElementById('about-qr-wrap');
      if (wrap) wrap.style.display = 'none';
    });
  }
  // 分享给好友：点击直接复制安装包下载链接到剪贴板，反馈「链接已复制」
  const shareBtn = document.getElementById('about-share');
  if (shareBtn){
    const APP_URL = 'https://cdn.jsdelivr.net/gh/DJW0420613/jianceji-ota@latest/jiancheji-release.apk';
    shareBtn.addEventListener('click', ()=> _copyText(APP_URL, shareBtn));
  }
  if (typeof fetch === 'function'){
    fetch('version.json', { cache:'no-store' })
      .then(r=> r.ok ? r.json() : null)
      .then(d=>{
        if (d && d.appVersion){ const v=document.getElementById('about-version'); if(v) v.textContent=d.appVersion; }
        const el = document.getElementById('about-build');
        if (el && d){
          const h = d.buildHash ? d.buildHash : '—';
          const t = d.buildAt ? ' · ' + d.buildAt : '';
          el.textContent = h + t;
        }
      })
      .catch(()=>{});
  }
}

// ============ App 壳 / 远程加载专属逻辑 ============
// 两种远程模式：
// ① Capacitor 云壳：URL 带 ?shell=1.0.0 参数
// ② 公共 CDN 加载（jsDelivr）：内容实时来自 claw-web 仓库，刷新即更新
function setupAppShell(){
  var sp = new URLSearchParams(location.search);
  var shellV = sp.get('shell');
  var isCdn = location.hostname.indexOf('jsdelivr') >= 0;
  var isRemote = !!shellV || isCdn;
  if (!isRemote) return;                       // 普通浏览器本地打开不触发
  document.body.classList.add('app-shell');
  var footer = document.querySelector('.site-footer span');
  if (footer) footer.textContent = 'App 模式 · 内容实时同步云端，老师更新后刷新即生效';
  var brand = document.querySelector('.brand');
  if (brand && !document.getElementById('app-badge')) {
    var b = document.createElement('span');
    b.id = 'app-badge'; b.className = 'app-badge';
    b.textContent = isCdn ? 'App · 实时同步' : 'App · 实时云端';
    brand.appendChild(b);
  }
  // 注：已停用自动更新横幅（不再从远程 apkUrl 拉取安装包），
  // 避免误导用户装回公开仓的旧版本。所有更新统一走本机覆盖安装最新 APK。
}
function cmpVer(a, b){
  var pa = String(a).split('.').map(Number);
  var pb = String(b).split('.').map(Number);
  var n = Math.max(pa.length, pb.length);
  for (var i=0;i<n;i++){
    var x = pa[i]||0, y = pb[i]||0;
    if (x>y) return 1; if (x<y) return -1;
  }
  return 0;
}
function showUpdateBanner(d){
  if (document.getElementById('app-update-banner')) return;
  var bar = document.createElement('div');
  bar.id = 'app-update-banner'; bar.className = 'app-update-banner';
  bar.appendChild(document.createTextNode('发现新版本 v' + d.appVersion));
  if (d.note) bar.appendChild(document.createTextNode('：' + d.note));
  var btn = document.createElement('a');
  btn.className = 'aub-btn'; btn.textContent = '更新';
  btn.href = d.apkUrl || '#'; btn.target = '_blank'; btn.rel = 'noopener';
  var close = document.createElement('span');
  close.className = 'aub-close'; close.textContent = '×'; close.title = '关闭';
  close.onclick = function(){ bar.remove(); };
  bar.appendChild(btn); bar.appendChild(close);
  document.body.appendChild(bar);
}

function initLngPicker(){
  const sel = document.getElementById('bazi-longitude');
  const disp = document.getElementById('bazi-longitude-disp');
  const mask = document.getElementById('lng-picker-mask');
  const list = document.getElementById('lng-list');
  const sheet = document.getElementById('lng-picker-sheet');
  if (!sel || !disp || !mask || !list || !sheet) return;

  const syncDisp = ()=>{ const o = sel.options[sel.selectedIndex]; const t = o ? o.textContent : '北京'; disp.textContent = t; const dp = document.getElementById('dp-lng-disp'); if (dp) dp.textContent = t; };
  syncDisp();

  let selVal = sel.value;
  function buildList(){
    list.innerHTML = '';
    Array.prototype.forEach.call(sel.options, (o)=>{
      if (o.textContent === '选择出生地') return;   // 占位提示不进城市列表，保持列表纯净
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'lng-item' + (o.value === selVal ? ' sel' : '');
      b.textContent = o.textContent;
      // 选择即返回：点城市直接选中并关闭，无需再点“确定”（出生地是单一选择）
      b.addEventListener('click', ()=>{ sel.value = o.value; selVal = o.value; syncDisp(); hide(); });
      list.appendChild(b);
    });
  }

  // 像时间滚轮一样就近跟随“出生地”按钮定位（JS 设 left/top），高度由 CSS 固定裁剪（列表显 5 行，超出滚动），不再动态算高度
  function positionLngSheet(anchor){
    if (!anchor) anchor = disp;
    sheet.style.maxHeight = '';   // 交还 CSS：.lng-list 固定显 5 行
    const r = anchor.getBoundingClientRect();
    const sw = sheet.offsetWidth || 280;
    const sh = sheet.offsetHeight || 320;
    const vw = window.innerWidth, vh = window.innerHeight;
    // 顶部安全间距：避开手机状态栏（时间/电量）。优先读原生注入的 --safe-top，无则回退 32px
    let safeTop = 32;
    try { const st = getComputedStyle(document.documentElement).getPropertyValue('--safe-top'); if (st){ const v = parseFloat(st); if (!isNaN(v)) safeTop = Math.max(safeTop, v); } } catch(e){}
    let left = r.left;
    if (left + sw > vw - 8) left = Math.max(8, vw - sw - 8);
    if (left < 8) left = 8;
    let top = r.bottom + 6;
    if (top + sh > vh - 8) top = r.top - 6 - sh;   // 下方放不下 → 翻到上方
    if (top < safeTop) top = safeTop;              // 上方也放不下 → 夹到状态栏安全间距，绝不进状态栏
    sheet.style.left = left + 'px';
    sheet.style.top = top + 'px';
  }

  function openLng(anchor){
    buildList();
    mask.hidden = false;
    requestAnimationFrame(()=>{ positionLngSheet(anchor || disp); });
  }

  function hide(){ mask.hidden = true; }

  // 八字页与滚轮内“出生地”都直接打开并就近定位
  disp.addEventListener('click', ()=> openLng(disp));
  const dpLng = document.getElementById('dp-lng-disp');
  if (dpLng) dpLng.addEventListener('click', ()=> openLng(dpLng));
  document.getElementById('lng-cancel').addEventListener('click', hide);
  // “确定”已无意义（点城市即返回），隐藏之
  const cf = document.getElementById('lng-confirm'); if (cf) cf.style.display = 'none';
  mask.addEventListener('click', (e)=>{ if (e.target === mask) hide(); });
}

// 兼容DOMContentLoaded 已提前触发的环境（部分预览器异步注入脚本）
function markOtaReady(){
  try {
    var cap = window.Capacitor;
    var up = cap && cap.Plugins && cap.Plugins.CapacitorUpdater;
    if (up && typeof up.notifyAppReady === 'function') up.notifyAppReady();
  } catch (e) {}
}
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initApp);
  document.addEventListener('DOMContentLoaded', setupAppShell);
  document.addEventListener('DOMContentLoaded', markOtaReady);
} else {
  initApp();
  setupAppShell();
  markOtaReady();
}
