/* ===================================================================
 * 简策集  Build ancient text and bazi
 * 八字排盘 / 万年历 / 古籍阅读 / 数理分析
 * 农历与节气数据来自 calendar.js（jjonline，1900–2100）
 * =================================================================== */


/* UI 层：引擎核心已抽至 engine-core.js（2026-08-18 双端同源） */
function wxTag(wx){ return `<span class="wx-${wx}">${WX_NAME[wx]}</span>`; }

// 十二时辰下拉：value=时辰序 0-11（子…亥），标签含时间段，便于直观选择
const SHICHEN_RANGES = ['23–1','1–3','3–5','5–7','7–9','9–11','11–13','13–15','15–17','17–19','19–21','21–23'];
function fillShichenSelect(sel, defIdx){
  if (!sel) return;
  sel.innerHTML = '';
  for (let i=0;i<12;i++){
    const o=document.createElement('option');
    o.value=i; o.textContent = BRANCHES[i]+'时 '+SHICHEN_RANGES[i]+'点';
    sel.appendChild(o);
  }
  if (defIdx!=null && defIdx>=0 && defIdx<12) sel.value = defIdx;
}
// 从 date input 的 value（YYYY-MM-DD）拆出 年/月/日
function parseDateInput(id){
  const el = document.getElementById(id);
  if (!el || !el.value) return null;
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(el.value);
  if (!m) return null;
  const y = +m[1], mo = +m[2], d = +m[3];
  if (y < 100 || mo < 1 || mo > 12 || d < 1 || d > 31) return null;
  return { y, m: mo, d };
}
function formatDateInput(y, m, d){
  const p = n => String(n).padStart(2,'0');
  return `${y}-${p(m)}-${p(d)}`;
}
// 时辰序 → 代表时:分（保证 computeBazi 内 hourBranch 反推回同一时辰）
function shichenToHM(sc){ return [ (sc===0 ? 0 : sc*2) % 24, 0 ]; }

function initBaziForm(){
  fillShichenSelect(document.getElementById('bazi-shichen'), 6);   // 默认午时
  fillShichenSelect(document.getElementById('lunar-shichen'), 6);
  updateShichenDisp('bazi-shichen');
  updateShichenDisp('lunar-shichen');

  // 默认出生时间由 Birth 单一数据源初始化（2026-07-02 午时），并同步隐藏镜像与显示标签
  Birth._syncDOM();
  applyBaziCalTypeRows();   // 恢复上次历法（localStorage）时同步公历/农历行显隐
  // 历法选择已并入时间滚轮（滚轮内可切新历/农历），页面不再有独立历法入口：
  // 「出生日期」入口只弹滚轮（不展开出生卡，避免取消后卡片残留遮挡排盘）
  const curCal = ()=>{ const b = (typeof Birth !== 'undefined' && Birth) ? Birth.get() : null; return (b && b.calType === 'lunar') ? 'lunar' : 'solar'; };
  const entryCal = document.getElementById('bazi-entry-cal');
  if (entryCal) entryCal.addEventListener('click', ()=>{
    dwOpen({ calType:curCal() });
  });
  // 出生信息各输入变化 → 同步下方日期标签
  ['solar-date','bazi-shichen','lunar-date','lunar-shichen','lunar-leap'].forEach(id=>{
    const el = document.getElementById(id); if (el) el.addEventListener('change', updateBaziDateLabel);
  });
  document.querySelectorAll('input[name=gender]').forEach(r=> r.addEventListener('change', ()=>{ updateBaziDateLabel(); applyMainToSheet(); saveGender(document.querySelector('input[name=gender]:checked')?.value); }));
  const tsEl = document.getElementById('bazi-truesolar'); if (tsEl) tsEl.addEventListener('change', applyMainToSheet);
  const ziEl = document.getElementById('bazi-zi'); if (ziEl) ziEl.addEventListener('change', applyMainToSheet);
  // 年月日滚动选择器：显示按钮 → 打开滚轮（按当前历法；历法切换在滚轮内完成）
  ['solar-date-disp','lunar-date-disp','bazi-shichen-disp','lunar-shichen-disp'].forEach(id=>{
    const el = document.getElementById(id);
    if (el) el.addEventListener('click', ()=>dwOpen({ calType:curCal() }));
  });
  refreshDateDisps();
  // 历史记录：绑定「历史记录」切片展开/收起 + 清空
  const histBtn = document.getElementById('history-toggle');
  if (histBtn) histBtn.onclick = ()=> toggleHistory();
  const histClear = document.getElementById('history-clear');
  if (histClear) histClear.onclick = async ()=>{
    if (await showAppConfirm('确定清空全部排盘记录？')){ clearHistory(); renderHistoryList(); }
  };
  initAppConfirm();
  // ---- 悬浮 FAB 可拖动（触摸 + 鼠标），位置记忆，拖动不触发点击，边界不挡底部导航 ----
  function enableFabDrag(fab){
    if (fab.dataset.dragBound) return;
    fab.dataset.dragBound = '1';
    let startX=0, startY=0, origLeft=0, origTop=0, dragging=false, moved=false;
    const TH = 8; // 拖动阈值(px)，小于此视为点击
    function clampSet(nl, nt){
      const r = fab.getBoundingClientRect();
      const vw = window.innerWidth, vh = window.innerHeight;
      nl = Math.max(4, Math.min(nl, vw - r.width - 4));
      nt = Math.max(4, Math.min(nt, vh - r.height - 70)); // 底部留导航区
      fab.style.left = nl + 'px';
      fab.style.top = nt + 'px';
    }
    function toLeftTop(){
      const r = fab.getBoundingClientRect();
      fab.style.right = 'auto'; fab.style.bottom = 'auto';
      fab.style.left = r.left + 'px'; fab.style.top = r.top + 'px';
      return r;
    }
    function start(cx, cy){ const r = toLeftTop(); startX = cx; startY = cy; origLeft = r.left; origTop = r.top; dragging = true; moved = false; }
    function move(cx, cy){
      if(!dragging) return;
      const dx = cx-startX, dy = cy-startY;
      if(!moved && (Math.abs(dx)>TH || Math.abs(dy)>TH)) moved = true;
      if(moved) clampSet(origLeft+dx, origTop+dy);
    }
    function end(){
      if(!dragging) return;
      dragging = false;
      if(moved){ try { localStorage.setItem('fab_pos', JSON.stringify({ left: parseFloat(fab.style.left)||0, top: parseFloat(fab.style.top)||0 })); } catch(e){} }
    }
    fab.addEventListener('touchstart', e=>{ const t=e.touches[0]; start(t.clientX, t.clientY); }, {passive:true});
    fab.addEventListener('touchmove', e=>{ const t=e.touches[0]; move(t.clientX, t.clientY); if(moved) e.preventDefault(); }, {passive:false});
    fab.addEventListener('touchend', end);
    fab.addEventListener('mousedown', e=>{ start(e.clientX, e.clientY); e.preventDefault(); });
    window.addEventListener('mousemove', e=> move(e.clientX, e.clientY));
    window.addEventListener('mouseup', end);
    // 拖动结束后吞掉紧随的 click，避免误弹浮层
    fab.addEventListener('click', e=>{ if(moved){ e.stopImmediatePropagation(); e.preventDefault(); moved=false; } }, true);
  }
  // 悬浮入口：FAB 弹出「排盘方式」浮层（四柱入口切片），点击任一入口关闭浮层
  const _fab = document.getElementById('bazi-fab');
  const _entry = document.getElementById('bazi-entry-sheet');
  if (_fab && _entry){
    // 恢复上次拖动记忆的位置
    try {
      const sp = JSON.parse(localStorage.getItem('fab_pos') || 'null');
      if (sp && typeof sp.left === 'number'){ _fab.style.right='auto'; _fab.style.bottom='auto'; _fab.style.left=sp.left+'px'; _fab.style.top=sp.top+'px'; }
    } catch(e){}
    _fab.addEventListener('click', ()=>{ _entry.hidden = !_entry.hidden; });
    _entry.addEventListener('click', (e)=>{ if (e.target === _entry) _entry.hidden = true; });
    const _row = document.getElementById('bazi-caltype-row');
    if (_row) _row.addEventListener('click', (e)=>{ if (e.target.closest('.seg')) _entry.hidden = true; });
    enableFabDrag(_fab);
  }
  // 历史记录面板：点击面板之外（且非历史切片按钮）即收起
  document.addEventListener('click', (e)=>{
    const panel = document.getElementById('history-panel');
    if (!panel || panel.hidden) return;
    if (e.target.closest('#history-panel')) return;
    if (e.target.closest('#history-toggle')) return;
    panel.hidden = true;
    const btn = document.getElementById('history-toggle');
    if (btn){ btn.classList.remove('on'); btn.setAttribute('aria-expanded','false'); }
  });
}

/* ===================== 排盘历史记录 =====================
   每次成功排盘后写入 localStorage（clawBaziHistory_v1），同四柱+性别去重，最多 30 条。
   八字页「历史记录」切片点击展开列表，点某项回填并重排。 */
const HISTORY_KEY = 'clawBaziHistory_v1';
const HISTORY_MAX = 30;
function loadHistory(){
  try { const a = JSON.parse(localStorage.getItem(HISTORY_KEY) || '[]'); return Array.isArray(a) ? a : []; }
  catch(e){ return []; }
}
function saveHistory(arr){
  try { localStorage.setItem(HISTORY_KEY, JSON.stringify(arr.slice(0, HISTORY_MAX))); } catch(e){}
}
function pushHistory(item){
  const arr = loadHistory();
  const key = item.pillars + '|' + item.gender;
  const idx = arr.findIndex(h => (h.pillars + '|' + h.gender) === key);
  if (idx >= 0){ arr[idx] = Object.assign({}, arr[idx], item); }   // 同盘更新时间戳，不新增
  else { arr.unshift(item); }
  if (arr.length > HISTORY_MAX) arr.length = HISTORY_MAX;
  saveHistory(arr);
}
function clearHistory(){ saveHistory([]); }

/* 仅在用户显式确认排盘（滚轮确认 / 反推选中 / 历史项回填）后写入历史；
   自动渲染（切历法、Birth.subscribe、默认排一卦）不应记录。 */
let _baziRecordHistory = false;
/* applyHistory 程序化回填时不让 Birth.subscribe 的自动渲染抢跑（避免用旧历法段渲染/误 alert）；
   界面态就绪后由 applyHistory 显式 renderBazi 一次。 */
let _suppressBirthRender = false;

/* 通用确认弹层（替代原生 confirm） */
let _appConfirmResolve = null;
function showAppConfirm(msg){
  return new Promise((resolve)=>{
    _appConfirmResolve = resolve;
    const overlay = document.getElementById('app-confirm-overlay');
    const msgEl = document.getElementById('app-confirm-msg');
    if (msgEl) msgEl.textContent = msg;
    if (overlay) overlay.hidden = false;
  });
}
function hideAppConfirm(result){
  const overlay = document.getElementById('app-confirm-overlay');
  if (overlay) overlay.hidden = true;
  if (_appConfirmResolve){ _appConfirmResolve(result); _appConfirmResolve = null; }
}
function initAppConfirm(){
  const cancel = document.getElementById('app-confirm-cancel');
  const ok = document.getElementById('app-confirm-ok');
  if (cancel) cancel.onclick = ()=> hideAppConfirm(false);
  if (ok) ok.onclick = ()=> hideAppConfirm(true);
}

function renderHistoryList(){
  const list = document.getElementById('history-list');
  const empty = document.getElementById('history-empty');
  if (!list) return;
  const arr = loadHistory();
  list.innerHTML = '';
  if (!arr.length){ if (empty) empty.hidden = false; return; }
  if (empty) empty.hidden = true;
  arr.forEach((h)=>{
    const el = document.createElement('div');
    el.className = 'hist-item';
    const genderLabel = (h.gender === 'female') ? '坤造' : '乾造';
    const calLabel = (h.calType === 'lunar') ? '农历' : '新历';
    el.innerHTML = `<span class="hist-pillars">${h.pillars}</span>` +
      `<span class="hist-meta">${genderLabel} · ${calLabel} ${h.solarLabel || ''}</span>`;
    el.onclick = ()=> applyHistory(h);
    list.appendChild(el);
  });
}
function toggleHistory(){
  const panel = document.getElementById('history-panel');
  const btn = document.getElementById('history-toggle');
  if (!panel) return;
  const show = panel.hidden;
  panel.hidden = !show;
  if (btn){ btn.classList.toggle('on', show); btn.setAttribute('aria-expanded', String(show)); }
  if (show) renderHistoryList();
}
function applyHistory(h){
  if (!h) return;
  // 兼容旧 schema：优先 h.solar，其次 h.date（数组），再退 h.y/h.m/h.d；都没有则尝试从 pillars 取不出公历，报错提示
  let solar = (Array.isArray(h.solar) && h.solar.length >= 3) ? h.solar
            : (Array.isArray(h.date) && h.date.length >= 3) ? h.date
            : (typeof h.y === 'number' && typeof h.m === 'number' && typeof h.d === 'number') ? [h.y, h.m, h.d]
            : null;
  if (!solar || !solar[0] || !solar[1] || !solar[2]){
    console.error('历史记录缺少有效公历日期，无法回填', h);
    if (typeof alert === 'function') alert('该历史记录数据不完整，无法重新排盘');
    return;
  }
  const y = +solar[0], m = +solar[1], d = +solar[2];
  if (isNaN(y) || isNaN(m) || isNaN(d) || y < 100 || m < 1 || m > 12 || d < 1 || d > 31){
    console.error('历史记录日期非法', h);
    if (typeof alert === 'function') alert('该历史记录日期非法，无法重新排盘');
    return;
  }
  try {
    // 1) 先把界面态设好（性别 / 历法切新历），确保后续渲染用正确上下文；
    //    公历/农历输入行显隐由 Birth 订阅者按 calType 驱动，此处不再手动切换
    const gR = document.querySelector('input[name="gender"][value="' + (h.gender === 'female' ? 'female' : 'male') + '"]');
    if (gR) gR.checked = true;
    // 2) 抑制订阅者自动渲染，等界面态就绪后一次性渲染（避免用旧历法段渲染 / 农历分支误 alert）
    _suppressBirthRender = true;
    if (typeof Birth !== 'undefined' && Birth){
      _baziRecordHistory = true;
      const _hh = (typeof h.hour === 'number') ? h.hour : shichenToHM(h.shichen || 0)[0];
      const _mm = (typeof h.minute === 'number') ? h.minute : 0;
      Birth.set({ calType:'solar', y, m, d, leap:false, hour:_hh, minute:_mm, shichen: (h.shichen || 0) });
    }
  } catch(e){
    _suppressBirthRender = false;
    console.error('applyHistory 回填失败', e);
    if (typeof alert === 'function') alert('回填出生时间失败：' + (e && e.message ? e.message : e));
    return;
  } finally {
    _suppressBirthRender = false;
  }
  // 3) 关闭面板
  const panel = document.getElementById('history-panel');
  if (panel) panel.hidden = true;
  const btn = document.getElementById('history-toggle');
  if (btn){ btn.classList.remove('on'); btn.setAttribute('aria-expanded','false'); }
  // 4) 界面态已就绪 → 用新历上下文一次性渲染
  if (typeof renderBazi === 'function') renderBazi();
}

/* ============ 统一出生时间数据源 Birth（单一真相） ============
   八字 / 起名 / 数理 三页共用同一份出生时间。任意一页确认滚轮后写回 Birth，
   自动同步隐藏 DOM 镜像（#solar-date / #lunar-date / #lunar-leap / #bazi-shichen / #lunar-shichen）
   并通知所有订阅者刷新，彻底取代 DP_lastPicked / window.nameBirthSel 等散落状态。 */
const Birth = {
  _v: { calType:'solar', y:2026, m:7, d:2, leap:false, hour:12, minute:0, shichen:6 },
  _subs: [],
  _init(){
    try {
      const s = localStorage.getItem('clawBirth');
      if (s){ const o = JSON.parse(s); if (o && o.y >= 1900){
        Object.assign(this._v, o);
        // 旧数据仅含 shichen 时，按 shichen 派生 hour（避免沿用默认 hour=12）
        if (typeof o.hour !== 'number' && typeof this._v.shichen === 'number'){ this._v.hour = shichenToHM(this._v.shichen)[0]; }
      } }
    } catch(e){}
    if (typeof this._v.hour !== 'number'){ this._v.hour = shichenToHM(this._v.shichen || 0)[0]; }
    if (typeof this._v.minute !== 'number'){ this._v.minute = 0; }
  },
  // 时间统一以 hour(0-23)+minute(0-59) 为权威源，shichen 为派生兼容字段；旧数据缺小时/分钟时回退。
  _normalize(){
    if (typeof this._v.hour === 'number' && typeof this._v.shichen !== 'number'){ this._v.shichen = hourBranch(this._v.hour); }
    if (typeof this._v.shichen === 'number' && typeof this._v.hour !== 'number'){ this._v.hour = shichenToHM(this._v.shichen)[0]; }
    if (typeof this._v.minute !== 'number'){ this._v.minute = 0; }
  },
  get(){ return Object.assign({}, this._v); },
  // 取农历表示：_v 内 y/m/d 恒为公历真值（dwConfirm 无论 solar/lunar 模式都存公历，
  // leap 为农历闰月标记），故农历表示始终由 solar→lunar 换算得到，
  // 绝不可直接用 _v.y/m/d 当农历值（否则在“数理/起名用公历输完后切八字农历”会算错 → “农历日期不存在”）
  lunar(){
    const cv = window.calendar.solar2lunar(this._v.y, this._v.m, this._v.d);
    if (!cv || cv === -1) return null;
    return { ly:cv.lYear, lm:cv.lMonth, ld:cv.lDay, leap:cv.isLeap };
  },
  set(partial){
    Object.assign(this._v, partial);
    this._normalize();
    try { localStorage.setItem('clawBirth', JSON.stringify(this._v)); } catch(e){}
    this._syncDOM();
    this._notify();
  },
  _syncDOM(){
    const v = this._v;
    const solarEl = document.getElementById('solar-date');
    const lunarEl = document.getElementById('lunar-date');
    const lunarLeap = document.getElementById('lunar-leap');
    const baziShi = document.getElementById('bazi-shichen');
    const lunarShi = document.getElementById('lunar-shichen');
    if (solarEl) solarEl.value = formatDateInput(v.y, v.m, v.d);
    const lv = this.lunar();
    if (lunarEl && lv) lunarEl.value = formatDateInput(lv.ly, lv.lm, lv.ld);
    if (lunarLeap) lunarLeap.checked = (v.calType === 'lunar') ? !!v.leap : false;
    if (baziShi) baziShi.value = String(v.shichen);
    if (lunarShi) lunarShi.value = String(v.shichen);
    if (typeof updateDateDisp === 'function'){ updateDateDisp('solar'); updateDateDisp('lunar'); }
    if (typeof updateShichenDisp === 'function'){ updateShichenDisp('bazi-shichen'); updateShichenDisp('lunar-shichen'); }
  },
  _notify(){ this._subs.forEach(fn=>{ try { fn(this.get()); } catch(e){ console.error(e); } }); },
  subscribe(fn){ this._subs.push(fn); }
};
Birth._init();

/* ============ 统一日期/时辰滚轮 DateWheel（年·月·日·时辰，跨页共用） ============ */
const DW = {
  mask:null, sheet:null, title:null, leapWrap:null, leapChk:null, caltypeRow:null, fromZeri:false,
  inner:{year:null, month:null, day:null, hour:null, minute:null},
  colEl:{year:null, month:null, day:null, hour:null, minute:null},
  values:{year:[], month:[], day:[], hour:[], minute:[]},
  ITEM_H:46, VISIBLE:5,
  sel:{y:2026, m:7, d:2, leap:false, hour:12, minute:0, shichen:6},
  calType:'solar',
  onConfirm:null,
  ready:false, _t:{}
};

function dwEnsureInit(){
  if (DW.ready) return;
  DW.mask = document.getElementById('date-picker-mask');
  DW.sheet = document.getElementById('date-picker-sheet');
  DW.title = document.getElementById('dp-title');
  DW.leapWrap = document.getElementById('dp-leap-wrap');
  DW.leapChk = document.getElementById('dp-leap');
  DW.caltypeRow = document.getElementById('dp-caltype-row');
  DW.inner.year = document.getElementById('dp-year-inner');
  DW.inner.month = document.getElementById('dp-month-inner');
  DW.inner.day = document.getElementById('dp-day-inner');
  DW.inner.hour = document.getElementById('dp-hour-inner');
  DW.inner.minute = document.getElementById('dp-minute-inner');
  ['year','month','day','hour','minute'].forEach(u=>{
    DW.colEl[u] = DW.inner[u].parentElement;
    DW.colEl[u].addEventListener('scroll', ()=>dwOnScroll(u), {passive:true});
  });
  document.getElementById('dp-cancel').onclick = dwClose;
  document.getElementById('dp-confirm').onclick = dwConfirm;
  DW.leapChk.addEventListener('change', ()=>{ DW.sel.leap = DW.leapChk.checked; dwRebuildDay(); dwApplySel(); });
  // 滚轮内新历/农历切换：切历法即按对应历法重渲年月日列（八字页显示，其余页隐藏）
  if (DW.caltypeRow){
    DW.caltypeRow.querySelectorAll('.seg[data-caltype]').forEach(b=>{
      b.addEventListener('click', ()=>dwSetCalType(b.dataset.caltype));
    });
  }
  DW.mask.addEventListener('click', e=>{ if (e.target===DW.mask) dwClose(); });
  // 弹层内的出生信息控件（男/女/真太阳时/早夜子时/经度）↔ 主页面 双向同步
  DW.sheet.querySelectorAll('input[name="dp-gender"]').forEach(r=> r.addEventListener('change', applySheetToMain));
  const dpTs = document.getElementById('dp-truesolar'); if (dpTs) dpTs.addEventListener('change', applySheetToMain);
  const dpZi = document.getElementById('dp-zi'); if (dpZi) dpZi.addEventListener('change', applySheetToMain);
  // 出生地下拉框的打开逻辑改由 initLngPicker 内就近定位打开（见 initLngPicker），此处不再委托给八字页控件
  DW.ready = true;
}

// 滚轮内切换历法：保留已选日期换算（公历↔农历），重渲月列/闰月/日列
function dwSetCalType(calType){
  if (calType !== 'lunar') calType = 'solar';
  if (DW.calType === calType) return;
  if (calType === 'lunar'){
    const cv = window.calendar.solar2lunar(DW.sel.y, DW.sel.m, DW.sel.d);
    if (cv && cv !== -1){ DW.sel.y = cv.lYear; DW.sel.m = cv.lMonth; DW.sel.d = cv.lDay; DW.sel.leap = cv.isLeap; }
  } else {
    const cv = window.calendar.lunar2solar(DW.sel.y, DW.sel.m, DW.sel.d, DW.sel.leap);
    if (cv && cv !== -1){ DW.sel.y = cv.cYear; DW.sel.m = cv.cMonth; DW.sel.d = cv.cDay; DW.sel.leap = false; }
  }
  DW.calType = calType;
  if (DW.caltypeRow){
    DW.caltypeRow.querySelectorAll('.seg[data-caltype]').forEach(b=> b.classList.toggle('on', b.dataset.caltype === calType));
  }
  DW.values.month = [];
  for (let m=1; m<=12; m++) DW.values.month.push(m);
  dwRender('month', val=>(calType==='lunar' ? (LUNAR_MONTHS[val-1] || (val+'月')) : (val+'月')));
  DW.leapWrap.hidden = (calType !== 'lunar');
  if (calType === 'lunar') dwUpdateLeapAvail();
  dwRebuildDay();
  dwApplySel();
}

// 打开统一滚轮：calType 决定年/月/日按公历还是农历显示；时辰列始终显示
function dwOpen(opts){
  dwEnsureInit();
  opts = opts || {};
  DW.calType = (opts.calType === 'lunar') ? 'lunar' : 'solar';
  DW.onConfirm = opts.onConfirm || null;
  DW.fromZeri = (opts.calTypeSwitch === true);
  // 滚轮弹出时强制收起出生信息卡（避免其残留显示在排盘结果上方挡视线），关掉时按之前状态恢复
  const _baziCard = document.getElementById('bazi-card');
  if (_baziCard){
    DW._baziWasShown = _baziCard.classList.contains('show');
    _baziCard.classList.remove('show');
  }
  // 历法切换条：八字页默认显示；择日页显式开启（calTypeSwitch）；数理/起名页隐藏
  const _active = document.querySelector('.panel.active');
  const _isBazi = !!(_active && _active.id === 'bazi');
  if (DW.caltypeRow){
    DW.caltypeRow.hidden = !(opts.calTypeSwitch || _isBazi);
    DW.caltypeRow.querySelectorAll('.seg[data-caltype]').forEach(b=> b.classList.toggle('on', b.dataset.caltype === DW.calType));
  }
  const v = Birth.get();
  const init = opts.initial || null;   // 择日场景：以调用方提供的公历日期为滚轮初始值
  if (DW.calType === 'lunar'){
    let _ly, _lm, _ld, _leap;
    if (init){
      const cv = window.calendar.solar2lunar(init.y, init.m, init.d);
      if (cv && cv !== -1){ _ly = cv.lYear; _lm = cv.lMonth; _ld = cv.lDay; _leap = cv.isLeap; }
    } else {
      const lv = Birth.lunar();
      if (lv){ _ly = lv.ly; _lm = lv.lm; _ld = lv.ld; _leap = lv.leap; }
    }
    if (_ly){ DW.sel.y = _ly; DW.sel.m = _lm; DW.sel.d = _ld; DW.sel.leap = _leap; }
    else { DW.calType = 'solar'; }
  }
  if (DW.calType === 'solar'){
    if (init){ DW.sel.y = init.y; DW.sel.m = init.m; DW.sel.d = init.d; DW.sel.leap = false; }
    else { DW.sel.y = v.y; DW.sel.m = v.m; DW.sel.d = v.d; DW.sel.leap = false; }
  }
  DW.sel.hour = (typeof v.hour === 'number') ? v.hour : shichenToHM(v.shichen || 0)[0];
  DW.sel.minute = (typeof v.minute === 'number') ? v.minute : 0;
  DW.title.textContent = '请选择出生时间';
  DW.leapWrap.hidden = (DW.calType !== 'lunar');
  DW.values.year = [];
  for (let y=1900; y<=2100; y++) DW.values.year.push(y);
  dwRender('year', val=>`${val}年`);
  DW.values.month = [];
  for (let m=1; m<=12; m++) DW.values.month.push(m);
  dwRender('month', val=>(DW.calType==='lunar' ? (LUNAR_MONTHS[val-1] || (val+'月')) : (val+'月')));
  if (DW.calType==='lunar'){
    const lm = window.calendar.leapMonth(DW.sel.y);
    const hasLeap = (lm === DW.sel.m);
    DW.leapChk.disabled = !hasLeap;
    DW.leapChk.checked = hasLeap ? DW.sel.leap : false;
    DW.sel.leap = DW.leapChk.checked;
  }
  DW.values.hour = [];
  for (let i=0; i<24; i++) DW.values.hour.push(i);
  dwRender('hour', val=>`${BRANCHES[hourBranch(val)]}时 ${val}点`);
  DW.values.minute = [];
  for (let i=0; i<60; i++) DW.values.minute.push(i);
  dwRender('minute', val=>`${String(val).padStart(2,'0')}分`);
  dwRebuildDay();
  dwApplySel();
  DW.mask.hidden = false;
  document.body.classList.add('dp-locked');
  applyMainToSheet();          // 打开时把主页面性别/选项/经度同步进弹层
  requestAnimationFrame(()=>{ dwApplySel(); positionSheetNearInput(); });
}

function dwRender(unit, fmt){
  const vals = DW.values[unit];
  let html = '';
  vals.forEach(v=>{ html += `<div class="dp-item">${fmt(v)}</div>`; });
  DW.inner[unit].innerHTML = html;
}

function dwRebuildDay(){
  const calType = DW.calType;
  let max;
  if (calType==='lunar'){
    max = DW.sel.leap ? window.calendar.leapDays(DW.sel.y) : window.calendar.monthDays(DW.sel.y, DW.sel.m);
    if (!(max > 0)) max = 30;
  } else {
    max = new Date(DW.sel.y, DW.sel.m, 0).getDate();
  }
  DW.values.day = [];
  for (let d=1; d<=max; d++) DW.values.day.push(d);
  dwRender('day', val=> val + '日');
}

function dwUpdateLeapAvail(){
  if (DW.calType !== 'lunar') return;
  const lm = window.calendar.leapMonth(DW.sel.y);
  const hasLeap = (lm === DW.sel.m);
  DW.leapChk.disabled = !hasLeap;
  if (!hasLeap){ DW.leapChk.checked = false; DW.sel.leap = false; }
}

function dwClampDay(){
  if (DW.sel.d > DW.values.day.length) DW.sel.d = DW.values.day[DW.values.day.length - 1] || 1;
  if (DW.sel.d < 1) DW.sel.d = 1;
}

function dwCenterOn(unit, idx){
  const col = DW.colEl[unit];
  const items = DW.inner[unit].querySelectorAll('.dp-item');
  if (idx < 0 || idx >= items.length) return;
  col.scrollTop = idx * DW.ITEM_H;
}

function dwApplySel(){
  dwClampDay();
  ['year','month','day','hour','minute'].forEach(u=>{
    const key = u==='year' ? 'y' : (u==='month' ? 'm' : (u==='day' ? 'd' : (u==='hour' ? 'hour' : 'minute')));
    let idx = DW.values[u].indexOf(DW.sel[key]);
    if (idx < 0) idx = Math.max(0, DW.values[u].length - 1);
    const items = DW.inner[u].querySelectorAll('.dp-item');
    items.forEach((el,i)=> el.classList.toggle('on', i===idx));
    dwCenterOn(u, idx);
  });
}

function dwOnScroll(unit){
  clearTimeout(DW._t[unit]);
  DW._t[unit] = setTimeout(()=>dwSettle(unit), 100);
}

function dwSettle(unit){
  const col = DW.colEl[unit];
  const colRect = col.getBoundingClientRect();
  const centerY = colRect.top + colRect.height/2;
  const items = DW.inner[unit].querySelectorAll('.dp-item');
  let best = -1, bestDist = Infinity;
  items.forEach((el,i)=>{
    const r = el.getBoundingClientRect();
    const c = r.top + r.height/2;
    const dist = Math.abs(c - centerY);
    if (dist < bestDist){ bestDist = dist; best = i; }
  });
  if (best < 0) return;
  const val = DW.values[unit][best];
  if (val == null) return;
  if (unit==='year'){ DW.sel.y = val; dwUpdateLeapAvail(); dwRebuildDay(); }
  else if (unit==='month'){ DW.sel.m = val; dwUpdateLeapAvail(); dwRebuildDay(); }
  else if (unit==='day'){ DW.sel.d = val; }
  else if (unit==='hour'){ DW.sel.hour = val; }
  else { DW.sel.minute = val; }
  dwApplySel();
}

function dwConfirm(){
  let y, m, d, leap = DW.sel.leap;
  const shichen = hourBranch(DW.sel.hour);
  if (DW.calType==='lunar'){
    const cv = window.calendar.lunar2solar(DW.sel.y, DW.sel.m, DW.sel.d, leap);
    if (!cv || cv === -1){ alert('该农历日期不存在，请重新选择'); return; }
    y = cv.cYear; m = cv.cMonth; d = cv.cDay;
  } else {
    y = DW.sel.y; m = DW.sel.m; d = DW.sel.d;
    const max = new Date(y, m, 0).getDate();
    if (!(d > 0 && d <= max)){ alert('该日期不存在，请重新选择'); return; }
  }
  // 择日场景（calTypeSwitch）选生日不写八字排盘历史，其余入口照常记录
  if (!DW.fromZeri) _baziRecordHistory = true;
  Birth.set({ calType:DW.calType, y, m, d, leap, hour:DW.sel.hour, minute:DW.sel.minute, shichen });
  dwClose();
  if (DW.onConfirm) DW.onConfirm(Birth.get());
}

function dwClose(){
  DW.mask.hidden = true;
  document.body.classList.remove('dp-locked');
  // 滚轮关闭后，按弹出前的状态恢复出生信息卡（避免残留遮挡）
  const _baziCard = document.getElementById('bazi-card');
  if (_baziCard && DW._baziWasShown) _baziCard.classList.add('show');
  DW._baziWasShown = null;
}

// 主页面 → 弹层：把性别/真太阳时/早夜子时/经度写进弹层控件
function applyMainToSheet(){
  const active = document.querySelector('.panel.active');
  let gval = 'male';
  if (active && active.id === 'name') gval = nameGender || 'male';
  else { const m = document.querySelector('input[name="gender"]:checked'); gval = m ? m.value : 'male'; }
  const s = document.querySelector('input[name="dp-gender"][value="' + gval + '"]');
  if (s) s.checked = true;
  const ts = document.getElementById('dp-truesolar'); if (ts) ts.checked = !!document.getElementById('bazi-truesolar').checked;
  const zi = document.getElementById('dp-zi'); if (zi) zi.checked = !!document.getElementById('bazi-zi').checked;
  const ld = document.getElementById('dp-lng-disp'); if (ld) ld.textContent = document.getElementById('bazi-longitude-disp').textContent;
}

// 弹层 → 主页面：弹层控件改动实时写回主页面（renderBazi 确认时直接读主页面控件）
function applySheetToMain(){
  const s = document.querySelector('input[name="dp-gender"]:checked');
  if (s){
    // 性别全局同步：无论从哪个页打开时间滚轮，都写回起名页状态与八字页性别单选，
    // 保证“起名页选日期+性别 → 八字排盘”时性别随之同步（日期已由 Birth.set 全局同步）
    nameGender = s.value;
    saveGender(s.value);
    const m = document.querySelector('input[name="gender"][value="' + s.value + '"]');
    if (m) m.checked = true;
    const active = document.querySelector('.panel.active');
    if (active && active.id === 'name'){
      // 已生成过候选名字时，滚轮内切换性别自动按新性别重新生成（男女字库不同，避免“切了性别名字没变”）
      const box = document.getElementById('name-candidates');
      if (box && box.querySelector('.cand-card')){ try { doGenerate(); } catch(e){} }
    }
  }
  document.getElementById('bazi-truesolar').checked = !!document.getElementById('dp-truesolar').checked;
  document.getElementById('bazi-zi').checked = !!document.getElementById('dp-zi').checked;
  if (typeof updateBaziDateLabel === 'function') updateBaziDateLabel();
}

// 弹层跟随日期输入框位置（不再是全屏底部弹层）
function getSheetAnchor(){
  // 时间滚轮跟随触发元素：八字页→出生信息卡；数理页→出生日期按钮；起名页→出生时间按钮；择日→用事人生日
  const active = document.querySelector('.panel.active');
  let el = null;
  if (active){
    if (active.id === 'bazi') el = document.getElementById('bazi-daterow');
    else if (active.id === 'math') el = document.getElementById('num-birth-btn');
    else if (active.id === 'name') el = document.getElementById('name-birth-btn');
    else if (active.id === 'calendar') el = document.getElementById('zeri-birth-btn');
  }
  if (!el || el.offsetParent === null) el = document.getElementById('bazi-daterow') || document.querySelector('.dt-date-disp');
  return el;
}
function positionSheetNearInput(){
  const sheet = DW.sheet; if (!sheet) return;
  const active = document.querySelector('.panel.active');
  sheet.style.maxHeight = '';
  let left, top;
  const sw = sheet.offsetWidth || 320, sh = sheet.offsetHeight || 420;
  const vw = window.innerWidth, vh = window.innerHeight;
  if (active && active.id === 'calendar'){
    // 择日页：时间滚轮居中显示（2026-08-10 用户定）
    left = Math.max(8, (vw - sw) / 2);
    top = Math.max(8, (vh - sh) / 2);
    sheet.style.left = left + 'px';
    sheet.style.top = top + 'px';
    sheet.style.maxHeight = Math.min(sh, vh - 16) + 'px';
    return;
  }
  const anchor = getSheetAnchor();
  if (!anchor || anchor.getBoundingClientRect().width === 0){
    // 无有效锚点（如隐藏）时居中兜底
    left = (vw - sw) / 2; top = (vh - sh) / 2;
  } else {
    const r = anchor.getBoundingClientRect();
    left = r.left;
    if (left + sw > vw - 8) left = Math.max(8, vw - sw - 8);
    if (left < 8) left = 8;
    // 时间滚轮卡片上边与触发元素下边平齐（仅留 4px 视觉呼吸）
    top = r.bottom + 4;
    if (top + sh > vh - 8){ top = r.top - 8 - sh; if (top < 8) top = 8; }
  }
  sheet.style.left = left + 'px';
  sheet.style.top = top + 'px';
  sheet.style.maxHeight = Math.min(sh, vh - 16) + 'px';
}

/* 隐藏 select 的当前值刷新到对应显示按钮 */
function updateShichenDisp(targetId){
  const disp = document.getElementById(targetId + '-disp');
  if (!disp) return;
  const v = (typeof Birth !== 'undefined' && Birth) ? Birth.get() : null;
  const h = (v && typeof v.hour === 'number') ? v.hour : 12;
  const m = (v && typeof v.minute === 'number') ? v.minute : 0;
  const pad = n => String(n).padStart(2,'0');
  disp.textContent = BRANCHES[hourBranch(h)] + '时 ' + pad(h) + ':' + pad(m);
}
function updateDateDisp(calType){
  const btn = document.getElementById((calType==='lunar' ? 'lunar-date-disp' : 'solar-date-disp'));
  if (!btn) return;
  if (calType==='lunar'){
    const l = parseDateInput('lunar-date');
    const leap = document.getElementById('lunar-leap').checked;
    if (l) btn.textContent = `${l.y}年 ${leap?'闰':''}${l.m}月${l.d}日`;
  } else {
    const s = parseDateInput('solar-date');
    if (s) btn.textContent = `${s.y}年${String(s.m).padStart(2,'0')}月${String(s.d).padStart(2,'0')}日`;
  }
}
function refreshDateDisps(){
  updateDateDisp('solar');
  updateDateDisp('lunar');
}

/* 订阅者：任意一页写回 Birth 后，所有相关页自动刷新（单一数据流，无手动互写） */
let _birthSubsReady = false;
// 公历/农历输入行显隐跟随当前历法（历法合并后切换只发生在滚轮确认时）
function applyBaziCalTypeRows(){
  const _b = Birth.get();
  const _solarRow = document.getElementById('bazi-daterow');
  const _lunarRow = document.getElementById('bazi-lunar-row');
  if (_solarRow) _solarRow.hidden = (_b.calType === 'lunar');
  if (_lunarRow) _lunarRow.hidden = (_b.calType !== 'lunar');
}
function initBirthSubs(){
  if (_birthSubsReady) return;
  _birthSubsReady = true;
  Birth.subscribe(()=>{
    applyBaziCalTypeRows();
    updateBaziDateLabel();
    if (_suppressBirthRender) return;   // applyHistory 回填期间，等界面态就绪后一次性渲染
    if (typeof renderBazi === 'function') renderBazi();
  });
  Birth.subscribe(()=>{
    const nameTab = document.getElementById('name');
    if (nameTab && nameTab.classList.contains('active')){
      syncNameBirthLabel(); computeName();
    }
  });
  Birth.subscribe(()=>{
    const mathTab = document.getElementById('math');
    if (mathTab && mathTab.classList.contains('active')){
      syncNumBirthLabel(); renderNumberMath();
    }
  });
}


/* 出生信息卡下方标签：展示当前所选出生日期摘要（第3条需求） */
function updateBaziDateLabel(){
  const label = document.getElementById('baziDateLabel');
  if (!label) return;
  const bz = (typeof Birth !== 'undefined' && Birth) ? Birth.get() : null;
  const calType = (bz && bz.calType === 'lunar') ? 'lunar' : 'solar';
  const gender = document.querySelector('input[name=gender]:checked')?.value === 'female' ? '女' : '男';
  const pad = n => String(n).padStart(2,'0');
  const shi = (bz && typeof bz.hour === 'number') ? (BRANCHES[hourBranch(bz.hour)] + '时') : '';
  let txt = '';
  if (calType === 'lunar'){
    const l = (typeof Birth !== 'undefined' && Birth) ? Birth.lunar() : null;
    if (l){
      let lmName = LUNAR_MONTHS[l.lm-1] || (l.lm + '月');
      let ldName = lunarDayLabel(l.ld);
      txt = `农历 ${l.ly}年 ${l.leap?'闰':''}${lmName} ${ldName} ${shi}（${gender}）`;
    }
  } else if (bz && bz.y >= 1900){
    txt = `公历 ${bz.y}年${pad(bz.m)}月${pad(bz.d)}日 ${shi}（${gender}）`;
  } else {
    const s = parseDateInput('solar-date');
    if (s) txt = `公历 ${s.y}年${pad(s.m)}月${pad(s.d)}日 ${shi}（${gender}）`;
  }
  label.textContent = txt;
  updateShichenDisp('bazi-shichen');
  updateShichenDisp('lunar-shichen');
  // 点结果头部日期标签 → 展开出生信息卡（真太阳时/出生地/早夜子时/性别在此改），改完点排盘自动收起
  if (!label._expandBound){
    label._expandBound = true;
    label.addEventListener('click', ()=>{
      document.getElementById('bazi-card').classList.add('show');
    });
  }
}

// 流月干支：取当前真实节气月柱（与排盘月柱同源，按节气月建，不用公历月近似）
function liuyueGanZhi(yearGan){
  const now = new Date();
  const o = calendar.solar2lunar(now.getFullYear(), now.getMonth()+1, now.getDate());
  if (o && o.gzMonth) return o.gzMonth;
  return '';
}
// 某流年 12 个流月柱（五虎遁：年干起寅月=正月；2026-08-20 岁运卡流月条用）
const LY_MONTHS = ['正月','二月','三月','四月','五月','六月','七月','八月','九月','十月','冬月','腊月'];
function liuYueList(yearGan){
  if (!yearGan) return [];
  const st = REV_WU_HU[yearGan];
  const brs = ['寅','卯','辰','巳','午','未','申','酉','戌','亥','子','丑'];
  const out = [];
  for (let i = 0; i < 12; i++) out.push({ gz: REV_STEMS[(st+i)%10] + brs[i], m: LY_MONTHS[i], idx: i });
  return out;
}

// 归一化：去掉八字文案字与字之间的多余空格（含汉字↔汉字、汉字↔数字、汉字↔<标签>）。
// 仅在两侧至少一方为中文/全角标点时删空格，故不会破坏时间(12:30 → 12:45)、年份区间(1900–2100)、
// HTML 标签属性(class="x")与标签间的布局空格。
function despaceCJK(s){
  if (typeof s !== 'string') return s;
  var C = '\u4e00-\u9fff\u3400-\u4dbf';
  var P = '（）【】『』：，。；、·°';
  var re1 = new RegExp('([' + C + P + '])[ \\t]+(?=[' + C + P + '0-9<])', 'g');
  var re2 = new RegExp('([0-9%°>）】』])[ \\t]+(?=[' + C + P + '])', 'g');
  var prev;
  do { prev = s; s = s.replace(re1, '$1').replace(re2, '$1'); } while (s !== prev);
  return s;
}

function renderBazi(){
  document.getElementById('bazi-card').classList.remove('show');   // 点排盘自动折叠出生信息卡
  updateBaziDateLabel();                                           // 刷新下方日期标签
  // 历法合并后：Birth 为单一真相，y/m/d 恒为公历真值（滚轮确认时已换算），calType 仅作注释/历史标记
  const bz = (typeof Birth !== 'undefined' && Birth) ? Birth.get() : null;
  const calType = (bz && bz.calType === 'lunar') ? 'lunar' : 'solar';
  let y, m, d, baziIsLeap = false;
  if (bz && bz.y >= 1900){
    y = bz.y; m = bz.m; d = bz.d; baziIsLeap = !!bz.leap;
  } else {
    const s = parseDateInput('solar-date');
    if (!s){ alert('请选择出生日期'); return; }
    y = s.y; m = s.m; d = s.d;
  }
  // 时间统一取自 Birth 精确时分（hour/minute）；仅在 Birth 缺小时（如反推仅写隐藏 select）时回落到隐藏 select 的时辰。
  let hh, mm;
  if (bz && typeof bz.hour === 'number' && typeof bz.minute === 'number'){
    hh = bz.hour; mm = bz.minute;
  } else {
    const timeSel = document.getElementById('bazi-shichen');
    const sc = timeSel ? (+timeSel.value) : 6;
    const hm = shichenToHM(isNaN(sc) ? 6 : sc);
    hh = hm[0]; mm = hm[1];
  }
  const gender = document.querySelector('input[name="gender"]:checked').value;
  const trueSolar = document.getElementById('bazi-truesolar').checked;
  const zi = document.getElementById('bazi-zi').checked;
  const lng = parseFloat(document.getElementById('bazi-longitude').value);
  const b = computeBazi(y, m, d, hh, mm, gender,
    { calType, trueSolar, longitude: isNaN(lng) ? 116.4 : lng, ziType: zi ? 'traditional' : 'modern', isLeap: baziIsLeap });
  window.lastBazi = b;
  const box = document.getElementById('bazi-result');

  if (b.error){ box.innerHTML = `<p class="hint">${b.error}</p>`; const _hs=document.getElementById('bazi-head-slot'); if(_hs) _hs.innerHTML=''; return; }

  // 写入排盘历史（仅用户显式确认后排盘；始终存公历真值，农历模式由 Birth 单一真相取公历）
  if (_baziRecordHistory) {
    _baziRecordHistory = false;
    try {
      const bv = (typeof Birth !== 'undefined' && Birth) ? Birth.get() : null;
      const sy = bv ? bv.y : y, sm = bv ? bv.m : m, sd = bv ? bv.d : d;
      pushHistory({
        pillars: b.year + b.month + b.day + b.hour,
        solar: [sy, sm, sd],
        gender,
        hour: hh, minute: mm,
        shichen: (bv ? bv.shichen : hourBranch(hh)),
        calType: (calType === 'lunar' ? 'lunar' : 'solar'),
        solarLabel: (typeof formatDateInput === 'function') ? formatDateInput(sy, sm, sd) : (sy + '-' + sm + '-' + sd),
        ts: Date.now()
      });
      if (!document.getElementById('history-panel').hidden) renderHistoryList();
    } catch(e){}
  }

  // 四柱（年/月/日/时）+ 当前大运/当前流年：统一为柱并入出生日期信息卡片。
  // 各柱去线框，仅日柱保留高亮；天干十神标注在天干上方（日柱不标）；
  // 地支藏干纵向排并标注对应十神；大运柱仅当已起运时显示。
  function buildPillarsHtml(b, gender){
    // 四柱（年/月/日/时）+ 大运/流年/流月：大运、流年跟随岁运卡片选择（b.activeDayunIdx / b.activeLiuNianIdx），
    // 流月始终显示当前月（真实当前流年干支，不随选择变）。
    const dm = b.dayMaster, dmWx = b.dayMasterWx;
    const dayGan = b.dayMaster, dayZhi = b.day[1], monthZhi = b.month[1], yearZhi = b.year[1];
    const kwBranches = kongwangBranches(dayGan, dayZhi);
    const makePillar = (role, gz, tg, isDay) => {
      const gan = gz[0], zhi = gz[1];
      const cang = (HIDDEN[zhi] || []).map(g => {
        const ss = shiShen(dm, dmWx, g, GAN_WX[g]);
        return { char:g, wx:GAN_WX[g], ss };
      });
      return {
        role,
        roleLabel: isDay ? (gender==='male' ? '乾造' : '坤造') : role,
        gan, zhi, ganWx: GAN_WX[gan], zhiWx: ZHI_WX[zhi],
        ganSS: (!isDay && tg.gan) ? tg.gan : '',
        cang,
        cs: changshengOf(dayGan, zhi),
        kw: kwBranches.includes(zhi) ? '空' : '',
        sha: AD_shenshaFull(zhi, gan, dayGan, dayZhi, monthZhi, yearZhi).map(x=>x.n),
        isDay
      };
    };
    const pillarData = [
      makePillar('年柱', b.year, b.tenGods.year, false),
      makePillar('月柱', b.month, b.tenGods.month, false),
      makePillar('日柱', b.day, b.tenGods.day, true),
      makePillar('时柱', b.hour, b.tenGods.hour, false)
    ];
    // 选中大运/流年（跟随岁运卡片选择；未选时取当前大运/当前年流年）
    const _di = Math.min(b.activeDayunIdx||0, (b.fortuneLines||[]).length-1);
    const _fl = (b.fortuneLines && b.fortuneLines[_di]) || null;
    const _liArr = _fl ? (_fl.liuNian||[]) : [];
    const _liIdx = (typeof b.activeLiuNianIdx === 'number') ? b.activeLiuNianIdx
      : (()=>{ const k=_liArr.findIndex(x=>x.year===b.liuNianYear); return k>=0?k:0; })();
    if (b.startedDayun){
      const _dGz = _fl ? _fl.gz : b.curDayunGz;
      const _dTg = _fl ? {gan: pillarTG(b.dayMaster, b.dayMasterWx, _fl.gz).gan} : b.tenGods.dayun;
      pillarData.push(makePillar('大运', _dGz, _dTg, false));
    }
    const _ln = _liArr[_liIdx] || null;
    const _lnGz = _ln ? _ln.gz : b.liuNianGz;
    const _lnTg = _ln ? {gan: pillarTG(b.dayMaster, b.dayMasterWx, _ln.gz).gan} : b.tenGods.liuNian;
    pillarData.push(makePillar('流年', _lnGz, _lnTg, false));
    const liuYueGz = b.activeLiuYueGz || liuyueGanZhi(b.liuNianGz[0]); // 流月跟随岁运卡选择；未选时真实当前月（2026-08-20）
    pillarData.push(makePillar('流月', liuYueGz, {gan: pillarTG(b.dayMaster, b.dayMasterWx, liuYueGz).gan}, false));
    const dayFlags = pillarData.map(p => p.isDay);
    const gCell = (html, i, extra='') => `<div class="g-cell${dayFlags[i]?' is-day':''}${extra?' '+extra:''}">${html}</div>`;
    const gRow = (cells, cls) => `<div class="g-row ${cls}">${cells.join('')}</div>`;
    const roleCells = pillarData.map((p,i)=>gCell(p.isDay?`<span class="day-pill">${p.role}</span>`:p.role,i));
    const ssCells = pillarData.map((p,i)=>gCell(p.isDay?`<span class="zao-tag">${gender==='male'?'乾造':'坤造'}</span>`:(p.ganSS||''),i));
    const gzCells = pillarData.map((p,i)=>gCell(`<span class="wx-${p.ganWx}">${p.gan}</span><span class="wx-${p.zhiWx}">${p.zhi}</span>`,i));
    const cangCells = pillarData.map((p,i)=>gCell(p.cang.map(c=>`<span class="cang-item"><span class="cang-gz">${c.char}</span><i class="cang-ss">${c.ss}</i></span>`).join(''),i));
    const csCells = pillarData.map((p,i)=>gCell(p.cs||'',i));
    const nayinCells = pillarData.map((p,i)=>{
      const ny = AD_NAYIN[p.gan+p.zhi]||'';
      let inner = '';
      if (ny){
        const wxCh = ny.slice(-1);
        const wxKey = {'金':'metal','木':'wood','水':'water','火':'fire','土':'earth'}[wxCh]||'';
        inner = `${ny.slice(0,-1)}<i class="wx-${wxKey}">${wxCh}</i>`;
      }
      return gCell(inner, i);
    });
    const kwCells = pillarData.map((p,i)=>gCell(p.kw||'',i, p.kw?'kw-on':''));
    const shaCells = pillarData.map((p,i)=>gCell(p.sha.map(s=>`<span class="sha-tag">${s}</span>`).join(''),i));
    const pillarsHtml = gRow(roleCells,'g-role')+gRow(ssCells,'g-ss')+gRow(gzCells,'g-gz')+gRow(cangCells,'g-cang')+gRow(csCells,'g-cs')+gRow(nayinCells,'g-nayin')+gRow(shaCells,'g-sha')+gRow(kwCells,'g-kw');
    return pillarsHtml;
  }
  const pillarsHtml = buildPillarsHtml(b, gender);
  // 初始化选中流年索引（当前大运内当年流年），供 rebuildHead 与岁运选择同步
  if (typeof b.activeLiuNianIdx !== 'number'){
    const _fl0 = (b.fortuneLines && b.fortuneLines[Math.min(b.activeDayunIdx||0,(b.fortuneLines||[]).length-1)])||null;
    const _la = _fl0?(_fl0.liuNian||[]):[];
    const _k = _la.findIndex(x=>x.year===b.liuNianYear);
    b.activeLiuNianIdx = _k>=0?_k:0;
  }
  function rebuildHead(){
    const headSlot = document.getElementById('bazi-head-slot');
    if (!headSlot) return;
    headSlot.innerHTML = despaceCJK(`<div class="pillars-scroll"><div class="pillars-grid">${buildPillarsHtml(b, gender)}</div></div>`);
  }
  b._rebuildHead = rebuildHead;

  const maxWx = Math.max(1, ...Object.values(b.wx));
  const wxRows = ['wood','fire','earth','metal','water'].map(w=>{
    const pct = Math.max(6, Math.round(b.wx[w]/maxWx*100));
    return `<div class="wx-row">
      <span class="wx-label">${WX_NAME[w]}${b.wx[w]}</span>
      <div class="wx-track"><div class="wx-fill wx-${w}" style="width:${pct}%"></div></div>
    </div>`;
  }).join('');
  // 格局简析内容由 AD_geJuJing（adv.geJuJing）统一生成，避免月令格重复/误判（如比劫当令不入正格）

  const dayunHtml = b.fortuneLines.map((l, i)=>{
    const gan = l.gz[0], zhi = l.gz[1];
    const ganWx = GAN_WX[gan], zhiWx = ZHI_WX[zhi];
    const ganSS = pillarTG(b.dayMaster, GAN_WX[b.dayMaster], l.gz).gan;
    const cang = (HIDDEN[zhi]||[]).map(g => ({ char:g, wx:GAN_WX[g], ss: shiShen(b.dayMaster, GAN_WX[b.dayMaster], g, GAN_WX[g]) }));
    const sy0 = y + l.age, ey0 = y + l.age + 9;
    return `<div class="dayun-item ${l.isXi?'lucky':(l.isJi?'warn':'flat')}" data-idx="${i}">
      <div class="du-top">
        <span class="du-age">${l.age}岁起</span>
        <span class="du-range">${sy0}–${ey0}</span>
      </div>
      <div class="du-axis"><span class="du-dot"></span></div>
      <div class="du-gz"><span class="wx-${ganWx}">${gan}</span><span class="wx-${zhiWx}">${zhi}</span></div>
    </div>`;
  }).join('');

  // 进阶批断 HTML（神煞 / 纳音 / 刑冲合害 / 调候 / 格局简析（含十神格局） / 十神组合 / 用神分层 / 六亲 / 流年交互）
  const adv = b.advanced || {};
  // 纳音五行已并入八字盘四柱网格（十二长生行下方），不再单列卡片
  const advShaDesc = adv.shenShaDesc || [];
  const advShaHtml = advShaDesc.length ? `<!-- ⑪ 神煞总览 卡片 --><div class="analysis-block"><h3><i class="ico"></i>神煞总览</h3><div class="sha-desc">${advShaDesc.map(x=>`<div class="sha-row"><span class="sha-tag sha-${x.typCls}">${x.typ}</span><span class="sha-name">${x.name}</span>：${x.desc.replace(/[（(][^）)]*[）)]/g,'')}</div>`).join('')}</div></div>` : '';
  const advRelItems = adv.relItems || [];
  const advRelHtml = advRelItems.length ? `<!-- ⑬ 地支关系·刑冲合害破 卡片 --><div class="analysis-block"><h3><i class="ico"></i>地支关系 · 刑冲合害破</h3><div class="adv-list">${advRelItems.map(x=>`<div class="adv-item adv-item-2"><span class="adv-main">${x.text}</span><span class="adv-sub">${x.info}</span></div>`).join('')}</div></div>` : '';
  const geArr = adv.geJuJing || [];
  const geZong = geArr.filter(x => x.indexOf('总评') >= 0).map(x => x.replace(/^总评：/, ''));
  // 纯字符串条目（专旺/两神/化气/从格等特殊格句子）统一套 .ge-lead 字号，与 gj-item 结构一致（2026-08-09 用户定：格局不同字号须统一）
  const geDet = geArr.filter(x => x.indexOf('总评') < 0).map(x => (x.indexOf('<div') === 0 ? x : `<p class="ge-lead">${x}</p>`));
  const advGeHtml = geArr.length
    ? `<!-- ② 格局简析 卡片 --><div class="analysis-block"><h3><i class="ico"></i>格局简析</h3>`
      + (geZong.length ? `<p class="ge-lead">${geZong.join('')}</p>` : '')
      // 格局简析 narr 已是 gj-item 两栏结构，不得再套 .adv-item（否则 adv-item::before 棕点+16px缩进，用户 08-06 两次反馈）；行间 gap 由 .ge-list 收紧
      + (geDet.length ? `<div class="adv-list ge-list">${geDet.join('')}</div>` : '')
      + `</div>`
    : '';
  const advYongHtml = AD_renderXiDetail(b);
  // 十神组合：凶/潜伏类全部分散进各步大运明细（showDayunDetail 内「十神组合（此运成立）」段），仅在该运引动时显示，不引动则不出标签；吉象/中性为命局固有趋向，不挂大运，按用户 07-26 指令不再于命局层罗列。
  // ⑥ 流年批断已并入大运时间轴下方的展开明细（showDayunDetail 内「流年」），
  // 不再单列固定年份（2026）子节；打开即定位到当前大运及其当年流年。

  // 大运走势卡内仅保留「一生命运总势」叙事总断（格局定性 + 大运喜忌分段 + 定论）作简短总括；
  // 「各步大运」列表 / 关键运程 / 六亲应期 / 古籍引用依清理要求移除（各步大运在大运时间轴上已有，且不再引用古籍）

  const headSlot = document.getElementById('bazi-head-slot');
  if (headSlot) headSlot.innerHTML = despaceCJK(`<div class="pillars-scroll"><div class="pillars-grid">${pillarsHtml}</div></div>`);
  // 四柱排盘「随页面滚动」锁（吸顶固定 ↔ 随页面上下滚动）：按钮为静态元素，与日期标签同行
  let _sticky = true;
  try { _sticky = localStorage.getItem('clawHeadSticky') !== '0'; } catch(e){}
  const _headWrap = document.getElementById('baziResultHead');
  if (_headWrap) _headWrap.classList.toggle('is-flow', !_sticky);
  const _lb = document.getElementById('headStickLock');
  if (_lb){
    _lb.textContent = _sticky ? '🔒' : '🔓';
    _lb.setAttribute('title', _sticky ? '已锁定·固定在顶部不随页面滚' : '已解锁·随页面上下滚动');
    if (!_lb._bound){
      _lb.addEventListener('click', function(e){
        e.stopPropagation();
        const _wrap = document.getElementById('baziResultHead');
        if (!_wrap) return;
        const _now = _wrap.classList.toggle('is-flow');
        const _stick = !_now;
        _lb.textContent = _stick ? '🔒' : '🔓';
        _lb.setAttribute('title', _stick ? '已锁定·固定在顶部不随页面滚' : '已解锁·随页面上下滚动');
        try { localStorage.setItem('clawHeadSticky', _stick ? '1' : '0'); } catch(e){}
      });
      _lb._bound = true;
    }
  }
  box.innerHTML = despaceCJK(`
    <div class="analysis-block keep-open" data-keep-open="1">
      <!-- ① 日主强弱 · 喜忌神 卡片 -->
      <h3><i class="ico"></i>日主强弱</h3>
      <div class="strength-diagram">${AD_strengthDiagram({year:b.year, month:b.month, day:b.day, hour:b.hour}, b.dayMaster, b.dayMasterWx, b)}</div>
      ${b.strengthNarrative ? `<p class="strength-narr">${b.strengthNarrative}</p>` : ''}
      <div class="wx-chart">${wxRows}</div>
    </div>
    ${advGeHtml}
    ${advYongHtml}
    <div class="analysis-block">
      <!-- ⑤ 岁运走势 卡片（大运时间轴 + 流年时间轴合并同区；点击某步大运，其下流年轴同步切换；再点击流年看该年批断） -->
      <h3><i class="ico"></i>岁运走势</h3>
      <div class="dayun-axis-wrap"><div class="dayun-scroll"><div class="dayun-list">${dayunHtml}</div></div></div>
      <div class="ln-block" id="ln-block"><div class="ln-scroll"><div class="ln-list" id="ln-list"></div></div></div>
      <div class="ln-month-list" id="ln-month-list"></div>
      <span class="dayun-axis-label" id="dy-label"><span class="dayun-axis-title" id="dy-title">${(()=>{ const _d0=b.fortuneLines[b.activeDayunIdx]; return _d0?(_d0.gz+'大运'):'大运'; })()}</span><span class="dayun-axis-sub" id="dy-sub">${b.qiYun.years}岁${b.qiYun.months}个月起运</span></span>
      <div class="dayun-detail" id="dayun-detail"></div>
      <div class="ln-detail" id="ln-detail"><span class="dayun-axis-label ln-label" id="ln-label"><span class="dayun-axis-title" id="ln-title">流年</span></span><p class="dd-pidian" id="ln-pidian"></p><div class="ln-dims" id="ln-dims"></div></div>
    </div>
    ${advShaHtml}
    <div class="analysis-block chengu-block">
      <!-- ⑮ 袁天罡称骨 卡片 -->
      <h3><i class="ico"></i>袁天罡称骨</h3>
      <div class="chengu">
        <div class="chengu-weight">骨重 ${b.chengu.liang>0?cnNum(b.chengu.liang)+'两':''}${cnNum(b.chengu.qian)}钱</div>
        <blockquote class="chengu-poem">${b.chengu.poem}</blockquote>
        ${b.chengu.shi?`<p class="chengu-shi"><span class="shi-tag">释</span>${b.chengu.shi}</p>`:''}
      </div>
    </div>
  `);

  // 运程流年：大运左右滑动，点击展开该步大运的十年流年与批断
  setupCollapse(box);
  const dayunList = box.querySelector('.dayun-list');
  if (dayunList){
    const scrollWrap = dayunList.parentElement; // .dayun-scroll
    const items = dayunList.querySelectorAll('.dayun-item');
    const scrollDayunToActive = ()=>{
      const el = dayunList.querySelector('.dayun-item.active');
      if (!el || !scrollWrap) return;
      const sr = scrollWrap.getBoundingClientRect(); const er = el.getBoundingClientRect();
      const target = scrollWrap.scrollLeft + (er.left - sr.left) - (sr.width - er.width)/2;
      try { scrollWrap.scrollTo({ left: Math.max(0, target), behavior:'smooth' }); } catch(e){}
    };
    const selectDayun = (idx)=>{
      items.forEach(x=>x.classList.remove('active'));
      if (items[idx]) items[idx].classList.add('active');
      b.activeDayunIdx = idx;
      // 切大运时把流年指回该大运内「当前年」，与小程序 onSelectDayun 行为一致
      const _fl = (b.fortuneLines && b.fortuneLines[idx]) || null;
      const _la = _fl ? (_fl.liuNian||[]) : [];
      const _k = _la.findIndex(x=>x.year===b.liuNianYear);
      b.activeLiuNianIdx = _k>=0 ? _k : 0;
      if (b._rebuildHead) b._rebuildHead();   // 排盘卡大运柱跟随岁运选择同步
      showDayunDetail(b, idx);
    };
    items.forEach((el, i)=> el.onclick = ()=>{ selectDayun(i); setTimeout(scrollDayunToActive, 0); });
    if (b.fortuneLines.length){
      const startIdx = Math.min(b.activeDayunIdx, b.fortuneLines.length - 1);
      selectDayun(startIdx);
      // 多时机重滚：渲染后 / 字体与布局稳定后 / 岁运卡片展开后，确保当前步始终在可见范围（不带动页面竖向跳转）
      requestAnimationFrame(scrollDayunToActive);
      setTimeout(scrollDayunToActive, 300);
      setTimeout(scrollDayunToActive, 700);
      const yunBlock = Array.from(box.querySelectorAll('.analysis-block')).find(bl=>{ const h=bl.querySelector(':scope > h3'); return h && h.textContent.indexOf('岁运走势')>=0; });
      if (yunBlock){ const yh = yunBlock.querySelector(':scope > h3'); if (yh) yh.addEventListener('click', ()=> setTimeout(scrollDayunToActive, 80)); }
    }
    else { const d = document.getElementById('dayun-detail'); if (d) d.hidden = true; }
  }

}

// 八字结果卡片折叠：除四柱八字卡（在 #bazi-head-slot，不在 box 内）外，box 内所有 analysis-block 加可折叠头。
// 保留卡片（日主强弱/用神详析/岁运走势/神煞总览/袁天罡称骨）默认展开；其余「准备开放中」卡片默认收起且锁定不可展开。
const LOCKED_CARD_TITLES = new Set(['平安提示']);
function setupCollapse(root){
  if (!root) return;
  root.querySelectorAll('.analysis-block').forEach(function(block){
    if (block.dataset.collapsible === '1') return;          // 已处理过（重排盘时跳过）
    const h3 = block.querySelector(':scope > h3');
    if (!h3) return;
    const title = (h3.textContent || '').trim();
    const locked = LOCKED_CARD_TITLES.has(title);
    const body = document.createElement('div');
    body.className = 'ab-body';
    let n = h3.nextSibling;
    while (n){
      const nx = n.nextSibling;
      body.appendChild(n);          // 把 h3 之后的所有节点（含文本/注释/子元素）移入 body
      n = nx;
    }
    block.appendChild(body);
    block.classList.add('collapsible');
    h3.classList.add('ab-head');
    if (locked){
      // 准备开放中：默认收起 + 锁定，点击不展开
      block.classList.add('collapsed','locked');
      const badge = document.createElement('span');
      badge.className = 'coming-soon-badge';
      badge.textContent = '准备开放中';
      h3.appendChild(badge);
    } else {
      // 保留卡片：默认展开（用户要求 2026-07-20）；点击标题可折叠收起
      h3.addEventListener('click', function(){ block.classList.toggle('collapsed'); });
    }
    block.dataset.collapsible = '1';
  });
}

// 某步大运是否引动某组合：大运干透出 或 地支本气 含其触发十神时成立（中余气不计，降噪）；凶/中/吉通用
function comboActiveInDayun(c, gz, dayGan, dmWx){
  const g = (typeof gz === 'string') ? [gz[0], gz[1]] : gz;
  const ganSS = shiShen(dayGan, dmWx, g[0], GAN_WX[g[0]]);
  const ben = HIDDEN[g[1]] ? HIDDEN[g[1]][0] : '';
  const benSS = ben ? shiShen(dayGan, dmWx, ben, GAN_WX[ben]) : '';
  // 岁运动态组合（2026-08-10）：发动方十神再现即引动
  if (c.srcSS) return c.srcSS === ganSS || c.srcSS === benSS;
  if (!c.triggerSs || !c.triggerSs.length) return false;
  return c.triggerSs.includes(ganSS) || c.triggerSs.includes(benSS);
}
function showDayunDetail(b, idx){
  const detail = document.getElementById('dayun-detail');
  if (!detail) return;
  const l = b.fortuneLines[idx];
  if (!l){ detail.hidden = true; return; }
  const liuNianHtml = l.liuNian.map((ln, k)=>{
    const lnSS = shiShen(b.dayMaster, b.dayMasterWx, ln.gz[0], GAN_WX[ln.gz[0]]);
    const lnGan = ln.gz[0], lnZhi = ln.gz[1];
    const lnGanWx = GAN_WX[lnGan], lnZhiWx = ZHI_WX[lnZhi];
    const lnCang = (HIDDEN[lnZhi]||[]).map(g => ({ char:g, wx:GAN_WX[g], ss: shiShen(b.dayMaster, GAN_WX[b.dayMaster], g, GAN_WX[g]) }));
    return `
    <div class="ln-item ${k===0?'active':''}" data-k="${k}">
      <div class="ln-top"><span class="ln-age">${ln.age}岁</span><span class="ln-year">${ln.year}</span></div>
      <div class="ln-axis"><span class="ln-dot"></span></div>
      <div class="ln-gz"><span class="wx-${lnGanWx}">${lnGan}</span><span class="wx-${lnZhiWx}">${lnZhi}</span></div>
    </div>`;
  }).join('');
  // 此步大运引动之组合（命局层已立 + 岁运动态新成），凶先吉后、同类按力量降序，每步大运至多列 3 条
  const _dyCombos = [
    ...(b.advanced && b.advanced.combos ? b.advanced.combos : []).filter(c=> comboActiveInDayun(c, l.gz, b.dayMaster, b.dayMasterWx)),
    ...(l.dyCombo || [])
  ]
    .sort((x,y)=>{ const r=t=>t==='凶'?0:(t==='吉'?1:2); return r(x.typ)-r(y.typ) || (y.weight||0)-(x.weight||0); })
    .slice(0,3);
  const _dyComboHtml = _dyCombos.length ? `<div class="dd-section"><div class="adv-list">${_dyCombos.map(x=>{ const _strip=t=>(t||'').replace(/（[^）]*）/g,''); const _sym=_strip(x.symbol).replace(/，非忌则多不显$/,'').replace(/之符号$/,'');
    return `<div class="adv-item combo-item"><span class="combo-badge combo-${x.typCls}">${x.typ}</span><div class="combo-body"><div class="combo-line"><span class="combo-name">${x.name}</span><span class="combo-symbol">：${_sym}</span></div><div class="combo-cond">${_strip(x.cond)}</div></div></div>`; }).join('')}</div></div>` : '';
  detail.innerHTML = despaceCJK(`
    <div class="dd-section">
      <p class="dd-pidian">${l.desc}</p>
    </div>
    ${_dyComboHtml}`);
  detail.hidden = false;
  // 大运标题前缀：所选择大运干支（如「庚午大运」）
  const dyTitle = document.getElementById('dy-title');
  if (dyTitle) dyTitle.textContent = l.gz + '大运';
  // 流年时间轴：大运轴下方（ln-block）；流年批语与五维在「流年」标题下（ln-detail），选中某步大运即切换该运十年流年
  const lnBlock = document.getElementById('ln-block');
  const lnDetail = document.getElementById('ln-detail');
  if (!lnBlock || !lnDetail) return;
  const lnList = lnBlock.querySelector('#ln-list');
  const lnPid = lnDetail.querySelector('#ln-pidian');
  const lnDims = lnDetail.querySelector('#ln-dims');
  lnList.innerHTML = liuNianHtml;
  lnPid.innerHTML = '';
  lnDims.innerHTML = '';
  const scrollWrap = lnList.parentElement; // .ln-scroll
  const scrollLnToActive = ()=>{
    const el = lnList.querySelector('.ln-item.active');
    if (!el || !scrollWrap) return;
    const sr = scrollWrap.getBoundingClientRect(); const er = el.getBoundingClientRect();
    const target = scrollWrap.scrollLeft + (er.left - sr.left) - (sr.width - er.width)/2;
    try { scrollWrap.scrollTo({ left: Math.max(0, target), behavior:'smooth' }); } catch(e){}
  };
    const selectLn = (k)=>{
      lnList.querySelectorAll('.ln-item').forEach(x=>x.classList.remove('active'));
      const el = lnList.querySelector('.ln-item[data-k="'+k+'"]');
      if (el) el.classList.add('active');
      b.activeLiuNianIdx = k;
      const ln = l.liuNian[k] || {};
      // 2026-08-21 用户定：流月默认=当前流年取当前月、非当前流年取正月，同步四柱排盘「流月」柱
      if (ln && ln.year === b.liuNianYear) b.activeLiuYueGz = liuyueGanZhi() || '';
      else if (ln){ const _ms = liuYueList(ln.gz[0]); b.activeLiuYueGz = _ms.length ? _ms[0].gz : ''; }
      else b.activeLiuYueGz = null;
      if (b._rebuildHead) b._rebuildHead();   // 排盘卡流年+流月柱跟随岁运选择同步
    // 流年标题前缀：所选择流年干支（如「丙午流年」）
    const lnTitle = document.getElementById('ln-title');
    if (lnTitle && ln.gz) lnTitle.textContent = ln.gz + '流年';
    // 流月条：该流年 12 个月柱；点击联动四柱排盘卡「流月」柱（2026-08-20 用户定；默认高亮当前月/正月 2026-08-21）
    const lnMonthList = document.getElementById('ln-month-list');
    if (lnMonthList && ln.gz){
      const months = liuYueList(ln.gz[0]);
      lnMonthList.innerHTML = months.map(mo=>`
        <div class="ln-month-item${b.activeLiuYueGz === mo.gz ? ' active' : ''}" data-gz="${mo.gz}">
          <span class="lmi-m">${mo.m}</span>
          <span class="lmi-gz">${mo.gz}</span>
        </div>`).join('');
      lnMonthList.querySelectorAll('.ln-month-item').forEach(el=>{
        el.onclick = ()=>{
          const gz = el.dataset.gz;
          b.activeLiuYueGz = (b.activeLiuYueGz === gz) ? null : gz;   // 同月再点取消，回真实当前月
          if (b._rebuildHead) b._rebuildHead();   // 排盘卡「流月」柱跟随联动
          lnMonthList.querySelectorAll('.ln-month-item').forEach(x=>x.classList.toggle('active', x.dataset.gz === b.activeLiuYueGz));
        };
      });
    }
    // 【关注事项】：大运已立之十神组合，若被本年岁干/岁支引动，则「应期已至」——补「大运搭战场、流年开战」之收口。
    // 仅当该组合确被本运立局（已在 _dyCombos 中）且本年干支含其触发十神，方判定为引动，避免无中生有。
    let _gz = '';
    if (ln.year && _dyCombos.length){
      const _lnCombos = _dyCombos.filter(c => comboActiveInDayun(c, ln.gz, b.dayMaster, b.dayMasterWx));
      if (_lnCombos.length){
        const _lines = _lnCombos.slice(0,2).map(c=>{
          const _sym = (c.symbol||'').replace(/（[^）]*）/g,'').replace(/之符号$/,'').replace(/，非忌则多不显$/,'');
          const _verb = (c.typ==='吉') ? '吉象兑现' : '应期已至';
          const _tail = (c.typ==='吉') ? ('：'+_sym+'（宜把握）。') : ('：防'+_sym+'。');
          return '大运「'+c.name+'」已成之局，本年岁干岁支引动，'+_verb+_tail;
        });
        _gz = '<br><b class="ln-dir">【关注事项】</b><br>' + _lines.join('<br>');
      }
      // 大运已立组合但本年流年未引动：不显示【关注事项】，避免「未引动」空话（大运层已列立局，流年只补「应期已至」）
    }
    // 大运层面未立任何十神组合时，不显示【关注事项】，避免无中生有「未引动」空话。
    lnPid.innerHTML = despaceCJK(ln.desc || '') + _gz;
    lnDims.innerHTML = (ln.dims || []).map(d=>`
      <div class="ln-dim pol-${d.pol}">
        <div class="ln-dim-head">
          <span class="ln-dim-name">${d.name}</span>
          <span class="ln-dim-ss">${d.ss}</span>
        </div>
        <div class="ln-dim-tip">${d.tip}</div>
      </div>`).join('');
  };
  lnList.querySelectorAll('.ln-item').forEach(el=>{ el.onclick = ()=>{ selectLn(+el.dataset.k); setTimeout(scrollLnToActive, 0); }; });
  // 自动定位到当年流年（当前大运内含 b.liuNianYear 的那一步）；其余大运默认展示首年
  let defK = 0;
  const curK = l.liuNian.findIndex(x => x.year === b.liuNianYear);
  if (curK >= 0) defK = curK;
  selectLn(defK);
  requestAnimationFrame(scrollLnToActive);
  setTimeout(scrollLnToActive, 300);
}

/* ===================================================================
 * 四柱反推（网格窗体版）
 * =================================================================== */
const REV_STEMS = ['甲','乙','丙','丁','戊','己','庚','辛','壬','癸'];
const REV_YANG = new Set(['甲','丙','戊','庚','壬']);
const REV_WU_HU = {甲:2,己:2,乙:4,庚:4,丙:6,辛:6,丁:8,壬:8,戊:0,癸:0};
const REV_WU_SHU = {甲:0,己:0,乙:2,庚:2,丙:4,辛:4,丁:6,壬:6,戊:8,癸:8};
let revData = { yearGan:'', yearZhi:'', monthGz:'', dayGan:'', dayZhi:'', hourGz:'' };

// 年/日地支须与天干阴阳同配对（阳干配阳支、阴干配阴支）
function revBranchParityOk(gan, zhi){
  const yangGan = REV_YANG.has(gan);
  const yangZhi = ['子','寅','辰','午','申','戌'].includes(zhi);
  return yangGan === yangZhi;
}
// 五虎遁：依年干推出 12 个合法月柱
function revMonthOpts(yearGan){
  if (!yearGan) return [];
  const st = REV_WU_HU[yearGan];
  const brs = ['寅','卯','辰','巳','午','未','申','酉','戌','亥','子','丑'];
  const list = []; for (let i=0;i<12;i++) list.push(REV_STEMS[(st+i)%10]+brs[i]);
  return list;
}
// 五鼠遁：依日干推出 12 个合法时柱
function revHourOpts(dayGan){
  if (!dayGan) return [];
  const st = REV_WU_SHU[dayGan];
  const brs = ['子','丑','寅','卯','辰','巳','午','未','申','酉','戌','亥'];
  const list = []; for (let i=0;i<12;i++) list.push(REV_STEMS[(st+i)%10]+brs[i]);
  return list;
}
// 当前正在选择的柱与步骤：col=year/month/day/hour，step=gan/zhi
let revSel = { stepIdx:null };   // null=未开始（起始页）；0~5=自动推进的步骤序号
const REV_BRANCHES = ['子','丑','寅','卯','辰','巳','午','未','申','酉','戌','亥'];

// 一气呵成：固定的 6 步顺序，每选完一步自动进入下一步，不用再点方框切步骤
const REV_STEPS = [
  { col:'year',  part:'gan', hd:'选择「年柱」天干' },
  { col:'year',  part:'zhi', hd:'选择「年柱」地支' },
  { col:'month', part:'gz',  hd:'请选择「月柱」' },
  { col:'day',   part:'gan', hd:'选择「日柱」天干' },
  { col:'day',   part:'zhi', hd:'选择「日柱」地支' },
  { col:'hour',  part:'gz',  hd:'请选择「时柱」' },
];
// 某柱在步骤序列中的起始步（用于点已选方框回退修改）
const REV_COL_FIRST = { year:0, month:2, day:3, hour:5 };

// 四柱方框当前显示文本
function revBoxText(){
  return {
    year:  (revData.yearGan && revData.yearZhi) ? revData.yearGan+revData.yearZhi : '—',
    month: revData.monthGz || '—',
    day:   (revData.dayGan && revData.dayZhi) ? revData.dayGan+revData.dayZhi : '—',
    hour:  revData.hourGz || '—'
  };
}
function revRenderBoxes(){
  const txt = revBoxText();
  const curCol = (revSel.stepIdx!==null && revSel.stepIdx!==undefined && revSel.stepIdx < REV_STEPS.length) ? REV_STEPS[revSel.stepIdx].col : null;
  ['year','month','day','hour'].forEach(col=>{
    const box = document.querySelector('.rev-box[data-col="'+col+'"]');
    if (!box) return;
    box.textContent = txt[col];
    box.classList.toggle('filled', txt[col] !== '—');
    box.classList.toggle('active', curCol === col);
  });
}
// 渲染四柱选择器（一气呵成：当前只显示「一步」，选完自动进入下一步）
// 未开始（stepIdx=null）：显示起始页提示，点「年柱」方框开始。
// 进行中：显示第 N/6 步 + 该步选项；选完自动 revSel.stepIdx++ 进入下一步。
function revRenderPicker(){
  const pk = document.getElementById('rev-picker');
  if (!pk) return;
  // 未开始：起始页
  if (revSel.stepIdx === null || revSel.stepIdx === undefined){
    pk.innerHTML = '';
    return;
  }
  // 全部选完：结果在 #reverse-result 区显示，picker 留空
  if (revSel.stepIdx >= REV_STEPS.length){
    pk.innerHTML = '';
    return;
  }
  const st = REV_STEPS[revSel.stepIdx];
  const idx = revSel.stepIdx;
  let body = '';
  if (st.part === 'gan'){
    // 天干：一行 10 个切片，放不下由 JS 按实测宽度缩小字号
    const sel = st.col==='year' ? revData.yearGan : revData.dayGan;
    body = '<div class="rev-pk-bar gans">' + REV_STEMS.map(g =>
      '<button type="button" class="rev-pk-slice'+(sel===g?' on':'')+'" data-gan="'+g+'">'+g+'</button>').join('') + '</div>';
  } else if (st.part === 'zhi'){
    // 地支：只显示可与已选天干配对的（阳干配阳支），已选天干切片列在最前
    const selGan = st.col==='year' ? revData.yearGan : revData.dayGan;
    const selZhi = st.col==='year' ? revData.yearZhi : revData.dayZhi;
    const okList = selGan ? REV_BRANCHES.filter(function(z){ return revBranchParityOk(selGan, z); }) : REV_BRANCHES;
    body = '<div class="rev-pk-bar gans">' +
      (selGan ? '<span class="rev-pk-slice on rev-pk-selgan">'+selGan+'</span>' : '') +
      okList.map(z =>
        '<button type="button" class="rev-pk-slice'+(selZhi===z?' on':'')+'" data-zhi="'+z+'">'+z+'</button>'
      ).join('') + '</div>';
  } else { // gz：月柱 / 时柱 → 12 列横排切片，每列干支分两行（丙一行、寅一行）
    const opts = st.col==='month' ? revMonthOpts(revData.yearGan) : revHourOpts(revData.dayGan);
    const sel = st.col==='month' ? revData.monthGz : revData.hourGz;
    body = '<div class="rev-pk-bar gzc">' + opts.map(gz =>
      '<button type="button" class="rev-pk-slice'+(sel===gz?' on':'')+'" data-gz="'+gz+'">' +
      '<span class="rev-gz-gan">'+gz.charAt(0)+'</span><span class="rev-gz-zhi">'+gz.charAt(1)+'</span>' +
      '</button>').join('') + '</div>';
  }
  const hd = '<div class="rev-step-hd">'+st.hd+'</div>';
  pk.innerHTML = hd + body;
  pk.querySelectorAll('.rev-pk-btn, .rev-pk-slice').forEach(el => {
    if (el.classList.contains('disabled')) return;
    el.onclick = function(){
      if (el.dataset.gan) revOnGan(st.col, el.dataset.gan);
      else if (el.dataset.zhi) revOnZhi(st.col, el.dataset.zhi);
      else if (el.dataset.gz) revOnGz(st.col, el.dataset.gz);
    };
  });
}
function revOnGan(col, g){
  const ganKey = col==='year' ? 'yearGan' : 'dayGan';
  const zhiKey = col==='year' ? 'yearZhi' : 'dayZhi';
  revData[ganKey] = g;
  revData[zhiKey] = '';                 // 换天干则清空地支
  if (col==='year') revData.monthGz = ''; else revData.hourGz = '';  // 年/日变则依赖它的月/时失效
  revSel.stepIdx += 1;                  // 自动进入下一步（地支）
  revRenderBoxes(); revRenderPicker();
}
function revOnZhi(col, z){
  const zhiKey = col==='year' ? 'yearZhi' : 'dayZhi';
  revData[zhiKey] = z;
  revSel.stepIdx += 1;                  // 自动进入下一步（月柱 / 日干）
  revRenderBoxes(); revRenderPicker(); maybeAutoReverse();
}
function revOnGz(col, gz){
  if (col==='month') revData.monthGz = gz; else revData.hourGz = gz;
  revSel.stepIdx += 1;                  // 自动进入下一步（日干 / 完成）
  revRenderBoxes(); revRenderPicker(); maybeAutoReverse();
}
function revFlashPick(msg){
  const pk = document.getElementById('rev-picker');
  if (pk) pk.innerHTML = '<p class="rev-pk-warn">'+msg+'</p>';
}
// 点击某柱方框：
//  - 起始页（stepIdx=null）：只有「年柱」可开始；点其它柱提示先点年柱。
//  - 进行中：点已选柱可回退到该柱第一步修改（仍是自动推进，不用来回弹）
function revOnBoxClick(col){
  if (revSel.stepIdx === null || revSel.stepIdx === undefined){
    if (col !== 'year'){ revFlashPick('请先点击「年柱」开始排盘。'); setTimeout(revRenderPicker, 1400); return; }
    revSel.stepIdx = 0;                 // 开始：第一步=选年干
    revRenderBoxes(); revRenderPicker();
    return;
  }
  const first = REV_COL_FIRST[col];
  if (first === undefined) return;
  revSel.stepIdx = first;               // 回退到该柱第一步，可重选
  revRenderBoxes(); revRenderPicker();
}
// 四柱选齐即自动匹配（无需「确定」按钮）
function maybeAutoReverse(){
  const year = (revData.yearGan && revData.yearZhi) ? revData.yearGan+revData.yearZhi : null;
  const month = revData.monthGz || null;
  const day = (revData.dayGan && revData.dayZhi) ? revData.dayGan+revData.dayZhi : null;
  const hour = revData.hourGz || null;
  const box = document.getElementById('reverse-result');
  if (!box) return;
  if (!(year && month && day && hour)){ box.innerHTML = ''; return; } // 未选齐：清空旧结果
  let ys = parseInt(document.getElementById('rev-ys').value, 10) || 1900;
  let ye = parseInt(document.getElementById('rev-ye').value, 10) || new Date().getFullYear();
  if (ys > ye){ const t=ys; ys=ye; ye=t; }
  box.innerHTML = '<p class="hint">匹配中…</p>';
  setTimeout(function(){
    const r = BaziReverse.reverseBazi({ year:year, month:month, day:day, hour:hour }, { ys:ys, ye:ye, ziType:'modern' }, window.calendar);
    renderRevResults(r);
  }, 10);
}

function renderRevResults(r){
  const box = document.getElementById('reverse-result');
  if (!box) return;
  if (r.error){ box.innerHTML = '<p class="hint">请至少输入一柱。</p>'; return; }
  const seen = new Set(); const merged = [];
  for (let i=0;i<r.results.length;i++){
    const it = r.results[i];
    const k = it.y+'-'+it.m+'-'+it.d;
    if (!seen.has(k)){ seen.add(k); merged.push(it); }
  }
  if (merged.length === 0){ box.innerHTML = '<p class="hint">未找到匹配的数据。</p>'; return; }
  box.innerHTML = despaceCJK('<div class="rev-hint">找到 '+merged.length+' 个结果：</div><div class="rev-list">' +
    merged.map(function(it){
      var label = it.y+'年'+it.m+'月'+it.d+'日';
      if (it.hour !== null){
        var br = (it.hour === 23) ? 0 : Math.floor((it.hour + 1) / 2);
        var bNames = ['子','丑','寅','卯','辰','巳','午','未','申','酉','戌','亥'];
        var ss, ee;
        if (br === 0){ ss = 23; ee = 1; } else { ss = 2*br - 1; ee = 2*br + 1; }
        label += bNames[br] + '时' + ss + '-' + ee + '点';
      }
      return '<button type="button" class="rev-item" data-y="'+it.y+'" data-m="'+it.m+'" data-d="'+it.d+'" data-h="'+(it.hour!==null?it.hour:'')+'">'+label+'</button>';
    }).join('') +
    '</div>');
  box.querySelectorAll('.rev-item').forEach(function(el){
    el.onclick = function(){
      const y = +el.dataset.y, m = +el.dataset.m, d = +el.dataset.d;
      // 关键修复：必须把反推出的 年/月/日 一起写入 Birth（单一真相源）。
      // 否则 Birth.set 内部的 _syncDOM 会用陈旧的 y/m/d 回写 solar-date 输入框，
      // 导致订阅者 renderBazi 读到旧日期——反推「点完不排盘 / 排了错的盘」。
      const partial = { calType:'solar', y:y, m:m, d:d, leap:false };
      if (el.dataset.h !== '' && el.dataset.h != null){
        const h = +el.dataset.h;
        const sc = (h === 23 ? 0 : Math.floor((h + 1) / 2));
        partial.hour = h; partial.minute = 0; partial.shichen = sc;
      }
      _baziRecordHistory = true;
      Birth.set(partial);   // 统一写入 Birth；_syncDOM 同步 solar-date，订阅者自动重排
      closeRevModal();
    };
  });
}

function initReverseModal(){
  document.getElementById('rev-modal-close').onclick = closeRevModal;
  document.getElementById('rev-modal-reset').onclick = function(){
    revData = { yearGan:'', yearZhi:'', monthGz:'', dayGan:'', dayZhi:'', hourGz:'' };
    revSel = { stepIdx:null };
    const box = document.getElementById('reverse-result'); if (box) box.innerHTML = '';
    revRenderBoxes(); revRenderPicker();
  };
  // 四柱方框：起始页点「年柱」开始；进行中点已选柱可回退修改（仍是自动推进）
  document.querySelectorAll('.rev-box').forEach(function(b){
    b.onclick = function(){ revOnBoxClick(b.getAttribute('data-col')); };
  });
  const modal = document.getElementById('reverse-modal');
  if (modal) modal.onclick = function(e){ if (e.target === this) closeRevModal(); };
}
function openRevModal(){
  revData = { yearGan:'', yearZhi:'', monthGz:'', dayGan:'', dayZhi:'', hourGz:'' };
  revSel = { stepIdx:null };
  const box = document.getElementById('reverse-result'); if (box) box.innerHTML = '';
  revRenderBoxes(); revRenderPicker();
  const modal = document.getElementById('reverse-modal');
  // 弹层卡片锚定在吸顶四柱排盘头之下（顶部可见区），不再跟随切片按钮位置
  // （切片按钮现位于底部浮层，若按按钮坐标锚定会把模态顶到屏幕底部看不见）
  const head = document.getElementById('baziResultHead');
  const anchor = head ? (head.getBoundingClientRect().height + 10) : 70;
  if (modal) modal.style.setProperty('--rev-anchor', anchor + 'px');
  if (modal) modal.hidden = false;
  // 与四柱反推互斥：隐藏出生信息卡
  const card = document.getElementById('bazi-card'); if (card) card.classList.remove('show');
}
function closeRevModal(){
  const modal = document.getElementById('reverse-modal'); if (modal) modal.hidden = true;
  const rt = document.getElementById('reverse-toggle');
  if (rt){ rt.setAttribute('aria-expanded','false'); rt.classList.remove('rev-on'); }
}

/* ===================================================================
 * 黄历（老黄历 / 通书）
 * 依据日干支、节气月建推导：建除十二神、宜忌、冲煞、值神黄黑道、
 * 彭祖百忌、吉神方位、二十八宿值日。
 * =================================================================== */

function renderHuangliDetail(y, m, d){
  hlActive = {y, m, d};
  const h = computeHuangli(y, m, d);
  const o = h.lunar;
  const luTag = h.jc.lu === '黄'
    ? '<span class="lu-yellow">黄道吉</span>'
    : '<span class="lu-black">黑道凶</span>';
  const yi = h.jc.yi.map(x => `<span class="act yi">${x}</span>`).join('');
  const ji = h.jc.ji.map(x => `<span class="act ji">${x}</span>`).join('');
  const wxText = `${WX_NAME[GAN_WX[h.stem]]}${WX_NAME[ZHI_WX[h.branch]]}`;
  const inlineDate = document.getElementById('hl-date-inline');
  if (inlineDate) inlineDate.textContent = `${y}年${m}月${d}日`;
  const lunarInline = document.getElementById('hl-lunar-inline');
  if (lunarInline) lunarInline.textContent = `${o.gzYear}年 ${o.IMonthCn}${o.IDayCn}${o.isLeap ? '（闰）' : ''}`;

  // === 摘要卡片 ===
  const grade = h.grade;
  const yiCount = h.jc.yi.length;
  const jiCount = h.jc.ji.length;
  // === 值神 / 值日星宿 / 吉神凶神 / 六曜 / 喜福财神 / 贵人（并入当日黄历卡片内，紧随摘要徽章之后）===
  const liuyaoGood = (h.liuyao === '大安' || h.liuyao === '先胜' || h.liuyao === '友引');
  const zhishenHtml = `<div class="hl-shen-inline">
    <div class="hl-shen-row"><span class="hl-shen-k">值神</span><span class="hl-shen-v ${h.jc.lu==='黄'?'z-good':'z-bad'}">${h.jc.star}（${h.jc.lu==='黄'?'黄道':'黑道'}）</span></div>
    <div class="hl-shen-row"><span class="hl-shen-k">星宿</span><span class="hl-shen-v">${h.xingxiuFull}（<b class="${h.xingxiuLuck==='吉'?'z-good':'z-bad'}">${h.xingxiuLuck}宿</b>）</span></div>
    <div class="hl-shen-row"><span class="hl-shen-k">六曜</span><span class="hl-shen-v"><b class="${liuyaoGood?'z-good':'z-bad'}">${h.liuyao}</b></span></div>
    <div class="hl-shen-row"><span class="hl-shen-k">吉神</span><span class="hl-shen-v">${h.jiShen.length ? h.jiShen.map(x=>`<span class="shen-tag good">${x}</span>`).join('') : '<span class="hint">—</span>'}</span></div>
    <div class="hl-shen-row"><span class="hl-shen-k">凶神</span><span class="hl-shen-v">${h.xiongShen.length ? h.xiongShen.map(x=>`<span class="shen-tag bad">${x}</span>`).join('') : '<span class="hint">—</span>'}</span></div>
    <div class="hl-shen-row"><span class="hl-shen-k">喜神</span><span class="hl-shen-v">${h.xishen}</span></div>
    <div class="hl-shen-row"><span class="hl-shen-k">福神</span><span class="hl-shen-v">${h.fushen}</span></div>
    <div class="hl-shen-row"><span class="hl-shen-k">财神</span><span class="hl-shen-v">${h.caishen}</span></div>
    <div class="hl-shen-row"><span class="hl-shen-k">贵人</span><span class="hl-shen-v">阳贵${h.guiYang} ｜ 阴贵${h.guiYin}</span></div>
  </div>`;
  const summaryCard = `<div class="hl-summary">
    <div class="hls-top">
      <span class="hls-badge ${grade.cls}">${grade.label}</span>
      <span class="hls-stat">${h.jc.lu==='黄'?'黄道':'黑道'} · 宜${yiCount}事 ｜ 忌${jiCount}事</span>
    </div>
    <div class="hls-tags">
      <span class="hls-tag">冲${h.chong.animal}（${h.chong.branch}）煞${h.sha}</span>
      <span class="hls-tag">六合${h.liuHe} 害${h.liuHai}${h.sanHe.length ? ' 三合' + h.sanHe.join('、') : ''}</span>
      <span class="hls-tag">${h.jc.shen}日 · ${h.jc.star}</span>
    </div>
    ${zhishenHtml}
  </div>`;

  // === 宜忌双侧对比 ===
  const yjHtml = `<div class="hl-yj">
    <div class="hl-yi-card"><div class="hl-yj-title">宜</div><div class="hl-yj-items">${yi || '<span class="hint">—</span>'}</div></div>
    <div class="hl-ji-card"><div class="hl-yj-title">忌</div><div class="hl-yj-items">${ji || '<span class="hint">—</span>'}</div></div>
  </div>`;

  // === 彭祖百忌 / 四离四绝杨公忌 ===
  const shenPosHtml = `<div class="hl-badges hl-badges-below">
    <span class="hl-badge-plain">彭祖忌 ${h.pengzu[0]} ｜ ${h.pengzu[1]}</span>
    ${h.silijue ? `<span class="hl-badge bad">${h.silijue}日</span>` : ''}
    ${h.yang ? `<span class="hl-badge bad">杨公忌日</span>` : ''}
  </div>`;

  // === 时辰吉凶 ===
  const hourNames = ['子时','丑时','寅时','卯时','辰时','巳时','午时','未时','申时','酉时','戌时','亥时'];
  const hourStart = WU_SHUN_DUN[h.stem]; // 子时天干索引
  const hourCells = BRANCHES.map((br, i) => {
    const g = hourGrade(h.stem, h.branch, br);
    const stemIdx = (hourStart + i) % 10;
    return `<div class="hc-cell ${g.cls}"><span class="hc-time">${hourNames[i]}</span><span class="hc-g">${g.grade}</span></div>`;
  }).join('');
  const hourHtml = `<div class="hl-hours">
    <div class="hl-section-title">十二时辰吉凶</div>
    <div class="hc-grid hc-grid-12">${hourCells}</div>
  </div>`;

  // === 前后几天对比 ===
  const dayMs = 86400000;
  const today = new Date(y, m-1, d);
  const compareDays = [-3,-2,-1,0,1,2,3];
  const compItems = compareDays.map(offset => {
    const dt = new Date(today.getTime() + offset * dayMs);
    const yy = dt.getFullYear(), mm = dt.getMonth()+1, dd = dt.getDate();
    const hh = computeHuangli(yy, mm, dd);
    const gcls = hh.grade.cls;
    const isGoodDay = (gcls === 'dj' || gcls === 'ji');
    const isBadDay = (gcls === 'bu' || gcls === 'dx');
    const label = offset === 0 ? '今日' : `${mm}/${dd}`;
    return `<div class="cp-item${offset===0?' cp-today':''}">
      <div class="cp-date">${label}</div>
      <div class="cp-badge ${isGoodDay?'good':isBadDay?'bad':'mid'}">${hh.grade.label}</div>
      <div class="cp-shen">${hh.jc.shen}</div>
    </div>`;
  }).join('');
  const compareHtml = `<div class="hl-compare">
    <div class="hl-section-title">前后几日黄历对比</div>
    <div class="cp-grid">${compItems}</div>
  </div>`;

  // === 择日卡片（2026-08-20 用户定：弹层移为对比区后常驻卡片，对齐小程序；含「查看该日黄历」）===
  const zeriCardHtml = `<div class="analysis-block zeri-card">
    <h3><i class="ico"></i>择日 · 为用事择吉日</h3>
    <div class="zeri-body">
      <div class="zeri-field">
        <div class="zeri-use-grid" id="zeri-use-grid"></div>
      </div>
      <div class="zeri-field">
        <label class="zeri-label">用事人生日（公历/农历均可）</label>
        <div class="zeri-birth">
          <button type="button" class="zeri-birth-btn" id="zeri-birth-btn">${zeriBirthFmt(zeriBirth)}</button>
          <input type="hidden" id="zeri-birth-val" value="${zeriBirth.y}-${zeriBirth.m}-${zeriBirth.d}"/>
        </div>
      </div>
      <button type="button" class="btn btn-primary zeri-go" id="zeri-go">开始择日</button>
      <div id="zeri-result" class="zeri-result"></div>
    </div>
  </div>`;

  // === 详细行（按需求精简：日干支/年月干支/值日星宿/星期等整块删除，仅保留节气提示）===
  const detailRows = `${o.isTerm ? `<div class="hl-detail-rows"><div class="hl-row"><span class="hl-k">节气</span><span class="hl-v">${o.Term}</span></div></div>` : ''}`;

  document.getElementById('huangli-detail').innerHTML = `
    <div class="hl-result">
      ${summaryCard}
      ${yjHtml}
      ${hourHtml}
      ${compareHtml}
      ${zeriCardHtml}
      ${shenPosHtml}
      ${detailRows}
    </div>`;
  // 择日卡片每次重渲染都会重建：重新构建方向格并绑定（2026-08-20 卡片化）
  buildZeriUseGrid();
  const zeriBirthBtn = document.getElementById('zeri-birth-btn');
  if (zeriBirthBtn) zeriBirthBtn.onclick = openZeriBirthWheel;
  const zeriGoBtn = document.getElementById('zeri-go');
  if (zeriGoBtn) zeriGoBtn.onclick = runZeri;
  // 恢复择日结果（2026-08-21 用户定：查看该日黄历后结果面板不折叠）
  const zrOut = document.getElementById('zeri-result');
  if (zrOut && zeriCache){
    zrOut.innerHTML = zeriCache.html;
    bindZeriResult(zrOut);
  }
}

/* ===================================================================
 * 择日（黄历页：为用事择吉日）
 * =================================================================== */
let hlActive = {y:0, m:0, d:0};
// 用事方向 → 当日「宜」中应含的关键词（命中其一即视为契合）
const ZERI_USE = [
  {key:'嫁娶', label:'嫁娶 / 结婚',        yi:['嫁娶','结婚']},
  {key:'订婚', label:'纳采 / 订婚',        yi:['纳采','订盟']},
  {key:'入宅', label:'入宅 / 移徙（搬家）', yi:['入宅','移徙']},
  {key:'开业', label:'开市 / 开业',        yi:['开市']},
  {key:'动土', label:'动土 / 修造',        yi:['动土','修造','造屋']},
  {key:'出行', label:'出行',               yi:['出行']},
  {key:'安葬', label:'安葬 / 修坟',        yi:['安葬']},
  {key:'祭祀', label:'祈福 / 祭祀',        yi:['祈福','祭祀']},
  {key:'求财', label:'求财 / 纳财',        yi:['纳财']},
  {key:'求医', label:'求医 / 治病',        yi:['求医治病','求医','疗病']},
  {key:'签约', label:'签约 / 立券',        yi:['立券','立契']},
  {key:'入学', label:'入学 / 考试',        yi:['入学']},
];
function zeriIsChong(a, b){ return AD_CHONG.some(p => (p[0]===a && p[1]===b) || (p[0]===b && p[1]===a)); }
let zeriBirth = { y:1990, m:6, d:15, calType:'solar', leap:false };
// 用事人生日显示：按所选历法格式化（农历显示中文月日）
function zeriBirthFmt(b){
  if (b && b.calType === 'lunar'){
    const cv = window.calendar.solar2lunar(b.y, b.m, b.d);
    if (cv && cv !== -1){
      return `农历 ${cv.lYear}年 ${cv.isLeap?'闰':''}${LUNAR_MONTHS[cv.lMonth-1] || (cv.lMonth+'月')} ${lunarDayLabel(cv.lDay)}`;
    }
  }
  return `${b.y}年${b.m}月${b.d}日`;
}
function writeZeriBirth(b){   // b：公历真值 + calType + leap（Birth.get() 结构）
  zeriBirth = { y:b.y, m:b.m, d:b.d, calType:(b.calType==='lunar'?'lunar':'solar'), leap:!!b.leap };
  const val = document.getElementById('zeri-birth-val');
  if (val) val.value = `${b.y}-${b.m}-${b.d}`;
  const btn = document.getElementById('zeri-birth-btn');
  if (btn) btn.textContent = zeriBirthFmt(zeriBirth);
}
// 打开择日弹层时把「用事人生日」预填为八字页当前日期（2026-08-10 用户定：两处保持一致），
// 弹层内仍可单独改（只影响本次择日，Birth snapshot 还原、八字页不受影响）
function syncZeriBirthFromBazi(){
  const b = (typeof Birth !== 'undefined' && Birth) ? Birth.get() : null;
  if (!b || b.y < 1900) return;
  writeZeriBirth(b);
}
function openZeriBirthWheel(){
  const snap = Birth.get();   // 还原八字页 Birth，避免择日选生日污染全局
  // 复用统一时间滚轮：既有公历又有农历（2026-08-10 用户定：年轻人给老一辈择日只知道农历）
  dwOpen({
    calType: (zeriBirth.calType === 'lunar' ? 'lunar' : 'solar'),
    calTypeSwitch: true,
    initial: { y:zeriBirth.y, m:zeriBirth.m, d:zeriBirth.d },
    onConfirm: (bz)=>{
      writeZeriBirth(bz);
      Birth.set(snap);
    }
  });
}
function zeriIsLiuhe(a, b){ return AD_LIUHE.some(p => (p[0]===a && p[1]===b) || (p[0]===b && p[1]===a)); }
function zeriIsSanhe(a, b){ for (const k in AD_SANHE){ if (AD_SANHE[k].includes(a) && AD_SANHE[k].includes(b)) return true; } return false; }

// 用事方向选择（2026-08-20 卡片化：模块状态 + 黄历渲染后重建方向格）
let zeriUseKey = '嫁娶';
function buildZeriUseGrid(){
  const grid = document.getElementById('zeri-use-grid');
  if (!grid) return;
  grid.innerHTML = ZERI_USE.map((u, i) => {
    const parts = String(u.label).split(' / ');
    const main = parts[0] || u.key;
    const sub = parts[1] || '';
    const mono = u.key.charAt(0);
    return '<button type="button" class="zeri-use-item'+(i===0?' on':'')+'" data-key="'+u.key+'">'
      + '<span class="zeri-use-mono">'+mono+'</span>'
      + '<span class="zeri-use-main">'+main+'</span>'
      + (sub ? '<span class="zeri-use-sub">'+sub+'</span>' : '')
      + '</button>';
  }).join('');
  grid.querySelectorAll('.zeri-use-item').forEach(el => {
    el.onclick = function(){
      grid.querySelectorAll('.zeri-use-item').forEach(x => x.classList.remove('on'));
      el.classList.add('on');
      zeriUseKey = el.dataset.key;
    };
  });
}
function zeriGradeOf(s){ return s>=10 ? '上吉' : s>=6 ? '吉' : s>=2 ? '平吉' : s>=-2 ? '平' : '忌'; }

function runZeri(){
  const out = document.getElementById('zeri-result');
  if (!out) return;
  const useKey = zeriUseKey;   // 2026-08-20 卡片化：方向选择状态（原隐藏 input 移除）
  const use = ZERI_USE.find(u => u.key === useKey) || ZERI_USE[0];
  const bv = (document.getElementById('zeri-birth-val') || {}).value || '1990-6-15';
  const _bp = bv.split('-').map(Number);
  const by = _bp[0], bm = _bp[1], bd = _bp[2];
  if (!by || !bm || !bd || bm<1 || bm>12 || bd<1 || bd>31){ out.innerHTML = '<div class="zeri-tip">请选择有效的用事人生日（公历）。</div>'; return; }
  const bz = computeBazi(by, bm, bd, 12, 0, 'm');
  if (bz.error){ out.innerHTML = '<div class="zeri-tip">'+bz.error+'</div>'; return; }
  const userYearZhi = bz.year[1], userDayZhi = bz.day[1];
  const xiWx = (bz.xiNames||[]).map(n => WX_NAME_REV[n]).filter(Boolean);
  const jiWx = (bz.jiNames||[]).map(n => WX_NAME_REV[n]).filter(Boolean);

  // 扫描起点：以当前黄历显示日期为基准，向后 150 天
  const start = hlActive.y ? new Date(hlActive.y, hlActive.m-1, hlActive.d) : new Date();
  const cands = [];
  for (let i=0; i<150; i++){
    const dt = new Date(start.getTime() + i*86400000);
    const y = dt.getFullYear(), m = dt.getMonth()+1, d = dt.getDate();
    const h = computeHuangli(y, m, d);
    const hasYi = h.jc.yi.some(x => use.yi.includes(x));
    const hasJi = h.jc.ji.some(x => use.yi.includes(x));
    const reasons = [];
    let score = 0;
    if (hasYi){ score += 5; reasons.push('当日「宜」含此事'); }
    else if (hasJi){ score -= 2; reasons.push('当日「忌」含此事'); }
    if (h.jc.lu === '黄'){ score += 2; reasons.push('黄道吉日'); } else { score -= 1; reasons.push('黑道日'); }
    // 建除适配
    if ((JIANCHU_FOR_USE[use.key] || []).indexOf(h.jc.shen) >= 0){ score += 2; reasons.push(`${h.jc.shen}日宜${use.label}`); }
    // 神煞
    for (const g of h.jiShen){ if (YELLOW_STARS.has(g)) continue; const s = SHEN_SCORE[g]; if (s > 0){ score += s; if (s >= 2) reasons.push(`逢吉神${g}`); } }
    for (const g of h.xiongShen){ const s = SHEN_SCORE[g]; if (s < 0){ score += s; if (s <= -2) reasons.push(`犯凶神${g}`); } }
    // 二十八宿
    if (h.xingxiuLuck === '吉'){ score += 1; } else { score -= 1; reasons.push(`值日星宿${h.xingxiu}为凶宿`); }
    // 本命
    const dGanWx = GAN_WX[h.stem], dZhiWx = ZHI_WX[h.branch];
    if (xiWx.includes(dGanWx) || xiWx.includes(dZhiWx)){ score += 3; reasons.push('日干支五行合命主喜用'); }
    if (jiWx.includes(dGanWx) || jiWx.includes(dZhiWx)){ score -= 3; reasons.push('日干支犯命主忌神'); }
    if (zeriIsChong(h.branch, userYearZhi) || zeriIsChong(h.branch, userDayZhi)){ score -= 4; reasons.push('日支冲命主年支/日支'); }
    else if (zeriIsLiuhe(h.branch, userDayZhi) || zeriIsSanhe(h.branch, userDayZhi)){ score += 1; reasons.push('日支与命主日支相合（六合/三合）'); }
    // 重大忌日
    if (h.silijue){ score -= 4; reasons.push(`${h.silijue}日，诸事不宜`); }
    if (h.yang){ score -= 3; reasons.push('杨公忌日，诸事不宜'); }
    cands.push({ y, m, d, h, score, hasYi, hasJi, reasons });
  }
  let pool = cands.filter(c => c.hasYi);
  let fallback = false;
  if (!pool.length){ pool = cands.filter(c => c.h.jc.lu === '黄' && !c.hasJi); fallback = true; }
  pool.sort((a,b) => (a.y*10000 + a.m*100 + a.d) - (b.y*10000 + b.m*100 + b.d)); // 按时间先后排序
  const top = pool.slice(0, 12);
  if (!top.length){ out.innerHTML = '<div class="zeri-tip">未来 150 天内暂无合适之日，请调整用事方向或放宽条件。</div>'; return; }
  const cards = top.map((c, idx) => {
    const g = zeriGradeOf(c.score);
    const cls = idx===0 ? 'zr-card on' : 'zr-card';
    const lo = c.h.lunar;
    return `<div class="${cls}" data-idx="${idx}">
      <div class="zr-date">${c.m}月${c.d}日</div>
      <div class="zr-lunar">${lo.IMonthCn}${lo.IDayCn}</div>
      <div class="zr-shen">${c.h.jc.shen}日</div>
      <div class="zr-grade ${c.h.jc.lu==='黄'?'good':'bad'}">${g}</div>
    </div>`;
  }).join('');
  const tip = fallback ? '<div class="zeri-tip">未找到「宜」含此事之日，已按黄道且不忌此事推荐：</div>' : '';
  // 2026-08-21 用户定：只保留择出日子，理由面板删除；「查看该日黄历」独立按钮
  out.innerHTML = `${tip}<div class="zr-scroll" id="zr-scroll">${cards}</div><button type="button" class="zr-use-day" id="zeri-go-day">查看该日黄历 ›</button>`;
  zeriCache = {
    html: out.innerHTML,
    selC: top[0] ? { y: top[0].y, m: top[0].m, d: top[0].d } : null,
    selList: top.map(c => ({ y: c.y, m: c.m, d: c.d }))
  };
  bindZeriResult(out);
  const first = out.querySelector('.zr-card');
  if (first) first.click();
}

// 择日结果缓存与绑定（2026-08-21 用户定：查看该日黄历后结果面板不折叠，黄历卡重渲后恢复）
let zeriCache = null;   // { html, selC:{y,m,d}, selList:[{y,m,d}] }
function bindZeriResult(out){
  if (!out) return;
  out.querySelectorAll('.zr-card').forEach(el => {
    el.onclick = function(){
      out.querySelectorAll('.zr-card').forEach(x => x.classList.remove('on'));
      el.classList.add('on');
      if (zeriCache && zeriCache.selList) zeriCache.selC = zeriCache.selList[+el.dataset.idx] || zeriCache.selC;
    };
  });
  const goBtn = out.querySelector('#zeri-go-day');
  if (goBtn) goBtn.onclick = function(){
    const sc = (zeriCache && zeriCache.selC) || null;
    if (!sc) return;
    renderHuangliDetail(sc.y, sc.m, sc.d);
    const hd = document.getElementById('huangli-detail');
    if (hd && hd.scrollIntoView) hd.scrollIntoView({ behavior:'smooth', block:'start' });
  };
}

function zeriReason(c, use, bz, ctx){
  const h = c.h, o = h.lunar;
  const lunarStr = `${o.gzYear}年 ${o.IMonthCn}${o.IDayCn}${o.isLeap?'（闰）':''}`;
  const week = ['日','一','二','三','四','五','六'][new Date(c.y, c.m-1, c.d).getDay()];
  const lines = [];
  lines.push(`<div class="zr-reason-h">${c.y}年${c.m}月${c.d}日（星期${week}） · ${lunarStr}</div>`);
  lines.push(`<div class="zr-reason-row"><b>建除</b>：${h.jc.shen}日 · ${h.jc.star}（${h.jc.lu==='黄'?'黄道':'黑道'}）｜冲${h.chong.animal}（${h.chong.branch}）煞${h.sha}</div>`);
  lines.push(`<div class="zr-reason-row"><b>用事方向</b>：${use.label}。当日「宜」${c.hasYi?'含此事 ✔':'不含此事'}；「忌」${c.hasJi?'含此事 ✘':'不含此事'}。</div>`);
  const xiNames = (bz.xiNames||[]).join('、') || '—';
  lines.push(`<div class="zr-reason-row"><b>用事人</b>：日主${bz.dayMaster}（${WX_NAME[bz.dayMasterWx]}），喜用神：${xiNames}。</div>`);
  const dGanWx = GAN_WX[h.stem], dZhiWx = ZHI_WX[h.branch];
  const rel = [];
  if (ctx.xiWx.includes(dGanWx) || ctx.xiWx.includes(dZhiWx)) rel.push('日干支五行合喜用神，助益命主');
  if (ctx.jiWx.includes(dGanWx) || ctx.jiWx.includes(dZhiWx)) rel.push('日干支犯忌神，须慎');
  if (zeriIsChong(h.branch, ctx.userYearZhi) || zeriIsChong(h.branch, ctx.userDayZhi)) rel.push('日支冲命主年支/日支，犯冲');
  else if (zeriIsLiuhe(h.branch, ctx.userDayZhi) || zeriIsSanhe(h.branch, ctx.userDayZhi)) rel.push('日支与命主日支相合（六合/三合），气场相投');
  lines.push(`<div class="zr-reason-row"><b>与命主关系</b>：${rel.length?rel.join('；'):'日干支与命主无明显生克冲合'}。</div>`);
  const grade = zeriGradeOf(c.score);
  lines.push(`<div class="zr-reason-row zr-verdict">综合判定：<b>${grade}</b>。</div>`);
  return lines.join('');
}

/* ===================================================================
 * 万年历
 * =================================================================== */
let calSelDay = 1; // 当前选中日（万年历视图内）

function initCalendar(){
  const ySel = document.getElementById('cal-year');
  const mSel = document.getElementById('cal-month');
  const now = new Date();
  for (let y=1900; y<=2100; y++){
    const o = document.createElement('option'); o.value=y; o.textContent=y+'年'; ySel.appendChild(o);
  }
  for (let m=1; m<=12; m++){
    const o = document.createElement('option'); o.value=m; o.textContent=m+'月'; mSel.appendChild(o);
  }
  ySel.value = now.getFullYear();
  mSel.value = now.getMonth()+1;
  calSelDay = now.getDate();

  // 年/月/日选择器（复用八字排盘 .lunar-trigger / .lunar-popup / .lp-* 款式）
  const ymLabel = document.getElementById('cal-ym-label');
  const ymBtn = document.getElementById('cal-ym');
  const popup = document.getElementById('cal-popup');
  const yearList = document.getElementById('cal-year-list');
  const monthGrid = document.getElementById('cal-month-grid');
  function updateYMLabel(){ ymLabel.textContent = `${ySel.value}年${mSel.value}月`; }
  function closeCalPopup(){ popup.hidden = true; ymBtn.setAttribute('aria-expanded','false'); }
  function markSel(){
    yearList.querySelectorAll('.lp-year-item').forEach(it=> it.classList.toggle('sel', +it.dataset.y === +ySel.value));
    monthGrid.querySelectorAll('.lp-month-item').forEach(it=> it.classList.toggle('sel', +it.dataset.m === +mSel.value));
  }
  for (let y=1900; y<=2100; y++){
    const b = document.createElement('button');
    b.type='button'; b.className='lp-year-item'; b.dataset.y=y; b.textContent=y+'年';
    b.onclick = ()=>{ ySel.value=y; updateYMLabel(); markSel(); renderCalendar(); };
    yearList.appendChild(b);
  }
  for (let m=1; m<=12; m++){
    const b = document.createElement('button');
    b.type='button'; b.className='lp-month-item'; b.dataset.m=m; b.textContent=m+'月';
    b.onclick = ()=>{ mSel.value=m; updateYMLabel(); markSel(); renderCalendar(); closeCalPopup(); };
    monthGrid.appendChild(b);
  }
  markSel(); updateYMLabel();

  ymBtn.onclick = (e)=>{
    e.stopPropagation();
    const open = popup.hidden;
    popup.hidden = !open;
    ymBtn.setAttribute('aria-expanded', String(open));
    if (open){
      markSel();
      popup.style.top = (ymBtn.getBoundingClientRect().bottom + 8) + 'px';
      yearList.scrollTop = Math.max(0, (ySel.value - 1900) * 30 - 110);
    }
  };
  document.addEventListener('click', (e)=>{
    if (!popup.hidden && !popup.contains(e.target) && e.target !== ymBtn){
      popup.hidden = true; ymBtn.setAttribute('aria-expanded','false');
    }
  });

  document.getElementById('cal-prev').onclick = ()=> stepMonth(-1);
  document.getElementById('cal-next').onclick = ()=> stepMonth(1);
  document.getElementById('cal-today').onclick = ()=>{
    const n = new Date();
    ySel.value = n.getFullYear(); mSel.value = n.getMonth()+1;
    calSelDay = n.getDate();
    updateYMLabel(); markSel(); renderCalendar();
  };
  renderCalendar();
}

function stepMonth(delta){
  const ySel = document.getElementById('cal-year');
  const mSel = document.getElementById('cal-month');
  let y = +ySel.value, m = +mSel.value + delta;
  if (m < 1){ m = 12; y--; } else if (m > 12){ m = 1; y++; }
  if (y < 1900) y = 1900; if (y > 2100) y = 2100;
  ySel.value = y; mSel.value = m;
  calSelDay = Math.min(calSelDay, new Date(y, m, 0).getDate());
  const lbl = document.getElementById('cal-ym-label');
  if (lbl) lbl.textContent = `${y}年${m}月`;
  renderCalendar();
}

// 日历格农历显示：每月初一显示X月 初一，其余只显示日（去掉每日重复的月份数）
function lunarCell(o){
  return o.IDayCn === '初一' ? o.IMonthCn : o.IDayCn;
}

function renderCalendar(){
  // 兜底：若农历库尚未就绪（部分预览器异步注入脚本），稍后重试，避免首屏万年历空白
  if (typeof calendar === 'undefined' || typeof calendar.solar2lunar !== 'function'){
    setTimeout(renderCalendar, 50); return;
  }
  const y = +document.getElementById('cal-year').value;
  const m = +document.getElementById('cal-month').value;
  const grid = document.getElementById('cal-grid');
  const wkCls = ['日','一','二','三','四','五','六'];
  let html = wkCls.map((w,i)=>`<div class="weekday ${i===0?'wd-sun':(i===6?'wd-sat':'')}">${w}</div>`).join('');
  const first = new Date(y, m-1, 1).getDay();
  const days = new Date(y, m, 0).getDate();
  const today = new Date();
  const isToday = (dd)=> today.getFullYear()===y && today.getMonth()+1===m && today.getDate()===dd;
  // 相邻月份日期，用于补齐网格首尾空格：无边框、淡色
  let py=y, pm=m-1; if (pm<1){ pm=12; py=y-1; }
  const prevDays = new Date(py, pm, 0).getDate();
  let ny=y, nm=m+1; if (nm>12){ nm=1; ny=y+1; }
  const adjLunar = (yy,mm,dd)=>{ const o=calendar.solar2lunar(yy,mm,dd);
    if (o.isTerm) return o.Term; if (o.lunarFestival) return o.lunarFestival;
    if (o.festival) return o.festival; return o.IDayCn==='初一'?o.IMonthCn:o.IDayCn; };
  for (let i=0;i<first;i++){ const d=prevDays-first+1+i;
    html += `<div class="cal-cell adj"><div class="cal-cell-inner"><div class="g">${d}</div><div class="cell-info"><div class="l">${adjLunar(py,pm,d)}</div></div></div></div>`;
  }
  for (let dd=1; dd<=days; dd++){
    const h = computeHuangli(y, m, dd);
    const o = h.lunar;
    // 节气 / 节日：其名直接替代农历显示（不附农历）
    let lText = lunarCell(o);
    let lClass = 'l';
    let sub = '';
    if (o.isTerm) { lText = o.Term; lClass = 'l event term'; }
    else if (o.lunarFestival) { lText = o.lunarFestival; lClass = 'l event fest'; }
    else if (o.festival) { lText = o.festival; lClass = 'l event fest'; }
    const lu = h.jc.lu === '黄' ? 'huang' : 'hei';
    const isEvent = (o.isTerm || o.lunarFestival || o.festival) ? 'cell-event' : '';
    const gz = o.gzDay || '';
    const gCls = (gz[0] && GAN_WX[gz[0]]) ? 'wx-' + GAN_WX[gz[0]] : '';
    const zCls = (gz[1] && ZHI_WX[gz[1]]) ? 'wx-' + ZHI_WX[gz[1]] : '';
    const wd = (first + dd - 1) % 7;
    const weekend = (wd === 0 || wd === 6) ? 'weekend' : '';
    html += `<div class="cal-cell ${isToday(dd)?'today':''} ${lu} ${isEvent} ${weekend}" data-d="${dd}">
      <div class="cal-cell-inner">
        <div class="g">${dd}</div>
        <div class="cell-info">
          <div class="${lClass}">${lText}</div>
          <div class="d"><span class="${gCls}">${gz[0]||''}</span><span class="${zCls}">${gz[1]||''}</span></div>
        </div>
      </div>
    </div>`;
  }
  const trail = (7 - ((first + days) % 7)) % 7;
  for (let i=1;i<=trail;i++){
    html += `<div class="cal-cell adj"><div class="cal-cell-inner"><div class="g">${i}</div><div class="cell-info"><div class="l">${adjLunar(ny,nm,i)}</div></div></div></div>`;
  }
  grid.innerHTML = html;
  grid.querySelectorAll('.cal-cell').forEach(cell=>{
    cell.onclick = ()=>{
      const dd = +cell.dataset.d; if (!dd) return;
      grid.querySelectorAll('.cal-cell').forEach(c=> c.classList.remove('selected'));
      cell.classList.add('selected');
      calSelDay = dd;
      renderHuangliDetail(y, m, dd);
    };
  });
  // 默认选中：优先用已选日（跨月时夹紧），否则当月选今天、其它月选 1 号
  const maxD = new Date(y, m, 0).getDate();
  let selDay = calSelDay;
  if (!selDay || selDay > maxD) selDay = (today.getFullYear()===y && today.getMonth()+1===m) ? today.getDate() : 1;
  calSelDay = selDay;
  const lbl = document.getElementById('cal-ym-label');
  if (lbl) lbl.textContent = `${y}年${m}月`;
  const selCell = grid.querySelector(`.cal-cell[data-d="${selDay}"]`);
  if (selCell){ selCell.classList.add('selected'); renderHuangliDetail(y, m, selDay); }
}

/* ===================================================================
 * 古籍收集
 * =================================================================== */
function bookVisibleList(){
  const q = booksQuery.trim();
  return BOOKS.filter(b=>{
    if (booksFilter !== 'all' && b.cat !== booksFilter) return false;
    if (q && !(b.name.includes(q) || b.meta.includes(q) || (b.school||'').includes(q))) return false;
    return true;
  });
}
function renderBooks(){
  const grid = document.getElementById('books-grid');
  const chips = document.getElementById('books-chips');
  const status = loadBookStatus();
  // 分类筛选 chips（全部 + 数据中实际存在的部类）
  const cats = [...new Set(BOOKS.map(b=>b.cat))];
  const chipData = [{key:'all', label:'全部'}].concat(cats.map(c=>({key:c, label:BOOK_CAT[c].label})));
  chips.innerHTML = chipData.map(c=>`<button class="books-chip${booksFilter===c.key?' active':''}" data-cat="${c.key}">${c.label}</button>`).join('');
  chips.querySelectorAll('.books-chip').forEach(btn=>{
    btn.onclick = ()=>{ booksFilter = btn.dataset.cat; renderBooks(); };
  });
  // 选中项若被筛掉则收起
  const list = bookVisibleList();
  if (booksSelected && !list.some(b=>b.name===booksSelected)) booksSelected = null;
  // 卡片网格
  grid.innerHTML = list.map(b=>{
    const cat = BOOK_CAT[b.cat];
    const st = status[b.name];
    const badge = st ? `<span class="book-badge" style="background:${BOOK_STATUS[st].color}">${BOOK_STATUS[st].label}</span>` : '';
    return `<div class="book-card" data-name="${b.name}" style="border-left:3px solid ${cat.color}">
      <div class="book-top"><span class="book-tag" style="color:${cat.color}">${cat.label}${b.school?' · '+b.school:''}</span>${badge}</div>
      <h3>${b.name}</h3>
      <div class="meta">${b.meta}</div>
      <div class="desc">${b.desc}</div>
      <span class="book-more">阅读状态 ›</span>
    </div>`;
  }).join('') || '<p class="hint">没有匹配的古籍。</p>';
  grid.querySelectorAll('.book-card').forEach(card=>{
    card.onclick = ()=>{
      booksSelected = card.dataset.name;
      renderBookDetail();      // 渲染并就近浮动显示（不再跳转/滚动到底部）
      renderBooksStatusbar();
    };
  });
  renderBookDetail();
  renderBooksStatusbar();
}
/* 古籍「阅读状态」就近浮动：点击书籍后，popover 出现在该书籍卡附近，而非页面底部外卡 */
let docCloseBound = false;
function positionBookPopover(card){
  const det = document.getElementById('book-detail');
  if (!det) return;
  const pw = Math.min(360, window.innerWidth - 16);
  const ph = det.offsetHeight || 160;
  const vw = window.innerWidth, vh = window.innerHeight;
  let left = 8, top = 8;
  if (card){
    const r = card.getBoundingClientRect();
    left = r.left + r.width/2 - pw/2;
    top  = r.bottom + 8;
    if (left + pw > vw - 8) left = vw - pw - 8;
    if (left < 8) left = 8;
    if (top + ph > vh - 8) top = Math.max(8, r.top - ph - 8);  // 下方不够则翻到卡上方
  }
  det.style.width = pw + 'px';
  det.style.left = left + 'px';
  det.style.top = top + 'px';
}
function onDocClickClose(e){
  const det = document.getElementById('book-detail');
  if (!det || det.hidden) return;
  if (det.contains(e.target)) return;                 // 点在 popover 内不关
  if (e.target.closest && e.target.closest('.book-card')) return; // 点别的书卡交给卡片切换
  hideBookPopover();
}
function hideBookPopover(){
  const det = document.getElementById('book-detail');
  if (det) det.hidden = true;
  booksSelected = null;
  renderBooksStatusbar();
}
function renderBookDetail(){
  const el = document.getElementById('book-detail');
  if (!booksSelected){ el.hidden = true; el.innerHTML = ''; return; }
  const b = BOOKS.find(x=>x.name===booksSelected);
  if (!b){ el.hidden = true; el.innerHTML = ''; return; }
  const status = loadBookStatus();
  const st = status[b.name];
  const cat = BOOK_CAT[b.cat];
  // 全本：有 bookKey 且 window.BOOK_TEXT 含该书全文时视为「已有全本」
  const hasFull = !!(window.BOOK_TEXT && b.bookKey && window.BOOK_TEXT[b.bookKey]);
  // 阅读状态按钮（合并进小卡顶部，各书共有、随时可设）
  const statusBtns = Object.keys(BOOK_STATUS).map(k=>{
    const on = st === k;
    const style = on ? `background:${BOOK_STATUS[k].color};border-color:${BOOK_STATUS[k].color};color:#fff` : '';
    return `<button type="button" class="book-status-btn${on?' active':''}" data-status="${k}" style="${style}">${BOOK_STATUS[k].label}</button>`;
  }).join('') + `<button type="button" class="book-status-btn clear" data-status="">清除</button>`;
  // 继续阅读：记录每本书进度，进入阅读视图（全本读全文，非全本读精选）
  const prog = loadBookProgress(b.name);
  const contLabel = hasFull ? (prog ? `继续阅读 · ${prog.pct}%` : '开始阅读') : '阅读精选';
  el.hidden = false;
  el.innerHTML = `
    <div class="bd-mini">
      <div class="bd-mini-cap">《${b.name}》阅读状态</div>
      <div class="bd-status-btns">
        ${statusBtns}
      </div>
      <div class="bd-mini-actions">
        <button type="button" class="bd-cont-btn" id="bd-cont">${contLabel}</button>
        <button type="button" class="bd-close" id="bd-close">收起</button>
      </div>
    </div>
  `;
  // 就近浮动定位到该书籍卡（卡片可能被筛选重渲染，故按 data-name 重新查找）
  const card = document.querySelector('.book-card[data-name="' + (booksSelected||'').replace(/"/g,'\\"') + '"]');
  positionBookPopover(card);
  if (!docCloseBound){ document.addEventListener('click', onDocClickClose, true); docCloseBound = true; }
  el.querySelector('#bd-close').onclick = ()=>{ booksSelected = null; renderBookDetail(); renderBooksStatusbar(); };
  el.querySelector('#bd-cont').onclick = ()=>{ const d = document.getElementById('book-detail'); if (d) d.hidden = true; openReader(b, hasFull); };
  // 阅读状态按钮：点击即设/清除，更新卡片徽标与高亮
  el.querySelectorAll('.book-status-btn').forEach(btn=>{
    btn.onclick = ()=>{
      if (!booksSelected) return;
      const s = btn.dataset.status || null;
      const m = loadBookStatus();
      if (s) m[booksSelected] = s; else delete m[booksSelected];
      saveBookStatus(m);
      renderBooks();          // 更新卡片徽标
      renderBooksStatusbar(); // 同步高亮
    };
  });
}

/* ===================== 书籍阅读进度（每本书独立记录） ===================== */
function loadBookProgress(name){
  try { const m = JSON.parse(localStorage.getItem('claw_book_progress_v1') || '{}'); return m[name] || null; }
  catch (e) { return null; }
}
function saveBookProgress(name, pct, pos){
  try {
    const m = JSON.parse(localStorage.getItem('claw_book_progress_v1') || '{}');
    m[name] = { pct: Math.max(0, Math.min(100, Math.round(pct||0))), pos: pos||0, ts: Date.now() };
    localStorage.setItem('claw_book_progress_v1', JSON.stringify(m));
  } catch (e) {}
}

/* ===================== 阅读器（继续阅读 / 全书内容 / 精选） ===================== */
let readerState = null;
function escHtml(s){ return String(s==null?'':s).replace(/[&<>]/g, function(c){ return ({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]); }); }
// 把一本书拆成「章节」数组：全本按章节标题切分；精选按 excerpt 切分
function buildSections(b, hasFull){
  if (hasFull){
    const raw = (window.BOOK_TEXT && window.BOOK_TEXT[b.bookKey]) || '';
    const lines = raw.split(/\r?\n/);
    // 只把「短标题行」当章节，避免把 【原注】/【任氏曰】/命例【干支】等正文/注释误判为目录：
    // 卷一·… / 卷首中下末 / 第X章回节篇 / 上下篇·… / 一、… / 《论…》 / 甲木调候 / 序·… / 前言附录等
    const chapRe = /^(卷[一二三四五六七八九十百千0-9首中下末终][^\n]{0,20}|第[一二三四五六七八九十百千0-9]+[章回节篇集][^\n]{0,20}|[上中下]篇[·、][^\n]{0,18}|[一二三四五六七八九十百千]+、[^\n]{0,22}|《[^》]{1,20}》[^\n]{0,8}|[甲乙丙丁戊己庚辛壬癸][木火土金水]调候|调候总则|调候应用规则|序[·、][^\n]{0,18}|自序|原序|凡例|前言|附录|后记|引子|楔子)$/;
    const sections = [];
    let cur = null;
    lines.forEach(function(ln){
      const t = ln.trim();
      if (!t) return;
      if (t.length <= 26 && chapRe.test(t)){
        cur = { title: t.slice(0, 34), lines: [] };
        sections.push(cur);
      } else {
        if (!cur){ cur = { title: '', lines: [] }; sections.push(cur); }
        cur.lines.push(t);
      }
    });
    return sections;
  }
  return (b.excerpts||[]).map(function(e, i){ return {
    title: e.title || ('选段 ' + (i+1)),
    lines: [e.source, e.translation ? ('【译文】' + e.translation) : ''].filter(Boolean)
  }; });
}
function loadReaderFs(){ const v = parseInt(localStorage.getItem('claw_reader_fs'),10); return isNaN(v)?18:v; }
function saveReaderFs(v){ try{ localStorage.setItem('claw_reader_fs', String(v)); }catch(e){} }
function updateReaderProg(body){
  const max = body.scrollHeight - body.clientHeight;
  const pct = max>0 ? Math.round((body.scrollTop/max)*100) : 0;
  const bar = document.getElementById('rd-prog-bar');
  if (bar) bar.style.width = pct + '%';
  const cont = document.getElementById('bd-cont');
  if (cont && booksSelected) cont.textContent = `继续阅读 · ${pct}%`;
}
function saveReaderPos(body, name){
  const max = body.scrollHeight - body.clientHeight;
  const pct = max>0 ? (body.scrollTop/max)*100 : 0;
  saveBookProgress(name, pct, body.scrollTop);
  updateReaderProg(body);
}
function openReader(b, hasFull){
  const sections = buildSections(b, hasFull);
  if (!sections.length || !sections.some(function(s){ return s.lines.length || s.title; })){ alert('该书暂无可读内容'); return; }
  const old = document.getElementById('reader-overlay');
  if (old) old.remove();
  const ov = document.createElement('div');
  ov.id = 'reader-overlay';
  ov.innerHTML = `
    <div class="reader-head">
      <div class="reader-title">《${b.name}》</div>
        <div class="reader-tools">
          <button type="button" class="reader-btn" id="rd-toc" title="章节目录">目录</button>
          <button type="button" class="reader-btn" id="rd-fs-down" title="缩小字体">A-</button>
          <button type="button" class="reader-btn" id="rd-fs-up" title="放大字体">A+</button>
          <button type="button" class="reader-btn" id="rd-voice" title="语音朗读">语音</button>
          <button type="button" class="reader-btn" id="rd-close" title="关闭">关闭</button>
        </div>
    </div>
    <div class="reader-prog"><div class="reader-prog-bar" id="rd-prog-bar"></div></div>
    <div class="reader-body" id="rd-body"></div>
    <div class="reader-toc-mask" id="rd-toc-mask"></div>
    <div class="reader-toc" id="rd-toc-panel">
      <div class="reader-toc-head">目录<button type="button" id="rd-toc-close" aria-label="收起目录">×</button></div>
      <div class="reader-toc-list" id="rd-toc-list"></div>
    </div>
    ${b.url && !hasFull ? `<div class="reader-foot"><a href="${b.url}" target="_blank" rel="noopener">查看原文站点 ↗</a></div>` : ''}
  `;
  document.body.appendChild(ov);
  document.body.style.overflow = 'hidden';
  const body = ov.querySelector('#rd-body');
  body.innerHTML = (function(){
    let h = '';
    sections.forEach(function(s,i){
      const secId = 'rd-sec-' + i;
      if (s.title) h += '<h3 class="reader-chap" id="' + secId + '">' + escHtml(s.title) + '</h3>';
      h += '<div class="reader-sec-body">' + s.lines.map(function(l){ return l ? '<p>' + escHtml(l) + '</p>' : ''; }).join('') + '</div>';
    });
    return h;
  })();
  // 章节目录：列出全部章节标题，点击平滑滚动到对应锚点
  const tocList = ov.querySelector('#rd-toc-list');
  const tocItemsHtml = sections.map(function(s,i){ return s.title ? '<button type="button" class="reader-toc-item" data-sec="' + i + '">' + escHtml(s.title) + '</button>' : ''; }).filter(Boolean).join('');
  const tocPanel = ov.querySelector('#rd-toc-panel');
  const tocMask = ov.querySelector('#rd-toc-mask');
  const tocBtn = ov.querySelector('#rd-toc');
  const closeToc = function(){ tocPanel.classList.remove('open'); tocMask.classList.remove('open'); };
  if (!tocItemsHtml){
    // 无可用章节：隐藏「目录」按钮，避免弹出空/错目录
    if (tocBtn) tocBtn.style.display = 'none';
    tocPanel.remove(); tocMask.remove();
  } else {
    tocList.innerHTML = tocItemsHtml;
    tocBtn.onclick = function(){ tocPanel.classList.add('open'); tocMask.classList.add('open'); };
    ov.querySelector('#rd-toc-close').onclick = closeToc;
    tocMask.onclick = closeToc;   // 点目录以外区域关闭
    tocList.querySelectorAll('.reader-toc-item').forEach(function(it){
      it.onclick = function(){ var el = document.getElementById('rd-sec-' + it.dataset.sec); if (el) el.scrollIntoView({ behavior:'smooth', block:'start' }); closeToc(); };
    });                 // 纯文本，避免注入
  }
  let fs = loadReaderFs();
  const applyFs = ()=>{ body.style.fontSize = fs + 'px'; };
  applyFs();
  // 恢复上次阅读进度
  const prog = loadBookProgress(b.name);
  requestAnimationFrame(()=>{
    if (prog && prog.pos) body.scrollTop = prog.pos;
    updateReaderProg(body);
  });
  // 滚动记录进度
  let raf = null;
  body.onscroll = ()=>{ if (raf) cancelAnimationFrame(raf); raf = requestAnimationFrame(()=>{ saveReaderPos(body, b.name); }); };
  // 字体缩放
  ov.querySelector('#rd-fs-up').onclick = ()=>{ fs = Math.min(42, fs+2); saveReaderFs(fs); applyFs(); };
  ov.querySelector('#rd-fs-down').onclick = ()=>{ fs = Math.max(12, fs-2); saveReaderFs(fs); applyFs(); };
  ov.querySelector('#rd-close').onclick = ()=> closeReader(ov);
  ov.querySelector('#rd-voice').onclick = (e)=> toggleVoice(body.innerText, e.currentTarget);
  readerState = { name: b.name, ov, body };
}
function closeReader(ov){
  stopVoice();
  if (readerState && readerState.body) saveReaderPos(readerState.body, readerState.name);
  ov.remove();
  document.body.style.overflow = '';
  readerState = null;
}

/* ===================== 语音朗读 =====================
 * 优先用原生 TTS 插件（@capacitor-community/text-to-speech）——安卓 WebView 普遍没有 Web Speech API，
 * 之前显示「语音不可用」正因如此。装了原生插件后走系统 TTS 引擎（多数国产机自带中文语音）。
 * 无插件时（如浏览器网页版）回退 Web Speech API。 */
let voiceUtter = null;
let voiceOn = false;
function getNativeTTS(){
  try{ return (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.TextToSpeech) || null; }catch(e){ return null; }
}
async function toggleVoice(text, btn){
  const tts = getNativeTTS();
  if (tts){
    if (voiceOn){ voiceOn = false; try{ await tts.stop(); }catch(e){} btn.textContent = '语音'; return; }
    voiceOn = true; btn.textContent = '停止';
    const chunks = String(text||'').split(/\n+/).map(s=>s.trim()).filter(Boolean);
    try{
      for (let i=0;i<chunks.length;i++){
        if (!voiceOn) break;
        await tts.speak({ text: chunks[i], lang: 'zh-CN', rate: 1.0 });
      }
    }catch(e){}
    voiceOn = false; btn.textContent = '语音';
    return;
  }
  // ---- Web Speech 回退（浏览器网页版）----
  if (!('speechSynthesis' in window)){ btn.textContent = '语音不可用'; btn.disabled = true; return; }
  const synth = window.speechSynthesis;
  if (synth.speaking && !synth.paused){ synth.pause(); btn.textContent = '继续朗读'; return; }
  if (synth.paused){ synth.resume(); btn.textContent = '暂停'; return; }
  synth.cancel();
  const paras = text.split(/\n+/).filter(p=>p.trim());
  let idx = 0;
  const speakNext = ()=>{
    if (idx >= paras.length){ btn.textContent = '语音'; return; }
    const u = new SpeechSynthesisUtterance(paras[idx]);
    u.lang = 'zh-CN'; u.rate = 0.95;
    u.onend = ()=>{ idx++; speakNext(); };
    u.onerror = ()=>{ btn.textContent = '语音'; };
    voiceUtter = u; synth.speak(u);
  };
  btn.textContent = '暂停';
  speakNext();
}
function stopVoice(){
  voiceOn = false;
  const tts = getNativeTTS();
  if (tts){ try{ tts.stop(); }catch(e){} }
  if ('speechSynthesis' in window){ try{ window.speechSynthesis.cancel(); }catch(e){} }
  voiceUtter = null;
}

// 阅读状态同步：详情卡已内嵌状态按钮，这里仅根据当前选中书籍高亮对应项
function renderBooksStatusbar(){
  const bar = document.getElementById('bd-status-btns');
  if (!bar) return;
  const status = loadBookStatus();
  const st = booksSelected ? status[booksSelected] : null;
  bar.querySelectorAll('.book-status-btn').forEach(btn=>{
    if (btn.classList.contains('clear')) return; // 清除按钮不高亮
    const k = btn.dataset.status || null;
    btn.classList.toggle('active', k === (st || ''));
  });
}

/* ===================================================================
 * 数理分析
 * =================================================================== */
/* ===================================================================
 * 梅花易数（数字起卦）— 与小程序引擎同源
 * 先天八卦数：乾1 兑2 离3 震4 巽5 坎6 艮7 坤8
 * =================================================================== */
const BAGUA_XT = {1:'乾',2:'兑',3:'离',4:'震',5:'巽',6:'坎',7:'艮',8:'坤'};
const XT_BAGUA = {'乾':1,'兑':2,'离':3,'震':4,'巽':5,'坎':6,'艮':7,'坤':8};
const BAGUA_WX = {'乾':'metal','兑':'metal','离':'fire','震':'wood','巽':'wood','坎':'water','艮':'earth','坤':'earth'};
const TRIGRAM_BITS = {'乾':[1,1,1],'兑':[0,1,1],'离':[1,0,1],'震':[0,0,1],'巽':[1,1,0],'坎':[0,1,0],'艮':[1,0,0],'坤':[0,0,0]};
// 由本/互/变卦的上下卦名渲染六爻卦符：bit=1 阳爻(实线)，0 阴爻(中间分隔的断线)
function guaLinesHtml(info){
  if (!info || !info.upT || !info.downT) return '';
  const bits = guaBits(info.upT, info.downT); // [下初,下二,下三,上初,上二,上三]，index0=初爻(底)
  let s = '<div class="gua-lines">';
  for (let i = 5; i >= 0; i--){            // 从顶爻(5)排到底爻(0)
    s += bits[i]
      ? '<div class="gl-row gl-yang"></div>'
      : '<div class="gl-row gl-yin"><span></span><span></span></div>';
  }
  return s + '</div>';
}
const GUA_64 = {
  '11':'乾为天','12':'天泽履','13':'天火同人','14':'天雷无妄','15':'天风姤','16':'天水讼','17':'天山遁','18':'天地否',
  '21':'泽天夬','22':'兑为泽','23':'泽火革','24':'泽雷随','25':'泽风大过','26':'泽水困','27':'泽山咸','28':'泽地萃',
  '31':'火天大有','32':'火泽睽','33':'离为火','34':'火雷噬嗑','35':'火风鼎','36':'火水未济','37':'火山旅','38':'火地晋',
  '41':'雷天大壮','42':'雷泽归妹','43':'雷火丰','44':'震为雷','45':'雷风恒','46':'雷水解','47':'雷山小过','48':'雷地豫',
  '51':'风天小畜','52':'风泽中孚','53':'风火家人','54':'风雷益','55':'巽为风','56':'风水涣','57':'风山渐','58':'风地观',
  '61':'水天需','62':'水泽节','63':'水火既济','64':'水雷屯','65':'水风井','66':'坎为水','67':'水山蹇','68':'水地比',
  '71':'山天大畜','72':'山泽损','73':'山火贲','74':'山雷颐','75':'山风蛊','76':'山水蒙','77':'艮为山','78':'山地剥',
  '81':'地天泰','82':'地泽临','83':'地火明夷','84':'地雷复','85':'地风升','86':'地水师','87':'地山谦','88':'坤为地'
};
const GUA_DESC = {
  '11':'刚健中正，自强不息','12':'履虎尾，慎行免咎','13':'和同于人，协力共进','14':'不妄为，顺天合道','15':'遇合之初，防阴渐长','16':'争讼，慎防口舌官非','17':'退避以全，适时而隐','18':'闭塞不通，待机转泰',
  '21':'决而能和，刚断去小人','22':'喜悦和顺，口舌生财','23':'顺天应人，变革更新','24':'随时而动，从善得吉','25':'非常之事，独立不惧','26':'困穷守正，静待其通','27':'感应交欢，少男少女','28':'荟萃聚集，人才汇拢',
  '31':'富有日新，大而能谦','32':'乖离反常，求同存异','33':'光明附丽，柔顺得中','34':'咬合去梗，决断除碍','35':'鼎新取象，稳重养贤','36':'事未成，慎终如始','37':'行旅在外，依义安身','38':'进长光明，步步高升',
  '41':'阳刚壮盛，戒躁用壮','42':'归妹依礼，失正则凶','43':'丰大光明，盛极当忧','44':'震动奋发，恐惧修省','45':'恒久不已，持之以正','46':'险难消解，舒缓解脱','47':'小有过越，宜下不宜上','48':'欢悦顺动，备豫有乐',
  '51':'小有蓄积，待时而发','52':'诚信感格，心交信孚','53':'齐家有序，内睦外安','54':'损上益下，与时偕行','55':'谦顺而入，渐进得通','56':'涣散离析，散财聚神','57':'渐次而进，女归吉渐','58':'观察风化，省方设教',
  '61':'等待时机，饮食宴乐','62':'节制有度，适可而止','63':'事已成，防初吉终乱','64':'万物始生，艰难创基','65':'养而不穷，井渫不食','66':'重险陷难，维心亨通','67':'见险止行，反身修德','68':'亲比相辅，择善而从',
  '71':'厚积德载，止健笃实','72':'损下益上，惩忿窒欲','73':'文饰之美，质素为本','74':'颐养正道，慎言节食','75':'蛊坏整治，振民育德','76':'启蒙养正，匪我求童','77':'止而有节，动静以时','78':'剥落侵蚀，顺止避害',
  '81':'天地交泰，安稳通达','82':'临下亲民，阳气渐长','83':'明入地中，韬光养晦','84':'一阳来复，生机重启','85':'柔顺上升，积小成高','86':'兵众用师，忧劳得正','87':'谦尊而光，卑而不可踰','88':'厚德载物，柔顺承天'
};
function guaBits(upT, downT){ return TRIGRAM_BITS[downT].concat(TRIGRAM_BITS[upT]); }
function bitsToTrigrams(bits){
  const down = bits.slice(0,3), up = bits.slice(3,6);
  const toT = b => Object.keys(TRIGRAM_BITS).find(k=>{ const v=TRIGRAM_BITS[k]; return v[0]===b[0]&&v[1]===b[1]&&v[2]===b[2]; });
  return { up: toT(up), down: toT(down) };
}
function huaGuaBits(bits){ return [bits[1],bits[2],bits[3]].concat([bits[2],bits[3],bits[4]]); }
function bianGuaBits(bits, dong){ const b = bits.slice(); b[dong-1] = b[dong-1] ? 0 : 1; return b; }
function guaInfoFromBits(bits){
  const t = bitsToTrigrams(bits);
  const u = XT_BAGUA[t.up], d = XT_BAGUA[t.down];
  return { up:u, down:d, upT:t.up, downT:t.down, name: GUA_64[`${u}${d}`] || '', desc: GUA_DESC[`${u}${d}`] || '' };
}
function meihuaGua(digits){
  if (!digits || digits.length < 2) return null;
  const n = digits.length;
  const mid = Math.ceil(n/2);
  const upSum = digits.slice(0, mid).reduce((a,b)=>a+b,0);
  const downSum = digits.slice(mid).reduce((a,b)=>a+b,0);
  const up = ((upSum - 1) % 8) + 1;
  const down = ((downSum - 1) % 8) + 1;
  const total = digits.reduce((a,b)=>a+b,0);
  const dong = ((total - 1) % 6) + 1;
  const benBits = guaBits(BAGUA_XT[up], BAGUA_XT[down]);
  const ben = { up, down, upT: BAGUA_XT[up], downT: BAGUA_XT[down], name: GUA_64[`${up}${down}`], desc: GUA_DESC[`${up}${down}`] || '' };
  const hua = guaInfoFromBits(huaGuaBits(benBits));
  const bian = guaInfoFromBits(bianGuaBits(benBits, dong));
  const yongIsDown = dong <= 3;
  const tiT = yongIsDown ? ben.upT : ben.downT;
  const yongT = yongIsDown ? ben.downT : ben.upT;
  const tiWx = BAGUA_WX[tiT], yongWx = BAGUA_WX[yongT];
  let tiYong;
  if (tiWx === yongWx) tiYong = '体用比和（平）';
  else if (WX_SHENG[tiWx] === yongWx) tiYong = '用生体（吉）';
  else if (WX_SHENG[yongWx] === tiWx) tiYong = '体生用（小耗）';
  else if (WX_KE[tiWx] === yongWx) tiYong = '体克用（吉）';
  else tiYong = '用克体（凶）';
  return { dong, ben, hua, bian, tiT, yongT, tiWx, yongWx, tiWxName: WX_NAME[tiWx], yongWxName: WX_NAME[yongWx], tiYong };
}

function baziMathHtml(b){
  if (!b) return '<p class="hint">请先在八字排盘中排盘，再来查看八字数理。</p>';
  const GAN_YIN = {甲:1,丙:1,戊:1,庚:1,壬:1};           // 阳干
  const ZHI_YIN = {子:1,寅:1,辰:1,午:1,申:1,戌:1};       // 阳支
  const HETU = {wood:'3·8',fire:'2·7',earth:'5·10',metal:'4·9',water:'1·6'}; // 河图生成数
  const pillars = [['年柱',b.year],['月柱',b.month],['日柱',b.day],['时柱',b.hour]];

  // —— 五行数理（个数 · 旺衰）——
  const wx = b.wx || {wood:0,fire:0,earth:0,metal:0,water:0};
  const wxArr = [['wood','木'],['fire','火'],['earth','土'],['metal','金'],['water','水']];
  const maxWx = Math.max(...wxArr.map(([k])=>wx[k]));
  const minWx = Math.min(...wxArr.map(([k])=>wx[k]));
  const wxRows = wxArr.map(([k,name])=>{
    const v = wx[k]; const pct = Math.max(6, Math.round(v/maxWx*100));
    const tag = v===maxWx ? ' <i class="wx-strong">旺</i>' : (v===minWx && v<maxWx ? ' <i class="wx-weak">弱</i>' : '');
    return `<div class="wx-row"><span class="wx-name">${name}${tag}</span><div class="wx-track"><div class="wx-fill wx-${k}" style="width:${pct}%"></div></div><span class="wx-num">${v}</span></div>`;
  }).join('');

  // —— 十神格局（天干 + 地支藏干）——
  const SS = ['比肩','劫财','食神','伤官','正财','偏财','正官','七杀','正印','偏印'];
  const ssCount = {}; SS.forEach(s=>ssCount[s]=0);
  pillars.forEach(([,gz])=>{
    const s1 = shiShen(b.dayMaster, b.dayMasterWx, gz[0], GAN_WX[gz[0]]); if (s1) ssCount[s1]++;
    (HIDDEN[gz[1]]||[]).forEach(hg=>{ const s2 = shiShen(b.dayMaster, b.dayMasterWx, hg, GAN_WX[hg]); if (s2) ssCount[s2]++; });
  });
  const ssHtml = SS.map(s=> ssCount[s] ? `<span class="ss-chip">${s}<i>${ssCount[s]}</i></span>` : '').filter(Boolean).join('') || '<span class="hint">—</span>';

  // —— 四柱纳音 ——
  const nayinRows = pillars.map(([r,gz])=>{
    const ny = AD_NAYIN[gz] || '';
    return `<tr><td>${r}</td><td>${gz}</td><td>${ny}</td><td>${AD_NAYIN_GONG[r]}</td><td class="ny-desc">${AD_NAYIN_DESC[ny]||''}</td></tr>`;
  }).join('');

  // —— 各柱详表：阴阳 / 五行 / 天干十神 / 河图生成数 ——
  const rows = pillars.map(([r,gz])=>{
    const g = gz[0], z = gz[1];
    const yinG = GAN_YIN[g]?'阳':'阴', yinZ = ZHI_YIN[z]?'阳':'阴';
    const ssG = shiShen(b.dayMaster, b.dayMasterWx, g, GAN_WX[g]);
    return `<tr><td>${r}</td><td>${gz}</td><td>${yinG}${yinZ}</td>
        <td>${wxTag(GAN_WX[g])} / ${wxTag(ZHI_WX[z])}</td>
        <td>${ssG||'—'}</td><td>${HETU[GAN_WX[g]]} / ${HETU[ZHI_WX[z]]}</td></tr>`;
  }).join('');

  const xi = (b.xiNames||[]).join('、') || '—';
  const ji = (b.jiNames||[]).join('、') || '—';
  const strength = b.strengthLabel ? `；日主强弱：<b>${b.strengthLabel}</b>` : '';
  return `
    <p class="hint">日主 <b>${b.dayMaster}</b>（${WX_NAME[b.dayMasterWx]}）${strength}。</p>
    <div class="bm-block">
      <div class="bm-sub">五行数理<span class="bm-sub-note">（各五行出现次数 · 旺衰）</span></div>
      <div class="wx-chart">${wxRows}</div>
    </div>
    <div class="bm-block">
      <div class="bm-sub">十神格局<span class="bm-sub-note">（天干与地支藏干分布）</span></div>
      <div class="ss-wrap">${ssHtml}</div>
    </div>
    <div class="bm-block">
      <div class="bm-sub">四柱纳音</div>
      <table>
        <thead><tr><th>柱</th><th>干支</th><th>纳音</th><th>宫位</th><th>简释</th></tr></thead>
        <tbody>${nayinRows}</tbody>
      </table>
    </div>
    <table>
      <thead><tr><th>柱</th><th>干支</th><th>阴阳</th><th>五行（干/支）</th><th>天干十神</th><th>河图生成数</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>
    <p class="hint" style="margin-top:14px">喜用神：<b class="good">${xi}</b>；忌神：<b class="bad">${ji}</b>。
      五行分布：木${b.wx.wood} 火${b.wx.fire} 土${b.wx.earth} 金${b.wx.metal} 水${b.wx.water}。
      河图数取天一生水…地十成之生成之数，仅作术数趣味参考。</p>`;
}
function renderBaziMath(){
  const html = window.lastBazi ? baziMathHtml(window.lastBazi)
    : '<p class="hint">请先在八字排盘中排盘。</p>';
  const out = document.getElementById('bazi-math-out');
  if (out) out.innerHTML = html;
  const inline = document.getElementById('bazi-math-inline');
  if (inline) inline.innerHTML = html;
}

function renderNameStrokes(){
  const s = document.getElementById('name-surname').value.trim();
  const g = document.getElementById('name-given').value.trim();
  if (s && g) {
    computeName();
  } else {
    // 只填了一个字段时清空结果
    document.getElementById('name-math-out').innerHTML = '';
  }
}

/* ---------- 起名：八字喜用神结合 ---------- */
const SHENGXIAO = {
  子:{wx:'water', xi:['metal','water','wood'], ji:['earth','fire'], label:'鼠'},
  丑:{wx:'earth', xi:['fire','earth','metal'], ji:['water','wood'], label:'牛'},
  寅:{wx:'wood', xi:['water','wood','fire'], ji:['metal','earth'], label:'虎'},
  卯:{wx:'wood', xi:['water','wood'], ji:['metal'], label:'兔'},
  辰:{wx:'earth', xi:['water','fire','earth','metal'], ji:['wood'], label:'龙'},
  巳:{wx:'fire', xi:['wood','fire','earth'], ji:['water','metal'], label:'蛇'},
  午:{wx:'fire', xi:['wood','fire','earth'], ji:['water','metal'], label:'马'},
  未:{wx:'earth', xi:['fire','earth','metal'], ji:['water','wood'], label:'羊'},
  申:{wx:'metal', xi:['earth','metal','water'], ji:['fire','wood'], label:'猴'},
  酉:{wx:'metal', xi:['earth','metal','water'], ji:['fire','wood'], label:'鸡'},
  戌:{wx:'earth', xi:['fire','earth','metal'], ji:['water','wood'], label:'狗'},
  亥:{wx:'water', xi:['metal','water','wood'], ji:['earth','fire'], label:'猪'}
};
let nameBirthYear = null;  // 手动输入的出生年（用于生肖）
const NAME_PINYIN = { '林':'lin','梓':'zi','桐':'tong','楠':'nan','楷':'kai','荣':'rong','杰':'jie','松':'song','柏':'bai','栋':'dong','楚':'chu','梵':'fan','梅':'mei','兰':'lan','竹':'zhu','茜':'qian','萱':'xuan','萌':'meng','艺':'yi','芙':'fu','蓉':'rong','菁':'jing','蕊':'rui','芊':'qian','筠':'yun','茉':'mo','杉':'shan','柳':'liu','枫':'feng','槐':'huai','榆':'yu','桂':'gui','梧':'wu','樟':'zhang','槟':'bin','棋':'qi','桦':'hua','槿':'jin','樾':'yue','横':'heng','朴':'pu','朵':'duo','禾':'he','秀':'xiu','秉':'bing','秋':'qiu','科':'ke','秒':'miao','稀':'xi','秦':'qin','穗':'sui','稼':'jia','颖':'ying','芳':'fang','芬':'fen','芷':'zhi','芮':'rui','芩':'qin','苓':'ling','苑':'yuan','茵':'yin','茹':'ru','莎':'sha','莲':'lian','莹':'ying','萍':'ping','蔓':'man','薇':'wei','蕾':'lei','蔚':'wei','蘅':'heng','萧':'xiao','艾':'ai','芭':'ba','芝':'zhi','芯':'xin','莞':'guan','萃':'cui','菡':'han','葳':'wei','箫':'xiao','篮':'lan','篆':'zhuan','篇':'pian','简':'jian','策':'ce','筱':'xiao','笙':'sheng','笛':'di','符':'fu','笠':'li','第':'di','等':'deng','本':'ben','末':'mo','李':'li','杨':'yang','杭':'hang','杯':'bei','枚':'mei','果':'guo','枝':'zhi','枢':'shu','析':'xi','枕':'zhen','柿':'shi','栏':'lan','树':'shu','柔':'rou','桔':'ju','栖':'qi','栗':'li','校':'xiao','株':'zhu','梁':'liang','梦':'meng','森':'sen','棠':'tang','植':'zhi','榜':'bang','榛':'zhen','棉':'mian','棕':'zong','棱':'leng','朱':'zhu','束':'shu','染':'ran','标':'biao','栈':'zhan','栎':'li','栩':'xu','桓':'huan','炎':'yan','煜':'yu','炳':'bing','焕':'huan','灿':'can','烨':'ye','昕':'xin','昭':'zhao','晗':'han','晞':'xi','晴':'qing','曦':'xi','暖':'nuan','灵':'ling','焱':'yan','炜':'wei','煊':'xuan','熠':'yi','熹':'xi','丹':'dan','丽':'li','彤':'tong','采':'cai','晶':'jing','晟':'cheng','智':'zhi','朗':'lang','旭':'xu','昀':'yun','昉':'fang','昂':'ang','昆':'kun','昌':'chang','昇':'sheng','昱':'yu','晏':'yan','晖':'hui','普':'pu','景':'jing','暄':'xuan','曙':'shu','曜':'yao','昊':'hao','旻':'min','昶':'chang','晋':'jin','晓':'xiao','映':'ying','光':'guang','辉':'hui','耀':'yao','显':'xian','晃':'huang','晨':'chen','焜':'kun','焯':'chao','炯':'jiong','烽':'feng','烛':'zhu','燊':'shen','熳':'man','灯':'deng','炉':'lu','燃':'ran','焰':'yan','烁':'shuo','夏':'xia','南':'nan','坤':'kun','垚':'yao','城':'cheng','培':'pei','基':'ji','堂':'tang','墨':'mo','宇':'yu','安':'an','宛':'wan','婉':'wan','怡':'yi','恩':'en','唯':'wei','维':'wei','圣':'sheng','坚':'jian','峰':'feng','岳':'yue','岚':'lan','岩':'yan','磊':'lei','硕':'shuo','邦':'bang','辰':'chen','延':'yan','地':'di','场':'chang','坪':'ping','坦':'tan','域':'yu','境':'jing','增':'zeng','壁':'bi','垒':'lei','垦':'ken','堃':'kun','巍':'wei','嵩':'song','峦':'luan','岑':'cen','岫':'xiu','岱':'dai','岭':'ling','峻':'jun','崇':'chong','崔':'cui','崖':'ya','岸':'an','崧':'song','石':'shi','碧':'bi','磐':'pan','研':'yan','砂':'sha','田':'tian','由':'you','甲':'jia','申':'shen','男':'nan','画':'hua','界':'jie','留':'liu','畴':'chou','疆':'jiang','益':'yi','黄':'huang','圭':'gui','均':'jun','坊':'fang','坎':'kan','坐':'zuo','垂':'chui','型':'xing','垠':'yin','钧':'jun','铭':'ming','锐':'rui','铎':'duo','锦':'jin','锡':'xi','铠':'kai','铮':'zheng','钦':'qin','钰':'yu','铃':'ling','银':'yin','锋':'feng','镇':'zhen','鑫':'xin','钊':'zhao','铄':'shuo','锴':'kai','瑞':'rui','瑜':'yu','瑾':'jin','璇':'xuan','璋':'zhang','琛':'chen','珂':'ke','瑶':'yao','钢':'gang','铁':'tie','铜':'tong','钟':'zhong','铸':'zhu','铿':'keng','锵':'qiang','锟':'kun','锷':'e','镕':'rong','镐':'gao','镒':'yi','镔':'bin','钺':'yue','钿':'dian','钻':'zuan','铅':'qian','剑':'jian','刚':'gang','利':'li','刘':'liu','列':'lie','初':'chu','删':'shan','判':'pan','剀':'kai','前':'qian','勇':'yong','成':'cheng','战':'zhan','戟':'ji','戈':'ge','戊':'wu','戌':'xu','戍':'shu','琦':'qi','琪':'qi','琳':'lin','琅':'lang','璜':'huang','璧':'bi','瓒':'zan','琨':'kun','西':'xi','兑':'dui','鉴':'jian','浩':'hao','瀚':'han','泽':'ze','泓':'hong','涵':'han','沛':'pei','沐':'mu','淳':'chun','清':'qing','润':'run','溪':'xi','源':'yuan','渊':'yuan','潇':'xiao','澜':'lan','沁':'qin','汐':'xi','淑':'shu','洁':'jie','洵':'xun','淇':'qi','漫':'man','灏':'hao','淼':'miao','滢':'ying','潼':'tong','洛':'luo','江':'jiang','河':'he','湖':'hu','海':'hai','涛':'tao','波':'bo','川':'chuan','流':'liu','泳':'yong','泛':'fan','沙':'sha','沃':'wo','汇':'hui','汉':'han','潮':'chao','池':'chi','沈':'shen','沉':'chen','震':'zhen','北':'bei','玄':'xuan','永':'yong','泉':'quan','泰':'tai','济':'ji','涉':'she','游':'you','满':'man','溢':'yi','治':'zhi','泌':'mi','法':'fa','雨':'yu','雪':'xue','云':'yun','雯':'wen','霏':'fei','霖':'lin','露':'lu','霓':'ni','霞':'xia','霁':'ji','霜':'shuang','零':'ling','霈':'pei','子':'zi','文':'wen','书':'shu','诗':'shi','语':'yu','鱼':'yu','贝':'bei','亥':'hai' };
let nameGender = 'male';   // 起名页性别（原起名页男/女按钮已并入共享时间滚轮，由 dp-gender 同步读写）
// 性别持久化：与 Birth（clawBirth）一样需要跨 App 关闭/重启保留，否则重启复位“男”
const GENDER_KEY = 'clawGender';
function saveGender(g){ try{ if (g==='male'||g==='female') localStorage.setItem(GENDER_KEY, g); }catch(e){} }
function loadGender(){ try{ const g = localStorage.getItem(GENDER_KEY); return (g==='male'||g==='female')?g:'male'; }catch(e){ return 'male'; } }
function restoreGender(){
  const g = loadGender();
  nameGender = g;
  const r = document.querySelector('input[name="gender"][value="'+g+'"]'); if (r) r.checked = true;
}

/* ---------- 三才五格分析 ---------- */
function wxRelation(aWx, bWx){
  if (!aWx || !bWx) return { type:'—', grade:'', desc:'' };
  if (aWx === bWx) return { type:'比和', grade:'吉', desc:'五行相同，相互助益' };
  if (WX_SHENG[aWx] === bWx) return { type:'相生', grade:'吉', desc:'相生相助' };
  if (WX_SHENG[bWx] === aWx) return { type:'相生', grade:'半吉', desc:'反向相生' };
  return { type:'相克', grade:'凶', desc:'相克制约' };
}
function getWx(num){
  const L = liuShu(num);
  return L.wx;
}
function sancaiDetail(tian, ren, di, cells){
  const tianWx = getWx(tian);
  const renWx = getWx(ren);
  const diWx = getWx(di);
  const t2r = wxRelation(tianWx, renWx);
  const r2d = wxRelation(renWx, diWx);
  const scoreMap = { '吉':2, '半吉':1, '凶':0 };
  const sum = (scoreMap[t2r.grade]||0) + (scoreMap[r2d.grade]||0);
  let summary, suggestion;
  if (sum >= 3) {
    summary = '三才配置优良，五行流通有情，整体趋向通达。';
    suggestion = '此姓名配置相生相助，天地人三才和谐，可充分扬其所长。';
  } else if (sum === 2) {
    summary = '三才配置尚可，五行配合度较好，个别方面需注意搭配。';
    suggestion = '可考虑在姓名使用中注意补齐被克之五行。';
  } else {
    summary = '三才配置欠佳，五行有克无生，建议斟酌搭配。';
    suggestion = '建议调整姓名用字，使天格→人格→地格五行相生流通。';
  }
  const totalCell = cells ? cells.find(c=>c.name==='总格') : null;
  const jxScore = { '吉':85, '半吉':65, '凶':40 };
  let scores = cells ? cells.map(c => jxScore[c.jx] || 50) : [60];
  if (totalCell) {
    const ti = cells.findIndex(c => c.name==='总格');
    if (ti >= 0) scores[ti] = (scores[ti] || 50) * 1.2;
  }
  const overallScore = Math.round(scores.reduce((a,b)=>a+b,0) / scores.length);
  const goodCount = cells ? cells.filter(c=>c.jx==='吉').length : 0;
  const badCount = cells ? cells.filter(c=>c.jx==='凶').length : 0;
  return {
    tianWx: WX_NAME[tianWx]||'',
    renWx: WX_NAME[renWx]||'',
    diWx: WX_NAME[diWx]||'',
    t2r, r2d,
    summary, suggestion,
    overallScore,
    stable: goodCount >= 3 && badCount === 0
  };
}

/* 评估一个具体名字：五格三才 + 八字补益，返回结构化结果（不渲染） */
function evaluateName(surname, given, compound, bazi){
  const chars = (surname + given).split('');
  const strokes = chars.map(c => STROKE[c]);
  if (strokes.some(s => !s)) return null;
  const s1 = strokes[0];
  const s2 = chars.length>1 && surname.length>1 ? strokes[1] : 0;
  const g1 = strokes[surname.length];
  const g2 = chars.length > surname.length+1 ? strokes[surname.length+1] : 0;
  const isCompound = (surname.length>=2) && compound;
  let tian, ren, di, wai, zong;
  if (isCompound){ tian=s1+s2; ren=s2+g1; di=g2?g1+g2:g1+1; zong=s1+s2+g1+(g2||0); wai=s1+(g2||1); }
  else { tian=s1+1; ren=s1+g1; di=g2?g1+g2:g1+1; zong=s1+g1+(g2||0); wai=g2?(g2+1):2; }
  const jxClass = j => j==='吉'?'good':(j==='凶'?'bad':'mid');
  const cells = [['天格',tian],['人格',ren],['地格',di],['外格',wai],['总格',zong]].map(([name,num])=>{
    const L = liuShu(num);
    return { name, num, wx:L.wx, wxName:WX_NAME[L.wx], jx:L.jx, jxClass:jxClass(L.jx), desc:L.desc };
  });
  const sancai = sancaiDetail(tian, ren, di, cells);
  let baziInfo = null;
  if (bazi){
    const xiKeys = [...new Set((bazi.xiNames||[]).map(n=>WX_KEY[n]).filter(Boolean))];
    const jiKeys = [...new Set((bazi.jiNames||[]).map(n=>WX_KEY[n]).filter(Boolean))];
    const nameWx = strokes.map(s=> liuShu(s).wx);
    const hitXi = xiKeys.filter(k=> nameWx.includes(k));
    const hitJi = jiKeys.filter(k=> nameWx.includes(k));
    if (hitJi.length>0) sancai.overallScore = Math.max(30, sancai.overallScore - 15);
    else if (hitXi.length>0) sancai.overallScore = Math.min(96, sancai.overallScore + 10);
    let verdict;
    if (hitJi.length>0) verdict = {cls:'bad', text:`含忌神（${hitJi.map(k=>WX_NAME[k]).join('、')}），与八字相损`};
    else if (hitXi.length>0) verdict = {cls:'good', text:`含喜用神（${hitXi.map(k=>WX_NAME[k]).join('、')}），可补益命局`};
    else verdict = {cls:'mid', text:`未直接补益喜用神（喜：${xiKeys.map(k=>WX_NAME[k]).join('、')}）`};
    baziInfo = { xiKeys, jiKeys, hitXi, hitJi, verdict };
  }
  return { chars, surname, given, compound:isCompound, strokes, ge:{tian,ren,di,wai,zong}, cells, sancai, bazi:baziInfo, score:sancai.overallScore };
}

/* 候选名字精炼：去同字、去反转重复、拗口(声母相同)、谐音忌讳 */
const SM_LIST = ['zh','ch','sh','b','p','m','f','d','t','n','l','g','k','h','j','q','x','z','c','s','r'];
function smOf(ch){ const py = NAME_PINYIN[ch] || ''; for (const s of SM_LIST){ if (py.indexOf(s) === 0) return s; } return ''; }
// 谐音忌讳（仅收录明显粗鄙、且全名拼音易撞的给定组合；精确匹配全名拼音，避免误伤正常名）
const BAD_HOMO = ['jiba','biaozi','shabi','wangba','chunhuo','guyong','shaizi','fenpi','roupi','nangua'];
function polishNames(list, surname){
  const seen = new Set();      // 已保留的“名字”串（用于反转去重）
  const out = [];
  for (const r of list){
    const given = r.given || '';
    // 1. 名字二字相同（如 杰杰）→ 剔除
    if (given.length >= 2 && given[0] === given[1]) continue;
    // 2. 名字含与姓氏末字相同（单姓时避免“邓邓”式）→ 剔除
    if (surname && surname.length === 1 && given.indexOf(surname[0]) >= 0) continue;
    // 3. 反转去重：杰光 / 光杰 只留先入（评分更高）的一条
    const rev = given.split('').reverse().join('');
    if (rev !== given && seen.has(rev) && !seen.has(given)) continue;
    // 4. 拗口筛查：两名字声母相同（如 林岚 lin·lan 皆 l）或 姓末字与名首字声母相同（如 邓丹 deng·dan 皆 d）
    if (given.length >= 2){
      const sm1 = smOf(given[0]), sm2 = smOf(given[1]);
      if (sm1 && sm1 === sm2) continue;
      const sLast = surname ? surname[surname.length - 1] : '';
      const ss = smOf(sLast);
      if (ss && ss === sm1) continue;
    }
    // 5. 谐音忌讳（全名拼音精确匹配）
    const fullPy = (surname + given).split('').map(c => NAME_PINYIN[c] || '').join('');
    if (BAD_HOMO.some(h => h === fullPy)) continue;
    seen.add(given);
    out.push(r);
  }
  return out;
}

/* 批量生成候选名字 */
function generateNames(surname, gender, bazi, wordCount){
  if (!surname) return [];
  const compound = surname.length>=2;
  const gk = (gender==='male'||gender==='m') ? 'm' : (gender==='female'||gender==='f') ? 'f' : gender;
  let pool = NAME_WORDS.filter(w => w.g===gk || w.g==='u');
  if (!pool.length) pool = NAME_WORDS.slice();
  const xiKeys = (bazi && bazi.xiNames) ? [...new Set((bazi.xiNames||[]).map(n=>WX_KEY[n]).filter(Boolean))] : [];
  const ranked = pool.slice().sort((a,b)=> b.lv - a.lv);
  const top = ranked.slice(0, Math.min(50, ranked.length));
  let results = [];
  if (wordCount === 1){
    top.forEach(w => { const r = evaluateName(surname, w.c, compound, bazi); if (r) results.push(r); });
  } else {
    for (let i=0;i<top.length;i++){
      for (let j=0;j<top.length;j++){
        if (i===j) continue;
        const r = evaluateName(surname, top[i].c+top[j].c, compound, bazi);
        if (r) results.push(r);
      }
    }
  }
  results.forEach(r=>{
    r.lvTotal = r.chars.reduce((s,c)=>{ const wd = NAME_WORDS.find(x=>x.c===c); return s + (wd?wd.lv:0); }, 0);
    if (xiKeys.length && r.bazi && r.bazi.hitXi.length===0 && r.bazi.hitJi.length===0) r.score = Math.max(20, r.score - 8);
  });
  // 精炼：先按评分降序，使“反转去重”保留高分者；再剔除同字/拗口/谐音等不佳组合
  results.sort((a,b)=> b.score - a.score);
  results = polishNames(results, surname);
  // 排序：先按综合评分，再用“喜忌命中”作为显式次级键——命中喜用神加分靠前、命中忌神减分靠后。
  // 这样八字（喜忌）一变，候选顺序会明显不同（常理：补益命局的字应排在前面）。
  results.sort((a,b)=>{
    const aw = a.bazi ? (a.bazi.hitXi.length*3 - a.bazi.hitJi.length*4) : 0;
    const bw = b.bazi ? (b.bazi.hitXi.length*3 - b.bazi.hitJi.length*4) : 0;
    return (b.score - a.score) || (bw - aw) || (b.lvTotal - a.lvTotal);
  });
  return results.slice(0, wordCount===1 ? 20 : 24);
}

/* 渲染候选列表 */
function renderCandidates(list){
  const box = document.getElementById('name-candidates');
  if (!box) return;
  if (!list || !list.length){ box.innerHTML = '<p class="hint">暂未生成候选名字。请先在上方填写姓氏（建议同时填出生信息或载入八字页命盘以按喜用神补益），再点生成候选名字。</p>'; return; }
  const cards = list.map(r=>{
    const nameStr = r.chars.join('');
    const strokeTags = r.chars.map((c,i)=>`${c}<small class="ns-stroke">${r.strokes[i]}</small>`).join(' ');
    const geCells = r.cells.map(c=>`<span class="nc-mini ${c.jxClass}">${c.name}${c.num}<i>${c.jx}</i></span>`).join('');
    const wxChips = r.chars.map((c,i)=>{ const w=liuShu(r.strokes[i]).wx; return `<span class="bx-chip wx-${w}">${WX_NAME[w]}</span>`; }).join('');
    const mean = r.chars.map(c=>{ const wd=NAME_WORDS.find(x=>x.c===c); return wd?wd.m:''; }).filter(Boolean).join('；');
    const bx = r.bazi ? `<div class="bx-verdict ${r.bazi.verdict.cls}">${r.bazi.verdict.text}</div>` : '';
    return `<div class="cand-card" data-surname="${r.surname}" data-given="${r.given}">
      <div class="cand-head"><span class="cand-name">${nameStr}</span><span class="cand-score ${r.score>=70?'good':'mid'}">${r.score}<small>分</small></span></div>
      <div class="cand-strokes">${strokeTags}</div>
      <div class="cand-ge">${geCells}</div>
      <div class="cand-wx">五行 ${wxChips}</div>
      ${bx}
      <div class="cand-sancai">三才：${r.sancai.summary}</div>
      <div class="cand-mean">寓意：${mean}</div>
    </div>`;
  }).join('');
  box.innerHTML = cards;   // 直接平铺候选卡（二层结构：候选区 > 候选卡），不再套外层 cand-list
  // 点击候选卡 → 载入到上方「姓名分析」框，展示完整五格三才 / 八字补益 / 生肖宜忌
  box.querySelectorAll('.cand-card').forEach(el => {
    el.addEventListener('click', () => {
      // 候选卡自成一体（已含分数/五格/三才/寓意），点选仅高亮标记「已选」。
      // 不再写入上方「起名信息」输入框——那里是为「已有名字」服务、供「综合评分」解析，
      // 两块功能彻底解耦、互不干扰（候选生成属独立工具）。
      box.querySelectorAll('.cand-card').forEach(x => x.classList.remove('sel'));
      el.classList.add('sel');
    });
  });
}

/* 触发智能起名 */
function doGenerate(){
  const surname = (document.getElementById('name-surname').value || '').trim();
  if (!surname){ const box=document.getElementById('name-candidates'); if(box) box.innerHTML='<p class="form-warn"><svg class="fw-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2.6 L22.6 21 H1.4 Z" fill="#e23b3b"/><rect x="11" y="8.4" width="2" height="6.6" rx="1" fill="#fff"/><circle cx="12" cy="18" r="1.35" fill="#fff"/></svg>请先在上方填写姓氏</p>'; return; }
  // 强制从时间滚轮读取当前性别（确保姓名页滚轮内切换的性别对候选生效，避免“性别不起作用”）
  const sheetG = document.querySelector('input[name="dp-gender"]:checked');
  if (sheetG){ nameGender = sheetG.value; saveGender(sheetG.value); }
  const gender = nameGender || 'male';
  const wcEl = document.querySelector('input[name="name-count"]:checked');
  const wordCount = wcEl ? (wcEl.value === '1' ? 1 : 2) : 2;
  // 是否结合八字喜用：勾选才传命盘，取消则纯按五格三才+寓意起名，
  // 这样“结合八字喜用”勾选/取消会明显改变候选顺序与补益结论，开关才有意义。
  const useBazi = document.getElementById('name-use-bazi').checked;
  let bazi = null;
  if (useBazi){
    const b = Birth.get();   // 统一出生时间数据源
    const hasBirth = b && b.y>=1900 && b.m>=1 && b.d>=1;
    // 起名页已填出生时间 → 按当前性别重排命盘（性别对候选字库/补益生效）；
    // 未填出生时间时，才回落引用八字页已排命盘（避免覆盖用户在八字页选定的盘）。
    if (!hasBirth && window.lastBazi){ bazi = window.lastBazi; }
    else if (hasBirth){
      const by = b.y, bm = b.m, bd = b.d;
      const bh = (typeof b.hour === 'number') ? b.hour : shichenToHM(b.shichen || 6)[0];
      const bm2 = (typeof b.minute === 'number') ? b.minute : 0;
      const r = computeBazi(by,bm,bd,bh,bm2,gender,{calType:'solar'});
      if (r && !r.error){ bazi = r; nameBirthYear = by; }
    }
  }
  renderCandidates(generateNames(surname, gender, bazi, wordCount));
}

const _arrowClassGlobal = g => g==='吉'?'good':(g==='凶'?'bad':'mid');

function computeName(restoreIdx){
  const s = document.getElementById('name-surname').value.trim();
  const g = document.getElementById('name-given').value.trim();
  const compound = s.length >= 2;  // 复姓以“姓氏长度≥2”统一判定（与 generateNames 一致，不再依赖复姓勾选框）
  const sOverride = readStrokeOverride();
  const chars = (s + g).split('');
  if (chars.length === 0){ document.getElementById('name-math-out').innerHTML=''; return; }
  // 只有姓氏、还没有名字（如新生儿）：五格三才需名字才能算，缺失名字笔画会得到 NaN 并崩溃，给出温和提示后返回
  if (!g){ document.getElementById('name-math-out').innerHTML = '<p class="hint">输入名字后可查看五格三才分析；新生儿只有姓氏时，可直接点下方「生成候选名字」按性别取名。</p>'; return; }
  // 从康熙字典自动取笔画（允许笔画微调覆盖）
  let strokes = chars.map(c => STROKE[c]);
  if (sOverride && sOverride.length === chars.length) strokes = strokes.map((v,i)=> sOverride[i] > 0 ? sOverride[i] : v);
  const unknown = chars.filter((c,i) => !strokes[i]);
  if (unknown.length > 0){
    document.getElementById('name-math-out').innerHTML = `<p class="hint">以下字不在笔画字典中：${unknown.join('、')}，请检查输入。</p>`;
    return;
  }
  const s1 = strokes[0];
  const s2 = chars.length>1 && s.length>1 ? strokes[1] : 0;
  const g1 = strokes[s.length];
  const g2 = chars.length > s.length+1 ? strokes[s.length+1] : 0;
  const isCompound = (s.length>=2) && compound;

  let tian, ren, di, zong, wai;
  if (isCompound){
    tian = s1 + s2; ren = s2 + g1;
    di = g2 ? g1+g2 : g1+1; zong = s1 + s2 + g1 + (g2||0); wai = s1 + (g2||1);
  } else {
    tian = s1 + 1; ren = s1 + g1;
    di = g2 ? g1+g2 : g1+1; zong = s1 + g1 + (g2||0); wai = g2 ? (g2+1) : 2;
  }

  const jxClass = j => j==='吉'?'good':(j==='凶'?'bad':'mid');
  const WX_SYMBOL = {wood:'木',fire:'火',earth:'土',metal:'金',water:'水'};
  const GE_YI = {
    '天格':'祖先根基·家风渊源，主先天格局与长辈缘分',
    '人格':'姓名核心，主一生主运、性格与事业中枢',
    '地格':'前运青年运，主少年至中年根基与家庭',
    '外格':'副运·社交人际，主外界助力与人际缘分',
    '总格':'后运一生总纲，主中晚年的综合成就'
  };
  const cells = [['天格',tian],['人格',ren],['地格',di],['外格',wai],['总格',zong]].map(([name,num])=>{
    const L = liuShu(num);
    return { name, num, wx:L.wx, wxName:WX_NAME[L.wx], jx:L.jx, jxClass:jxClass(L.jx), desc:L.desc, yi:GE_YI[name] };
  });

  const sancai = sancaiDetail(tian, ren, di, cells);

  // ===== 八字喜用神结合分析 =====
  const useBazi = document.getElementById('name-use-bazi').checked;
  let bazi = null, baziErr = '';
  if (useBazi){
    // 优先引用八字页已算好的命盘（与数理页同范式：直接引用，不依赖手动点载入）；其次用统一出生时间所算
    if (window.lastBazi) { bazi = window.lastBazi; }
    else {
      const b = Birth.get();
      let by, bm, bd, bh, bmi;
      if (b && b.y>=1900 && b.m>=1 && b.d>=1){
        by = b.y; bm = b.m; bd = b.d;
        bh = (typeof b.hour === 'number') ? b.hour : shichenToHM(b.shichen != null ? b.shichen : 6)[0];
        bmi = (typeof b.minute === 'number') ? b.minute : 0;
      }
      const bg = nameGender || 'male';
      if (by>=1900 && bm>=1 && bd>=1){
        nameBirthYear = by;
        const r = computeBazi(by, bm, bd, bh, bmi, bg, { calType:'solar' });
        if (r && r.error) baziErr = r.error; else bazi = r;
      }
    }
  }
  const baziHtml = buildNameBaziHtml(bazi, baziErr, strokes, sancai);

  // 五格卡片
  const cardsHtml = cells.map(c => `
    <div class="nc-card ${c.jxClass}">
      <div class="ncc-title">${c.name}</div>
      <div class="ncc-num">${c.num}</div>
      <div class="ncc-wx wx-${c.wx}">${c.wxName}</div>
      <div class="ncc-jx ${c.jxClass}">${c.jx}</div>
      <div class="ncc-desc">${c.desc}</div>
    </div>
  `).join('');
  // 五格释义
  const yiHtml = cells.map(c => `<span class="ge-yi"><b>${c.name}</b>：${c.yi}</span>`).join('');

  // 三才流（标注成功运 / 基础运）
  const arrowClass = _arrowClassGlobal;
  const scHtml = `
    <div class="sc-node">天<span class="sc-wx">${sancai.tianWx}</span></div>
    <div class="sc-arrow ${arrowClass(sancai.t2r.grade)}">${sancai.t2r.type}</div>
    <div class="sc-label">成功运</div>
    <div class="sc-node">人<span class="sc-wx">${sancai.renWx}</span></div>
    <div class="sc-arrow ${arrowClass(sancai.r2d.grade)}">${sancai.r2d.type}</div>
    <div class="sc-label">基础运</div>
    <div class="sc-node">地<span class="sc-wx">${sancai.diWx}</span></div>
  `;

  document.getElementById('name-math-out').innerHTML = `
    <div class="nr-result">
      <div class="nr-header">
        <span class="nr-title">${chars.map((c,i)=> c+'<input class="ns-stroke-edit" data-idx="'+i+'" type="number" min="1" max="60" value="'+strokes[i]+'" aria-label="'+c+'的笔画数" />').join(' ')}${isCompound?'（复姓）':''}</span>
        <span class="nr-score ${sancai.overallScore>=70?'good':'mid'}" id="nr-score">综合评分 <b>${sancai.overallScore}</b></span>
      </div>
      <div class="nr-cards" id="nr-cards">${cardsHtml}</div>
      <div class="nr-geyi" id="nr-geyi">${yiHtml}</div>
      <div class="nr-sancai" id="nr-sancai">
        <div class="ns-title">三才配置（天→人→地）</div>
        <div class="sc-flow">${scHtml}</div>
        <p class="sc-summary">${sancai.summary}</p>
        <p class="sc-suggest">💡 ${sancai.suggestion}</p>
      </div>
      ${baziHtml ? `<div class="num-bazi-fit" id="nr-bazi-fit">${baziHtml}</div>` : ''}
    </div>`;
  // 笔画微调：标题内数字可编辑，输入实时重算依赖项（评分/三才/八字契合），但【不重建标题输入框】，保留焦点
  const edits = document.querySelectorAll('#name-math-out .ns-stroke-edit');
  edits.forEach(inp => {
    inp.addEventListener('input', () => { updateNameMetrics(+inp.dataset.idx, inp); });
  });
  if (restoreIdx != null && edits[restoreIdx]){
    const el = edits[restoreIdx];
    try { el.focus(); el.setSelectionRange(el.value.length, el.value.length); } catch(e){}
  }
}

// 笔画微调输入时局部更新：只重算并重绘依赖笔画的区块（评分/三才/八字契合），
// 不触碰 nr-title 内的输入DOM，避免每次按键重建输入框导致焦点丢失、改不动。
function updateNameMetrics(restoreIdx, activeEl){
  const s = document.getElementById('name-surname').value.trim();
  const g = document.getElementById('name-given').value.trim();
  const compound = s.length >= 2;
  const chars = (s + g).split('');
  if (chars.length === 0 || !g) return;
  const override = Array.from(document.querySelectorAll('#name-math-out .ns-stroke-edit')).map(i => parseInt(i.value, 10));
  if (override.some(v => isNaN(v))) return; // 输入中途为空/非法，暂不重算
  let strokes = chars.map(c => STROKE[c]);
  if (override.length === chars.length) strokes = strokes.map((v,i)=> override[i] > 0 ? override[i] : v);
  const s1 = strokes[0];
  const s2 = chars.length>1 && s.length>1 ? strokes[1] : 0;
  const g1 = strokes[s.length];
  const g2 = chars.length > s.length+1 ? strokes[s.length+1] : 0;
  const isCompound = (s.length>=2) && compound;
  let tian, ren, di, zong, wai;
  if (isCompound){ tian = s1+s2; ren = s2+g1; di = g2?g1+g2:g1+1; zong = s1+s2+g1+(g2||0); wai = s1+(g2||1); }
  else { tian = s1+1; ren = s1+g1; di = g2?g1+g2:g1+1; zong = s1+g1+(g2||0); wai = g2?(g2+1):2; }
  const cells = [['天格',tian],['人格',ren],['地格',di],['外格',wai],['总格',zong]].map(([name,num])=>{
    const L = liuShu(num);
    return { name, num, wx:L.wx, wxName:WX_NAME[L.wx], jx:L.jx, jxClass:(j=>j==='吉'?'good':(j==='凶'?'bad':'mid'))(L.jx), desc:L.desc, yi:{'天格':'祖先根基·家风渊源，主先天格局与长辈缘分','人格':'姓名核心，主一生主运、性格与事业中枢','地格':'前运青年运，主少年至中年根基与家庭','外格':'副运·社交人际，主外界助力与人际缘分','总格':'后运一生总纲，主中晚年的综合成就'}[name] };
  });
  const sancai = sancaiDetail(tian, ren, di, cells);
  // 五格卡片随笔画实时重算（修复：此前仅首渲写入，微调后数字/五行/吉凶不更新）
  const cardsHtml = cells.map(c => `
    <div class="nc-card ${c.jxClass}">
      <div class="ncc-title">${c.name}</div>
      <div class="ncc-num">${c.num}</div>
      <div class="ncc-wx wx-${c.wx}">${c.wxName}</div>
      <div class="ncc-jx ${c.jxClass}">${c.jx}</div>
      <div class="ncc-desc">${c.desc}</div>
    </div>
  `).join('');
  const cardsEl = document.getElementById('nr-cards');
  if (cardsEl) cardsEl.innerHTML = cardsHtml;
  // 五格释义（仅依赖格名，不随笔画数值变；一并刷新以防万一）
  const yiHtml = cells.map(c => `<span class="ge-yi"><b>${c.name}</b>：${c.yi}</span>`).join('');
  const geyiEl = document.getElementById('nr-geyi');
  if (geyiEl) geyiEl.innerHTML = yiHtml;
  const scoreEl = document.getElementById('nr-score');
  if (scoreEl) scoreEl.outerHTML = `<span class="nr-score ${sancai.overallScore>=70?'good':'mid'}" id="nr-score">综合评分 <b>${sancai.overallScore}</b></span>`;
  const scHtml = `
    <div class="sc-node">天<span class="sc-wx">${sancai.tianWx}</span></div>
    <div class="sc-arrow ${_arrowClassGlobal(sancai.t2r.grade)}">${sancai.t2r.type}</div>
    <div class="sc-label">成功运</div>
    <div class="sc-node">人<span class="sc-wx">${sancai.renWx}</span></div>
    <div class="sc-arrow ${_arrowClassGlobal(sancai.r2d.grade)}">${sancai.r2d.type}</div>
    <div class="sc-label">基础运</div>
    <div class="sc-node">地<span class="sc-wx">${sancai.diWx}</span></div>`;
  const sanEl = document.getElementById('nr-sancai');
  if (sanEl) sanEl.innerHTML = `<div class="ns-title">三才配置（天→人→地）</div><div class="sc-flow">${scHtml}</div><p class="sc-summary">${sancai.summary}</p><p class="sc-suggest">💡 ${sancai.suggestion}</p>`;
  // 八字契合度区块（若存在）随笔画变化重算
  const fit = document.getElementById('nr-bazi-fit');
  if (fit){
    const useBazi = document.getElementById('name-use-bazi').checked;
    if (useBazi){
      let bazi = null, baziErr = '';
      if (window.lastBazi) bazi = window.lastBazi;
      else {
        const b = Birth.get();
        let by, bm, bd, bh, bmi;
        if (b && b.y>=1900 && b.m>=1 && b.d>=1){
          by=b.y; bm=b.m; bd=b.d;
          bh=(typeof b.hour==='number')?b.hour:shichenToHM(b.shichen!=null?b.shichen:6)[0];
          bmi=(typeof b.minute==='number')?b.minute:0;
        }
        const bg = nameGender||'male';
        if (by>=1900 && bm>=1 && bd>=1){
          const r = computeBazi(by,bm,bd,bh,bmi,bg,{calType:'solar'});
          if (r&&r.error) baziErr=r.error; else bazi=r;
        }
      }
      const bh2 = buildNameBaziHtml(bazi, baziErr, strokes, sancai);
      fit.outerHTML = `<div class="num-bazi-fit" id="nr-bazi-fit">${bh2}</div>`;
    }
  }
  if (activeEl && document.activeElement !== activeEl){
    try { activeEl.focus(); activeEl.setSelectionRange(activeEl.value.length, activeEl.value.length); } catch(e){}
  }
}

// 起名页「结合八字喜用」区块渲染（首渲与局部更新共用）。会按名字五行与八字喜忌调整综合评分。
function buildNameBaziHtml(bazi, baziErr, strokes, sancai){
  if (baziErr) return `<div class="nr-bazi"><div class="nb-err">⚠ 八字排盘：${baziErr}</div></div>`;
  if (!bazi) return '';
  const xiKeys = [...new Set((bazi.xiNames||[]).map(n=>WX_KEY[n]).filter(Boolean))];
  const jiKeys = [...new Set((bazi.jiNames||[]).map(n=>WX_KEY[n]).filter(Boolean))];
  const nameWx = strokes.map(s=> liuShu(s).wx);
  const hitXi = xiKeys.filter(k=> nameWx.includes(k));
  const hitJi = jiKeys.filter(k=> nameWx.includes(k));
  if (hitJi.length>0) sancai.overallScore = Math.max(30, sancai.overallScore - 15);
  else if (hitXi.length>0) sancai.overallScore = Math.min(96, sancai.overallScore + 10);
  const xiChips = xiKeys.map(k=>`<span class="bx-chip wx-${k}">${WX_NAME[k]}</span>`).join('');
  const jiChips = jiKeys.map(k=>`<span class="bx-chip bx-ji wx-${k}">${WX_NAME[k]}</span>`).join('');
  let bxVerdict;
  if (hitJi.length>0) bxVerdict = `<div class="bx-verdict bad">⚠ 名字五行含<b>忌神（${hitJi.map(k=>WX_NAME[k]).join('、')}）</b>，与八字相损，建议替换为喜用神之字。</div>`;
  else if (hitXi.length>0) bxVerdict = `<div class="bx-verdict good">✓ 名字五行含<b>喜用神（${hitXi.map(k=>WX_NAME[k]).join('、')}）</b>，可补益八字、助旺命局。</div>`;
  else bxVerdict = `<div class="bx-verdict mid">○ 名字五行未直接补益喜用神（喜：${xiKeys.map(k=>WX_NAME[k]).join('、')}），可改用含该五行之字增强。</div>`;
  let sxHtml = '';
  if (nameBirthYear && !isNaN(nameBirthYear)){
    const ZHIS = ['子','丑','寅','卯','辰','巳','午','未','申','酉','戌','亥'];
    const branch = ZHIS[((nameBirthYear-4)%12+12)%12];
    const sx = SHENGXIAO[branch];
    if (sx){
      const sxXi = sx.xi.map(k=>`<span class="bx-chip wx-${k}">${WX_NAME[k]}</span>`).join('');
      const sxJi = sx.ji.map(k=>`<span class="bx-chip bx-ji wx-${k}">${WX_NAME[k]}</span>`).join('');
      sxHtml = `<div class="bx-sx"><span class="bx-sx-label">生肖${sx.label}喜忌</span> 喜用 ${sxXi} ｜ 宜避 ${sxJi}</div>`;
    }
  }
  const srcNote = window.lastBazi ? '（数据来自八字页已排命盘）' : '（依所填公历出生时间排盘）';
  return `<div class="nr-bazi">
      <div class="nb-title">八字喜用神 · 起名补益${srcNote}</div>
      <div class="bx-line">日主 <b>${bazi.dayMaster}</b>（${WX_NAME[bazi.dayMasterWx]}）｜强弱 <b>${bazi.strengthLabel||'—'}</b></div>
      <div class="bx-row"><span class="bx-k">喜用神</span> ${xiChips}</div>
      <div class="bx-row"><span class="bx-k">忌神</span> ${jiChips}</div>
      ${bxVerdict}
      ${sxHtml}
    </div>`;
}
function readStrokeOverride(){
  // 笔画微调已移入三才五格结果卡标题（“邓19 志7 勤13”中的数字），按字序读取
  const w = document.querySelector('#name-math-out .ns-stroke-edit');
  if (!w) return null;
  return Array.from(document.querySelectorAll('#name-math-out .ns-stroke-edit')).map(i => parseInt(i.value, 10));
}

function initNameBirth(){
  const birthBtn = document.getElementById('name-birth-btn');
  if (birthBtn) birthBtn.addEventListener('click', ()=>dwOpen({ calType:'solar' }));
  const ub = document.getElementById('name-use-bazi');
  if (ub){
    const onToggle = () => {
      syncNameBirthLabel(true);
      computeName();
      // 勾选/取消结合八字喜用：若已生成候选名字，实时按新喜忌重算候选列表（否则切了开关名字不变）
      const nbox = document.getElementById('name-candidates');
      if (nbox && nbox.querySelector('.cand-card')){ try { doGenerate(); } catch(e){} }
    };
    ub.addEventListener('input', onToggle);
    ub.addEventListener('change', onToggle);
  }
  const genBtn = document.getElementById('name-generate');
  if (genBtn) genBtn.addEventListener('click', doGenerate);
  // 单字名/双字名 单选切换：若已生成候选，实时按新字数重算候选列表
  document.querySelectorAll('input[name="name-count"]').forEach(r=> r.addEventListener('change', ()=>{
    const nbox = document.getElementById('name-candidates');
    if (nbox && nbox.querySelector('.cand-card')){ try { doGenerate(); } catch(e){} }
  }));
}

/* ===================================================================
 * 常见数字数理（身份证 / 车牌 / 手机 / 门牌）
 * 数字五行：1,2 木；3,4 火；5,6 土；7,8 金；9,0 水
 * =================================================================== */

/* ---------- 八星数字能量学（手机 / 车牌选号主流体系） ---------- */
function renderNumberMath(){
  const out = document.getElementById('number-math-out');
  if (!out) return;
  const valEl = document.getElementById('num-value');
  const raw = valEl ? valEl.value.trim() : '';
  if (!raw){
    out.innerHTML = '';
    return;
  }
  const r = analyzeNumber(raw);
  if (!r){ out.innerHTML = '<p class="hint">未识别到数字，请检查输入。</p>'; return; }
  const cards = r.cells.map(c => `
    <div class="nc-card ${c.jxClass}">
      <div class="ncc-title">${c.name}</div>
      <div class="ncc-num">${c.num}</div>
      <div class="ncc-wx wx-${c.wx}">${c.wxName}</div>
      <div class="ncc-jx ${c.jxClass}">${c.jx}</div>
      <div class="ncc-desc">${c.desc}</div>
    </div>`).join('');

  // 八星数字能量
  const bx = r.baxing;
  const starCards = Object.keys(BAXING).map(star=>{
    const info = BAXING[star];
    const n = bx.cnt[star];
    const items = bx.groups.filter(g=>g.star===star).map(g=>`<span class="bx-pair">${g.pair}<small>第${g.pos}位</small></span>`).join('');
    const detailHtml = n > 0 ? `<ul class="bx-detail">${info.detail.map(d=>`<li>${d}</li>`).join('')}</ul>` : '';
    return `<div class="bx-cell ${info.cls}">
        <div class="bx-name">${star}<i class="bx-n">${n}</i></div>
        <div class="bx-yi">${info.yi}</div>
        ${detailHtml}
        <div class="bx-pairs">${items || '<span class="bx-none">—</span>'}</div>
      </div>`;
  }).join('');
  // 相邻组合明细：号码从头到尾每个相邻两位组合，标注星性与吉凶（含无星性组合）
  const _digits = toDigits(raw).split('').map(Number);
  const pairChain = _digits.length > 1 ? _digits.slice(0, -1).map((d, i) => {
    const pair = '' + d + _digits[i+1];
    const star = PAIR_BAXING[pair];
    const pcls = !star ? 'none' : (BAXING[star].cls === 'bx-good' ? 'good' : BAXING[star].cls === 'bx-bad' ? 'bad' : 'mid');
    const label = star || '无星';
    return `<span class="pc-item ${pcls}"><b>${pair}</b><i>${label}</i><small>第${i+1}位</small></span>`;
  }).join('') : '';

  const scoreCard = `<div class="num-score ${r.levelKey}">
      <div class="ns-score">${r.score}<span>分</span></div>
      <div class="ns-stars">${'★'.repeat(r.stars)}${'☆'.repeat(5 - r.stars)}</div>
      <div class="ns-level">${r.level}</div>
    </div>`;
  const numUseBazi = (() => { try { return localStorage.getItem('numUseBazi') === '1'; } catch (e) { return false; } })();
  const baziFitCard = (numUseBazi && r.baziFit) ? `<div class="num-section num-bazi-fit ${r.baziFit.cls}">
      <span class="ns-label">与你的八字契合度</span> <b class="nbf-fit">${r.baziFit.fit}%</b>
      <p class="nbf-verdict">${r.baziFit.verdict}</p>
      <div class="nbf-chips">喜用神 ${r.baziFit.xiNames.join('、')} ｜ 忌神 ${r.baziFit.jiNames.join('、')}</div>
    </div>` : '';
  const wxCommentText = (r.wxComment || '').replace(/^五行/, '');
  out.innerHTML = `<div class="num-result">
    ${scoreCard}
    <div class="num-section num-81"><span class="ns-label">八十一数理</span></div>
    <div class="nr-cards">${cards}</div>
    ${baziFitCard}
    <div class="num-section num-baxing">
      <span class="ns-label">八星数字能量</span>
      ${r.magnet ? `<div class="bx-magnet">号码磁场倾向：以<b>${r.magnet.star}</b>为主——${r.magnet.text}。</div>` : ''}
      ${pairChain ? `<div class="pair-chain"><span class="pc-cap">相邻组合</span>${pairChain}</div>` : ''}
      <div class="bx-grid">${starCards}</div>
    </div>
    <div class="num-section num-basic">
      <div class="ns-block">
        <div class="num-digits-label">数字五行分布：<small>共 ${r.count} 位</small></div>
        <div class="num-chips">${r.digitChips}</div>
        <div class="num-wx-chart wx-chart">${r.wxRows}</div>
      </div>
      <div class="ns-block"><span class="ns-label">五行</span> ${wxCommentText}</div>
    </div>
    <div class="num-overall-card">
      <div class="num-overall">${r.overall}</div>
      ${r.suggestion ? `<div class="num-suggestion">💡 改善建议：${r.suggestion}</div>` : ''}
    </div>
  </div>`;
}

/* ---------- 选号生成器（按八字喜用神 / 八星吉星 / 八十一数理生成吉祥号码） ---------- */
function genLuckyNumbers(len, count, mobile){
  len = len || 11; count = count || 8;
  mobile = mobile !== false;  // 默认手机号模式（首位1、第二位限定）；custom 模式首位1-9任意、长度由调用方指定
  let numUseBazi = false;
  try { numUseBazi = localStorage.getItem('numUseBazi') === '1'; } catch (e) {}
  const lb = window.lastBazi;
  let xiKeys = [], jiKeys = [];
  if (numUseBazi && lb && lb.xiNames && lb.xiNames.length){
    xiKeys = [...new Set(lb.xiNames.map(n => WX_KEY[n]).filter(Boolean))];
    jiKeys = [...new Set((lb.jiNames || []).map(n => WX_KEY[n]).filter(Boolean))];
  }
  const WXD = { wood:'1、2', fire:'3、4', earth:'5、6', metal:'7、8', water:'9、0' };
  const baseW = {}; for (let d = 0; d <= 9; d++) baseW[d] = 1;
  // 八星吉星数字加成
  ['天医','延年','生气'].forEach(s => BAXING[s].nums.forEach(p => { baseW[+p[0]] += 2; baseW[+p[1]] += 2; }));
  // 八字喜用神加权 / 忌神降权
  xiKeys.forEach(k => (WXD[k] || '').split('、').map(Number).forEach(d => baseW[d] *= 3));
  jiKeys.forEach(k => (WXD[k] || '').split('、').map(Number).forEach(d => baseW[d] *= 0.2));
  // 凶星相邻对（生成时规避）
  const BAD = []; ['六煞','祸害','五鬼','绝命'].forEach(s => BAXING[s].nums.forEach(p => BAD.push(p)));
  function wpick(w){
    let tot = 0; for (const k in w) tot += Math.max(0, w[k]);
    let r = Math.random() * tot;
    for (const k in w){ r -= Math.max(0, w[k]); if (r <= 0) return +k; }
    return 8;
  }
  function genOnce(){
    const arr = [];
    if (mobile){
      arr.push(1);                                            // 手机号首位固定 1
      arr.push([3,5,7,8,9][Math.floor(Math.random() * 5)]);
    } else {
      arr.push(1 + Math.floor(Math.random() * 9));             // 自定义：首位 1-9（无前导 0）
    }
    while (arr.length < len){
      const prev = arr[arr.length - 1];
      // 30% 概率尝试插入吉星相邻对
      if (Math.random() < 0.3){
        const goodNext = [];
        ['天医','延年','生气','伏位'].forEach(s => BAXING[s].nums.forEach(p => { if (+p[0] === prev) goodNext.push(+p[1]); }));
        if (goodNext.length){ arr.push(goodNext[Math.floor(Math.random() * goodNext.length)]); continue; }
      }
      const w = {};
      for (let d = 0; d <= 9; d++){ if (BAD.includes('' + prev + d)) continue; w[d] = baseW[d]; }
      arr.push(wpick(w));
    }
    return arr.join('');
  }
  const pool = [];
  const tries = count * 6;
  for (let i = 0; i < tries; i++) pool.push(genOnce());
  const scored = pool.map(num => { const r = analyzeNumber(num); return { num, score: r.score, level: r.level, levelKey: r.levelKey }; });
  scored.sort((a, b) => b.score - a.score);
  return scored.slice(0, count);
}

function renderLuckyNumbers(){
  const out = document.getElementById('num-gen-out');
  if (!out) return;
  // 选项 A：直接读号码输入框当种子，长度=位数、模式=长度11且^1[35789]→手机否则自定义（空→11位手机）
  const seedEl = document.getElementById('num-value');
  const seedDigits = seedEl ? (seedEl.value || '').replace(/\D/g, '') : '';
  let len, isMobile;
  if (seedDigits.length){
    len = Math.max(3, Math.min(20, seedDigits.length));
    isMobile = len === 11 && /^1[35789]/.test(seedDigits);
  } else {
    len = 11; isMobile = true;
  }
  const cands = genLuckyNumbers(len, 8, isMobile);
  if (!cands.length){ out.innerHTML = '<p class="hint">生成失败，请稍后重试。</p>'; return; }
  let numUseBazi = false;
  try { numUseBazi = localStorage.getItem('numUseBazi') === '1'; } catch (e) {}
  const hasBazi = numUseBazi && window.lastBazi && window.lastBazi.xiNames && window.lastBazi.xiNames.length;
  const tip = hasBazi
    ? `已按你的喜用神（${window.lastBazi.xiNames.join('、')}）优先生成；点选号码即可载入分析。`
    : `按八星吉星与八十一数理生成 ${len} 位${isMobile ? '（手机号风格）' : '（自定义）'}号码；开启「结合八字」可更合你命局。`;
  out.innerHTML = `<div class="num-gen-list">` + cands.map(c => `
    <div class="num-gen-item ${c.levelKey}" data-num="${c.num}">
      <div class="ngi-num">${c.num}</div>
      <div class="ngi-meta"><b class="ngi-score">${c.score}</b>分 · ${c.level}</div>
    </div>`).join('') + `</div>
    <p class="num-gen-tip">${tip}</p>`;
  out.querySelectorAll('.num-gen-item').forEach(el => {
    el.onclick = () => {
      const inp = document.getElementById('num-value');
      if (inp){ inp.value = el.dataset.num; renderNumberMath(); }
      out.querySelectorAll('.num-gen-item').forEach(x => x.classList.remove('sel'));
      el.classList.add('sel');
      const tgt = document.getElementById('number-math-out');
      if (tgt) tgt.scrollIntoView({ behavior: 'smooth', block: 'start' });
    };
  });
}

function meihuaCardsHtml(g){
  if (!g) return '';
  const gCard = (t, info) => `<div class="gua-card">
      <div class="gua-tag">${t}</div>
      <div class="gua-name">${info.name}</div>
      ${guaLinesHtml(info)}
      <div class="gua-trigram">上${info.upT}下${info.downT}</div>
      <div class="gua-desc">${info.desc}</div>
    </div>`;
  return `<div class="gua-flow">
      ${gCard('本卦', g.ben)}
      ${gCard('互卦', g.hua)}
      ${gCard('变卦', g.bian)}
    </div>
    <div class="gua-meta">动爻第 <b>${g.dong}</b> 爻（初爻起）｜ 体卦 <b class="wx-${g.tiWx}">${g.tiT}</b>（${g.tiWxName}）· 用卦 <b class="wx-${g.yongWx}">${g.yongT}</b>（${g.yongWxName}）｜ <b>${g.tiYong}</b></div>`;
}
function meihuaExplainHtml(g){
  const TIYONG_TEXT = {
    '体用比和（平）': '体卦与用卦五行相同、比和相助，事情多半平顺少波折，宜守成稳进、不宜冒进。',
    '用生体（吉）': '用卦生助体卦，表示外力相助、得人扶持，谋事易成、多有进益，宜把握时机。',
    '体生用（小耗）': '体卦生用卦，表示我方耗力以成事，付出多而回报缓，须防资源外泄、量力而行。',
    '体克用（吉）': '体卦克用卦，表示我主其事、能控局面，主动进取可成，但需亲力亲为、稍费心力。',
    '用克体（凶）': '用卦克体卦，表示外力压制、受阻不顺，谋事多艰，宜守不宜攻、暂避其锋。'
  };
  const ty = TIYONG_TEXT[g.tiYong] || '';
  const dongYao = `动爻落在第 <b>${g.dong}</b> 爻（由初爻起算）。动爻是卦中由阳变阴、或由阴变阳的那一爻，它牵引本卦走向变卦，是事情发生转变的关键节点。`;
  const roles = [
    ['本卦', '所占之事的现状 / 起始——事情当下的态势与根基。'],
    ['互卦', '事情发展的过程 / 内情——由本卦二、三、四、五爻重组而成，揭示演变中的隐藏环节。'],
    ['变卦', '事情的结果 / 趋向——动爻变化后所成的卦，预示最终走向。']
  ];
  const roleHtml = roles.map(([t,d])=>`<div class="mx-role"><b>${t}</b>：${d}</div>`).join('');
  // 综合解读：体用吉凶定夺 + 三卦时序 + 动爻位置提示，给出一句可执行的结论
  const TY_CONC = {
    '体用比和（平）': '体用同气相应，事体平顺，谋事可成，宜稳扎稳打、按部就班。',
    '用生体（吉）': '用生体为得助之象，谋事顺遂、多有进益，宜乘势而为、把握时机。',
    '体生用（小耗）': '体生用为耗泄之象，事虽可成而费心耗力，宜量力而行、防资源外流。',
    '体克用（吉）': '体克用为制胜之象，主动权在己，谋事可成，宜亲力亲为、一鼓作气。',
    '用克体（凶）': '用克体为受制之象，谋事多阻，宜守不宜攻、静待时机，忌强求冒进。'
  };
  const dongStage = g.dong <= 2
    ? '动爻居下，事起于微，宜早作谋划、慎始善终。'
    : g.dong <= 4
      ? '动爻居中，事行至半，变数渐显，宜随机应变、稳住阵脚。'
      : '动爻居上，事将定局，宜顺势收束，防临成生变。';
  const summary = `体卦${g.tiT}（${g.tiWxName}）为己方，用卦${g.yongT}（${g.yongWxName}）为所占之事：${TY_CONC[g.tiYong] || ty}本卦《${g.ben.name}》（${g.ben.desc}）示事之始，互卦《${g.hua.name}》示事之中，变卦《${g.bian.name}》（${g.bian.desc}）示事之终。${dongStage}`;
  return `<div class="meihua-read">
    <div class="mx-block">
      <div class="mx-h">如何读这三卦</div>
      ${roleHtml}
      <div class="mx-sub-h">体用生克</div>
      <div class="mx-tiyong">${g.tiYong} —— ${ty}</div>
      <div class="mx-sub-h">动爻</div>
      <div class="mx-dong">${dongYao}</div>
    </div>
    <div class="mx-block mx-summary">
      <div class="mx-h">综合解读</div>
      <div class="mx-sum">${summary}</div>
    </div>
  </div>`;
}
function renderMeihua(){
  const out = document.getElementById('meihua-out');
  if (!out) return;
  const valEl = document.getElementById('meihua-value');
  const raw = valEl ? valEl.value.trim() : '';
  if (!raw){
    out.innerHTML = '';
    return;
  }
  const digits = (raw.replace(/\D/g,'')).split('').map(Number);
  if (digits.length < 2){ out.innerHTML = '<p class="hint">至少输入 2 位数字方可起卦。</p>'; return; }
  const g = meihuaGua(digits);
  if (!g){ out.innerHTML = '<p class="hint">数字不足，无法起卦。</p>'; return; }
  out.innerHTML = `<div class="num-result">${meihuaCardsHtml(g)}${meihuaExplainHtml(g)}</div>`;
}
/* ===================================================================
 * 罗盘（二十四山 + 八卦内环）
 * =================================================================== */
const LUOPAN_24 = [
  ['子','坎','water','正北'],['癸','坎','water','北偏西'],['丑','艮','earth','东北偏北'],['艮','艮','earth','东北'],
  ['寅','艮','wood','东北偏东'],['甲','震','wood','东偏北'],['卯','震','wood','正东'],['乙','震','wood','东偏南'],
  ['辰','巽','earth','东南偏东'],['巽','巽','wood','东南'],['巳','巽','fire','东南偏南'],['丙','离','fire','南偏东'],
  ['午','离','fire','正南'],['丁','离','fire','南偏西'],['未','坤','earth','西南偏南'],['坤','坤','earth','西南'],
  ['申','坤','metal','西南偏西'],['庚','兑','metal','西偏南'],['酉','兑','metal','正西'],['辛','兑','metal','西偏北'],
  ['戌','乾','earth','西北偏西'],['乾','乾','metal','西北'],['亥','乾','water','西北偏北'],['壬','坎','water','北偏东']
];
const BAGUA_INFO = {
  '坎':{wx:'water',dir:'北',desc:'坎为水：主智慧、险陷，方位正北，五行属水。'},
  '艮':{wx:'earth',dir:'东北',desc:'艮为山：主静止、安稳，方位东北，五行属土。'},
  '震':{wx:'wood',dir:'东',desc:'震为雷：主动、奋发，方位正东，五行属木。'},
  '巽':{wx:'wood',dir:'东南',desc:'巽为风：主谦逊、顺入，方位东南，五行属木。'},
  '离':{wx:'fire',dir:'南',desc:'离为火：主光明、华丽，方位正南，五行属火。'},
  '坤':{wx:'earth',dir:'西南',desc:'坤为地：主柔顺、承载，方位西南，五行属土。'},
  '兑':{wx:'metal',dir:'西',desc:'兑为泽：主喜悦、口舌，方位正西，五行属金。'},
  '乾':{wx:'metal',dir:'西北',desc:'乾为天：主刚健、强健，方位西北，五行属金。'}
};
// 八卦对应卦符（三爻）：乾☰ 坤☷ 震☳ 艮☶ 兑☱ 巽☴ 离☲ 坎☵
const BAGUA_SYM = {'乾':'☰','坤':'☷','震':'☳','艮':'☶','兑':'☱','巽':'☴','离':'☲','坎':'☵'};
// 罗盘上以红底白字突出的十二山/卦；其余天干地支统一为单一颜色
const LUOPAN_RED = new Set(['甲','乙','辰','午','坤','申','戌','乾','壬','子','癸','寅']);
function _lpPt(cx,cy,r,deg){ const a=(deg-90)*Math.PI/180; return [cx+r*Math.cos(a), cy+r*Math.sin(a)]; }
function _lpAnnular(cx,cy,r1,r2,a0,a1){
  const [x1,y1]=_lpPt(cx,cy,r2,a0),[x2,y2]=_lpPt(cx,cy,r2,a1);
  const [x3,y3]=_lpPt(cx,cy,r1,a1),[x4,y4]=_lpPt(cx,cy,r1,a0);
  const large=(a1-a0)>180?1:0;
  return `M${x1} ${y1} A${r2} ${r2} 0 ${large} 1 ${x2} ${y2} L${x3} ${y3} A${r1} ${r1} 0 ${large} 0 ${x4} ${y4} Z`;
}
function buildLuopanSVG(){
  // 传统罗盘：三盘三针（天盘缝针 +7.5° / 地盘正针 0° / 人盘中针 −7.5°）+ 八卦内环 + 周天刻度
  const cx=220, cy=220;
  const WX = {
    wood:{d:'#3f7d4f', l:'#cfe6d6', t:'#fff'},
    fire:{d:'#c0392b', l:'#f3cdc7', t:'#fff'},
    earth:{d:'#b8893b', l:'#ecd9b0', t:'#fff'},
    metal:{d:'#8a8f98', l:'#e2e4e9', t:'#fff'},
    water:{d:'#2f6f9f', l:'#c6dcef', t:'#fff'}
  };
  const plates = [
    { key:'earth',  name:'地盘正针', off: 0,    R_out:135, R_in:109, fs:13, light:false },
    { key:'human',  name:'人盘中针', off:-7.5, R_out:169, R_in:139, fs:13, light:true },
    { key:'heaven', name:'天盘缝针', off: 7.5, R_out:200, R_in:173, fs:13, light:true }
  ];
  // 向心文字：以 (x,y) 为锚点，整字旋转 deg 度，字顶统一朝向天池中心
  function radialText(x,y,deg,ch,fs,w,fill){
    return `<text x="0" y="0" transform="translate(${x.toFixed(1)} ${y.toFixed(1)}) rotate(${deg.toFixed(1)})" font-size="${fs}" font-weight="${w}" fill="${fill}" text-anchor="middle" dominant-baseline="central" class="lp-text" pointer-events="none">${ch}</text>`;
  }
  let s = `<svg viewBox="-12 -12 464 464" class="luopan-svg" id="luopan-svg" role="img" aria-label="风水罗盘">`;
  s += `<circle cx="${cx}" cy="${cy}" r="214" class="lp-rim"/>`;
  // 周天 360° 刻度：每 5° 一细线，每 10° 一中线，每 30° 一粗线；刻度值（度数）置于刻度环之外（r=221），避免与刻度线重叠
  let ticks = '', deg = '';
  for (let d=0; d<360; d+=5){
    const heavy = (Math.round(d) % 30 === 0);
    const med = !heavy && (Math.round(d) % 10 === 0);
    const rin = heavy ? 200 : (med ? 203 : 207);
    const p1 = _lpPt(cx,cy,214,d), p2 = _lpPt(cx,cy, rin, d);
    ticks += `<line x1="${p1[0].toFixed(1)}" y1="${p1[1].toFixed(1)}" x2="${p2[0].toFixed(1)}" y2="${p2[1].toFixed(1)}" class="lp-tick${heavy?' heavy':med?' med':''}"/>`;
    if (Math.round(d) % 10 !== 0){
      const p = _lpPt(cx,cy,221,d);   // 移至刻度环外（rim=214），刻度值不再压线
      deg += radialText(p[0], p[1], d+180, d, 7, 400, '#8a6d3b');
    }
  }
  s += ticks + deg;
  // 金色分隔圈
  [201,170,136,106,74].forEach(r=>{ s += `<circle cx="${cx}" cy="${cy}" r="${r}" class="lp-ring"/>`; });
  // 三盘
  plates.forEach(pg=>{
    LUOPAN_24.forEach((m,i)=>{
      const a0 = i*15 + pg.off - 7.5, a1 = i*15 + pg.off + 7.5;
      const isRed = (pg.key === 'earth') && LUOPAN_RED.has(m[0]);
      const fill = isRed ? '#c0392b' : '#e7d9bc';
      const txt  = isRed ? '#ffffff' : '#4a3b2a';
      const ang = i*15 + pg.off;
      const p = _lpPt(cx,cy,(pg.R_out+pg.R_in)/2, ang);
      s += `<path d="${_lpAnnular(cx,cy,pg.R_out,pg.R_in,a0,a1)}" fill="${fill}" stroke="#fff" stroke-width="1" class="lp-sector" data-plate="${pg.key}" data-idx="${i}" opacity="0.97"/>`;
      s += radialText(p[0], p[1], ang+180, m[0], pg.fs, isRed?800:700, txt);
    });
  });
  // 八卦内环（后天八卦：坎北·艮东北·震东·巽东南·离南·坤西南·兑西·乾西北）
  // 每个卦居中于其本宫山角度（坎=子0°·艮=艮45°·震=卯90°·巽=巽135°·离=午180°·坤=坤225°·兑=酉270°·乾=乾315°），
  // 即每卦跨 ±22.5°，正好覆盖所辖三山（如震=甲卯乙、巽=辰巽巳）。
  Object.keys(BAGUA_INFO).forEach((g,i)=>{
    const a0=i*45-22.5, a1=i*45+22.5;
    const fill = '#e7d9bc';
    const txt  = '#4a3b2a';
    const ang = i*45;
    const pName = _lpPt(cx,cy,100, ang);
    const pSym  = _lpPt(cx,cy,83, ang);
    s += `<path d="${_lpAnnular(cx,cy,105,75,a0,a1)}" fill="${fill}" stroke="#fff" stroke-width="1" class="lp-gua" data-gua="${g}" opacity="0.97"/>`;
    s += radialText(pName[0], pName[1], ang+180, g, 11, 700, txt);
    s += radialText(pSym[0], pSym[1], ang+180, BAGUA_SYM[g], 15, 700, txt);
  });
  s += `</svg>`;
  return s;
}
function selectLuopan(i){
  const m=LUOPAN_24[i], body=document.getElementById('luopan-info-body');
  if (!body) return;
  body.innerHTML='';
  _lpManual = true;
}
function selectGua(g){
  const body=document.getElementById('luopan-info-body');
  if (!body) return;
  const info = BAGUA_INFO[g];
  if (info){
    body.innerHTML = `<div class="lp-gua-card">
      <div class="lp-gua-sym">${BAGUA_SYM[g]}</div>
      <div class="lp-gua-name">${g}卦</div>
      <div class="lp-gua-meta">方位 ${info.dir}　·　五行 ${WX_NAME[info.wx]}</div>
      <div class="lp-gua-desc">${info.desc}</div>
    </div>`;
  } else { body.innerHTML=''; }
  _lpManual = true;
}
function fetchLuopanLocation(){
  const locEl = document.getElementById('luopan-loc');
  if (!locEl) return;
  if (!navigator.geolocation){ locEl.textContent = '经纬度：环境不支持'; return; }
  locEl.textContent = '经纬度：定位中…';
  let settled = false;
  const t = setTimeout(function(){
    if (!settled){ settled = true; if (locEl.textContent === '经纬度：定位中…') locEl.textContent = '经纬度：定位超时（请检查定位权限 / 需 HTTPS 或 localhost）'; }
  }, 8000);
  navigator.geolocation.getCurrentPosition(function(pos){
    if (settled) return; settled = true; clearTimeout(t);
    locEl.textContent = '纬度 ' + pos.coords.latitude.toFixed(3) + '°　经度 ' + pos.coords.longitude.toFixed(3) + '°';
  }, function(err){
    if (settled) return; settled = true; clearTimeout(t);
    const why = (err && err.code === 1) ? '未授权定位' : '定位不可用';
    locEl.textContent = '经纬度：获取失败（' + why + '）';
  }, { enableHighAccuracy:true, timeout:8000 });
}
function renderLuopan(){
  const box=document.getElementById('luopan-out');
  if (!box || box.dataset.built) return;
  box.innerHTML=buildLuopanSVG();
  box.dataset.built='1';
  box.querySelectorAll('.lp-sector').forEach(p=>{ p.style.cursor='pointer'; p.addEventListener('click',()=>selectLuopan(+p.dataset.idx)); });
  box.querySelectorAll('.lp-gua').forEach(p=>{ p.style.cursor='pointer'; p.addEventListener('click',()=>selectGua(p.dataset.gua)); });
  // 初始坐向信息（正北·子山），未启动指南针时显示；转动后由 lpUpdateReadout 动态更新
  const body0 = document.getElementById('luopan-info-body');
  if (body0){ body0.innerHTML = ''; }
}

let _lpAngle = 0, _lpTarget = null, _lpHandler = null, _lpLocked = false, _lpRAF = false, _lpManual = false;
let _lpNeedle = null, _lpOut = null;

// 缓存磁针与盘面元素（避免每帧查 DOM）
function lpCacheEls(){
  _lpNeedle = document.querySelector('.lp-tianchi svg');
  _lpOut = document.getElementById('luopan-out');
  return _lpNeedle && _lpOut;
}

// 坐/向读数（仅在未锁定时刷新，锁定后冻结）
function lpUpdateReadout(h){
  const headingEl = document.getElementById('luopan-heading');
  if (headingEl) headingEl.textContent = '朝向：' + Math.round(h) + '°';
  const idx = Math.round(h/15) % 24;
  const facing = LUOPAN_24[idx], sitting = LUOPAN_24[(idx+12)%24];
  const readout = document.getElementById('luopan-readout');
  if (readout) readout.innerHTML = '<div class="lp-readout-main">坐 <b class="lp-mt">'+sitting[0]+'</b> <span class="lp-sub-sm">'+sitting[3]+'（'+WX_NAME[sitting[2]]+'）</span> 向 <b class="lp-mt">'+facing[0]+'</b> <span class="lp-sub-sm">'+facing[3]+'（'+WX_NAME[facing[2]]+'）</span></div>';
  // 度数移到页面罗盘上方的「向」字右边
  const ptr = document.querySelector('.lp-pointer');
  if (ptr) ptr.innerHTML = '▲ 向 <b class="lp-deg">'+Math.round(h)+'°</b>';
  // 未手动点选某山/卦时，坐山五行随当前朝向动态更新（解决子山·五行水固定不变）
  if (!_lpManual){
    const body = document.getElementById('luopan-info-body');
    if (body){ body.innerHTML = ''; }
  }
}

// 平滑跟随渲染循环：持续把盘面缓动到目标角——既灵敏跟手又稳居南北；锁定则冻结
function lpTick(){
  if (_lpTarget != null && !_lpLocked && _lpNeedle && _lpOut){
    let diff = _lpTarget - _lpAngle;
    while (diff > 180) diff -= 360;
    while (diff < -180) diff += 360;
    // 自适应缓动：转动幅度越大系数越高（更跟手），小幅微动时保持平稳；整体比旧版(0.2)灵敏很多
    const ease = Math.min(0.6, 0.4 + Math.abs(diff) / 180 * 0.2);
    _lpAngle += diff * ease;
    if (Math.abs(diff) < 0.05) _lpAngle = _lpTarget;
    _lpNeedle.style.transform = 'rotate(' + _lpAngle + 'deg)';
    _lpOut.style.transform = 'rotate(' + _lpAngle + 'deg)';   // 盘面随磁针同步旋转，使子午始终对准磁针
  }
  requestAnimationFrame(lpTick);
}

// 传感器回调：仅采用绝对朝向（iOS 的 webkitCompassHeading 或 Android 的 absolute alpha），
// 拒绝相对 alpha（相对设备启动朝向，迟钝且漂移），解决磁针不指南北/灵敏度差
function onOrient(e){
  let h = null;
  if (typeof e.webkitCompassHeading === 'number') h = e.webkitCompassHeading;
  else if (e.absolute === true && typeof e.alpha === 'number') h = (360 - e.alpha) % 360;
  if (h == null) return;
  h = (h % 360 + 360) % 360;
  _lpTarget = -h;                          // 显示目标角：手机朝北(h=0)→0；朝东(h=90)→-90（子端指向屏幕左侧=北）
  if (_lpLocked) return;                   // 已锁定坐向 → 冻结盘面，不再跟随
  lpUpdateReadout(h);
}

// 进入罗盘页默认调用：挂载传感器监听（幂等），盘面默认即可转动
function startLuopanCompass(){
  if (_lpHandler) return;
  const btn = document.getElementById('luopan-compass-btn');
  const needHttps = location.protocol !== 'https:' && location.hostname !== 'localhost' && location.hostname !== '127.0.0.1';
  const attach = ()=>{
    _lpHandler = onOrient;
    if (window.DeviceOrientationEvent && 'ondeviceorientationabsolute' in window) window.addEventListener('deviceorientationabsolute', onOrient, true);
    window.addEventListener('deviceorientation', onOrient, true);
    lpCacheEls();
    if (!_lpRAF){ _lpRAF = true; requestAnimationFrame(lpTick); }
    if (btn) btn.textContent = _lpLocked ? '解除锁定坐向' : '锁定坐山朝向';
    fetchLuopanLocation();
  };
  if (typeof DeviceOrientationEvent !== 'undefined' && typeof DeviceOrientationEvent.requestPermission === 'function'){
    DeviceOrientationEvent.requestPermission().then(function(state){
      if (state === 'granted') attach();
      else alert('未授权设备方向权限，无法启动指南针。');
    }).catch(function(){ alert('无法获取设备方向权限（可能需 HTTPS 环境）。'); });
  } else if (needHttps){
    alert('指南针需要 HTTPS 或本机（localhost）环境才能读取设备方向。当前为 HTTP，无法启动；你可点击罗盘上的二十四山手动查看。');
  } else {
    attach();
  }
}

// 点锁定坐山朝向→ 启动并立即锁定（单击即生效，不再需点两次）；再点解除锁定坐向→ 恢复跟随
function toggleLuopanLock(){
  const btn = document.getElementById('luopan-compass-btn');
  if (!_lpHandler){ startLuopanCompass(); _lpLocked = true; if (btn) btn.textContent = '解除锁定坐向'; return; }
  _lpLocked = !_lpLocked;
  if (btn) btn.textContent = _lpLocked ? '解除锁定坐向' : '锁定坐山朝向';
  if (!_lpLocked){ _lpTarget = null; lpCacheEls(); _lpManual = false; }   // 解除后重新跟随坐向（含坐山五行）
}

/* ===================================================================
 * 标签切换 & 初始化
 * =================================================================== */
const TAB_TITLES = { bazi:'八字排盘', calendar:'黄历', books:'古籍收集', math:'数理分析', name:'起名', luopan:'罗盘', about:'关于' };
// 各页面底部免责声明文案（随当前页切换，对应页面对应的方案）
const FOOTER_TEXT = {
  bazi: '内容仅供传统文化娱乐参考，不作决策依据。',
  calendar: '内容仅供传统文化娱乐参考，不作决策依据。',
  books: '内容仅供传统文化娱乐参考，不作决策依据。',
  math: '内容仅供传统文化娱乐参考，不作决策依据。',
  name: '内容仅供传统文化娱乐参考，不作决策依据。',
  luopan: '内容仅供传统文化娱乐参考，不作决策依据。',
  about: '感谢使用简策集，如有建议欢迎联系。'
};
// 全局构建信息（由 loadBuildInfo 从 version.json 读取，CI 构建时写入）
let APP_BUILD = '';
function loadBuildInfo(){
  try {
    fetch('version.json', { cache:'no-store' })
      .then(r=> r.ok ? r.json() : null)
      .then(d=>{
        if (!d) return;
        APP_BUILD = (d.buildHash ? d.buildHash : '') + (d.buildAt ? ' · ' + d.buildAt : '');
        if (d.appVersion){ const v=document.getElementById('about-version'); if(v) v.textContent=d.appVersion; }
        const ab=document.getElementById('about-build'); if(ab){ ab.textContent=(d.buildHash||'—')+(d.buildAt?' · '+d.buildAt:''); }
        // 刷新底部哈希（若当前页已渲染 footer）
        const cur = document.querySelector('#tabs .tab.active');
        if (cur) updateFooter(cur.dataset.tab);
      })
      .catch(()=>{});
  } catch(e){}
}
function updateFooter(tab){
  const f = document.querySelector('.site-footer');
  if (!f) return;
  f.style.display = '';
  const span = f.querySelector('span');
  if (span){
    let txt = FOOTER_TEXT[tab] || FOOTER_TEXT.bazi;
    span.textContent = txt;
  }
  // 版本号仅【关于】页显示，位于感谢语下方
  const ver = document.getElementById('footer-about-meta');
  if (ver) ver.style.display = (tab === 'about') ? '' : 'none';
}
// 统计埋点：仅在 APP 内（存在 window.UmengStats）且非排版编辑器模式调用；桌面预览无此接口，安全降级
function trackPage(tab){
  try {
    if (window.UmengStats && !/editor=1/.test(location.search)) {
      window.UmengStats.track(tab);
    }
  } catch(e){}
}

// 数字能量的出生日期直接复用「八字」页日期（八字页是权威来源，始终是默认/已设日期）
function syncNumBirthLabel(){
  const btn = document.getElementById('num-birth-btn');
  const sw = document.getElementById('num-use-bazi');
  if (!btn || !sw || !sw.checked) return;
  const s = parseDateInput('solar-date');          // 八字页公历日期，始终存在
  btn.textContent = s
    ? `出生日期：${s.y}年${String(s.m).padStart(2,'0')}月${String(s.d).padStart(2,'0')}日`
        : '请选择出生日期';
}

/* 起名页：结合八字喜用勾选时，把出生时间下拉框默认显示为八字页已排的出生日期（y/m/d + 时辰） */
function showBuildTag(){
  const el = document.getElementById('name-build-tag');
  if (!el) return;
  const fallback = '7a05c4e';
  el.textContent = '当前包版本：' + fallback;
  try {
    if (typeof fetch === 'function'){
      fetch('version.json').then(r=>r.json()).then(j=>{
        if (j && j.buildHash) el.textContent = '当前包版本：' + j.buildHash;
      }).catch(()=>{});
    }
  } catch(e){}
}

function syncNameBirthLabel(force){
  const btn = document.getElementById('name-birth-btn');
  const ub = document.getElementById('name-use-bazi');
  if (!btn || !ub || !ub.checked) return;
  const b = Birth.get();   // 统一出生时间数据源（权威源）
  if (!b || b.y < 1900){ btn.textContent = '请选择出生时间'; return; }
  // 时辰：优先用八字页已算命盘的时柱地支；否则用统一数据源的时辰
  let h = (typeof b.hour === 'number') ? b.hour : shichenToHM(b.shichen || 6)[0];
  const mm = (typeof b.minute === 'number') ? b.minute : 0;
  const lb = window.lastBazi;
  if (lb && lb.hour && lb.hour.length >= 2){
    const idx = BRANCHES.indexOf(lb.hour[1]);
    if (idx >= 0) h = idx;
  }
  btn.textContent = `${b.y}年${String(b.m).padStart(2,'0')}月${String(b.d).padStart(2,'0')}日 ${BRANCHES[hourBranch(h)]}时 ${String(h).padStart(2,'0')}:${String(mm).padStart(2,'0')}`;
}

function initTabs(){
  document.querySelectorAll('#tabs .tab').forEach(t=>{
    t.onclick = ()=>{
      document.querySelectorAll('#tabs .tab').forEach(x=>x.classList.remove('active'));
      document.querySelectorAll('main .panel').forEach(x=>x.classList.remove('active'));
      t.classList.add('active');
      const tab = t.dataset.tab;
      document.getElementById(tab).classList.add('active');
      const otaEl = document.getElementById('ota-ver');
      if (otaEl) otaEl.style.display = (tab === 'about') ? '' : 'none'; // 版本角标仅【关于】页显示
      const mainEl = document.querySelector('main'); if (mainEl) mainEl.scrollTop = 0; // 切页回顶（内容区滚动）
      const tt = document.getElementById('top-page-title');
      if (tt && TAB_TITLES[tab]) tt.textContent = TAB_TITLES[tab];
      updateFooter(tab);
      trackPage(tab);
      if (tab === 'calendar') renderCalendar(); // 进入黄历时默认显示当天日期与黄历
      if (tab === 'name') {
        renderNameStrokes(); syncNameBirthLabel(); computeName(); showBuildTag();
        // 再次进入起名页（如八字页改日期重新排盘后返回）：若已生成过候选，用最新八字喜用自动重生成，
        // 确保候选随八字（喜忌）变化而更新，而不是停留在上一次的旧候选
        const nbox = document.getElementById('name-candidates');
        if (nbox && nbox.querySelector('.cand-card')) { try { doGenerate(); } catch(e){} }
      }
      if (tab === 'luopan') { renderLuopan(); setTimeout(startLuopanCompass, 300); }
      if (tab === 'math'){
        // 从八字页排盘返回数理页时，刷新出生日期标签与契合度（复用八字页最新日期/命盘）
        const act = document.querySelector('#math-subtabs .subtab.active');
        const sub = act ? act.dataset.sub : 'number-math';
        if (sub === 'number-math'){ syncNumBirthLabel(); renderNumberMath(); }
      }
    };
  });
  document.querySelectorAll('#math-subtabs .subtab').forEach(t=>{
    t.onclick = ()=>{
      document.querySelectorAll('#math-subtabs .subtab').forEach(x=>x.classList.remove('active'));
      document.querySelectorAll('#math .subpanel').forEach(x=>x.classList.remove('active'));
      t.classList.add('active');
      const sub = t.dataset.sub;
      document.getElementById(sub).classList.add('active');
      if (sub === 'number-math'){ renderNumberMath(); syncNumBirthLabel(); }
      if (sub === 'meihua') renderMeihua();
    };
  });
  // 初始页脚文案（默认 八字 页）
  const defTab = document.querySelector('#tabs .tab.active');
  updateFooter(defTab ? defTab.dataset.tab : 'bazi');
  trackPage(defTab ? defTab.dataset.tab : 'bazi');
  // 版本角标仅【关于】页显示：默认非 about 则隐藏
  const otaEl0 = document.getElementById('ota-ver');
  if (otaEl0) otaEl0.style.display = (defTab && defTab.dataset.tab === 'about') ? '' : 'none';
}

let _appStarted = false;
function initApp(){
  if (_appStarted) return;
  // 预览器等环境会异步加载 calendar.js，需等其就绪再初始化，否则首屏渲染会因
  // calendar 未定义而抛错，导致万年历/八字空白（手动点击后 calendar 已加载才正常）。
  if (typeof calendar === 'undefined' || !(calendar && typeof calendar.solar2lunar === 'function')) {
    setTimeout(initApp, 30); return;
  }
  _appStarted = true;
  loadBuildInfo();
  initTabs();
  // 全局夜间模式：启动应用保存的主题，并绑定标题栏切换按钮（全局各页面共享 header）
  (function(){
    const root = document.documentElement;
    const btn = document.getElementById('theme-toggle');
    const apply = (dark)=>{
      if (dark){ root.setAttribute('data-theme','dark'); if (btn){ btn.textContent='☀️'; btn.title='日间模式'; } }
      else { root.removeAttribute('data-theme'); if (btn){ btn.textContent='🌙'; btn.title='夜间模式'; } }
    };
    try { apply(localStorage.getItem('claw_theme')==='dark'); } catch(e){}
    if (btn) btn.onclick = ()=>{
      const dark = root.getAttribute('data-theme')==='dark';
      apply(!dark);
      try { localStorage.setItem('claw_theme', dark?'light':'dark'); } catch(e){}
    };
  })();
  document.getElementById('bazi-btn').onclick = renderBazi;
  initReverseModal();
  const _revYe = document.getElementById('rev-ye');
  if (_revYe && (_revYe.value === '2100' || !_revYe.value)) _revYe.value = new Date().getFullYear();
  const rt = document.getElementById('reverse-toggle');
  if (rt) rt.onclick = ()=>{
    openRevModal();
    rt.setAttribute('aria-expanded', 'true');
    rt.classList.add('rev-on');
  };
  restoreGender();   // 恢复上次选择的性别（与日期 clawBirth 一样跨重启保留）
  initBaziForm();
  initBirthSubs();   // 注册出生时间订阅者：任一页写回 Birth 后所有相关页自动刷新
  initLngPicker();
  initCalendar();
  renderBooks();
  const bs = document.getElementById('books-search');
  if (bs) bs.addEventListener('input', ()=>{ booksQuery = bs.value; renderBooks(); });
  document.getElementById('name-surname').addEventListener('input', renderNameStrokes);
  document.getElementById('name-given').addEventListener('input', renderNameStrokes);
  document.getElementById('num-value').addEventListener('input', renderNumberMath);
  const numBaziSw = document.getElementById('num-use-bazi');
  const numBirthBtn = document.getElementById('num-birth-btn');
  const syncNumBaziUI = () => {
    const on = numBaziSw && numBaziSw.checked;
    if (numBirthBtn) numBirthBtn.hidden = !on;
    syncNumBirthLabel();   // 直接读八字页日期作为数字能量的出生日期
  };
  if (numBaziSw) {
    try { if (localStorage.getItem('numUseBazi') === '1') numBaziSw.checked = true; } catch (e) {}
    syncNumBaziUI();
    numBaziSw.addEventListener('change', () => {
      const on = numBaziSw.checked;
      try { localStorage.setItem('numUseBazi', on ? '1' : '0'); } catch (e) {}
      syncNumBaziUI();
      renderNumberMath();
      // 勾选/取消结合八字喜用：实时重算吉祥号码候选列表（含提示语），否则要再点一次生成才生效
      const genOut = document.getElementById('num-gen-out');
      if (genOut && genOut.querySelector('.num-gen-item')) renderLuckyNumbers();
    });
    // 数字能量本地弹滚轮选出生日期（预填八字页日期，确认后双向同步）
    if (numBirthBtn) numBirthBtn.addEventListener('click', ()=>dwOpen({ calType:'solar' }));
  }
  const genBtn = document.getElementById('num-gen-btn');
  if (genBtn) genBtn.onclick = renderLuckyNumbers;
  const meihuaInput = document.getElementById('meihua-value');
  if (meihuaInput) meihuaInput.addEventListener('input', renderMeihua);
  const lpBtn = document.getElementById('luopan-compass-btn');
  if (lpBtn) lpBtn.onclick = toggleLuopanLock;
  renderBazi();           // 默认排一卦
  renderNumberMath();     // 数理页默认激活数字能量子页，载入即显示该页
  initNameBirth();
  renderNameStrokes();
  initAboutPage();
}

// 复制文本到剪贴板：优先异步 API（仅安全上下文），失败/拒绝一律走 execCommand 兜底
// （重要：Capacitor WebView 中 navigator.clipboard 存在但 writeText 常 reject，
//   原逻辑“仅当 clipboard 不存在时才兜底”会导致永远走 fail，故改为 reject 也兜底）
function copyToClipboard(text){
  return new Promise(function(resolve){
    if (navigator.clipboard && navigator.clipboard.writeText && window.isSecureContext){
      try {
        const p = navigator.clipboard.writeText(text);
        if (p && p.then){
          p.then(function(){ resolve(true); })
           .catch(function(){ resolve(legacyCopy(text)); });
          return;
        }
      } catch(e){ /* 落到兜底 */ }
    }
    resolve(legacyCopy(text));
  });
}
function legacyCopy(text){
  try {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.setAttribute('readonly', '');
    ta.style.position = 'fixed';
    ta.style.top = '0';
    ta.style.left = '0';
    ta.style.opacity = '0';
    ta.style.fontSize = '16px';            // 防止 iOS 聚焦缩放
    document.body.appendChild(ta);
    ta.focus();
    ta.select();
    try { ta.setSelectionRange(0, ta.value.length); } catch(e){}
    const ok = document.execCommand('copy');
    document.body.removeChild(ta);
    return ok;
  } catch(e){ return false; }
}
function _copyText(url, btn){
  copyToClipboard(url).then(function(ok){
    _flashBtn(btn, ok ? '链接已复制' : '复制失败，长按链接');
  });
}
function _flashBtn(btn, msg){
  if (!btn) return;
  const orig = btn.innerHTML;
  btn.innerHTML = '<span>' + msg + '</span>';
  setTimeout(()=>{ btn.innerHTML = orig; }, 1600);
}

// 分享二维码图：先把图写入缓存目录拿真实文件 URI，再调系统分享面板（Capacitor 安卓端只认 URI，JS File 对象会被原生忽略导致只发文字）
function shareQrImage(){
  var Capacitor = window.Capacitor;
  var Share = Capacitor && Capacitor.Plugins && Capacitor.Plugins.Share;
  if (Share && typeof Share.share === 'function'){
    fetch('wechat-qr.png', { cache:'no-store' })
      .then(function(r){ if (!r.ok) throw new Error('qr'); return r.blob(); })
      .then(blobToBase64)
      .then(function(b64){
        var FS = Capacitor.Plugins.Filesystem;
        if (!FS || typeof FS.writeFile !== 'function'){ return window.open('wechat-qr.png', '_blank'); }  // 旧包无 FS 插件：降级打开图片供保存
        return FS.writeFile({ path:'share/wechat-qr.png', data:b64, directory:'CACHE', recursive:true })
          .then(function(res){
            return Share.share({ title:'微信二维码 · 简策集', text:'微信扫一扫添加', files:[res.uri], dialogTitle:'分享二维码' });
          });
      })
      .catch(function(){ /* 用户取消等，静默 */ });
  } else {
    window.open('wechat-qr.png', '_blank');
  }
}
// blob → base64（FileReader，兼容 WebView）
function blobToBase64(blob){
  return new Promise(function(resolve, reject){
    var fr = new FileReader();
    fr.onload = function(){ resolve(String(fr.result).split(',')[1]); };
    fr.onerror = function(){ reject(new Error('read')); };
    fr.readAsDataURL(blob);
  });
}

function initAboutPage(){
  const qr = document.getElementById('about-qr');
  if (qr){
    qr.addEventListener('error', ()=>{
      var wrap = document.getElementById('about-qr-wrap');
      if (wrap) wrap.style.display = 'none';
    });
    // 点二维码：App 内直接弹系统分享面板分享二维码图（可发微信等）；浏览器环境降级为打开图片供保存后用微信扫一扫
    qr.addEventListener('click', ()=> shareQrImage());
  }
  // 分享给好友：弹分享浮层（系统分享 / 二维码 / 复制链接），无原生 Share 时自动降级为二维码+复制
  const shareBtn = document.getElementById('about-share');
  if (shareBtn){
    const APP_URL = 'https://github.com/DJW0420613/jianceji-ota/releases/latest/download/jiancheji-release.apk';
    // H5 落地页：微信内打开自动引导浏览器下载，避免 APK 直链被微信拦截（复制链接/系统分享都用它，二维码仍为 APK 直链扫码）
    // 托管在 GitHub Pages（github.io 渲染 HTML）；曾用 jsDelivr 返回 text/plain 显示源码，弃用
    const SHARE_URL = 'https://DJW0420613.github.io/claw-web/dl/';
    shareBtn.addEventListener('click', ()=> openShareSheet(APP_URL, SHARE_URL));
  }
  if (typeof fetch === 'function'){
    fetch('version.json', { cache:'no-store' })
      .then(r=> r.ok ? r.json() : null)
      .then(d=>{
        if (d && d.appVersion){ const v=document.getElementById('about-version'); if(v) v.textContent=d.appVersion; }
        const el = document.getElementById('about-build');
        if (el && d){
          const h = d.buildHash ? d.buildHash : '—';
          const t = d.buildAt ? ' · ' + d.buildAt : '';
          el.textContent = h + t;
        }
      })
      .catch(()=>{});
  }
}

// 分享给好友浮层：系统分享（原生 Share，不可用时隐藏降级）+ 二维码（身边扫码）+ 复制链接兜底
// url=二维码对应直链；shareUrl=系统分享/复制链接用的 H5 落地页（微信内可正常引导下载）
function openShareSheet(url, shareUrl){
  if (shareUrl == null) shareUrl = url;
  var overlay = document.getElementById('shareMask');
  if (!overlay){
    overlay = document.createElement('div');
    overlay.id = 'shareMask';
    overlay.className = 'share-mask';
    overlay.innerHTML =
      '<div class="share-sheet" role="dialog" aria-modal="true">'
      + '<div class="share-sheet-head"><span class="share-sheet-title">分享给好友</span>'
      + '<button class="share-sheet-x" id="shareCloseX" type="button" aria-label="关闭">×</button></div>'
      + '<div class="share-qr-box"><img class="share-qr-img" id="shareQr" alt="扫码下载安装包" /></div>'
      + '<button class="share-btn share-btn-primary" id="shareSys" type="button">系统分享</button>'
      + '<button class="share-btn" id="shareCopy" type="button">复制链接</button>'
      + '</div>';
    document.body.appendChild(overlay);
    overlay.addEventListener('click', function(e){ if (e.target === overlay) closeShareSheet(); });
  }
  var qr = document.getElementById('shareQr');
  if (qr) qr.src = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAWgAAAFoCAIAAAD1h/aCAAAIbklEQVR4nO3d240jtxZA0WljQrgBKP+oFIBz0I2gPrZB4pDqtb7bpedsUK4D8ufz+fwBKP5Jfw0gHMB/YcUBZMIBZMIBZMIBZMIBZMIBZMIBZMIBZMIBZMIBZMIBZMIBZMIBZH/rf/D638+fG7z//Sx5XfU69fq7n/8qT89n1ev6bd+r21+XFQeQCQeQCQeQCQeQCQeQCQeQCQewf47jyap5h2rqPvmquY+p+Yj697fMIzzZPY/zXvS577bqc7TiADLhADLhADLhADLhADLhADLhAObmOHbfN566711N7Ytxy/Vvmb84bT7otM/RigPIhAPIhAPIhAPIhAPIhAPIhAM4b47jFrv30dg9LzB1nd3zAqftA3LanMsUKw4gEw4gEw4gEw4gEw4gEw4gEw4gM8ex+LyMJ7vPN5k6n+W0uY/6uLs/929lxQFkwgFkwgFkwgFkwgFkwgFkwgGcN8dx2v3wVXMQq/bvqKbmSnbvP3LafiVT8x3vw/69PLHiADLhADLhADLhADLhADLhADLhAObmOE47/+IWp82V3LI/xWlzJe/4/tz+78WKA8iEA8iEA8iEA8iEA8iEA8iEA8h+Pp+z7s9PWXVffff5Jk+m5gumXu9pn+9vY8UBZMIBZMIBZMIBZMIBZMIBZMIB7N+PY/e8wO65gKl5jfr3u1/v1Lkwp30fVnkN7esxxYoDyIQDyIQDyIQDyIQDyIQDyIQDmDtX5Vv3QVj1uFPnfUy93tP2AZnar+S16HPZfQ5LfR+sOIBMOIBMOIBMOIBMOIBMOIBMOID9cxy793GYul+9+/7/k6l9GU7b72O3qf1i3pd8/ysrDiATDiATDiATDiATDiATDiATDiD7+Xz23t9edZ1b7qvf/vyr057PLXMor8O+n5UVB5AJB5AJB5AJB5AJB5AJB5AJBzA3x3Haff7dcyW73TJ/ccs5L7uf/3toHmdqPsWKA8iEA8iEA8iEA8iEA8iEA8iEA9g/x3HaffLdds8jnHZ//vZ9NOp1npw2h3IaKw4gEw4gEw4gEw4gEw4gEw4gEw4g+3vL/fzT7tvv3ofi9nNYVr0/U3Mru/cBmZr3qY/7xIoDyIQDyIQDyIQDyIQDyIQDyIQDOG8/jlWmzkk57f75LfMXu+dcVj3uLXMxp+33YcUBZMIBZMIBZMIBZMIBZMIBZMIBzO3Hcdp8xG63vA/1Orv3E/lt54+8DzsfZxUrDiATDiATDiATDiATDiATDiATDmD/HMeT3felV81H7H6et7wPu+cFVp2f8mT3vM9p+6Q8mdpnxIoDyIQDyIQDyIQDyIQDyIQDyIQD2D/Hcdp+GVP3/6f2TZiaQ3ny9LinPZ+p7+f7krmbyooDyIQDyIQDyIQDyIQDyIQDyIQDyH4+n89X7hew+/7/ac9nlanXter6U4/7HjoHZ+rcFisOIBMOIBMOIBMOIBMOIBMOIBMOYG6O45Y5hW/dX+P280ROe9xVcxPVLZ+7FQeQCQeQCQeQCQeQCQeQCQeQCQew/1yV08592H1f/bTzYla9z7v3j1h1/VXvw6q/P21e5j00D2XFAWTCAWTCAWTCAWTCAWTCAWTCAdyzH8ct+3Ssctq5LU9WPe7UeR9T+2h867k2T6w4gEw4gEw4gEw4gEw4gEw4gEw4gLn9OKrd+yncvr+Gc0lmTc2VrLL7+lYcQCYcQCYcQCYcQCYcQCYcQCYcwP79OFbNF0ztm7B7v4lV19k9bzJ1Ds5p35/T9ul4D30ulRUHkAkHkAkHIBzAflYcQCYcQCYcwNwcx+3zCKedCzP1unY//6n9KZ7c8rpeh51fY8UBZMIBZMIBZMIBZMIBZMIBZMIB7D9X5bTzIFbdr759H4fb9x9ZZer78NvOebHiADLhADLhADLhADLhADLhADLhAM7bj2OV0+YLbj9v5fbrr3rcVZ/XKs5VAb6WnypAJhxAJhxAJhxAJhxAJhzA/jmOW+Y7qt37cUzNC9y+r8S3nnuym3NVgOP4qQJkwgFkwgFkwgFkwgFkwgHMzXGsMnW//fY5hdvnDm75vL517ubtXBVgNz9VgEw4gEw4gEw4gEw4gEw4gOzv7ff/d+/XsNtpcwS37z/yZPf38/3L9lux4gAy4QAy4QAy4QAy4QAy4QAy4QC+dz+OJ986P7JqLuBb51aqW85VeQ3NxdiPA9jOTxUgEw4gEw4gEw4gEw4gEw5g/xzHLXMHq+YmbjnnZer9P21O5Mlpn1e1+99FZcUBZMIBZMIBZMIBZMIBZMIBZMIB7D9XZdV94HqdqX0cqlvOyzjt+rvnLKbmhqrdj7vq/bfiADLhADLhADLhADLhADLhADLhAPbPcZy2z8KTp/vSp+3T8a37jJw2jzO1z8jrsPNc7McBjPFTBciEA8iEA8iEA8iEA8iEA9g/x3Ha/flV99VXuWXOpTptf4pb9md5H/bvwhwHMMZPFSATDiATDiATDiATDkA4gIvmOJ7sPqdj93Wmnv/uuYlVf7/qHJNVjzvlNTQf5FwV4Br+HweQCQeQCQeQCQeQCQeQCQdw3hzHaXbPR5w217BqDmLVOR1T78PueZzX0Pk4U6w4gEw4gEw4gEw4gEw4gEw4gEw4gOzn89l7H37q/vlp+25MnUty2r4SU/MLq763uz+X1+Z5kHqdJ1YcQCYcQCYcQCYcQCYcQCYcQCYcwHn7cZy2j8CT0+YFVl1/1XWm5mVOm3+5fd+N96LrW3EAmXAAmXAAmXAAmXAAmXAAmXAAc3Mcu/dxWOW0+YXd8x2rTO238q2v94lzVYCv5acKkAkHkAkHkAkHkAkHkAkHsP9cFQArDiATDiATDiATDiATDiATDiATDiATDiATDiATDiATDiATDiATDiATDiATDuBP9X9Nbbbl33QJfAAAAABJRU5ErkJggg==';
  var sysBtn = document.getElementById('shareSys');
  var Share = (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.Share);
  if (sysBtn){
    if (Share && typeof Share.share === 'function'){
      sysBtn.style.display = '';
      sysBtn.onclick = function(){
        Share.share({ title:'简策集 · 八字命盘', text:'推荐一款八字排盘/万年历/古籍 App', url:shareUrl, dialogTitle:'分享给好友' })
          .catch(function(){});   // 用户取消或不支持，静默
      };
    } else {
      sysBtn.style.display = 'none';   // 降级：旧 APK / 浏览器无 Share，隐藏系统分享
    }
  }
  var copyBtn = document.getElementById('shareCopy');
  if (copyBtn) copyBtn.onclick = function(){ _copyText(shareUrl, copyBtn); };
  var closeX = document.getElementById('shareCloseX');
  if (closeX) closeX.onclick = closeShareSheet;
  overlay.style.display = 'flex';
  document.body.style.overflow = 'hidden';
}
function closeShareSheet(){
  var overlay = document.getElementById('shareMask');
  if (overlay) overlay.style.display = 'none';
  document.body.style.overflow = '';
}

// ============ App 壳 / 远程加载专属逻辑 ============
// 两种远程模式：
// ① Capacitor 云壳：URL 带 ?shell=1.0.0 参数
// ② 公共 CDN 加载（jsDelivr）：内容实时来自 claw-web 仓库，刷新即更新
function setupAppShell(){
  var sp = new URLSearchParams(location.search);
  var shellV = sp.get('shell');
  var isCdn = location.hostname.indexOf('jsdelivr') >= 0;
  var isRemote = !!shellV || isCdn;
  if (!isRemote) return;                       // 普通浏览器本地打开不触发
  document.body.classList.add('app-shell');
  var footer = document.querySelector('.site-footer span');
  if (footer) footer.textContent = 'App 模式 · 内容实时同步云端，老师更新后刷新即生效';
  var brand = document.querySelector('.brand');
  if (brand && !document.getElementById('app-badge')) {
    var b = document.createElement('span');
    b.id = 'app-badge'; b.className = 'app-badge';
    b.textContent = isCdn ? 'App · 实时同步' : 'App · 实时云端';
    brand.appendChild(b);
  }
  // 注：已停用自动更新横幅（不再从远程 apkUrl 拉取安装包），
  // 避免误导用户装回公开仓的旧版本。所有更新统一走本机覆盖安装最新 APK。
}
function cmpVer(a, b){
  var pa = String(a).split('.').map(Number);
  var pb = String(b).split('.').map(Number);
  var n = Math.max(pa.length, pb.length);
  for (var i=0;i<n;i++){
    var x = pa[i]||0, y = pb[i]||0;
    if (x>y) return 1; if (x<y) return -1;
  }
  return 0;
}
function showUpdateBanner(d){
  if (document.getElementById('app-update-banner')) return;
  var bar = document.createElement('div');
  bar.id = 'app-update-banner'; bar.className = 'app-update-banner';
  bar.appendChild(document.createTextNode('发现新版本 v' + d.appVersion));
  if (d.note) bar.appendChild(document.createTextNode('：' + d.note));
  var btn = document.createElement('a');
  btn.className = 'aub-btn'; btn.textContent = '更新';
  btn.href = d.apkUrl || '#'; btn.target = '_blank'; btn.rel = 'noopener';
  var close = document.createElement('span');
  close.className = 'aub-close'; close.textContent = '×'; close.title = '关闭';
  close.onclick = function(){ bar.remove(); };
  bar.appendChild(btn); bar.appendChild(close);
  document.body.appendChild(bar);
}

function initLngPicker(){
  const sel = document.getElementById('bazi-longitude');
  const disp = document.getElementById('bazi-longitude-disp');
  const mask = document.getElementById('lng-picker-mask');
  const provBox = document.getElementById('lng-prov');
  const locBox = document.getElementById('lng-loc');
  const sheet = document.getElementById('lng-picker-sheet');
  if (!sel || !disp || !mask || !provBox || !locBox || !sheet) return;
  const DATA = (typeof CITY_DATA === 'object' && CITY_DATA) ? CITY_DATA : null;

  let curName = '';                                   // 已选地名（空=未选，显示占位）
  let curProv = DATA ? Object.keys(DATA)[0] : '';     // 当前省

  const shortProv = (p)=> p
    .replace('内蒙古自治区','内蒙古').replace('广西壮族自治区','广西').replace('西藏自治区','西藏')
    .replace('宁夏回族自治区','宁夏').replace('新疆维吾尔自治区','新疆').replace('香港特别行政区','香港')
    .replace('澳门特别行政区','澳门').replace(/(省|市)$/,'');

  const syncDisp = ()=>{
    const t = curName ? (curName + ' E' + sel.value + '°') : '选择出生地';
    disp.textContent = t;
    const dp = document.getElementById('dp-lng-disp'); if (dp) dp.textContent = t;
  };
  syncDisp();

  function buildProv(){
    provBox.innerHTML = '';
    Object.keys(DATA).forEach((p)=>{
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'lng-prov-item' + (p === curProv ? ' sel' : '');
      b.textContent = shortProv(p);
      b.addEventListener('click', ()=>{ if (curProv !== p){ curProv = p; buildProv(); buildLoc(); } });
      provBox.appendChild(b);
    });
  }
  function buildLoc(){
    locBox.innerHTML = '';
    const list = DATA[curProv] || [];
    list.forEach((row)=>{
      const name = row[0], lng = row[1];
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'lng-loc-item' + (curName === name && parseFloat(sel.value) === lng ? ' sel' : '');
      b.textContent = name + ' E' + lng + '°';
      // 选择即返回：点地名直接选中并关闭（出生地为单一选择）
      b.addEventListener('click', ()=>{
        let opt = sel.querySelector('option[value="' + lng + '"]');
        if (!opt){ opt = document.createElement('option'); opt.value = lng; opt.textContent = name; sel.appendChild(opt); }
        sel.value = lng; curName = name; syncDisp(); hide();
      });
      locBox.appendChild(b);
    });
  }

  // 出生地弹层居中显示（弹层较窄，屏幕正中更稳，避免贴顶部被状态栏遮挡）
  function positionLngSheet(){
    const sw = sheet.offsetWidth || 300;
    const sh = sheet.offsetHeight || 360;
    const vw = window.innerWidth, vh = window.innerHeight;
    // 顶部安全间距：避开手机状态栏（时间/电量）。优先读原生注入的 --safe-top，无则回退 32px
    let safeTop = 32;
    try { const st = getComputedStyle(document.documentElement).getPropertyValue('--safe-top'); if (st){ const v = parseFloat(st); if (!isNaN(v)) safeTop = Math.max(safeTop, v); } } catch(e){}
    let left = Math.max(8, Math.min(vw - sw - 8, (vw - sw) / 2));
    let top = Math.max(safeTop, Math.min(vh - sh - 8, (vh - sh) / 2));
    sheet.style.left = left + 'px';
    sheet.style.top = top + 'px';
  }

  function openLng(anchor){
    buildProv(); buildLoc();
    mask.hidden = false;
    requestAnimationFrame(()=>{ positionLngSheet(anchor || disp); });
  }
  function hide(){ mask.hidden = true; }

  // 八字页与滚轮内“出生地”都直接打开并就近定位
  disp.addEventListener('click', ()=> openLng(disp));
  const dpLng = document.getElementById('dp-lng-disp');
  if (dpLng) dpLng.addEventListener('click', ()=> openLng(dpLng));
  mask.addEventListener('click', (e)=>{ if (e.target === mask) hide(); });
  if (!DATA) { /* 无数据则退化为占位，不崩溃 */ }
}

// 兼容DOMContentLoaded 已提前触发的环境（部分预览器异步注入脚本）
function markOtaReady(){
  try {
    var cap = window.Capacitor;
    var up = cap && cap.Plugins && cap.Plugins.CapacitorUpdater;
    if (up && typeof up.notifyAppReady === 'function') up.notifyAppReady();
  } catch (e) {}
}
// f0f87c1-32：底部显示当前 OTA 版本（取 buildHash），方便用户确认是否拉到新版
function showOtaVer(){
  try{
    fetch('version.json', {cache:'no-store'}).then(function(r){return r.ok?r.json():null;}).then(function(j){
      var v = (j && (j.buildHash || j.version)) || 'unknown';
      var b = document.createElement('div');
      b.className = 'ota-ver-badge';
      b.id = 'ota-ver-badge';
      b.textContent = 'v ' + v;
      b.title = '当前 OTA 版本：' + v + '\n若非 f0f87c1-32 请在 Android 设置→应用→Claw→存储→清除缓存后重启 App';
      document.body.appendChild(b);
    }).catch(function(){});
  }catch(e){}
}
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initApp);
  document.addEventListener('DOMContentLoaded', setupAppShell);
  document.addEventListener('DOMContentLoaded', markOtaReady);
  document.addEventListener('DOMContentLoaded', showOtaVer);
} else {
  initApp();
  setupAppShell();
  markOtaReady();
  showOtaVer();
}
