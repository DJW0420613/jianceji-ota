/* ===================================================================
 * reverse-core.js — 四柱反推核心算法（UMD）
 * 浏览器（挂到 window.BaziReverse）/ Node / 小程序（module.exports）通用。
 * 不依赖任何全局 calendar，calendar 以参数传入，保证与 computeBazi 的排盘
 * 逻辑完全一致（含「早晚子时」对日柱的 dayShift 处理）。
 *
 * 说明：年柱以「春节」为界（与 calendar.solar2lunar 的 gzYear 一致），
 *       而非「立春」。这样四柱反推与正向排盘严格互逆。
 * =================================================================== */
(function (root, factory) {
  if (typeof module !== 'undefined' && module.exports) module.exports = factory();
  else root.BaziReverse = factory();
})(typeof self !== 'undefined' ? self : this, function () {

  const STEMS   = ['甲','乙','丙','丁','戊','己','庚','辛','壬','癸'];
  const BRANCHES= ['子','丑','寅','卯','辰','巳','午','未','申','酉','戌','亥'];
  const DAY_STEM_ZI = {甲:0,己:0,乙:2,庚:2,丙:4,辛:4,丁:6,壬:6,戊:8,癸:8};
  const GZ_60   = Array.from({length:60}, (_,k)=> STEMS[k%10] + BRANCHES[k%12]);
  const ALL_GZ  = new Set(GZ_60);

  // 时辰（12 地支）对应 24 小时：子时跨 23:00–00:59
  const SHICHEN = ['子时','丑时','寅时','卯时','辰时','巳时','午时','未时','申时','酉时','戌时','亥时'];

  function hourBranch(h){ if (h === 23) return 0; return Math.floor((h + 1) / 2); }
  function hourShichen(h){
    let br; if (h === 23) br = 0; else br = Math.floor((h + 1) / 2);
    return SHICHEN[br];
  }
  // 由（已考虑早晚子时的）公历日期与小时，求四柱。与 computeBazi 完全一致。
  function fourPillars(sy, sm, sd, h, ziType, calendar){
    let dayShift = 0, useH = h;
    if (ziType === 'traditional' && h === 23){ dayShift = 1; useH = 0; }
    const obj = calendar.solar2lunar(sy, sm, sd + dayShift);
    const yearGZ = obj.gzYear, monthGZ = obj.gzMonth, dayGZ = obj.gzDay;
    const dayStem = dayGZ[0];
    const br = hourBranch(useH);
    const hrStem = (DAY_STEM_ZI[dayStem] + br) % 10;
    const hourGZ = STEMS[hrStem] + BRANCHES[br];
    return { yearGZ, monthGZ, dayGZ, hourGZ, dayStem };
  }
  // 次日的农历对象（用于夜子时取次日日干）
  function nextObj(y, m, d, dim, calendar){
    if (d < dim) return calendar.solar2lunar(y, m, d + 1);
    if (m < 12) return calendar.solar2lunar(y, m + 1, 1);
    return calendar.solar2lunar(y + 1, 1, 1);
  }

  /* targets: { year, month, day, hour } 各柱干支字符串或 null（null=不限）
   * opts: { ys, ye, ziType:'modern'|'traditional', cap, displayCap }
   * 返回 { results:[{y,m,d,hour,shifted}], total, capped, error }
   *   results 仅含前 displayCap 条；total 为实际命中总数（可能 > displayCap）。
   */
  function reverseBazi(targets, opts, calendar){
    const ys0 = opts.ys, ye0 = opts.ye;
    const ziType = opts.ziType === 'traditional' ? 'traditional' : 'modern';
    const CAP = typeof opts.cap === 'number' ? opts.cap : 2000;
    const DISPLAY_CAP = typeof opts.displayCap === 'number' ? opts.displayCap : 500;
    const provided = [targets.year, targets.month, targets.day, targets.hour].filter(Boolean).length;
    if (provided === 0) return { results: [], total: 0, capped: false, error: 'empty' };

    const results = [];
    let done = false;
    for (let y = ys0; y <= ye0 && !done; y++){
      for (let m = 1; m <= 12 && !done; m++){
        const dim = new Date(y, m, 0).getDate();
        for (let d = 1; d <= dim && !done; d++){
          const oToday = calendar.solar2lunar(y, m, d);
          // 不归子时（现代 / 传统非 23 点）筛查：用当日干支
          const fToday = (!targets.year || oToday.gzYear === targets.year)
                      && (!targets.month || oToday.gzMonth === targets.month)
                      && (!targets.day || oToday.gzDay === targets.day);

          if (!targets.hour){
            if (fToday) results.push({ y, m, d, hour: null, shifted: false });
            if (results.length > CAP) done = true;
            continue;
          }

          // 当日日干推断时柱（h=23 在传统下改由下方「夜子时归次日」分支处理）
          if (fToday){
            const stem = oToday.gzDay[0];
            const lastH = (ziType === 'traditional') ? 22 : 23;
            for (let h = 0; h <= lastH; h++){
              const br = hourBranch(h);
              const hrStem = (DAY_STEM_ZI[stem] + br) % 10;
              const hg = STEMS[hrStem] + BRANCHES[br];
              if (hg === targets.hour){
                results.push({ y, m, d, hour: h, shifted: false });
                if (results.length > CAP) { done = true; break; }
              }
            }
            if (done) break;
          }

          // 夜子时归次日：仅传统模式且给定时柱时。年/月/日柱取次日，时柱为「子」
          if (ziType === 'traditional'){
            const oTom = nextObj(y, m, d, dim, calendar);
            const fTom = (!targets.year || oTom.gzYear === targets.year)
                      && (!targets.month || oTom.gzMonth === targets.month)
                      && (!targets.day || oTom.gzDay === targets.day);
            if (fTom){
              const stem = oTom.gzDay[0];
              const hg = STEMS[DAY_STEM_ZI[stem] % 10] + BRANCHES[0]; // 子时
              if (hg === targets.hour){
                results.push({ y, m, d, hour: 23, shifted: true });
                if (results.length > CAP) done = true;
              }
            }
          }
        }
        if (results.length > CAP) done = true;
      }
      if (results.length > CAP) done = true;
    }
  const capped = results.length > CAP;
  return { results: results.slice(0, DISPLAY_CAP), total: results.length, capped, error: null };
  }

  return { STEMS, BRANCHES, GZ_60, ALL_GZ, hourBranch, hourShichen, fourPillars, reverseBazi };
});
