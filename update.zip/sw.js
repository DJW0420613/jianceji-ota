// Claw Service Worker
// 策略：network-first。Capacitor 内置资源经本地 http server 提供，始终在线，
// 故每次优先取网络最新文件，失败再回退缓存/旧页面。这样真机更新立即生效，
// 不再出现「改了源码但 SW 缓存吐旧样式」的钉子户问题。
const CACHE = 'claw-vc5b7159';
const ASSETS = [
  './',
  './index.html',
  './app.js',
  './styles.css',
  './calendar.js',
  './reverse-core.js',
  './strokes-data.js',
  './manifest.json',
  './icon-192.png',
  './icon-512.png'
];

self.addEventListener('install', function (e) {
  // 直接激活新 SW，不打断用户
  e.waitUntil(self.skipWaiting());
});

self.addEventListener('activate', function (e) {
  e.waitUntil(self.clients.claim());
});

self.addEventListener('fetch', function (e) {
  if (e.request.method !== 'GET') return;
  var u = new URL(e.request.url);
  // 排版覆盖层 theme.css 永远走网络，保证保存后刷新立即生效
  if (u.pathname.indexOf('theme.css') !== -1) {
    e.respondWith(fetch(e.request));
    return;
  }
  // network-first：优先取最新，离线/失败再回退缓存
  e.respondWith(
    fetch(e.request).then(function (resp) {
      // 顺手把成功响应写进缓存，作为离线兜底（仍以网络优先）
      if (resp && resp.status === 200 && resp.type === 'basic') {
        var copy = resp.clone();
        caches.open(CACHE).then(function (c) { c.put(e.request, copy); });
      }
      return resp;
    }).catch(function () {
      return caches.match(e.request).then(function (cached) {
        return cached || caches.match('./index.html');
      });
    })
  );
});
